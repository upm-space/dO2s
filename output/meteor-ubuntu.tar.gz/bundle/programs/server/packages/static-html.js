(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['static-html'] = {};

})();
