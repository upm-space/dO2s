(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var EJSON = Package.ejson.EJSON;
var EventEmitter = Package['raix:eventemitter'].EventEmitter;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var Collection2;

var require = meteorInstall({"node_modules":{"meteor":{"aldeed:collection2-core":{"collection2.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/aldeed_collection2-core/collection2.js                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let EventEmitter;
module.watch(require("meteor/raix:eventemitter"), {
  EventEmitter(v) {
    EventEmitter = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let EJSON;
module.watch(require("meteor/ejson"), {
  EJSON(v) {
    EJSON = v;
  }

}, 2);

let _;

module.watch(require("meteor/underscore"), {
  _(v) {
    _ = v;
  }

}, 3);
let checkNpmVersions;
module.watch(require("meteor/tmeasday:check-npm-versions"), {
  checkNpmVersions(v) {
    checkNpmVersions = v;
  }

}, 4);
checkNpmVersions({
  'simpl-schema': '0.x.x'
}, 'aldeed:meteor-collection2-core');

const SimpleSchema = require('simpl-schema').default; // Exported only for listening to events


const Collection2 = new EventEmitter(); /**
                                         * Mongo.Collection.prototype.attachSchema
                                         * @param {SimpleSchema|Object} ss - SimpleSchema instance or a schema definition object
                                         *    from which to create a new SimpleSchema instance
                                         * @param {Object} [options]
                                         * @param {Boolean} [options.transform=false] Set to `true` if your document must be passed
                                         *    through the collection's transform to properly validate.
                                         * @param {Boolean} [options.replace=false] Set to `true` to replace any existing schema instead of combining
                                         * @return {undefined}
                                         *
                                         * Use this method to attach a schema to a collection created by another package,
                                         * such as Meteor.users. It is most likely unsafe to call this method more than
                                         * once for a single collection, or to call this for a collection that had a
                                         * schema object passed to its constructor.
                                         */

Mongo.Collection.prototype.attachSchema = function c2AttachSchema(ss, options) {
  var self = this;
  options = options || {}; // Allow passing just the schema object

  if (!(ss instanceof SimpleSchema)) {
    ss = new SimpleSchema(ss);
  }

  self._c2 = self._c2 || {}; // If we've already attached one schema, we combine both into a new schema unless options.replace is `true`

  if (self._c2._simpleSchema && options.replace !== true) {
    if (ss.version >= 2) {
      var newSS = new SimpleSchema(self._c2._simpleSchema);
      newSS.extend(ss);
      ss = newSS;
    } else {
      ss = new SimpleSchema([self._c2._simpleSchema, ss]);
    }
  }

  var selector = options.selector;

  function attachTo(obj) {
    if (typeof selector === "object") {
      // Index of existing schema with identical selector
      var schemaIndex = -1; // we need an array to hold multiple schemas

      obj._c2._simpleSchemas = obj._c2._simpleSchemas || []; // Loop through existing schemas with selectors

      obj._c2._simpleSchemas.forEach(function (schema, index) {
        // if we find a schema with an identical selector, save it's index
        if (_.isEqual(schema.selector, selector)) {
          schemaIndex = index;
        }
      });

      if (schemaIndex === -1) {
        // We didn't find the schema in our array - push it into the array
        obj._c2._simpleSchemas.push({
          schema: new SimpleSchema(ss),
          selector: selector
        });
      } else {
        // We found a schema with an identical selector in our array,
        if (options.replace !== true) {
          // Merge with existing schema unless options.replace is `true`
          if (obj._c2._simpleSchemas[schemaIndex].schema.version >= 2) {
            obj._c2._simpleSchemas[schemaIndex].schema.extend(ss);
          } else {
            obj._c2._simpleSchemas[schemaIndex].schema = new SimpleSchema([obj._c2._simpleSchemas[schemaIndex].schema, ss]);
          }
        } else {
          // If options.repalce is `true` replace existing schema with new schema
          obj._c2._simpleSchemas[schemaIndex].schema = ss;
        }
      } // Remove existing schemas without selector


      delete obj._c2._simpleSchema;
    } else {
      // Track the schema in the collection
      obj._c2._simpleSchema = ss; // Remove existing schemas with selector

      delete obj._c2._simpleSchemas;
    }
  }

  attachTo(self); // Attach the schema to the underlying LocalCollection, too

  if (self._collection instanceof LocalCollection) {
    self._collection._c2 = self._collection._c2 || {};
    attachTo(self._collection);
  }

  defineDeny(self, options);
  keepInsecure(self);
  Collection2.emit('schema.attached', self, ss, options);
};

_.each([Mongo.Collection, LocalCollection], function (obj) {
  /**
   * simpleSchema
   * @description function detect the correct schema by given params. If it
   * detect multi-schema presence in `self`, then it made an attempt to find a
   * `selector` in args
   * @param {Object} doc - It could be <update> on update/upsert or document
   * itself on insert/remove
   * @param {Object} [options] - It could be <update> on update/upsert etc
   * @param {Object} [query] - it could be <query> on update/upsert
   * @return {Object} Schema
   */obj.prototype.simpleSchema = function (doc, options, query) {
    if (!this._c2) return null;
    if (this._c2._simpleSchema) return this._c2._simpleSchema;
    var schemas = this._c2._simpleSchemas;

    if (schemas && schemas.length > 0) {
      if (!doc) throw new Error('collection.simpleSchema() requires doc argument when there are multiple schemas');
      var schema, selector, target;

      for (var i = 0; i < schemas.length; i++) {
        schema = schemas[i];
        selector = Object.keys(schema.selector)[0]; // We will set this to undefined because in theory you might want to select
        // on a null value.

        target = undefined; // here we are looking for selector in different places
        // $set should have more priority here

        if (doc.$set && typeof doc.$set[selector] !== 'undefined') {
          target = doc.$set[selector];
        } else if (typeof doc[selector] !== 'undefined') {
          target = doc[selector];
        } else if (options && options.selector) {
          target = options.selector[selector];
        } else if (query && query[selector]) {
          // on upsert/update operations
          target = query[selector];
        } // we need to compare given selector with doc property or option to
        // find right schema


        if (target !== undefined && target === schema.selector[selector]) {
          return schema.schema;
        }
      }
    }

    return null;
  };
}); // Wrap DB write operation methods


_.each(['insert', 'update'], function (methodName) {
  var _super = Mongo.Collection.prototype[methodName];

  Mongo.Collection.prototype[methodName] = function () {
    var self = this,
        options,
        args = _.toArray(arguments);

    options = methodName === "insert" ? args[1] : args[2]; // Support missing options arg

    if (!options || typeof options === "function") {
      options = {};
    }

    if (self._c2 && options.bypassCollection2 !== true) {
      var userId = null;

      try {
        // https://github.com/aldeed/meteor-collection2/issues/175
        userId = Meteor.userId();
      } catch (err) {}

      args = doValidate.call(self, methodName, args, Meteor.isServer || self._connection === null, // getAutoValues
      userId, Meteor.isServer // isFromTrustedCode
      );

      if (!args) {
        // doValidate already called the callback or threw the error so we're done.
        // But insert should always return an ID to match core behavior.
        return methodName === "insert" ? self._makeNewID() : undefined;
      }
    } else {
      // We still need to adjust args because insert does not take options
      if (methodName === "insert" && typeof args[1] !== 'function') args.splice(1, 1);
    }

    return _super.apply(self, args);
  };
}); /*
     * Private
     */

function doValidate(type, args, getAutoValues, userId, isFromTrustedCode) {
  var self = this,
      doc,
      callback,
      error,
      options,
      isUpsert,
      selector,
      last,
      hasCallback;

  if (!args.length) {
    throw new Error(type + " requires an argument");
  } // Gather arguments and cache the selector


  if (type === "insert") {
    doc = args[0];
    options = args[1];
    callback = args[2]; // The real insert doesn't take options

    if (typeof options === "function") {
      args = [doc, options];
    } else if (typeof callback === "function") {
      args = [doc, callback];
    } else {
      args = [doc];
    }
  } else if (type === "update") {
    selector = args[0];
    doc = args[1];
    options = args[2];
    callback = args[3];
  } else {
    throw new Error("invalid type argument");
  }

  var validatedObjectWasInitiallyEmpty = _.isEmpty(doc); // Support missing options arg


  if (!callback && typeof options === "function") {
    callback = options;
    options = {};
  }

  options = options || {};
  last = args.length - 1;
  hasCallback = typeof args[last] === 'function'; // If update was called with upsert:true, flag as an upsert

  isUpsert = type === "update" && options.upsert === true; // we need to pass `doc` and `options` to `simpleSchema` method, that's why
  // schema declaration moved here

  var schema = self.simpleSchema(doc, options, selector);
  var isLocalCollection = self._connection === null; // On the server and for local collections, we allow passing `getAutoValues: false` to disable autoValue functions

  if ((Meteor.isServer || isLocalCollection) && options.getAutoValues === false) {
    getAutoValues = false;
  } // Determine validation context


  var validationContext = options.validationContext;

  if (validationContext) {
    if (typeof validationContext === 'string') {
      validationContext = schema.namedContext(validationContext);
    }
  } else {
    validationContext = schema.namedContext();
  } // Add a default callback function if we're on the client and no callback was given


  if (Meteor.isClient && !callback) {
    // Client can't block, so it can't report errors by exception,
    // only by callback. If they forget the callback, give them a
    // default one that logs the error, so they aren't totally
    // baffled if their writes don't work because their database is
    // down.
    callback = function (err) {
      if (err) {
        Meteor._debug(type + " failed: " + (err.reason || err.stack));
      }
    };
  } // If client validation is fine or is skipped but then something
  // is found to be invalid on the server, we get that error back
  // as a special Meteor.Error that we need to parse.


  if (Meteor.isClient && hasCallback) {
    callback = args[last] = wrapCallbackForParsingServerErrors(validationContext, callback);
  }

  var schemaAllowsId = schema.allowsKey("_id");

  if (type === "insert" && !doc._id && schemaAllowsId) {
    doc._id = self._makeNewID();
  } // Get the docId for passing in the autoValue/custom context


  var docId;

  if (type === 'insert') {
    docId = doc._id; // might be undefined
  } else if (type === "update" && selector) {
    docId = typeof selector === 'string' || selector instanceof Mongo.ObjectID ? selector : selector._id;
  } // If _id has already been added, remove it temporarily if it's
  // not explicitly defined in the schema.


  var cachedId;

  if (doc._id && !schemaAllowsId) {
    cachedId = doc._id;
    delete doc._id;
  }

  function doClean(docToClean, getAutoValues, filter, autoConvert, removeEmptyStrings, trimStrings) {
    // Clean the doc/modifier in place
    schema.clean(docToClean, {
      mutate: true,
      filter: filter,
      autoConvert: autoConvert,
      getAutoValues: getAutoValues,
      isModifier: type !== "insert",
      removeEmptyStrings: removeEmptyStrings,
      trimStrings: trimStrings,
      extendAutoValueContext: _.extend({
        isInsert: type === "insert",
        isUpdate: type === "update" && options.upsert !== true,
        isUpsert: isUpsert,
        userId: userId,
        isFromTrustedCode: isFromTrustedCode,
        docId: docId,
        isLocalCollection: isLocalCollection
      }, options.extendAutoValueContext || {})
    });
  } // Preliminary cleaning on both client and server. On the server and for local
  // collections, automatic values will also be set at this point.


  doClean(doc, getAutoValues, options.filter !== false, options.autoConvert !== false, options.removeEmptyStrings !== false, options.trimStrings !== false); // We clone before validating because in some cases we need to adjust the
  // object a bit before validating it. If we adjusted `doc` itself, our
  // changes would persist into the database.

  var docToValidate = {};

  for (var prop in doc) {
    // We omit prototype properties when cloning because they will not be valid
    // and mongo omits them when saving to the database anyway.
    if (Object.prototype.hasOwnProperty.call(doc, prop)) {
      docToValidate[prop] = doc[prop];
    }
  } // On the server, upserts are possible; SimpleSchema handles upserts pretty
  // well by default, but it will not know about the fields in the selector,
  // which are also stored in the database if an insert is performed. So we
  // will allow these fields to be considered for validation by adding them
  // to the $set in the modifier. This is no doubt prone to errors, but there
  // probably isn't any better way right now.


  if (Meteor.isServer && isUpsert && _.isObject(selector)) {
    var set = docToValidate.$set || {}; // If selector uses $and format, convert to plain object selector

    if (Array.isArray(selector.$and)) {
      const plainSelector = {};
      selector.$and.forEach(sel => {
        _.extend(plainSelector, sel);
      });
      docToValidate.$set = plainSelector;
    } else {
      docToValidate.$set = _.clone(selector);
    }

    if (!schemaAllowsId) delete docToValidate.$set._id;

    _.extend(docToValidate.$set, set);
  } // Set automatic values for validation on the client.
  // On the server, we already updated doc with auto values, but on the client,
  // we will add them to docToValidate for validation purposes only.
  // This is because we want all actual values generated on the server.


  if (Meteor.isClient && !isLocalCollection) {
    doClean(docToValidate, true, false, false, false, false);
  } // XXX Maybe move this into SimpleSchema


  if (!validatedObjectWasInitiallyEmpty && _.isEmpty(docToValidate)) {
    throw new Error('After filtering out keys not in the schema, your ' + (type === 'update' ? 'modifier' : 'object') + ' is now empty');
  } // Validate doc


  var isValid;

  if (options.validate === false) {
    isValid = true;
  } else {
    isValid = validationContext.validate(docToValidate, {
      modifier: type === "update" || type === "upsert",
      upsert: isUpsert,
      extendedCustomContext: _.extend({
        isInsert: type === "insert",
        isUpdate: type === "update" && options.upsert !== true,
        isUpsert: isUpsert,
        userId: userId,
        isFromTrustedCode: isFromTrustedCode,
        docId: docId,
        isLocalCollection: isLocalCollection
      }, options.extendedCustomContext || {})
    });
  }

  if (isValid) {
    // Add the ID back
    if (cachedId) {
      doc._id = cachedId;
    } // Update the args to reflect the cleaned doc
    // XXX not sure this is necessary since we mutate


    if (type === "insert") {
      args[0] = doc;
    } else {
      args[1] = doc;
    } // If callback, set invalidKey when we get a mongo unique error


    if (Meteor.isServer && hasCallback) {
      args[last] = wrapCallbackForParsingMongoValidationErrors(validationContext, args[last]);
    }

    return args;
  } else {
    error = getErrorObject(validationContext);

    if (callback) {
      // insert/update/upsert pass `false` when there's an error, so we do that
      callback(error, false);
    } else {
      throw error;
    }
  }
}

function getErrorObject(context) {
  var message;
  var invalidKeys = typeof context.validationErrors === 'function' ? context.validationErrors() : context.invalidKeys();

  if (invalidKeys.length) {
    message = context.keyErrorMessage(invalidKeys[0].name);
  } else {
    message = "Failed validation";
  }

  var error = new Error(message);
  error.invalidKeys = invalidKeys;
  error.validationContext = context; // If on the server, we add a sanitized error, too, in case we're
  // called from a method.

  if (Meteor.isServer) {
    error.sanitizedError = new Meteor.Error(400, message, EJSON.stringify(error.invalidKeys));
  }

  return error;
}

function addUniqueError(context, errorMessage) {
  var name = errorMessage.split('c2_')[1].split(' ')[0];
  var val = errorMessage.split('dup key:')[1].split('"')[1];
  var addValidationErrorsPropName = typeof context.addValidationErrors === 'function' ? 'addValidationErrors' : 'addInvalidKeys';
  context[addValidationErrorsPropName]([{
    name: name,
    type: 'notUnique',
    value: val
  }]);
}

function wrapCallbackForParsingMongoValidationErrors(validationContext, cb) {
  return function wrappedCallbackForParsingMongoValidationErrors(error) {
    var args = _.toArray(arguments);

    if (error && (error.name === "MongoError" && error.code === 11001 || error.message.indexOf('MongoError: E11000' !== -1)) && error.message.indexOf('c2_') !== -1) {
      addUniqueError(validationContext, error.message);
      args[0] = getErrorObject(validationContext);
    }

    return cb.apply(this, args);
  };
}

function wrapCallbackForParsingServerErrors(validationContext, cb) {
  var addValidationErrorsPropName = typeof validationContext.addValidationErrors === 'function' ? 'addValidationErrors' : 'addInvalidKeys';
  return function wrappedCallbackForParsingServerErrors(error) {
    var args = _.toArray(arguments); // Handle our own validation errors


    if (error instanceof Meteor.Error && error.error === 400 && error.reason === "INVALID" && typeof error.details === "string") {
      var invalidKeysFromServer = EJSON.parse(error.details);
      validationContext[addValidationErrorsPropName](invalidKeysFromServer);
      args[0] = getErrorObject(validationContext);
    } // Handle Mongo unique index errors, which are forwarded to the client as 409 errors
    else if (error instanceof Meteor.Error && error.error === 409 && error.reason && error.reason.indexOf('E11000') !== -1 && error.reason.indexOf('c2_') !== -1) {
        addUniqueError(validationContext, error.reason);
        args[0] = getErrorObject(validationContext);
      }

    return cb.apply(this, args);
  };
}

var alreadyInsecured = {};

function keepInsecure(c) {
  // If insecure package is in use, we need to add allow rules that return
  // true. Otherwise, it would seemingly turn off insecure mode.
  if (Package && Package.insecure && !alreadyInsecured[c._name]) {
    c.allow({
      insert: function () {
        return true;
      },
      update: function () {
        return true;
      },
      remove: function () {
        return true;
      },
      fetch: [],
      transform: null
    });
    alreadyInsecured[c._name] = true;
  } // If insecure package is NOT in use, then adding the two deny functions
  // does not have any effect on the main app's security paradigm. The
  // user will still be required to add at least one allow function of her
  // own for each operation for this collection. And the user may still add
  // additional deny functions, but does not have to.

}

var alreadyDefined = {};

function defineDeny(c, options) {
  if (!alreadyDefined[c._name]) {
    var isLocalCollection = c._connection === null; // First define deny functions to extend doc with the results of clean
    // and autovalues. This must be done with "transform: null" or we would be
    // extending a clone of doc and therefore have no effect.

    c.deny({
      insert: function (userId, doc) {
        // Referenced doc is cleaned in place
        c.simpleSchema(doc).clean(doc, {
          mutate: true,
          isModifier: false,
          // We don't do these here because they are done on the client if desired
          filter: false,
          autoConvert: false,
          removeEmptyStrings: false,
          trimStrings: false,
          extendAutoValueContext: {
            isInsert: true,
            isUpdate: false,
            isUpsert: false,
            userId: userId,
            isFromTrustedCode: false,
            docId: doc._id,
            isLocalCollection: isLocalCollection
          }
        });
        return false;
      },
      update: function (userId, doc, fields, modifier) {
        // Referenced modifier is cleaned in place
        c.simpleSchema(modifier).clean(modifier, {
          mutate: true,
          isModifier: true,
          // We don't do these here because they are done on the client if desired
          filter: false,
          autoConvert: false,
          removeEmptyStrings: false,
          trimStrings: false,
          extendAutoValueContext: {
            isInsert: false,
            isUpdate: true,
            isUpsert: false,
            userId: userId,
            isFromTrustedCode: false,
            docId: doc && doc._id,
            isLocalCollection: isLocalCollection
          }
        });
        return false;
      },
      fetch: ['_id'],
      transform: null
    }); // Second define deny functions to validate again on the server
    // for client-initiated inserts and updates. These should be
    // called after the clean/autovalue functions since we're adding
    // them after. These must *not* have "transform: null" if options.transform is true because
    // we need to pass the doc through any transforms to be sure
    // that custom types are properly recognized for type validation.

    c.deny(_.extend({
      insert: function (userId, doc) {
        // We pass the false options because we will have done them on client if desired
        doValidate.call(c, "insert", [doc, {
          trimStrings: false,
          removeEmptyStrings: false,
          filter: false,
          autoConvert: false
        }, function (error) {
          if (error) {
            throw new Meteor.Error(400, 'INVALID', EJSON.stringify(error.invalidKeys));
          }
        }], false, // getAutoValues
        userId, false // isFromTrustedCode
        );
        return false;
      },
      update: function (userId, doc, fields, modifier) {
        // NOTE: This will never be an upsert because client-side upserts
        // are not allowed once you define allow/deny functions.
        // We pass the false options because we will have done them on client if desired
        doValidate.call(c, "update", [{
          _id: doc && doc._id
        }, modifier, {
          trimStrings: false,
          removeEmptyStrings: false,
          filter: false,
          autoConvert: false
        }, function (error) {
          if (error) {
            throw new Meteor.Error(400, 'INVALID', EJSON.stringify(error.invalidKeys));
          }
        }], false, // getAutoValues
        userId, false // isFromTrustedCode
        );
        return false;
      },
      fetch: ['_id']
    }, options.transform === true ? {} : {
      transform: null
    })); // note that we've already done this collection so that we don't do it again
    // if attachSchema is called again

    alreadyDefined[c._name] = true;
  }
}

module.exportDefault(Collection2);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("./node_modules/meteor/aldeed:collection2-core/collection2.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['aldeed:collection2-core'] = exports, {
  Collection2: Collection2
});

})();

//# sourceURL=meteor://💻app/packages/aldeed_collection2-core.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYWxkZWVkOmNvbGxlY3Rpb24yLWNvcmUvY29sbGVjdGlvbjIuanMiXSwibmFtZXMiOlsiRXZlbnRFbWl0dGVyIiwibW9kdWxlIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIk1ldGVvciIsIkVKU09OIiwiXyIsImNoZWNrTnBtVmVyc2lvbnMiLCJTaW1wbGVTY2hlbWEiLCJkZWZhdWx0IiwiQ29sbGVjdGlvbjIiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJwcm90b3R5cGUiLCJhdHRhY2hTY2hlbWEiLCJjMkF0dGFjaFNjaGVtYSIsInNzIiwib3B0aW9ucyIsInNlbGYiLCJfYzIiLCJfc2ltcGxlU2NoZW1hIiwicmVwbGFjZSIsInZlcnNpb24iLCJuZXdTUyIsImV4dGVuZCIsInNlbGVjdG9yIiwiYXR0YWNoVG8iLCJvYmoiLCJzY2hlbWFJbmRleCIsIl9zaW1wbGVTY2hlbWFzIiwiZm9yRWFjaCIsInNjaGVtYSIsImluZGV4IiwiaXNFcXVhbCIsInB1c2giLCJfY29sbGVjdGlvbiIsIkxvY2FsQ29sbGVjdGlvbiIsImRlZmluZURlbnkiLCJrZWVwSW5zZWN1cmUiLCJlbWl0IiwiZWFjaCIsInNpbXBsZVNjaGVtYSIsImRvYyIsInF1ZXJ5Iiwic2NoZW1hcyIsImxlbmd0aCIsIkVycm9yIiwidGFyZ2V0IiwiaSIsIk9iamVjdCIsImtleXMiLCJ1bmRlZmluZWQiLCIkc2V0IiwibWV0aG9kTmFtZSIsIl9zdXBlciIsImFyZ3MiLCJ0b0FycmF5IiwiYXJndW1lbnRzIiwiYnlwYXNzQ29sbGVjdGlvbjIiLCJ1c2VySWQiLCJlcnIiLCJkb1ZhbGlkYXRlIiwiY2FsbCIsImlzU2VydmVyIiwiX2Nvbm5lY3Rpb24iLCJfbWFrZU5ld0lEIiwic3BsaWNlIiwiYXBwbHkiLCJ0eXBlIiwiZ2V0QXV0b1ZhbHVlcyIsImlzRnJvbVRydXN0ZWRDb2RlIiwiY2FsbGJhY2siLCJlcnJvciIsImlzVXBzZXJ0IiwibGFzdCIsImhhc0NhbGxiYWNrIiwidmFsaWRhdGVkT2JqZWN0V2FzSW5pdGlhbGx5RW1wdHkiLCJpc0VtcHR5IiwidXBzZXJ0IiwiaXNMb2NhbENvbGxlY3Rpb24iLCJ2YWxpZGF0aW9uQ29udGV4dCIsIm5hbWVkQ29udGV4dCIsImlzQ2xpZW50IiwiX2RlYnVnIiwicmVhc29uIiwic3RhY2siLCJ3cmFwQ2FsbGJhY2tGb3JQYXJzaW5nU2VydmVyRXJyb3JzIiwic2NoZW1hQWxsb3dzSWQiLCJhbGxvd3NLZXkiLCJfaWQiLCJkb2NJZCIsIk9iamVjdElEIiwiY2FjaGVkSWQiLCJkb0NsZWFuIiwiZG9jVG9DbGVhbiIsImZpbHRlciIsImF1dG9Db252ZXJ0IiwicmVtb3ZlRW1wdHlTdHJpbmdzIiwidHJpbVN0cmluZ3MiLCJjbGVhbiIsIm11dGF0ZSIsImlzTW9kaWZpZXIiLCJleHRlbmRBdXRvVmFsdWVDb250ZXh0IiwiaXNJbnNlcnQiLCJpc1VwZGF0ZSIsImRvY1RvVmFsaWRhdGUiLCJwcm9wIiwiaGFzT3duUHJvcGVydHkiLCJpc09iamVjdCIsInNldCIsIkFycmF5IiwiaXNBcnJheSIsIiRhbmQiLCJwbGFpblNlbGVjdG9yIiwic2VsIiwiY2xvbmUiLCJpc1ZhbGlkIiwidmFsaWRhdGUiLCJtb2RpZmllciIsImV4dGVuZGVkQ3VzdG9tQ29udGV4dCIsIndyYXBDYWxsYmFja0ZvclBhcnNpbmdNb25nb1ZhbGlkYXRpb25FcnJvcnMiLCJnZXRFcnJvck9iamVjdCIsImNvbnRleHQiLCJtZXNzYWdlIiwiaW52YWxpZEtleXMiLCJ2YWxpZGF0aW9uRXJyb3JzIiwia2V5RXJyb3JNZXNzYWdlIiwibmFtZSIsInNhbml0aXplZEVycm9yIiwic3RyaW5naWZ5IiwiYWRkVW5pcXVlRXJyb3IiLCJlcnJvck1lc3NhZ2UiLCJzcGxpdCIsInZhbCIsImFkZFZhbGlkYXRpb25FcnJvcnNQcm9wTmFtZSIsImFkZFZhbGlkYXRpb25FcnJvcnMiLCJ2YWx1ZSIsImNiIiwid3JhcHBlZENhbGxiYWNrRm9yUGFyc2luZ01vbmdvVmFsaWRhdGlvbkVycm9ycyIsImNvZGUiLCJpbmRleE9mIiwid3JhcHBlZENhbGxiYWNrRm9yUGFyc2luZ1NlcnZlckVycm9ycyIsImRldGFpbHMiLCJpbnZhbGlkS2V5c0Zyb21TZXJ2ZXIiLCJwYXJzZSIsImFscmVhZHlJbnNlY3VyZWQiLCJjIiwiUGFja2FnZSIsImluc2VjdXJlIiwiX25hbWUiLCJhbGxvdyIsImluc2VydCIsInVwZGF0ZSIsInJlbW92ZSIsImZldGNoIiwidHJhbnNmb3JtIiwiYWxyZWFkeURlZmluZWQiLCJkZW55IiwiZmllbGRzIiwiZXhwb3J0RGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJQSxZQUFKO0FBQWlCQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDSCxlQUFhSSxDQUFiLEVBQWU7QUFBQ0osbUJBQWFJLENBQWI7QUFBZTs7QUFBaEMsQ0FBakQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSUMsTUFBSjtBQUFXSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNFLFNBQU9ELENBQVAsRUFBUztBQUFDQyxhQUFPRCxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlFLEtBQUo7QUFBVUwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRyxRQUFNRixDQUFOLEVBQVE7QUFBQ0UsWUFBTUYsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDs7QUFBNEQsSUFBSUcsQ0FBSjs7QUFBTU4sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG1CQUFSLENBQWIsRUFBMEM7QUFBQ0ksSUFBRUgsQ0FBRixFQUFJO0FBQUNHLFFBQUVILENBQUY7QUFBSTs7QUFBVixDQUExQyxFQUFzRCxDQUF0RDtBQUF5RCxJQUFJSSxnQkFBSjtBQUFxQlAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG9DQUFSLENBQWIsRUFBMkQ7QUFBQ0ssbUJBQWlCSixDQUFqQixFQUFtQjtBQUFDSSx1QkFBaUJKLENBQWpCO0FBQW1COztBQUF4QyxDQUEzRCxFQUFxRyxDQUFyRztBQU0zVUksaUJBQWlCO0FBQUUsa0JBQWdCO0FBQWxCLENBQWpCLEVBQThDLGdDQUE5Qzs7QUFFQSxNQUFNQyxlQUFlTixRQUFRLGNBQVIsRUFBd0JPLE9BQTdDLEMsQ0FFQTs7O0FBQ0EsTUFBTUMsY0FBYyxJQUFJWCxZQUFKLEVBQXBCLEMsQ0FFQTs7Ozs7Ozs7Ozs7Ozs7OztBQWVBWSxNQUFNQyxVQUFOLENBQWlCQyxTQUFqQixDQUEyQkMsWUFBM0IsR0FBMEMsU0FBU0MsY0FBVCxDQUF3QkMsRUFBeEIsRUFBNEJDLE9BQTVCLEVBQXFDO0FBQzdFLE1BQUlDLE9BQU8sSUFBWDtBQUNBRCxZQUFVQSxXQUFXLEVBQXJCLENBRjZFLENBSTdFOztBQUNBLE1BQUksRUFBRUQsY0FBY1IsWUFBaEIsQ0FBSixFQUFtQztBQUNqQ1EsU0FBSyxJQUFJUixZQUFKLENBQWlCUSxFQUFqQixDQUFMO0FBQ0Q7O0FBRURFLE9BQUtDLEdBQUwsR0FBV0QsS0FBS0MsR0FBTCxJQUFZLEVBQXZCLENBVDZFLENBVzdFOztBQUNBLE1BQUlELEtBQUtDLEdBQUwsQ0FBU0MsYUFBVCxJQUEwQkgsUUFBUUksT0FBUixLQUFvQixJQUFsRCxFQUF3RDtBQUN0RCxRQUFJTCxHQUFHTSxPQUFILElBQWMsQ0FBbEIsRUFBcUI7QUFDbkIsVUFBSUMsUUFBUSxJQUFJZixZQUFKLENBQWlCVSxLQUFLQyxHQUFMLENBQVNDLGFBQTFCLENBQVo7QUFDQUcsWUFBTUMsTUFBTixDQUFhUixFQUFiO0FBQ0FBLFdBQUtPLEtBQUw7QUFDRCxLQUpELE1BSU87QUFDTFAsV0FBSyxJQUFJUixZQUFKLENBQWlCLENBQUNVLEtBQUtDLEdBQUwsQ0FBU0MsYUFBVixFQUF5QkosRUFBekIsQ0FBakIsQ0FBTDtBQUNEO0FBQ0Y7O0FBRUQsTUFBSVMsV0FBV1IsUUFBUVEsUUFBdkI7O0FBRUEsV0FBU0MsUUFBVCxDQUFrQkMsR0FBbEIsRUFBdUI7QUFDckIsUUFBSSxPQUFPRixRQUFQLEtBQW9CLFFBQXhCLEVBQWtDO0FBQ2hDO0FBQ0EsVUFBSUcsY0FBYyxDQUFDLENBQW5CLENBRmdDLENBSWhDOztBQUNBRCxVQUFJUixHQUFKLENBQVFVLGNBQVIsR0FBeUJGLElBQUlSLEdBQUosQ0FBUVUsY0FBUixJQUEwQixFQUFuRCxDQUxnQyxDQU9oQzs7QUFDQUYsVUFBSVIsR0FBSixDQUFRVSxjQUFSLENBQXVCQyxPQUF2QixDQUErQixVQUFVQyxNQUFWLEVBQWtCQyxLQUFsQixFQUF5QjtBQUN0RDtBQUNBLFlBQUcxQixFQUFFMkIsT0FBRixDQUFVRixPQUFPTixRQUFqQixFQUEyQkEsUUFBM0IsQ0FBSCxFQUF5QztBQUN2Q0csd0JBQWNJLEtBQWQ7QUFDRDtBQUNGLE9BTEQ7O0FBTUEsVUFBSUosZ0JBQWdCLENBQUMsQ0FBckIsRUFBd0I7QUFDdEI7QUFDQUQsWUFBSVIsR0FBSixDQUFRVSxjQUFSLENBQXVCSyxJQUF2QixDQUE0QjtBQUMxQkgsa0JBQVEsSUFBSXZCLFlBQUosQ0FBaUJRLEVBQWpCLENBRGtCO0FBRTFCUyxvQkFBVUE7QUFGZ0IsU0FBNUI7QUFJRCxPQU5ELE1BTU87QUFDTDtBQUNBLFlBQUlSLFFBQVFJLE9BQVIsS0FBb0IsSUFBeEIsRUFBOEI7QUFDNUI7QUFDQSxjQUFJTSxJQUFJUixHQUFKLENBQVFVLGNBQVIsQ0FBdUJELFdBQXZCLEVBQW9DRyxNQUFwQyxDQUEyQ1QsT0FBM0MsSUFBc0QsQ0FBMUQsRUFBNkQ7QUFDM0RLLGdCQUFJUixHQUFKLENBQVFVLGNBQVIsQ0FBdUJELFdBQXZCLEVBQW9DRyxNQUFwQyxDQUEyQ1AsTUFBM0MsQ0FBa0RSLEVBQWxEO0FBQ0QsV0FGRCxNQUVPO0FBQ0xXLGdCQUFJUixHQUFKLENBQVFVLGNBQVIsQ0FBdUJELFdBQXZCLEVBQW9DRyxNQUFwQyxHQUE2QyxJQUFJdkIsWUFBSixDQUFpQixDQUFDbUIsSUFBSVIsR0FBSixDQUFRVSxjQUFSLENBQXVCRCxXQUF2QixFQUFvQ0csTUFBckMsRUFBNkNmLEVBQTdDLENBQWpCLENBQTdDO0FBQ0Q7QUFDRixTQVBELE1BT087QUFDTDtBQUNBVyxjQUFJUixHQUFKLENBQVFVLGNBQVIsQ0FBdUJELFdBQXZCLEVBQW9DRyxNQUFwQyxHQUE2Q2YsRUFBN0M7QUFDRDtBQUVGLE9BbEMrQixDQW9DaEM7OztBQUNBLGFBQU9XLElBQUlSLEdBQUosQ0FBUUMsYUFBZjtBQUNELEtBdENELE1Bc0NPO0FBQ0w7QUFDQU8sVUFBSVIsR0FBSixDQUFRQyxhQUFSLEdBQXdCSixFQUF4QixDQUZLLENBSUw7O0FBQ0EsYUFBT1csSUFBSVIsR0FBSixDQUFRVSxjQUFmO0FBQ0Q7QUFDRjs7QUFFREgsV0FBU1IsSUFBVCxFQXhFNkUsQ0F5RTdFOztBQUNBLE1BQUlBLEtBQUtpQixXQUFMLFlBQTRCQyxlQUFoQyxFQUFpRDtBQUMvQ2xCLFNBQUtpQixXQUFMLENBQWlCaEIsR0FBakIsR0FBdUJELEtBQUtpQixXQUFMLENBQWlCaEIsR0FBakIsSUFBd0IsRUFBL0M7QUFDQU8sYUFBU1IsS0FBS2lCLFdBQWQ7QUFDRDs7QUFFREUsYUFBV25CLElBQVgsRUFBaUJELE9BQWpCO0FBQ0FxQixlQUFhcEIsSUFBYjtBQUVBUixjQUFZNkIsSUFBWixDQUFpQixpQkFBakIsRUFBb0NyQixJQUFwQyxFQUEwQ0YsRUFBMUMsRUFBOENDLE9BQTlDO0FBQ0QsQ0FuRkQ7O0FBcUZBWCxFQUFFa0MsSUFBRixDQUFPLENBQUM3QixNQUFNQyxVQUFQLEVBQW1Cd0IsZUFBbkIsQ0FBUCxFQUE0QyxVQUFVVCxHQUFWLEVBQWU7QUFDekQ7Ozs7Ozs7Ozs7S0FXQUEsSUFBSWQsU0FBSixDQUFjNEIsWUFBZCxHQUE2QixVQUFVQyxHQUFWLEVBQWV6QixPQUFmLEVBQXdCMEIsS0FBeEIsRUFBK0I7QUFDMUQsUUFBSSxDQUFDLEtBQUt4QixHQUFWLEVBQWUsT0FBTyxJQUFQO0FBQ2YsUUFBSSxLQUFLQSxHQUFMLENBQVNDLGFBQWIsRUFBNEIsT0FBTyxLQUFLRCxHQUFMLENBQVNDLGFBQWhCO0FBRTVCLFFBQUl3QixVQUFVLEtBQUt6QixHQUFMLENBQVNVLGNBQXZCOztBQUNBLFFBQUllLFdBQVdBLFFBQVFDLE1BQVIsR0FBaUIsQ0FBaEMsRUFBbUM7QUFDakMsVUFBSSxDQUFDSCxHQUFMLEVBQVUsTUFBTSxJQUFJSSxLQUFKLENBQVUsaUZBQVYsQ0FBTjtBQUVWLFVBQUlmLE1BQUosRUFBWU4sUUFBWixFQUFzQnNCLE1BQXRCOztBQUNBLFdBQUssSUFBSUMsSUFBSSxDQUFiLEVBQWdCQSxJQUFJSixRQUFRQyxNQUE1QixFQUFvQ0csR0FBcEMsRUFBeUM7QUFDdkNqQixpQkFBU2EsUUFBUUksQ0FBUixDQUFUO0FBQ0F2QixtQkFBV3dCLE9BQU9DLElBQVAsQ0FBWW5CLE9BQU9OLFFBQW5CLEVBQTZCLENBQTdCLENBQVgsQ0FGdUMsQ0FJdkM7QUFDQTs7QUFDQXNCLGlCQUFTSSxTQUFULENBTnVDLENBUXZDO0FBQ0E7O0FBQ0EsWUFBSVQsSUFBSVUsSUFBSixJQUFZLE9BQU9WLElBQUlVLElBQUosQ0FBUzNCLFFBQVQsQ0FBUCxLQUE4QixXQUE5QyxFQUEyRDtBQUN6RHNCLG1CQUFTTCxJQUFJVSxJQUFKLENBQVMzQixRQUFULENBQVQ7QUFDRCxTQUZELE1BRU8sSUFBSSxPQUFPaUIsSUFBSWpCLFFBQUosQ0FBUCxLQUF5QixXQUE3QixFQUEwQztBQUMvQ3NCLG1CQUFTTCxJQUFJakIsUUFBSixDQUFUO0FBQ0QsU0FGTSxNQUVBLElBQUlSLFdBQVdBLFFBQVFRLFFBQXZCLEVBQWlDO0FBQ3RDc0IsbUJBQVM5QixRQUFRUSxRQUFSLENBQWlCQSxRQUFqQixDQUFUO0FBQ0QsU0FGTSxNQUVBLElBQUlrQixTQUFTQSxNQUFNbEIsUUFBTixDQUFiLEVBQThCO0FBQUU7QUFDckNzQixtQkFBU0osTUFBTWxCLFFBQU4sQ0FBVDtBQUNELFNBbEJzQyxDQW9CdkM7QUFDQTs7O0FBQ0EsWUFBSXNCLFdBQVdJLFNBQVgsSUFBd0JKLFdBQVdoQixPQUFPTixRQUFQLENBQWdCQSxRQUFoQixDQUF2QyxFQUFrRTtBQUNoRSxpQkFBT00sT0FBT0EsTUFBZDtBQUNEO0FBQ0Y7QUFDRjs7QUFFRCxXQUFPLElBQVA7QUFDRCxHQXRDRDtBQXVDRCxDQW5ERCxFLENBcURBOzs7QUFDQXpCLEVBQUVrQyxJQUFGLENBQU8sQ0FBQyxRQUFELEVBQVcsUUFBWCxDQUFQLEVBQTZCLFVBQVNhLFVBQVQsRUFBcUI7QUFDaEQsTUFBSUMsU0FBUzNDLE1BQU1DLFVBQU4sQ0FBaUJDLFNBQWpCLENBQTJCd0MsVUFBM0IsQ0FBYjs7QUFDQTFDLFFBQU1DLFVBQU4sQ0FBaUJDLFNBQWpCLENBQTJCd0MsVUFBM0IsSUFBeUMsWUFBVztBQUNsRCxRQUFJbkMsT0FBTyxJQUFYO0FBQUEsUUFBaUJELE9BQWpCO0FBQUEsUUFDSXNDLE9BQU9qRCxFQUFFa0QsT0FBRixDQUFVQyxTQUFWLENBRFg7O0FBR0F4QyxjQUFXb0MsZUFBZSxRQUFoQixHQUE0QkUsS0FBSyxDQUFMLENBQTVCLEdBQXNDQSxLQUFLLENBQUwsQ0FBaEQsQ0FKa0QsQ0FNbEQ7O0FBQ0EsUUFBSSxDQUFDdEMsT0FBRCxJQUFZLE9BQU9BLE9BQVAsS0FBbUIsVUFBbkMsRUFBK0M7QUFDN0NBLGdCQUFVLEVBQVY7QUFDRDs7QUFFRCxRQUFJQyxLQUFLQyxHQUFMLElBQVlGLFFBQVF5QyxpQkFBUixLQUE4QixJQUE5QyxFQUFvRDtBQUNsRCxVQUFJQyxTQUFTLElBQWI7O0FBQ0EsVUFBSTtBQUFFO0FBQ0pBLGlCQUFTdkQsT0FBT3VELE1BQVAsRUFBVDtBQUNELE9BRkQsQ0FFRSxPQUFPQyxHQUFQLEVBQVksQ0FBRTs7QUFFaEJMLGFBQU9NLFdBQVdDLElBQVgsQ0FDTDVDLElBREssRUFFTG1DLFVBRkssRUFHTEUsSUFISyxFQUlMbkQsT0FBTzJELFFBQVAsSUFBbUI3QyxLQUFLOEMsV0FBTCxLQUFxQixJQUpuQyxFQUl5QztBQUM5Q0wsWUFMSyxFQU1MdkQsT0FBTzJELFFBTkYsQ0FNVztBQU5YLE9BQVA7O0FBUUEsVUFBSSxDQUFDUixJQUFMLEVBQVc7QUFDVDtBQUNBO0FBQ0EsZUFBT0YsZUFBZSxRQUFmLEdBQTBCbkMsS0FBSytDLFVBQUwsRUFBMUIsR0FBOENkLFNBQXJEO0FBQ0Q7QUFDRixLQW5CRCxNQW1CTztBQUNMO0FBQ0EsVUFBSUUsZUFBZSxRQUFmLElBQTJCLE9BQU9FLEtBQUssQ0FBTCxDQUFQLEtBQW1CLFVBQWxELEVBQThEQSxLQUFLVyxNQUFMLENBQVksQ0FBWixFQUFlLENBQWY7QUFDL0Q7O0FBRUQsV0FBT1osT0FBT2EsS0FBUCxDQUFhakQsSUFBYixFQUFtQnFDLElBQW5CLENBQVA7QUFDRCxHQXBDRDtBQXFDRCxDQXZDRCxFLENBeUNBOzs7O0FBSUEsU0FBU00sVUFBVCxDQUFvQk8sSUFBcEIsRUFBMEJiLElBQTFCLEVBQWdDYyxhQUFoQyxFQUErQ1YsTUFBL0MsRUFBdURXLGlCQUF2RCxFQUEwRTtBQUN4RSxNQUFJcEQsT0FBTyxJQUFYO0FBQUEsTUFBaUJ3QixHQUFqQjtBQUFBLE1BQXNCNkIsUUFBdEI7QUFBQSxNQUFnQ0MsS0FBaEM7QUFBQSxNQUF1Q3ZELE9BQXZDO0FBQUEsTUFBZ0R3RCxRQUFoRDtBQUFBLE1BQTBEaEQsUUFBMUQ7QUFBQSxNQUFvRWlELElBQXBFO0FBQUEsTUFBMEVDLFdBQTFFOztBQUVBLE1BQUksQ0FBQ3BCLEtBQUtWLE1BQVYsRUFBa0I7QUFDaEIsVUFBTSxJQUFJQyxLQUFKLENBQVVzQixPQUFPLHVCQUFqQixDQUFOO0FBQ0QsR0FMdUUsQ0FPeEU7OztBQUNBLE1BQUlBLFNBQVMsUUFBYixFQUF1QjtBQUNyQjFCLFVBQU1hLEtBQUssQ0FBTCxDQUFOO0FBQ0F0QyxjQUFVc0MsS0FBSyxDQUFMLENBQVY7QUFDQWdCLGVBQVdoQixLQUFLLENBQUwsQ0FBWCxDQUhxQixDQUtyQjs7QUFDQSxRQUFJLE9BQU90QyxPQUFQLEtBQW1CLFVBQXZCLEVBQW1DO0FBQ2pDc0MsYUFBTyxDQUFDYixHQUFELEVBQU16QixPQUFOLENBQVA7QUFDRCxLQUZELE1BRU8sSUFBSSxPQUFPc0QsUUFBUCxLQUFvQixVQUF4QixFQUFvQztBQUN6Q2hCLGFBQU8sQ0FBQ2IsR0FBRCxFQUFNNkIsUUFBTixDQUFQO0FBQ0QsS0FGTSxNQUVBO0FBQ0xoQixhQUFPLENBQUNiLEdBQUQsQ0FBUDtBQUNEO0FBQ0YsR0FiRCxNQWFPLElBQUkwQixTQUFTLFFBQWIsRUFBdUI7QUFDNUIzQyxlQUFXOEIsS0FBSyxDQUFMLENBQVg7QUFDQWIsVUFBTWEsS0FBSyxDQUFMLENBQU47QUFDQXRDLGNBQVVzQyxLQUFLLENBQUwsQ0FBVjtBQUNBZ0IsZUFBV2hCLEtBQUssQ0FBTCxDQUFYO0FBQ0QsR0FMTSxNQUtBO0FBQ0wsVUFBTSxJQUFJVCxLQUFKLENBQVUsdUJBQVYsQ0FBTjtBQUNEOztBQUVELE1BQUk4QixtQ0FBbUN0RSxFQUFFdUUsT0FBRixDQUFVbkMsR0FBVixDQUF2QyxDQTlCd0UsQ0FnQ3hFOzs7QUFDQSxNQUFJLENBQUM2QixRQUFELElBQWEsT0FBT3RELE9BQVAsS0FBbUIsVUFBcEMsRUFBZ0Q7QUFDOUNzRCxlQUFXdEQsT0FBWDtBQUNBQSxjQUFVLEVBQVY7QUFDRDs7QUFDREEsWUFBVUEsV0FBVyxFQUFyQjtBQUVBeUQsU0FBT25CLEtBQUtWLE1BQUwsR0FBYyxDQUFyQjtBQUVBOEIsZ0JBQWUsT0FBT3BCLEtBQUttQixJQUFMLENBQVAsS0FBc0IsVUFBckMsQ0F6Q3dFLENBMkN4RTs7QUFDQUQsYUFBWUwsU0FBUyxRQUFULElBQXFCbkQsUUFBUTZELE1BQVIsS0FBbUIsSUFBcEQsQ0E1Q3dFLENBOEN4RTtBQUNBOztBQUNBLE1BQUkvQyxTQUFTYixLQUFLdUIsWUFBTCxDQUFrQkMsR0FBbEIsRUFBdUJ6QixPQUF2QixFQUFnQ1EsUUFBaEMsQ0FBYjtBQUNBLE1BQUlzRCxvQkFBcUI3RCxLQUFLOEMsV0FBTCxLQUFxQixJQUE5QyxDQWpEd0UsQ0FtRHhFOztBQUNBLE1BQUksQ0FBQzVELE9BQU8yRCxRQUFQLElBQW1CZ0IsaUJBQXBCLEtBQTBDOUQsUUFBUW9ELGFBQVIsS0FBMEIsS0FBeEUsRUFBK0U7QUFDN0VBLG9CQUFnQixLQUFoQjtBQUNELEdBdER1RSxDQXdEeEU7OztBQUNBLE1BQUlXLG9CQUFvQi9ELFFBQVErRCxpQkFBaEM7O0FBQ0EsTUFBSUEsaUJBQUosRUFBdUI7QUFDckIsUUFBSSxPQUFPQSxpQkFBUCxLQUE2QixRQUFqQyxFQUEyQztBQUN6Q0EsMEJBQW9CakQsT0FBT2tELFlBQVAsQ0FBb0JELGlCQUFwQixDQUFwQjtBQUNEO0FBQ0YsR0FKRCxNQUlPO0FBQ0xBLHdCQUFvQmpELE9BQU9rRCxZQUFQLEVBQXBCO0FBQ0QsR0FoRXVFLENBa0V4RTs7O0FBQ0EsTUFBSTdFLE9BQU84RSxRQUFQLElBQW1CLENBQUNYLFFBQXhCLEVBQWtDO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQUEsZUFBVyxVQUFTWCxHQUFULEVBQWM7QUFDdkIsVUFBSUEsR0FBSixFQUFTO0FBQ1B4RCxlQUFPK0UsTUFBUCxDQUFjZixPQUFPLFdBQVAsSUFBc0JSLElBQUl3QixNQUFKLElBQWN4QixJQUFJeUIsS0FBeEMsQ0FBZDtBQUNEO0FBQ0YsS0FKRDtBQUtELEdBOUV1RSxDQWdGeEU7QUFDQTtBQUNBOzs7QUFDQSxNQUFJakYsT0FBTzhFLFFBQVAsSUFBbUJQLFdBQXZCLEVBQW9DO0FBQ2xDSixlQUFXaEIsS0FBS21CLElBQUwsSUFBYVksbUNBQW1DTixpQkFBbkMsRUFBc0RULFFBQXRELENBQXhCO0FBQ0Q7O0FBRUQsTUFBSWdCLGlCQUFpQnhELE9BQU95RCxTQUFQLENBQWlCLEtBQWpCLENBQXJCOztBQUNBLE1BQUlwQixTQUFTLFFBQVQsSUFBcUIsQ0FBQzFCLElBQUkrQyxHQUExQixJQUFpQ0YsY0FBckMsRUFBcUQ7QUFDbkQ3QyxRQUFJK0MsR0FBSixHQUFVdkUsS0FBSytDLFVBQUwsRUFBVjtBQUNELEdBMUZ1RSxDQTRGeEU7OztBQUNBLE1BQUl5QixLQUFKOztBQUNBLE1BQUl0QixTQUFTLFFBQWIsRUFBdUI7QUFDckJzQixZQUFRaEQsSUFBSStDLEdBQVosQ0FEcUIsQ0FDSjtBQUNsQixHQUZELE1BRU8sSUFBSXJCLFNBQVMsUUFBVCxJQUFxQjNDLFFBQXpCLEVBQW1DO0FBQ3hDaUUsWUFBUSxPQUFPakUsUUFBUCxLQUFvQixRQUFwQixJQUFnQ0Esb0JBQW9CZCxNQUFNZ0YsUUFBMUQsR0FBcUVsRSxRQUFyRSxHQUFnRkEsU0FBU2dFLEdBQWpHO0FBQ0QsR0FsR3VFLENBb0d4RTtBQUNBOzs7QUFDQSxNQUFJRyxRQUFKOztBQUNBLE1BQUlsRCxJQUFJK0MsR0FBSixJQUFXLENBQUNGLGNBQWhCLEVBQWdDO0FBQzlCSyxlQUFXbEQsSUFBSStDLEdBQWY7QUFDQSxXQUFPL0MsSUFBSStDLEdBQVg7QUFDRDs7QUFFRCxXQUFTSSxPQUFULENBQWlCQyxVQUFqQixFQUE2QnpCLGFBQTdCLEVBQTRDMEIsTUFBNUMsRUFBb0RDLFdBQXBELEVBQWlFQyxrQkFBakUsRUFBcUZDLFdBQXJGLEVBQWtHO0FBQ2hHO0FBQ0FuRSxXQUFPb0UsS0FBUCxDQUFhTCxVQUFiLEVBQXlCO0FBQ3ZCTSxjQUFRLElBRGU7QUFFdkJMLGNBQVFBLE1BRmU7QUFHdkJDLG1CQUFhQSxXQUhVO0FBSXZCM0IscUJBQWVBLGFBSlE7QUFLdkJnQyxrQkFBYWpDLFNBQVMsUUFMQztBQU12QjZCLDBCQUFvQkEsa0JBTkc7QUFPdkJDLG1CQUFhQSxXQVBVO0FBUXZCSSw4QkFBd0JoRyxFQUFFa0IsTUFBRixDQUFTO0FBQy9CK0Usa0JBQVduQyxTQUFTLFFBRFc7QUFFL0JvQyxrQkFBV3BDLFNBQVMsUUFBVCxJQUFxQm5ELFFBQVE2RCxNQUFSLEtBQW1CLElBRnBCO0FBRy9CTCxrQkFBVUEsUUFIcUI7QUFJL0JkLGdCQUFRQSxNQUp1QjtBQUsvQlcsMkJBQW1CQSxpQkFMWTtBQU0vQm9CLGVBQU9BLEtBTndCO0FBTy9CWCwyQkFBbUJBO0FBUFksT0FBVCxFQVFyQjlELFFBQVFxRixzQkFBUixJQUFrQyxFQVJiO0FBUkQsS0FBekI7QUFrQkQsR0FoSXVFLENBa0l4RTtBQUNBOzs7QUFDQVQsVUFDRW5ELEdBREYsRUFFRTJCLGFBRkYsRUFHRXBELFFBQVE4RSxNQUFSLEtBQW1CLEtBSHJCLEVBSUU5RSxRQUFRK0UsV0FBUixLQUF3QixLQUoxQixFQUtFL0UsUUFBUWdGLGtCQUFSLEtBQStCLEtBTGpDLEVBTUVoRixRQUFRaUYsV0FBUixLQUF3QixLQU4xQixFQXBJd0UsQ0E2SXhFO0FBQ0E7QUFDQTs7QUFDQSxNQUFJTyxnQkFBZ0IsRUFBcEI7O0FBQ0EsT0FBSyxJQUFJQyxJQUFULElBQWlCaEUsR0FBakIsRUFBc0I7QUFDcEI7QUFDQTtBQUNBLFFBQUlPLE9BQU9wQyxTQUFQLENBQWlCOEYsY0FBakIsQ0FBZ0M3QyxJQUFoQyxDQUFxQ3BCLEdBQXJDLEVBQTBDZ0UsSUFBMUMsQ0FBSixFQUFxRDtBQUNuREQsb0JBQWNDLElBQWQsSUFBc0JoRSxJQUFJZ0UsSUFBSixDQUF0QjtBQUNEO0FBQ0YsR0F2SnVFLENBeUp4RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLE1BQUl0RyxPQUFPMkQsUUFBUCxJQUFtQlUsUUFBbkIsSUFBK0JuRSxFQUFFc0csUUFBRixDQUFXbkYsUUFBWCxDQUFuQyxFQUF5RDtBQUN2RCxRQUFJb0YsTUFBTUosY0FBY3JELElBQWQsSUFBc0IsRUFBaEMsQ0FEdUQsQ0FHdkQ7O0FBQ0EsUUFBSTBELE1BQU1DLE9BQU4sQ0FBY3RGLFNBQVN1RixJQUF2QixDQUFKLEVBQWtDO0FBQ2hDLFlBQU1DLGdCQUFnQixFQUF0QjtBQUNBeEYsZUFBU3VGLElBQVQsQ0FBY2xGLE9BQWQsQ0FBc0JvRixPQUFPO0FBQzNCNUcsVUFBRWtCLE1BQUYsQ0FBU3lGLGFBQVQsRUFBd0JDLEdBQXhCO0FBQ0QsT0FGRDtBQUdBVCxvQkFBY3JELElBQWQsR0FBcUI2RCxhQUFyQjtBQUNELEtBTkQsTUFNTztBQUNMUixvQkFBY3JELElBQWQsR0FBcUI5QyxFQUFFNkcsS0FBRixDQUFRMUYsUUFBUixDQUFyQjtBQUNEOztBQUVELFFBQUksQ0FBQzhELGNBQUwsRUFBcUIsT0FBT2tCLGNBQWNyRCxJQUFkLENBQW1CcUMsR0FBMUI7O0FBQ3JCbkYsTUFBRWtCLE1BQUYsQ0FBU2lGLGNBQWNyRCxJQUF2QixFQUE2QnlELEdBQTdCO0FBQ0QsR0EvS3VFLENBaUx4RTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBSXpHLE9BQU84RSxRQUFQLElBQW1CLENBQUNILGlCQUF4QixFQUEyQztBQUN6Q2MsWUFBUVksYUFBUixFQUF1QixJQUF2QixFQUE2QixLQUE3QixFQUFvQyxLQUFwQyxFQUEyQyxLQUEzQyxFQUFrRCxLQUFsRDtBQUNELEdBdkx1RSxDQXlMeEU7OztBQUNBLE1BQUksQ0FBQzdCLGdDQUFELElBQXFDdEUsRUFBRXVFLE9BQUYsQ0FBVTRCLGFBQVYsQ0FBekMsRUFBbUU7QUFDakUsVUFBTSxJQUFJM0QsS0FBSixDQUFVLHVEQUNic0IsU0FBUyxRQUFULEdBQW9CLFVBQXBCLEdBQWlDLFFBRHBCLElBRWQsZUFGSSxDQUFOO0FBR0QsR0E5THVFLENBZ014RTs7O0FBQ0EsTUFBSWdELE9BQUo7O0FBQ0EsTUFBSW5HLFFBQVFvRyxRQUFSLEtBQXFCLEtBQXpCLEVBQWdDO0FBQzlCRCxjQUFVLElBQVY7QUFDRCxHQUZELE1BRU87QUFDTEEsY0FBVXBDLGtCQUFrQnFDLFFBQWxCLENBQTJCWixhQUEzQixFQUEwQztBQUNsRGEsZ0JBQVdsRCxTQUFTLFFBQVQsSUFBcUJBLFNBQVMsUUFEUztBQUVsRFUsY0FBUUwsUUFGMEM7QUFHbEQ4Qyw2QkFBdUJqSCxFQUFFa0IsTUFBRixDQUFTO0FBQzlCK0Usa0JBQVduQyxTQUFTLFFBRFU7QUFFOUJvQyxrQkFBV3BDLFNBQVMsUUFBVCxJQUFxQm5ELFFBQVE2RCxNQUFSLEtBQW1CLElBRnJCO0FBRzlCTCxrQkFBVUEsUUFIb0I7QUFJOUJkLGdCQUFRQSxNQUpzQjtBQUs5QlcsMkJBQW1CQSxpQkFMVztBQU05Qm9CLGVBQU9BLEtBTnVCO0FBTzlCWCwyQkFBbUJBO0FBUFcsT0FBVCxFQVFwQjlELFFBQVFzRyxxQkFBUixJQUFpQyxFQVJiO0FBSDJCLEtBQTFDLENBQVY7QUFhRDs7QUFFRCxNQUFJSCxPQUFKLEVBQWE7QUFDWDtBQUNBLFFBQUl4QixRQUFKLEVBQWM7QUFDWmxELFVBQUkrQyxHQUFKLEdBQVVHLFFBQVY7QUFDRCxLQUpVLENBTVg7QUFDQTs7O0FBQ0EsUUFBSXhCLFNBQVMsUUFBYixFQUF1QjtBQUNyQmIsV0FBSyxDQUFMLElBQVViLEdBQVY7QUFDRCxLQUZELE1BRU87QUFDTGEsV0FBSyxDQUFMLElBQVViLEdBQVY7QUFDRCxLQVpVLENBY1g7OztBQUNBLFFBQUl0QyxPQUFPMkQsUUFBUCxJQUFtQlksV0FBdkIsRUFBb0M7QUFDbENwQixXQUFLbUIsSUFBTCxJQUFhOEMsNENBQTRDeEMsaUJBQTVDLEVBQStEekIsS0FBS21CLElBQUwsQ0FBL0QsQ0FBYjtBQUNEOztBQUVELFdBQU9uQixJQUFQO0FBQ0QsR0FwQkQsTUFvQk87QUFDTGlCLFlBQVFpRCxlQUFlekMsaUJBQWYsQ0FBUjs7QUFDQSxRQUFJVCxRQUFKLEVBQWM7QUFDWjtBQUNBQSxlQUFTQyxLQUFULEVBQWdCLEtBQWhCO0FBQ0QsS0FIRCxNQUdPO0FBQ0wsWUFBTUEsS0FBTjtBQUNEO0FBQ0Y7QUFDRjs7QUFFRCxTQUFTaUQsY0FBVCxDQUF3QkMsT0FBeEIsRUFBaUM7QUFDL0IsTUFBSUMsT0FBSjtBQUNBLE1BQUlDLGNBQWUsT0FBT0YsUUFBUUcsZ0JBQWYsS0FBb0MsVUFBckMsR0FBbURILFFBQVFHLGdCQUFSLEVBQW5ELEdBQWdGSCxRQUFRRSxXQUFSLEVBQWxHOztBQUNBLE1BQUlBLFlBQVkvRSxNQUFoQixFQUF3QjtBQUN0QjhFLGNBQVVELFFBQVFJLGVBQVIsQ0FBd0JGLFlBQVksQ0FBWixFQUFlRyxJQUF2QyxDQUFWO0FBQ0QsR0FGRCxNQUVPO0FBQ0xKLGNBQVUsbUJBQVY7QUFDRDs7QUFDRCxNQUFJbkQsUUFBUSxJQUFJMUIsS0FBSixDQUFVNkUsT0FBVixDQUFaO0FBQ0FuRCxRQUFNb0QsV0FBTixHQUFvQkEsV0FBcEI7QUFDQXBELFFBQU1RLGlCQUFOLEdBQTBCMEMsT0FBMUIsQ0FWK0IsQ0FXL0I7QUFDQTs7QUFDQSxNQUFJdEgsT0FBTzJELFFBQVgsRUFBcUI7QUFDbkJTLFVBQU13RCxjQUFOLEdBQXVCLElBQUk1SCxPQUFPMEMsS0FBWCxDQUFpQixHQUFqQixFQUFzQjZFLE9BQXRCLEVBQStCdEgsTUFBTTRILFNBQU4sQ0FBZ0J6RCxNQUFNb0QsV0FBdEIsQ0FBL0IsQ0FBdkI7QUFDRDs7QUFDRCxTQUFPcEQsS0FBUDtBQUNEOztBQUVELFNBQVMwRCxjQUFULENBQXdCUixPQUF4QixFQUFpQ1MsWUFBakMsRUFBK0M7QUFDN0MsTUFBSUosT0FBT0ksYUFBYUMsS0FBYixDQUFtQixLQUFuQixFQUEwQixDQUExQixFQUE2QkEsS0FBN0IsQ0FBbUMsR0FBbkMsRUFBd0MsQ0FBeEMsQ0FBWDtBQUNBLE1BQUlDLE1BQU1GLGFBQWFDLEtBQWIsQ0FBbUIsVUFBbkIsRUFBK0IsQ0FBL0IsRUFBa0NBLEtBQWxDLENBQXdDLEdBQXhDLEVBQTZDLENBQTdDLENBQVY7QUFFQSxNQUFJRSw4QkFBK0IsT0FBT1osUUFBUWEsbUJBQWYsS0FBdUMsVUFBeEMsR0FBc0QscUJBQXRELEdBQThFLGdCQUFoSDtBQUNBYixVQUFRWSwyQkFBUixFQUFxQyxDQUFDO0FBQ3BDUCxVQUFNQSxJQUQ4QjtBQUVwQzNELFVBQU0sV0FGOEI7QUFHcENvRSxXQUFPSDtBQUg2QixHQUFELENBQXJDO0FBS0Q7O0FBRUQsU0FBU2IsMkNBQVQsQ0FBcUR4QyxpQkFBckQsRUFBd0V5RCxFQUF4RSxFQUE0RTtBQUMxRSxTQUFPLFNBQVNDLDhDQUFULENBQXdEbEUsS0FBeEQsRUFBK0Q7QUFDcEUsUUFBSWpCLE9BQU9qRCxFQUFFa0QsT0FBRixDQUFVQyxTQUFWLENBQVg7O0FBQ0EsUUFBSWUsVUFDRUEsTUFBTXVELElBQU4sS0FBZSxZQUFmLElBQStCdkQsTUFBTW1FLElBQU4sS0FBZSxLQUEvQyxJQUF5RG5FLE1BQU1tRCxPQUFOLENBQWNpQixPQUFkLENBQXNCLHlCQUF5QixDQUFDLENBQWhELENBRDFELEtBRUFwRSxNQUFNbUQsT0FBTixDQUFjaUIsT0FBZCxDQUFzQixLQUF0QixNQUFpQyxDQUFDLENBRnRDLEVBRXlDO0FBQ3ZDVixxQkFBZWxELGlCQUFmLEVBQWtDUixNQUFNbUQsT0FBeEM7QUFDQXBFLFdBQUssQ0FBTCxJQUFVa0UsZUFBZXpDLGlCQUFmLENBQVY7QUFDRDs7QUFDRCxXQUFPeUQsR0FBR3RFLEtBQUgsQ0FBUyxJQUFULEVBQWVaLElBQWYsQ0FBUDtBQUNELEdBVEQ7QUFVRDs7QUFFRCxTQUFTK0Isa0NBQVQsQ0FBNENOLGlCQUE1QyxFQUErRHlELEVBQS9ELEVBQW1FO0FBQ2pFLE1BQUlILDhCQUErQixPQUFPdEQsa0JBQWtCdUQsbUJBQXpCLEtBQWlELFVBQWxELEdBQWdFLHFCQUFoRSxHQUF3RixnQkFBMUg7QUFDQSxTQUFPLFNBQVNNLHFDQUFULENBQStDckUsS0FBL0MsRUFBc0Q7QUFDM0QsUUFBSWpCLE9BQU9qRCxFQUFFa0QsT0FBRixDQUFVQyxTQUFWLENBQVgsQ0FEMkQsQ0FFM0Q7OztBQUNBLFFBQUllLGlCQUFpQnBFLE9BQU8wQyxLQUF4QixJQUNBMEIsTUFBTUEsS0FBTixLQUFnQixHQURoQixJQUVBQSxNQUFNWSxNQUFOLEtBQWlCLFNBRmpCLElBR0EsT0FBT1osTUFBTXNFLE9BQWIsS0FBeUIsUUFIN0IsRUFHdUM7QUFDckMsVUFBSUMsd0JBQXdCMUksTUFBTTJJLEtBQU4sQ0FBWXhFLE1BQU1zRSxPQUFsQixDQUE1QjtBQUNBOUQsd0JBQWtCc0QsMkJBQWxCLEVBQStDUyxxQkFBL0M7QUFDQXhGLFdBQUssQ0FBTCxJQUFVa0UsZUFBZXpDLGlCQUFmLENBQVY7QUFDRCxLQVBELENBUUE7QUFSQSxTQVNLLElBQUlSLGlCQUFpQnBFLE9BQU8wQyxLQUF4QixJQUNBMEIsTUFBTUEsS0FBTixLQUFnQixHQURoQixJQUVBQSxNQUFNWSxNQUZOLElBR0FaLE1BQU1ZLE1BQU4sQ0FBYXdELE9BQWIsQ0FBcUIsUUFBckIsTUFBbUMsQ0FBQyxDQUhwQyxJQUlBcEUsTUFBTVksTUFBTixDQUFhd0QsT0FBYixDQUFxQixLQUFyQixNQUFnQyxDQUFDLENBSnJDLEVBSXdDO0FBQzNDVix1QkFBZWxELGlCQUFmLEVBQWtDUixNQUFNWSxNQUF4QztBQUNBN0IsYUFBSyxDQUFMLElBQVVrRSxlQUFlekMsaUJBQWYsQ0FBVjtBQUNEOztBQUNELFdBQU95RCxHQUFHdEUsS0FBSCxDQUFTLElBQVQsRUFBZVosSUFBZixDQUFQO0FBQ0QsR0FyQkQ7QUFzQkQ7O0FBRUQsSUFBSTBGLG1CQUFtQixFQUF2Qjs7QUFDQSxTQUFTM0csWUFBVCxDQUFzQjRHLENBQXRCLEVBQXlCO0FBQ3ZCO0FBQ0E7QUFDQSxNQUFJQyxXQUFXQSxRQUFRQyxRQUFuQixJQUErQixDQUFDSCxpQkFBaUJDLEVBQUVHLEtBQW5CLENBQXBDLEVBQStEO0FBQzdESCxNQUFFSSxLQUFGLENBQVE7QUFDTkMsY0FBUSxZQUFXO0FBQ2pCLGVBQU8sSUFBUDtBQUNELE9BSEs7QUFJTkMsY0FBUSxZQUFXO0FBQ2pCLGVBQU8sSUFBUDtBQUNELE9BTks7QUFPTkMsY0FBUSxZQUFZO0FBQ2xCLGVBQU8sSUFBUDtBQUNELE9BVEs7QUFVTkMsYUFBTyxFQVZEO0FBV05DLGlCQUFXO0FBWEwsS0FBUjtBQWFBVixxQkFBaUJDLEVBQUVHLEtBQW5CLElBQTRCLElBQTVCO0FBQ0QsR0FsQnNCLENBbUJ2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNEOztBQUVELElBQUlPLGlCQUFpQixFQUFyQjs7QUFDQSxTQUFTdkgsVUFBVCxDQUFvQjZHLENBQXBCLEVBQXVCakksT0FBdkIsRUFBZ0M7QUFDOUIsTUFBSSxDQUFDMkksZUFBZVYsRUFBRUcsS0FBakIsQ0FBTCxFQUE4QjtBQUU1QixRQUFJdEUsb0JBQXFCbUUsRUFBRWxGLFdBQUYsS0FBa0IsSUFBM0MsQ0FGNEIsQ0FJNUI7QUFDQTtBQUNBOztBQUNBa0YsTUFBRVcsSUFBRixDQUFPO0FBQ0xOLGNBQVEsVUFBUzVGLE1BQVQsRUFBaUJqQixHQUFqQixFQUFzQjtBQUM1QjtBQUNBd0csVUFBRXpHLFlBQUYsQ0FBZUMsR0FBZixFQUFvQnlELEtBQXBCLENBQTBCekQsR0FBMUIsRUFBK0I7QUFDN0IwRCxrQkFBUSxJQURxQjtBQUU3QkMsc0JBQVksS0FGaUI7QUFHN0I7QUFDQU4sa0JBQVEsS0FKcUI7QUFLN0JDLHVCQUFhLEtBTGdCO0FBTTdCQyw4QkFBb0IsS0FOUztBQU83QkMsdUJBQWEsS0FQZ0I7QUFRN0JJLGtDQUF3QjtBQUN0QkMsc0JBQVUsSUFEWTtBQUV0QkMsc0JBQVUsS0FGWTtBQUd0Qi9CLHNCQUFVLEtBSFk7QUFJdEJkLG9CQUFRQSxNQUpjO0FBS3RCVywrQkFBbUIsS0FMRztBQU10Qm9CLG1CQUFPaEQsSUFBSStDLEdBTlc7QUFPdEJWLCtCQUFtQkE7QUFQRztBQVJLLFNBQS9CO0FBbUJBLGVBQU8sS0FBUDtBQUNELE9BdkJJO0FBd0JMeUUsY0FBUSxVQUFTN0YsTUFBVCxFQUFpQmpCLEdBQWpCLEVBQXNCb0gsTUFBdEIsRUFBOEJ4QyxRQUE5QixFQUF3QztBQUM5QztBQUNBNEIsVUFBRXpHLFlBQUYsQ0FBZTZFLFFBQWYsRUFBeUJuQixLQUF6QixDQUErQm1CLFFBQS9CLEVBQXlDO0FBQ3ZDbEIsa0JBQVEsSUFEK0I7QUFFdkNDLHNCQUFZLElBRjJCO0FBR3ZDO0FBQ0FOLGtCQUFRLEtBSitCO0FBS3ZDQyx1QkFBYSxLQUwwQjtBQU12Q0MsOEJBQW9CLEtBTm1CO0FBT3ZDQyx1QkFBYSxLQVAwQjtBQVF2Q0ksa0NBQXdCO0FBQ3RCQyxzQkFBVSxLQURZO0FBRXRCQyxzQkFBVSxJQUZZO0FBR3RCL0Isc0JBQVUsS0FIWTtBQUl0QmQsb0JBQVFBLE1BSmM7QUFLdEJXLCtCQUFtQixLQUxHO0FBTXRCb0IsbUJBQU9oRCxPQUFPQSxJQUFJK0MsR0FOSTtBQU90QlYsK0JBQW1CQTtBQVBHO0FBUmUsU0FBekM7QUFtQkEsZUFBTyxLQUFQO0FBQ0QsT0E5Q0k7QUErQ0wyRSxhQUFPLENBQUMsS0FBRCxDQS9DRjtBQWdETEMsaUJBQVc7QUFoRE4sS0FBUCxFQVA0QixDQTBENUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBVCxNQUFFVyxJQUFGLENBQU92SixFQUFFa0IsTUFBRixDQUFTO0FBQ2QrSCxjQUFRLFVBQVM1RixNQUFULEVBQWlCakIsR0FBakIsRUFBc0I7QUFDNUI7QUFDQW1CLG1CQUFXQyxJQUFYLENBQ0VvRixDQURGLEVBRUUsUUFGRixFQUdFLENBQ0V4RyxHQURGLEVBRUU7QUFDRXdELHVCQUFhLEtBRGY7QUFFRUQsOEJBQW9CLEtBRnRCO0FBR0VGLGtCQUFRLEtBSFY7QUFJRUMsdUJBQWE7QUFKZixTQUZGLEVBUUUsVUFBU3hCLEtBQVQsRUFBZ0I7QUFDZCxjQUFJQSxLQUFKLEVBQVc7QUFDVCxrQkFBTSxJQUFJcEUsT0FBTzBDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsU0FBdEIsRUFBaUN6QyxNQUFNNEgsU0FBTixDQUFnQnpELE1BQU1vRCxXQUF0QixDQUFqQyxDQUFOO0FBQ0Q7QUFDRixTQVpILENBSEYsRUFpQkUsS0FqQkYsRUFpQlM7QUFDUGpFLGNBbEJGLEVBbUJFLEtBbkJGLENBbUJRO0FBbkJSO0FBc0JBLGVBQU8sS0FBUDtBQUNELE9BMUJhO0FBMkJkNkYsY0FBUSxVQUFTN0YsTUFBVCxFQUFpQmpCLEdBQWpCLEVBQXNCb0gsTUFBdEIsRUFBOEJ4QyxRQUE5QixFQUF3QztBQUM5QztBQUNBO0FBQ0E7QUFDQXpELG1CQUFXQyxJQUFYLENBQ0VvRixDQURGLEVBRUUsUUFGRixFQUdFLENBQ0U7QUFBQ3pELGVBQUsvQyxPQUFPQSxJQUFJK0M7QUFBakIsU0FERixFQUVFNkIsUUFGRixFQUdFO0FBQ0VwQix1QkFBYSxLQURmO0FBRUVELDhCQUFvQixLQUZ0QjtBQUdFRixrQkFBUSxLQUhWO0FBSUVDLHVCQUFhO0FBSmYsU0FIRixFQVNFLFVBQVN4QixLQUFULEVBQWdCO0FBQ2QsY0FBSUEsS0FBSixFQUFXO0FBQ1Qsa0JBQU0sSUFBSXBFLE9BQU8wQyxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFNBQXRCLEVBQWlDekMsTUFBTTRILFNBQU4sQ0FBZ0J6RCxNQUFNb0QsV0FBdEIsQ0FBakMsQ0FBTjtBQUNEO0FBQ0YsU0FiSCxDQUhGLEVBa0JFLEtBbEJGLEVBa0JTO0FBQ1BqRSxjQW5CRixFQW9CRSxLQXBCRixDQW9CUTtBQXBCUjtBQXVCQSxlQUFPLEtBQVA7QUFDRCxPQXZEYTtBQXdEZCtGLGFBQU8sQ0FBQyxLQUFEO0FBeERPLEtBQVQsRUF5REp6SSxRQUFRMEksU0FBUixLQUFzQixJQUF0QixHQUE2QixFQUE3QixHQUFrQztBQUFDQSxpQkFBVztBQUFaLEtBekQ5QixDQUFQLEVBaEU0QixDQTJINUI7QUFDQTs7QUFDQUMsbUJBQWVWLEVBQUVHLEtBQWpCLElBQTBCLElBQTFCO0FBQ0Q7QUFDRjs7QUF6cUJEckosT0FBTytKLGFBQVAsQ0EycUJlckosV0EzcUJmLEUiLCJmaWxlIjoiL3BhY2thZ2VzL2FsZGVlZF9jb2xsZWN0aW9uMi1jb3JlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnbWV0ZW9yL3JhaXg6ZXZlbnRlbWl0dGVyJztcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgRUpTT04gfSBmcm9tICdtZXRlb3IvZWpzb24nO1xuaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJztcbmltcG9ydCB7IGNoZWNrTnBtVmVyc2lvbnMgfSBmcm9tICdtZXRlb3IvdG1lYXNkYXk6Y2hlY2stbnBtLXZlcnNpb25zJztcblxuY2hlY2tOcG1WZXJzaW9ucyh7ICdzaW1wbC1zY2hlbWEnOiAnMC54LngnIH0sICdhbGRlZWQ6bWV0ZW9yLWNvbGxlY3Rpb24yLWNvcmUnKTtcblxuY29uc3QgU2ltcGxlU2NoZW1hID0gcmVxdWlyZSgnc2ltcGwtc2NoZW1hJykuZGVmYXVsdDtcblxuLy8gRXhwb3J0ZWQgb25seSBmb3IgbGlzdGVuaW5nIHRvIGV2ZW50c1xuY29uc3QgQ29sbGVjdGlvbjIgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG5cbi8qKlxuICogTW9uZ28uQ29sbGVjdGlvbi5wcm90b3R5cGUuYXR0YWNoU2NoZW1hXG4gKiBAcGFyYW0ge1NpbXBsZVNjaGVtYXxPYmplY3R9IHNzIC0gU2ltcGxlU2NoZW1hIGluc3RhbmNlIG9yIGEgc2NoZW1hIGRlZmluaXRpb24gb2JqZWN0XG4gKiAgICBmcm9tIHdoaWNoIHRvIGNyZWF0ZSBhIG5ldyBTaW1wbGVTY2hlbWEgaW5zdGFuY2VcbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAqIEBwYXJhbSB7Qm9vbGVhbn0gW29wdGlvbnMudHJhbnNmb3JtPWZhbHNlXSBTZXQgdG8gYHRydWVgIGlmIHlvdXIgZG9jdW1lbnQgbXVzdCBiZSBwYXNzZWRcbiAqICAgIHRocm91Z2ggdGhlIGNvbGxlY3Rpb24ncyB0cmFuc2Zvcm0gdG8gcHJvcGVybHkgdmFsaWRhdGUuXG4gKiBAcGFyYW0ge0Jvb2xlYW59IFtvcHRpb25zLnJlcGxhY2U9ZmFsc2VdIFNldCB0byBgdHJ1ZWAgdG8gcmVwbGFjZSBhbnkgZXhpc3Rpbmcgc2NoZW1hIGluc3RlYWQgb2YgY29tYmluaW5nXG4gKiBAcmV0dXJuIHt1bmRlZmluZWR9XG4gKlxuICogVXNlIHRoaXMgbWV0aG9kIHRvIGF0dGFjaCBhIHNjaGVtYSB0byBhIGNvbGxlY3Rpb24gY3JlYXRlZCBieSBhbm90aGVyIHBhY2thZ2UsXG4gKiBzdWNoIGFzIE1ldGVvci51c2Vycy4gSXQgaXMgbW9zdCBsaWtlbHkgdW5zYWZlIHRvIGNhbGwgdGhpcyBtZXRob2QgbW9yZSB0aGFuXG4gKiBvbmNlIGZvciBhIHNpbmdsZSBjb2xsZWN0aW9uLCBvciB0byBjYWxsIHRoaXMgZm9yIGEgY29sbGVjdGlvbiB0aGF0IGhhZCBhXG4gKiBzY2hlbWEgb2JqZWN0IHBhc3NlZCB0byBpdHMgY29uc3RydWN0b3IuXG4gKi9cbk1vbmdvLkNvbGxlY3Rpb24ucHJvdG90eXBlLmF0dGFjaFNjaGVtYSA9IGZ1bmN0aW9uIGMyQXR0YWNoU2NoZW1hKHNzLCBvcHRpb25zKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG5cbiAgLy8gQWxsb3cgcGFzc2luZyBqdXN0IHRoZSBzY2hlbWEgb2JqZWN0XG4gIGlmICghKHNzIGluc3RhbmNlb2YgU2ltcGxlU2NoZW1hKSkge1xuICAgIHNzID0gbmV3IFNpbXBsZVNjaGVtYShzcyk7XG4gIH1cblxuICBzZWxmLl9jMiA9IHNlbGYuX2MyIHx8IHt9O1xuXG4gIC8vIElmIHdlJ3ZlIGFscmVhZHkgYXR0YWNoZWQgb25lIHNjaGVtYSwgd2UgY29tYmluZSBib3RoIGludG8gYSBuZXcgc2NoZW1hIHVubGVzcyBvcHRpb25zLnJlcGxhY2UgaXMgYHRydWVgXG4gIGlmIChzZWxmLl9jMi5fc2ltcGxlU2NoZW1hICYmIG9wdGlvbnMucmVwbGFjZSAhPT0gdHJ1ZSkge1xuICAgIGlmIChzcy52ZXJzaW9uID49IDIpIHtcbiAgICAgIHZhciBuZXdTUyA9IG5ldyBTaW1wbGVTY2hlbWEoc2VsZi5fYzIuX3NpbXBsZVNjaGVtYSk7XG4gICAgICBuZXdTUy5leHRlbmQoc3MpO1xuICAgICAgc3MgPSBuZXdTUztcbiAgICB9IGVsc2Uge1xuICAgICAgc3MgPSBuZXcgU2ltcGxlU2NoZW1hKFtzZWxmLl9jMi5fc2ltcGxlU2NoZW1hLCBzc10pO1xuICAgIH1cbiAgfVxuXG4gIHZhciBzZWxlY3RvciA9IG9wdGlvbnMuc2VsZWN0b3I7XG5cbiAgZnVuY3Rpb24gYXR0YWNoVG8ob2JqKSB7XG4gICAgaWYgKHR5cGVvZiBzZWxlY3RvciA9PT0gXCJvYmplY3RcIikge1xuICAgICAgLy8gSW5kZXggb2YgZXhpc3Rpbmcgc2NoZW1hIHdpdGggaWRlbnRpY2FsIHNlbGVjdG9yXG4gICAgICB2YXIgc2NoZW1hSW5kZXggPSAtMTtcblxuICAgICAgLy8gd2UgbmVlZCBhbiBhcnJheSB0byBob2xkIG11bHRpcGxlIHNjaGVtYXNcbiAgICAgIG9iai5fYzIuX3NpbXBsZVNjaGVtYXMgPSBvYmouX2MyLl9zaW1wbGVTY2hlbWFzIHx8IFtdO1xuXG4gICAgICAvLyBMb29wIHRocm91Z2ggZXhpc3Rpbmcgc2NoZW1hcyB3aXRoIHNlbGVjdG9yc1xuICAgICAgb2JqLl9jMi5fc2ltcGxlU2NoZW1hcy5mb3JFYWNoKGZ1bmN0aW9uIChzY2hlbWEsIGluZGV4KSB7XG4gICAgICAgIC8vIGlmIHdlIGZpbmQgYSBzY2hlbWEgd2l0aCBhbiBpZGVudGljYWwgc2VsZWN0b3IsIHNhdmUgaXQncyBpbmRleFxuICAgICAgICBpZihfLmlzRXF1YWwoc2NoZW1hLnNlbGVjdG9yLCBzZWxlY3RvcikpIHtcbiAgICAgICAgICBzY2hlbWFJbmRleCA9IGluZGV4O1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGlmIChzY2hlbWFJbmRleCA9PT0gLTEpIHtcbiAgICAgICAgLy8gV2UgZGlkbid0IGZpbmQgdGhlIHNjaGVtYSBpbiBvdXIgYXJyYXkgLSBwdXNoIGl0IGludG8gdGhlIGFycmF5XG4gICAgICAgIG9iai5fYzIuX3NpbXBsZVNjaGVtYXMucHVzaCh7XG4gICAgICAgICAgc2NoZW1hOiBuZXcgU2ltcGxlU2NoZW1hKHNzKSxcbiAgICAgICAgICBzZWxlY3Rvcjogc2VsZWN0b3IsXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gV2UgZm91bmQgYSBzY2hlbWEgd2l0aCBhbiBpZGVudGljYWwgc2VsZWN0b3IgaW4gb3VyIGFycmF5LFxuICAgICAgICBpZiAob3B0aW9ucy5yZXBsYWNlICE9PSB0cnVlKSB7XG4gICAgICAgICAgLy8gTWVyZ2Ugd2l0aCBleGlzdGluZyBzY2hlbWEgdW5sZXNzIG9wdGlvbnMucmVwbGFjZSBpcyBgdHJ1ZWBcbiAgICAgICAgICBpZiAob2JqLl9jMi5fc2ltcGxlU2NoZW1hc1tzY2hlbWFJbmRleF0uc2NoZW1hLnZlcnNpb24gPj0gMikge1xuICAgICAgICAgICAgb2JqLl9jMi5fc2ltcGxlU2NoZW1hc1tzY2hlbWFJbmRleF0uc2NoZW1hLmV4dGVuZChzcyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG9iai5fYzIuX3NpbXBsZVNjaGVtYXNbc2NoZW1hSW5kZXhdLnNjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoW29iai5fYzIuX3NpbXBsZVNjaGVtYXNbc2NoZW1hSW5kZXhdLnNjaGVtYSwgc3NdKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8gSWYgb3B0aW9ucy5yZXBhbGNlIGlzIGB0cnVlYCByZXBsYWNlIGV4aXN0aW5nIHNjaGVtYSB3aXRoIG5ldyBzY2hlbWFcbiAgICAgICAgICBvYmouX2MyLl9zaW1wbGVTY2hlbWFzW3NjaGVtYUluZGV4XS5zY2hlbWEgPSBzcztcbiAgICAgICAgfVxuXG4gICAgICB9XG5cbiAgICAgIC8vIFJlbW92ZSBleGlzdGluZyBzY2hlbWFzIHdpdGhvdXQgc2VsZWN0b3JcbiAgICAgIGRlbGV0ZSBvYmouX2MyLl9zaW1wbGVTY2hlbWE7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIFRyYWNrIHRoZSBzY2hlbWEgaW4gdGhlIGNvbGxlY3Rpb25cbiAgICAgIG9iai5fYzIuX3NpbXBsZVNjaGVtYSA9IHNzO1xuXG4gICAgICAvLyBSZW1vdmUgZXhpc3Rpbmcgc2NoZW1hcyB3aXRoIHNlbGVjdG9yXG4gICAgICBkZWxldGUgb2JqLl9jMi5fc2ltcGxlU2NoZW1hcztcbiAgICB9XG4gIH1cblxuICBhdHRhY2hUbyhzZWxmKTtcbiAgLy8gQXR0YWNoIHRoZSBzY2hlbWEgdG8gdGhlIHVuZGVybHlpbmcgTG9jYWxDb2xsZWN0aW9uLCB0b29cbiAgaWYgKHNlbGYuX2NvbGxlY3Rpb24gaW5zdGFuY2VvZiBMb2NhbENvbGxlY3Rpb24pIHtcbiAgICBzZWxmLl9jb2xsZWN0aW9uLl9jMiA9IHNlbGYuX2NvbGxlY3Rpb24uX2MyIHx8IHt9O1xuICAgIGF0dGFjaFRvKHNlbGYuX2NvbGxlY3Rpb24pO1xuICB9XG5cbiAgZGVmaW5lRGVueShzZWxmLCBvcHRpb25zKTtcbiAga2VlcEluc2VjdXJlKHNlbGYpO1xuXG4gIENvbGxlY3Rpb24yLmVtaXQoJ3NjaGVtYS5hdHRhY2hlZCcsIHNlbGYsIHNzLCBvcHRpb25zKTtcbn07XG5cbl8uZWFjaChbTW9uZ28uQ29sbGVjdGlvbiwgTG9jYWxDb2xsZWN0aW9uXSwgZnVuY3Rpb24gKG9iaikge1xuICAvKipcbiAgICogc2ltcGxlU2NoZW1hXG4gICAqIEBkZXNjcmlwdGlvbiBmdW5jdGlvbiBkZXRlY3QgdGhlIGNvcnJlY3Qgc2NoZW1hIGJ5IGdpdmVuIHBhcmFtcy4gSWYgaXRcbiAgICogZGV0ZWN0IG11bHRpLXNjaGVtYSBwcmVzZW5jZSBpbiBgc2VsZmAsIHRoZW4gaXQgbWFkZSBhbiBhdHRlbXB0IHRvIGZpbmQgYVxuICAgKiBgc2VsZWN0b3JgIGluIGFyZ3NcbiAgICogQHBhcmFtIHtPYmplY3R9IGRvYyAtIEl0IGNvdWxkIGJlIDx1cGRhdGU+IG9uIHVwZGF0ZS91cHNlcnQgb3IgZG9jdW1lbnRcbiAgICogaXRzZWxmIG9uIGluc2VydC9yZW1vdmVcbiAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXSAtIEl0IGNvdWxkIGJlIDx1cGRhdGU+IG9uIHVwZGF0ZS91cHNlcnQgZXRjXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbcXVlcnldIC0gaXQgY291bGQgYmUgPHF1ZXJ5PiBvbiB1cGRhdGUvdXBzZXJ0XG4gICAqIEByZXR1cm4ge09iamVjdH0gU2NoZW1hXG4gICAqL1xuICBvYmoucHJvdG90eXBlLnNpbXBsZVNjaGVtYSA9IGZ1bmN0aW9uIChkb2MsIG9wdGlvbnMsIHF1ZXJ5KSB7XG4gICAgaWYgKCF0aGlzLl9jMikgcmV0dXJuIG51bGw7XG4gICAgaWYgKHRoaXMuX2MyLl9zaW1wbGVTY2hlbWEpIHJldHVybiB0aGlzLl9jMi5fc2ltcGxlU2NoZW1hO1xuXG4gICAgdmFyIHNjaGVtYXMgPSB0aGlzLl9jMi5fc2ltcGxlU2NoZW1hcztcbiAgICBpZiAoc2NoZW1hcyAmJiBzY2hlbWFzLmxlbmd0aCA+IDApIHtcbiAgICAgIGlmICghZG9jKSB0aHJvdyBuZXcgRXJyb3IoJ2NvbGxlY3Rpb24uc2ltcGxlU2NoZW1hKCkgcmVxdWlyZXMgZG9jIGFyZ3VtZW50IHdoZW4gdGhlcmUgYXJlIG11bHRpcGxlIHNjaGVtYXMnKTtcblxuICAgICAgdmFyIHNjaGVtYSwgc2VsZWN0b3IsIHRhcmdldDtcbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2NoZW1hcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBzY2hlbWEgPSBzY2hlbWFzW2ldO1xuICAgICAgICBzZWxlY3RvciA9IE9iamVjdC5rZXlzKHNjaGVtYS5zZWxlY3RvcilbMF07XG5cbiAgICAgICAgLy8gV2Ugd2lsbCBzZXQgdGhpcyB0byB1bmRlZmluZWQgYmVjYXVzZSBpbiB0aGVvcnkgeW91IG1pZ2h0IHdhbnQgdG8gc2VsZWN0XG4gICAgICAgIC8vIG9uIGEgbnVsbCB2YWx1ZS5cbiAgICAgICAgdGFyZ2V0ID0gdW5kZWZpbmVkO1xuXG4gICAgICAgIC8vIGhlcmUgd2UgYXJlIGxvb2tpbmcgZm9yIHNlbGVjdG9yIGluIGRpZmZlcmVudCBwbGFjZXNcbiAgICAgICAgLy8gJHNldCBzaG91bGQgaGF2ZSBtb3JlIHByaW9yaXR5IGhlcmVcbiAgICAgICAgaWYgKGRvYy4kc2V0ICYmIHR5cGVvZiBkb2MuJHNldFtzZWxlY3Rvcl0gIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgdGFyZ2V0ID0gZG9jLiRzZXRbc2VsZWN0b3JdO1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBkb2Nbc2VsZWN0b3JdICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgIHRhcmdldCA9IGRvY1tzZWxlY3Rvcl07XG4gICAgICAgIH0gZWxzZSBpZiAob3B0aW9ucyAmJiBvcHRpb25zLnNlbGVjdG9yKSB7XG4gICAgICAgICAgdGFyZ2V0ID0gb3B0aW9ucy5zZWxlY3RvcltzZWxlY3Rvcl07XG4gICAgICAgIH0gZWxzZSBpZiAocXVlcnkgJiYgcXVlcnlbc2VsZWN0b3JdKSB7IC8vIG9uIHVwc2VydC91cGRhdGUgb3BlcmF0aW9uc1xuICAgICAgICAgIHRhcmdldCA9IHF1ZXJ5W3NlbGVjdG9yXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHdlIG5lZWQgdG8gY29tcGFyZSBnaXZlbiBzZWxlY3RvciB3aXRoIGRvYyBwcm9wZXJ0eSBvciBvcHRpb24gdG9cbiAgICAgICAgLy8gZmluZCByaWdodCBzY2hlbWFcbiAgICAgICAgaWYgKHRhcmdldCAhPT0gdW5kZWZpbmVkICYmIHRhcmdldCA9PT0gc2NoZW1hLnNlbGVjdG9yW3NlbGVjdG9yXSkge1xuICAgICAgICAgIHJldHVybiBzY2hlbWEuc2NoZW1hO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG51bGw7XG4gIH07XG59KTtcblxuLy8gV3JhcCBEQiB3cml0ZSBvcGVyYXRpb24gbWV0aG9kc1xuXy5lYWNoKFsnaW5zZXJ0JywgJ3VwZGF0ZSddLCBmdW5jdGlvbihtZXRob2ROYW1lKSB7XG4gIHZhciBfc3VwZXIgPSBNb25nby5Db2xsZWN0aW9uLnByb3RvdHlwZVttZXRob2ROYW1lXTtcbiAgTW9uZ28uQ29sbGVjdGlvbi5wcm90b3R5cGVbbWV0aG9kTmFtZV0gPSBmdW5jdGlvbigpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXMsIG9wdGlvbnMsXG4gICAgICAgIGFyZ3MgPSBfLnRvQXJyYXkoYXJndW1lbnRzKTtcblxuICAgIG9wdGlvbnMgPSAobWV0aG9kTmFtZSA9PT0gXCJpbnNlcnRcIikgPyBhcmdzWzFdIDogYXJnc1syXTtcblxuICAgIC8vIFN1cHBvcnQgbWlzc2luZyBvcHRpb25zIGFyZ1xuICAgIGlmICghb3B0aW9ucyB8fCB0eXBlb2Ygb3B0aW9ucyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICBvcHRpb25zID0ge307XG4gICAgfVxuXG4gICAgaWYgKHNlbGYuX2MyICYmIG9wdGlvbnMuYnlwYXNzQ29sbGVjdGlvbjIgIT09IHRydWUpIHtcbiAgICAgIHZhciB1c2VySWQgPSBudWxsO1xuICAgICAgdHJ5IHsgLy8gaHR0cHM6Ly9naXRodWIuY29tL2FsZGVlZC9tZXRlb3ItY29sbGVjdGlvbjIvaXNzdWVzLzE3NVxuICAgICAgICB1c2VySWQgPSBNZXRlb3IudXNlcklkKCk7XG4gICAgICB9IGNhdGNoIChlcnIpIHt9XG5cbiAgICAgIGFyZ3MgPSBkb1ZhbGlkYXRlLmNhbGwoXG4gICAgICAgIHNlbGYsXG4gICAgICAgIG1ldGhvZE5hbWUsXG4gICAgICAgIGFyZ3MsXG4gICAgICAgIE1ldGVvci5pc1NlcnZlciB8fCBzZWxmLl9jb25uZWN0aW9uID09PSBudWxsLCAvLyBnZXRBdXRvVmFsdWVzXG4gICAgICAgIHVzZXJJZCxcbiAgICAgICAgTWV0ZW9yLmlzU2VydmVyIC8vIGlzRnJvbVRydXN0ZWRDb2RlXG4gICAgICApO1xuICAgICAgaWYgKCFhcmdzKSB7XG4gICAgICAgIC8vIGRvVmFsaWRhdGUgYWxyZWFkeSBjYWxsZWQgdGhlIGNhbGxiYWNrIG9yIHRocmV3IHRoZSBlcnJvciBzbyB3ZSdyZSBkb25lLlxuICAgICAgICAvLyBCdXQgaW5zZXJ0IHNob3VsZCBhbHdheXMgcmV0dXJuIGFuIElEIHRvIG1hdGNoIGNvcmUgYmVoYXZpb3IuXG4gICAgICAgIHJldHVybiBtZXRob2ROYW1lID09PSBcImluc2VydFwiID8gc2VsZi5fbWFrZU5ld0lEKCkgOiB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIFdlIHN0aWxsIG5lZWQgdG8gYWRqdXN0IGFyZ3MgYmVjYXVzZSBpbnNlcnQgZG9lcyBub3QgdGFrZSBvcHRpb25zXG4gICAgICBpZiAobWV0aG9kTmFtZSA9PT0gXCJpbnNlcnRcIiAmJiB0eXBlb2YgYXJnc1sxXSAhPT0gJ2Z1bmN0aW9uJykgYXJncy5zcGxpY2UoMSwgMSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIF9zdXBlci5hcHBseShzZWxmLCBhcmdzKTtcbiAgfTtcbn0pO1xuXG4vKlxuICogUHJpdmF0ZVxuICovXG5cbmZ1bmN0aW9uIGRvVmFsaWRhdGUodHlwZSwgYXJncywgZ2V0QXV0b1ZhbHVlcywgdXNlcklkLCBpc0Zyb21UcnVzdGVkQ29kZSkge1xuICB2YXIgc2VsZiA9IHRoaXMsIGRvYywgY2FsbGJhY2ssIGVycm9yLCBvcHRpb25zLCBpc1Vwc2VydCwgc2VsZWN0b3IsIGxhc3QsIGhhc0NhbGxiYWNrO1xuXG4gIGlmICghYXJncy5sZW5ndGgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IodHlwZSArIFwiIHJlcXVpcmVzIGFuIGFyZ3VtZW50XCIpO1xuICB9XG5cbiAgLy8gR2F0aGVyIGFyZ3VtZW50cyBhbmQgY2FjaGUgdGhlIHNlbGVjdG9yXG4gIGlmICh0eXBlID09PSBcImluc2VydFwiKSB7XG4gICAgZG9jID0gYXJnc1swXTtcbiAgICBvcHRpb25zID0gYXJnc1sxXTtcbiAgICBjYWxsYmFjayA9IGFyZ3NbMl07XG5cbiAgICAvLyBUaGUgcmVhbCBpbnNlcnQgZG9lc24ndCB0YWtlIG9wdGlvbnNcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgYXJncyA9IFtkb2MsIG9wdGlvbnNdO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIGNhbGxiYWNrID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIGFyZ3MgPSBbZG9jLCBjYWxsYmFja107XG4gICAgfSBlbHNlIHtcbiAgICAgIGFyZ3MgPSBbZG9jXTtcbiAgICB9XG4gIH0gZWxzZSBpZiAodHlwZSA9PT0gXCJ1cGRhdGVcIikge1xuICAgIHNlbGVjdG9yID0gYXJnc1swXTtcbiAgICBkb2MgPSBhcmdzWzFdO1xuICAgIG9wdGlvbnMgPSBhcmdzWzJdO1xuICAgIGNhbGxiYWNrID0gYXJnc1szXTtcbiAgfSBlbHNlIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJpbnZhbGlkIHR5cGUgYXJndW1lbnRcIik7XG4gIH1cblxuICB2YXIgdmFsaWRhdGVkT2JqZWN0V2FzSW5pdGlhbGx5RW1wdHkgPSBfLmlzRW1wdHkoZG9jKTtcblxuICAvLyBTdXBwb3J0IG1pc3Npbmcgb3B0aW9ucyBhcmdcbiAgaWYgKCFjYWxsYmFjayAmJiB0eXBlb2Ygb3B0aW9ucyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgY2FsbGJhY2sgPSBvcHRpb25zO1xuICAgIG9wdGlvbnMgPSB7fTtcbiAgfVxuICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcblxuICBsYXN0ID0gYXJncy5sZW5ndGggLSAxO1xuXG4gIGhhc0NhbGxiYWNrID0gKHR5cGVvZiBhcmdzW2xhc3RdID09PSAnZnVuY3Rpb24nKTtcblxuICAvLyBJZiB1cGRhdGUgd2FzIGNhbGxlZCB3aXRoIHVwc2VydDp0cnVlLCBmbGFnIGFzIGFuIHVwc2VydFxuICBpc1Vwc2VydCA9ICh0eXBlID09PSBcInVwZGF0ZVwiICYmIG9wdGlvbnMudXBzZXJ0ID09PSB0cnVlKTtcblxuICAvLyB3ZSBuZWVkIHRvIHBhc3MgYGRvY2AgYW5kIGBvcHRpb25zYCB0byBgc2ltcGxlU2NoZW1hYCBtZXRob2QsIHRoYXQncyB3aHlcbiAgLy8gc2NoZW1hIGRlY2xhcmF0aW9uIG1vdmVkIGhlcmVcbiAgdmFyIHNjaGVtYSA9IHNlbGYuc2ltcGxlU2NoZW1hKGRvYywgb3B0aW9ucywgc2VsZWN0b3IpO1xuICB2YXIgaXNMb2NhbENvbGxlY3Rpb24gPSAoc2VsZi5fY29ubmVjdGlvbiA9PT0gbnVsbCk7XG5cbiAgLy8gT24gdGhlIHNlcnZlciBhbmQgZm9yIGxvY2FsIGNvbGxlY3Rpb25zLCB3ZSBhbGxvdyBwYXNzaW5nIGBnZXRBdXRvVmFsdWVzOiBmYWxzZWAgdG8gZGlzYWJsZSBhdXRvVmFsdWUgZnVuY3Rpb25zXG4gIGlmICgoTWV0ZW9yLmlzU2VydmVyIHx8IGlzTG9jYWxDb2xsZWN0aW9uKSAmJiBvcHRpb25zLmdldEF1dG9WYWx1ZXMgPT09IGZhbHNlKSB7XG4gICAgZ2V0QXV0b1ZhbHVlcyA9IGZhbHNlO1xuICB9XG5cbiAgLy8gRGV0ZXJtaW5lIHZhbGlkYXRpb24gY29udGV4dFxuICB2YXIgdmFsaWRhdGlvbkNvbnRleHQgPSBvcHRpb25zLnZhbGlkYXRpb25Db250ZXh0O1xuICBpZiAodmFsaWRhdGlvbkNvbnRleHQpIHtcbiAgICBpZiAodHlwZW9mIHZhbGlkYXRpb25Db250ZXh0ID09PSAnc3RyaW5nJykge1xuICAgICAgdmFsaWRhdGlvbkNvbnRleHQgPSBzY2hlbWEubmFtZWRDb250ZXh0KHZhbGlkYXRpb25Db250ZXh0KTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgdmFsaWRhdGlvbkNvbnRleHQgPSBzY2hlbWEubmFtZWRDb250ZXh0KCk7XG4gIH1cblxuICAvLyBBZGQgYSBkZWZhdWx0IGNhbGxiYWNrIGZ1bmN0aW9uIGlmIHdlJ3JlIG9uIHRoZSBjbGllbnQgYW5kIG5vIGNhbGxiYWNrIHdhcyBnaXZlblxuICBpZiAoTWV0ZW9yLmlzQ2xpZW50ICYmICFjYWxsYmFjaykge1xuICAgIC8vIENsaWVudCBjYW4ndCBibG9jaywgc28gaXQgY2FuJ3QgcmVwb3J0IGVycm9ycyBieSBleGNlcHRpb24sXG4gICAgLy8gb25seSBieSBjYWxsYmFjay4gSWYgdGhleSBmb3JnZXQgdGhlIGNhbGxiYWNrLCBnaXZlIHRoZW0gYVxuICAgIC8vIGRlZmF1bHQgb25lIHRoYXQgbG9ncyB0aGUgZXJyb3IsIHNvIHRoZXkgYXJlbid0IHRvdGFsbHlcbiAgICAvLyBiYWZmbGVkIGlmIHRoZWlyIHdyaXRlcyBkb24ndCB3b3JrIGJlY2F1c2UgdGhlaXIgZGF0YWJhc2UgaXNcbiAgICAvLyBkb3duLlxuICAgIGNhbGxiYWNrID0gZnVuY3Rpb24oZXJyKSB7XG4gICAgICBpZiAoZXJyKSB7XG4gICAgICAgIE1ldGVvci5fZGVidWcodHlwZSArIFwiIGZhaWxlZDogXCIgKyAoZXJyLnJlYXNvbiB8fCBlcnIuc3RhY2spKTtcbiAgICAgIH1cbiAgICB9O1xuICB9XG5cbiAgLy8gSWYgY2xpZW50IHZhbGlkYXRpb24gaXMgZmluZSBvciBpcyBza2lwcGVkIGJ1dCB0aGVuIHNvbWV0aGluZ1xuICAvLyBpcyBmb3VuZCB0byBiZSBpbnZhbGlkIG9uIHRoZSBzZXJ2ZXIsIHdlIGdldCB0aGF0IGVycm9yIGJhY2tcbiAgLy8gYXMgYSBzcGVjaWFsIE1ldGVvci5FcnJvciB0aGF0IHdlIG5lZWQgdG8gcGFyc2UuXG4gIGlmIChNZXRlb3IuaXNDbGllbnQgJiYgaGFzQ2FsbGJhY2spIHtcbiAgICBjYWxsYmFjayA9IGFyZ3NbbGFzdF0gPSB3cmFwQ2FsbGJhY2tGb3JQYXJzaW5nU2VydmVyRXJyb3JzKHZhbGlkYXRpb25Db250ZXh0LCBjYWxsYmFjayk7XG4gIH1cblxuICB2YXIgc2NoZW1hQWxsb3dzSWQgPSBzY2hlbWEuYWxsb3dzS2V5KFwiX2lkXCIpO1xuICBpZiAodHlwZSA9PT0gXCJpbnNlcnRcIiAmJiAhZG9jLl9pZCAmJiBzY2hlbWFBbGxvd3NJZCkge1xuICAgIGRvYy5faWQgPSBzZWxmLl9tYWtlTmV3SUQoKTtcbiAgfVxuXG4gIC8vIEdldCB0aGUgZG9jSWQgZm9yIHBhc3NpbmcgaW4gdGhlIGF1dG9WYWx1ZS9jdXN0b20gY29udGV4dFxuICB2YXIgZG9jSWQ7XG4gIGlmICh0eXBlID09PSAnaW5zZXJ0Jykge1xuICAgIGRvY0lkID0gZG9jLl9pZDsgLy8gbWlnaHQgYmUgdW5kZWZpbmVkXG4gIH0gZWxzZSBpZiAodHlwZSA9PT0gXCJ1cGRhdGVcIiAmJiBzZWxlY3Rvcikge1xuICAgIGRvY0lkID0gdHlwZW9mIHNlbGVjdG9yID09PSAnc3RyaW5nJyB8fCBzZWxlY3RvciBpbnN0YW5jZW9mIE1vbmdvLk9iamVjdElEID8gc2VsZWN0b3IgOiBzZWxlY3Rvci5faWQ7XG4gIH1cblxuICAvLyBJZiBfaWQgaGFzIGFscmVhZHkgYmVlbiBhZGRlZCwgcmVtb3ZlIGl0IHRlbXBvcmFyaWx5IGlmIGl0J3NcbiAgLy8gbm90IGV4cGxpY2l0bHkgZGVmaW5lZCBpbiB0aGUgc2NoZW1hLlxuICB2YXIgY2FjaGVkSWQ7XG4gIGlmIChkb2MuX2lkICYmICFzY2hlbWFBbGxvd3NJZCkge1xuICAgIGNhY2hlZElkID0gZG9jLl9pZDtcbiAgICBkZWxldGUgZG9jLl9pZDtcbiAgfVxuXG4gIGZ1bmN0aW9uIGRvQ2xlYW4oZG9jVG9DbGVhbiwgZ2V0QXV0b1ZhbHVlcywgZmlsdGVyLCBhdXRvQ29udmVydCwgcmVtb3ZlRW1wdHlTdHJpbmdzLCB0cmltU3RyaW5ncykge1xuICAgIC8vIENsZWFuIHRoZSBkb2MvbW9kaWZpZXIgaW4gcGxhY2VcbiAgICBzY2hlbWEuY2xlYW4oZG9jVG9DbGVhbiwge1xuICAgICAgbXV0YXRlOiB0cnVlLFxuICAgICAgZmlsdGVyOiBmaWx0ZXIsXG4gICAgICBhdXRvQ29udmVydDogYXV0b0NvbnZlcnQsXG4gICAgICBnZXRBdXRvVmFsdWVzOiBnZXRBdXRvVmFsdWVzLFxuICAgICAgaXNNb2RpZmllcjogKHR5cGUgIT09IFwiaW5zZXJ0XCIpLFxuICAgICAgcmVtb3ZlRW1wdHlTdHJpbmdzOiByZW1vdmVFbXB0eVN0cmluZ3MsXG4gICAgICB0cmltU3RyaW5nczogdHJpbVN0cmluZ3MsXG4gICAgICBleHRlbmRBdXRvVmFsdWVDb250ZXh0OiBfLmV4dGVuZCh7XG4gICAgICAgIGlzSW5zZXJ0OiAodHlwZSA9PT0gXCJpbnNlcnRcIiksXG4gICAgICAgIGlzVXBkYXRlOiAodHlwZSA9PT0gXCJ1cGRhdGVcIiAmJiBvcHRpb25zLnVwc2VydCAhPT0gdHJ1ZSksXG4gICAgICAgIGlzVXBzZXJ0OiBpc1Vwc2VydCxcbiAgICAgICAgdXNlcklkOiB1c2VySWQsXG4gICAgICAgIGlzRnJvbVRydXN0ZWRDb2RlOiBpc0Zyb21UcnVzdGVkQ29kZSxcbiAgICAgICAgZG9jSWQ6IGRvY0lkLFxuICAgICAgICBpc0xvY2FsQ29sbGVjdGlvbjogaXNMb2NhbENvbGxlY3Rpb25cbiAgICAgIH0sIG9wdGlvbnMuZXh0ZW5kQXV0b1ZhbHVlQ29udGV4dCB8fCB7fSlcbiAgICB9KTtcbiAgfVxuXG4gIC8vIFByZWxpbWluYXJ5IGNsZWFuaW5nIG9uIGJvdGggY2xpZW50IGFuZCBzZXJ2ZXIuIE9uIHRoZSBzZXJ2ZXIgYW5kIGZvciBsb2NhbFxuICAvLyBjb2xsZWN0aW9ucywgYXV0b21hdGljIHZhbHVlcyB3aWxsIGFsc28gYmUgc2V0IGF0IHRoaXMgcG9pbnQuXG4gIGRvQ2xlYW4oXG4gICAgZG9jLFxuICAgIGdldEF1dG9WYWx1ZXMsXG4gICAgb3B0aW9ucy5maWx0ZXIgIT09IGZhbHNlLFxuICAgIG9wdGlvbnMuYXV0b0NvbnZlcnQgIT09IGZhbHNlLFxuICAgIG9wdGlvbnMucmVtb3ZlRW1wdHlTdHJpbmdzICE9PSBmYWxzZSxcbiAgICBvcHRpb25zLnRyaW1TdHJpbmdzICE9PSBmYWxzZVxuICApO1xuXG4gIC8vIFdlIGNsb25lIGJlZm9yZSB2YWxpZGF0aW5nIGJlY2F1c2UgaW4gc29tZSBjYXNlcyB3ZSBuZWVkIHRvIGFkanVzdCB0aGVcbiAgLy8gb2JqZWN0IGEgYml0IGJlZm9yZSB2YWxpZGF0aW5nIGl0LiBJZiB3ZSBhZGp1c3RlZCBgZG9jYCBpdHNlbGYsIG91clxuICAvLyBjaGFuZ2VzIHdvdWxkIHBlcnNpc3QgaW50byB0aGUgZGF0YWJhc2UuXG4gIHZhciBkb2NUb1ZhbGlkYXRlID0ge307XG4gIGZvciAodmFyIHByb3AgaW4gZG9jKSB7XG4gICAgLy8gV2Ugb21pdCBwcm90b3R5cGUgcHJvcGVydGllcyB3aGVuIGNsb25pbmcgYmVjYXVzZSB0aGV5IHdpbGwgbm90IGJlIHZhbGlkXG4gICAgLy8gYW5kIG1vbmdvIG9taXRzIHRoZW0gd2hlbiBzYXZpbmcgdG8gdGhlIGRhdGFiYXNlIGFueXdheS5cbiAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGRvYywgcHJvcCkpIHtcbiAgICAgIGRvY1RvVmFsaWRhdGVbcHJvcF0gPSBkb2NbcHJvcF07XG4gICAgfVxuICB9XG5cbiAgLy8gT24gdGhlIHNlcnZlciwgdXBzZXJ0cyBhcmUgcG9zc2libGU7IFNpbXBsZVNjaGVtYSBoYW5kbGVzIHVwc2VydHMgcHJldHR5XG4gIC8vIHdlbGwgYnkgZGVmYXVsdCwgYnV0IGl0IHdpbGwgbm90IGtub3cgYWJvdXQgdGhlIGZpZWxkcyBpbiB0aGUgc2VsZWN0b3IsXG4gIC8vIHdoaWNoIGFyZSBhbHNvIHN0b3JlZCBpbiB0aGUgZGF0YWJhc2UgaWYgYW4gaW5zZXJ0IGlzIHBlcmZvcm1lZC4gU28gd2VcbiAgLy8gd2lsbCBhbGxvdyB0aGVzZSBmaWVsZHMgdG8gYmUgY29uc2lkZXJlZCBmb3IgdmFsaWRhdGlvbiBieSBhZGRpbmcgdGhlbVxuICAvLyB0byB0aGUgJHNldCBpbiB0aGUgbW9kaWZpZXIuIFRoaXMgaXMgbm8gZG91YnQgcHJvbmUgdG8gZXJyb3JzLCBidXQgdGhlcmVcbiAgLy8gcHJvYmFibHkgaXNuJ3QgYW55IGJldHRlciB3YXkgcmlnaHQgbm93LlxuICBpZiAoTWV0ZW9yLmlzU2VydmVyICYmIGlzVXBzZXJ0ICYmIF8uaXNPYmplY3Qoc2VsZWN0b3IpKSB7XG4gICAgdmFyIHNldCA9IGRvY1RvVmFsaWRhdGUuJHNldCB8fCB7fTtcblxuICAgIC8vIElmIHNlbGVjdG9yIHVzZXMgJGFuZCBmb3JtYXQsIGNvbnZlcnQgdG8gcGxhaW4gb2JqZWN0IHNlbGVjdG9yXG4gICAgaWYgKEFycmF5LmlzQXJyYXkoc2VsZWN0b3IuJGFuZCkpIHtcbiAgICAgIGNvbnN0IHBsYWluU2VsZWN0b3IgPSB7fTtcbiAgICAgIHNlbGVjdG9yLiRhbmQuZm9yRWFjaChzZWwgPT4ge1xuICAgICAgICBfLmV4dGVuZChwbGFpblNlbGVjdG9yLCBzZWwpO1xuICAgICAgfSk7XG4gICAgICBkb2NUb1ZhbGlkYXRlLiRzZXQgPSBwbGFpblNlbGVjdG9yO1xuICAgIH0gZWxzZSB7XG4gICAgICBkb2NUb1ZhbGlkYXRlLiRzZXQgPSBfLmNsb25lKHNlbGVjdG9yKTtcbiAgICB9XG5cbiAgICBpZiAoIXNjaGVtYUFsbG93c0lkKSBkZWxldGUgZG9jVG9WYWxpZGF0ZS4kc2V0Ll9pZDtcbiAgICBfLmV4dGVuZChkb2NUb1ZhbGlkYXRlLiRzZXQsIHNldCk7XG4gIH1cblxuICAvLyBTZXQgYXV0b21hdGljIHZhbHVlcyBmb3IgdmFsaWRhdGlvbiBvbiB0aGUgY2xpZW50LlxuICAvLyBPbiB0aGUgc2VydmVyLCB3ZSBhbHJlYWR5IHVwZGF0ZWQgZG9jIHdpdGggYXV0byB2YWx1ZXMsIGJ1dCBvbiB0aGUgY2xpZW50LFxuICAvLyB3ZSB3aWxsIGFkZCB0aGVtIHRvIGRvY1RvVmFsaWRhdGUgZm9yIHZhbGlkYXRpb24gcHVycG9zZXMgb25seS5cbiAgLy8gVGhpcyBpcyBiZWNhdXNlIHdlIHdhbnQgYWxsIGFjdHVhbCB2YWx1ZXMgZ2VuZXJhdGVkIG9uIHRoZSBzZXJ2ZXIuXG4gIGlmIChNZXRlb3IuaXNDbGllbnQgJiYgIWlzTG9jYWxDb2xsZWN0aW9uKSB7XG4gICAgZG9DbGVhbihkb2NUb1ZhbGlkYXRlLCB0cnVlLCBmYWxzZSwgZmFsc2UsIGZhbHNlLCBmYWxzZSk7XG4gIH1cblxuICAvLyBYWFggTWF5YmUgbW92ZSB0aGlzIGludG8gU2ltcGxlU2NoZW1hXG4gIGlmICghdmFsaWRhdGVkT2JqZWN0V2FzSW5pdGlhbGx5RW1wdHkgJiYgXy5pc0VtcHR5KGRvY1RvVmFsaWRhdGUpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdBZnRlciBmaWx0ZXJpbmcgb3V0IGtleXMgbm90IGluIHRoZSBzY2hlbWEsIHlvdXIgJyArXG4gICAgICAodHlwZSA9PT0gJ3VwZGF0ZScgPyAnbW9kaWZpZXInIDogJ29iamVjdCcpICtcbiAgICAgICcgaXMgbm93IGVtcHR5Jyk7XG4gIH1cblxuICAvLyBWYWxpZGF0ZSBkb2NcbiAgdmFyIGlzVmFsaWQ7XG4gIGlmIChvcHRpb25zLnZhbGlkYXRlID09PSBmYWxzZSkge1xuICAgIGlzVmFsaWQgPSB0cnVlO1xuICB9IGVsc2Uge1xuICAgIGlzVmFsaWQgPSB2YWxpZGF0aW9uQ29udGV4dC52YWxpZGF0ZShkb2NUb1ZhbGlkYXRlLCB7XG4gICAgICBtb2RpZmllcjogKHR5cGUgPT09IFwidXBkYXRlXCIgfHwgdHlwZSA9PT0gXCJ1cHNlcnRcIiksXG4gICAgICB1cHNlcnQ6IGlzVXBzZXJ0LFxuICAgICAgZXh0ZW5kZWRDdXN0b21Db250ZXh0OiBfLmV4dGVuZCh7XG4gICAgICAgIGlzSW5zZXJ0OiAodHlwZSA9PT0gXCJpbnNlcnRcIiksXG4gICAgICAgIGlzVXBkYXRlOiAodHlwZSA9PT0gXCJ1cGRhdGVcIiAmJiBvcHRpb25zLnVwc2VydCAhPT0gdHJ1ZSksXG4gICAgICAgIGlzVXBzZXJ0OiBpc1Vwc2VydCxcbiAgICAgICAgdXNlcklkOiB1c2VySWQsXG4gICAgICAgIGlzRnJvbVRydXN0ZWRDb2RlOiBpc0Zyb21UcnVzdGVkQ29kZSxcbiAgICAgICAgZG9jSWQ6IGRvY0lkLFxuICAgICAgICBpc0xvY2FsQ29sbGVjdGlvbjogaXNMb2NhbENvbGxlY3Rpb25cbiAgICAgIH0sIG9wdGlvbnMuZXh0ZW5kZWRDdXN0b21Db250ZXh0IHx8IHt9KVxuICAgIH0pO1xuICB9XG5cbiAgaWYgKGlzVmFsaWQpIHtcbiAgICAvLyBBZGQgdGhlIElEIGJhY2tcbiAgICBpZiAoY2FjaGVkSWQpIHtcbiAgICAgIGRvYy5faWQgPSBjYWNoZWRJZDtcbiAgICB9XG5cbiAgICAvLyBVcGRhdGUgdGhlIGFyZ3MgdG8gcmVmbGVjdCB0aGUgY2xlYW5lZCBkb2NcbiAgICAvLyBYWFggbm90IHN1cmUgdGhpcyBpcyBuZWNlc3Nhcnkgc2luY2Ugd2UgbXV0YXRlXG4gICAgaWYgKHR5cGUgPT09IFwiaW5zZXJ0XCIpIHtcbiAgICAgIGFyZ3NbMF0gPSBkb2M7XG4gICAgfSBlbHNlIHtcbiAgICAgIGFyZ3NbMV0gPSBkb2M7XG4gICAgfVxuXG4gICAgLy8gSWYgY2FsbGJhY2ssIHNldCBpbnZhbGlkS2V5IHdoZW4gd2UgZ2V0IGEgbW9uZ28gdW5pcXVlIGVycm9yXG4gICAgaWYgKE1ldGVvci5pc1NlcnZlciAmJiBoYXNDYWxsYmFjaykge1xuICAgICAgYXJnc1tsYXN0XSA9IHdyYXBDYWxsYmFja0ZvclBhcnNpbmdNb25nb1ZhbGlkYXRpb25FcnJvcnModmFsaWRhdGlvbkNvbnRleHQsIGFyZ3NbbGFzdF0pO1xuICAgIH1cblxuICAgIHJldHVybiBhcmdzO1xuICB9IGVsc2Uge1xuICAgIGVycm9yID0gZ2V0RXJyb3JPYmplY3QodmFsaWRhdGlvbkNvbnRleHQpO1xuICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgLy8gaW5zZXJ0L3VwZGF0ZS91cHNlcnQgcGFzcyBgZmFsc2VgIHdoZW4gdGhlcmUncyBhbiBlcnJvciwgc28gd2UgZG8gdGhhdFxuICAgICAgY2FsbGJhY2soZXJyb3IsIGZhbHNlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIGdldEVycm9yT2JqZWN0KGNvbnRleHQpIHtcbiAgdmFyIG1lc3NhZ2U7XG4gIHZhciBpbnZhbGlkS2V5cyA9ICh0eXBlb2YgY29udGV4dC52YWxpZGF0aW9uRXJyb3JzID09PSAnZnVuY3Rpb24nKSA/IGNvbnRleHQudmFsaWRhdGlvbkVycm9ycygpIDogY29udGV4dC5pbnZhbGlkS2V5cygpO1xuICBpZiAoaW52YWxpZEtleXMubGVuZ3RoKSB7XG4gICAgbWVzc2FnZSA9IGNvbnRleHQua2V5RXJyb3JNZXNzYWdlKGludmFsaWRLZXlzWzBdLm5hbWUpO1xuICB9IGVsc2Uge1xuICAgIG1lc3NhZ2UgPSBcIkZhaWxlZCB2YWxpZGF0aW9uXCI7XG4gIH1cbiAgdmFyIGVycm9yID0gbmV3IEVycm9yKG1lc3NhZ2UpO1xuICBlcnJvci5pbnZhbGlkS2V5cyA9IGludmFsaWRLZXlzO1xuICBlcnJvci52YWxpZGF0aW9uQ29udGV4dCA9IGNvbnRleHQ7XG4gIC8vIElmIG9uIHRoZSBzZXJ2ZXIsIHdlIGFkZCBhIHNhbml0aXplZCBlcnJvciwgdG9vLCBpbiBjYXNlIHdlJ3JlXG4gIC8vIGNhbGxlZCBmcm9tIGEgbWV0aG9kLlxuICBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgZXJyb3Iuc2FuaXRpemVkRXJyb3IgPSBuZXcgTWV0ZW9yLkVycm9yKDQwMCwgbWVzc2FnZSwgRUpTT04uc3RyaW5naWZ5KGVycm9yLmludmFsaWRLZXlzKSk7XG4gIH1cbiAgcmV0dXJuIGVycm9yO1xufVxuXG5mdW5jdGlvbiBhZGRVbmlxdWVFcnJvcihjb250ZXh0LCBlcnJvck1lc3NhZ2UpIHtcbiAgdmFyIG5hbWUgPSBlcnJvck1lc3NhZ2Uuc3BsaXQoJ2MyXycpWzFdLnNwbGl0KCcgJylbMF07XG4gIHZhciB2YWwgPSBlcnJvck1lc3NhZ2Uuc3BsaXQoJ2R1cCBrZXk6JylbMV0uc3BsaXQoJ1wiJylbMV07XG5cbiAgdmFyIGFkZFZhbGlkYXRpb25FcnJvcnNQcm9wTmFtZSA9ICh0eXBlb2YgY29udGV4dC5hZGRWYWxpZGF0aW9uRXJyb3JzID09PSAnZnVuY3Rpb24nKSA/ICdhZGRWYWxpZGF0aW9uRXJyb3JzJyA6ICdhZGRJbnZhbGlkS2V5cyc7XG4gIGNvbnRleHRbYWRkVmFsaWRhdGlvbkVycm9yc1Byb3BOYW1lXShbe1xuICAgIG5hbWU6IG5hbWUsXG4gICAgdHlwZTogJ25vdFVuaXF1ZScsXG4gICAgdmFsdWU6IHZhbFxuICB9XSk7XG59XG5cbmZ1bmN0aW9uIHdyYXBDYWxsYmFja0ZvclBhcnNpbmdNb25nb1ZhbGlkYXRpb25FcnJvcnModmFsaWRhdGlvbkNvbnRleHQsIGNiKSB7XG4gIHJldHVybiBmdW5jdGlvbiB3cmFwcGVkQ2FsbGJhY2tGb3JQYXJzaW5nTW9uZ29WYWxpZGF0aW9uRXJyb3JzKGVycm9yKSB7XG4gICAgdmFyIGFyZ3MgPSBfLnRvQXJyYXkoYXJndW1lbnRzKTtcbiAgICBpZiAoZXJyb3IgJiZcbiAgICAgICAgKChlcnJvci5uYW1lID09PSBcIk1vbmdvRXJyb3JcIiAmJiBlcnJvci5jb2RlID09PSAxMTAwMSkgfHwgZXJyb3IubWVzc2FnZS5pbmRleE9mKCdNb25nb0Vycm9yOiBFMTEwMDAnICE9PSAtMSkpICYmXG4gICAgICAgIGVycm9yLm1lc3NhZ2UuaW5kZXhPZignYzJfJykgIT09IC0xKSB7XG4gICAgICBhZGRVbmlxdWVFcnJvcih2YWxpZGF0aW9uQ29udGV4dCwgZXJyb3IubWVzc2FnZSk7XG4gICAgICBhcmdzWzBdID0gZ2V0RXJyb3JPYmplY3QodmFsaWRhdGlvbkNvbnRleHQpO1xuICAgIH1cbiAgICByZXR1cm4gY2IuYXBwbHkodGhpcywgYXJncyk7XG4gIH07XG59XG5cbmZ1bmN0aW9uIHdyYXBDYWxsYmFja0ZvclBhcnNpbmdTZXJ2ZXJFcnJvcnModmFsaWRhdGlvbkNvbnRleHQsIGNiKSB7XG4gIHZhciBhZGRWYWxpZGF0aW9uRXJyb3JzUHJvcE5hbWUgPSAodHlwZW9mIHZhbGlkYXRpb25Db250ZXh0LmFkZFZhbGlkYXRpb25FcnJvcnMgPT09ICdmdW5jdGlvbicpID8gJ2FkZFZhbGlkYXRpb25FcnJvcnMnIDogJ2FkZEludmFsaWRLZXlzJztcbiAgcmV0dXJuIGZ1bmN0aW9uIHdyYXBwZWRDYWxsYmFja0ZvclBhcnNpbmdTZXJ2ZXJFcnJvcnMoZXJyb3IpIHtcbiAgICB2YXIgYXJncyA9IF8udG9BcnJheShhcmd1bWVudHMpO1xuICAgIC8vIEhhbmRsZSBvdXIgb3duIHZhbGlkYXRpb24gZXJyb3JzXG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgTWV0ZW9yLkVycm9yICYmXG4gICAgICAgIGVycm9yLmVycm9yID09PSA0MDAgJiZcbiAgICAgICAgZXJyb3IucmVhc29uID09PSBcIklOVkFMSURcIiAmJlxuICAgICAgICB0eXBlb2YgZXJyb3IuZGV0YWlscyA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgdmFyIGludmFsaWRLZXlzRnJvbVNlcnZlciA9IEVKU09OLnBhcnNlKGVycm9yLmRldGFpbHMpO1xuICAgICAgdmFsaWRhdGlvbkNvbnRleHRbYWRkVmFsaWRhdGlvbkVycm9yc1Byb3BOYW1lXShpbnZhbGlkS2V5c0Zyb21TZXJ2ZXIpO1xuICAgICAgYXJnc1swXSA9IGdldEVycm9yT2JqZWN0KHZhbGlkYXRpb25Db250ZXh0KTtcbiAgICB9XG4gICAgLy8gSGFuZGxlIE1vbmdvIHVuaXF1ZSBpbmRleCBlcnJvcnMsIHdoaWNoIGFyZSBmb3J3YXJkZWQgdG8gdGhlIGNsaWVudCBhcyA0MDkgZXJyb3JzXG4gICAgZWxzZSBpZiAoZXJyb3IgaW5zdGFuY2VvZiBNZXRlb3IuRXJyb3IgJiZcbiAgICAgICAgICAgICBlcnJvci5lcnJvciA9PT0gNDA5ICYmXG4gICAgICAgICAgICAgZXJyb3IucmVhc29uICYmXG4gICAgICAgICAgICAgZXJyb3IucmVhc29uLmluZGV4T2YoJ0UxMTAwMCcpICE9PSAtMSAmJlxuICAgICAgICAgICAgIGVycm9yLnJlYXNvbi5pbmRleE9mKCdjMl8nKSAhPT0gLTEpIHtcbiAgICAgIGFkZFVuaXF1ZUVycm9yKHZhbGlkYXRpb25Db250ZXh0LCBlcnJvci5yZWFzb24pO1xuICAgICAgYXJnc1swXSA9IGdldEVycm9yT2JqZWN0KHZhbGlkYXRpb25Db250ZXh0KTtcbiAgICB9XG4gICAgcmV0dXJuIGNiLmFwcGx5KHRoaXMsIGFyZ3MpO1xuICB9O1xufVxuXG52YXIgYWxyZWFkeUluc2VjdXJlZCA9IHt9O1xuZnVuY3Rpb24ga2VlcEluc2VjdXJlKGMpIHtcbiAgLy8gSWYgaW5zZWN1cmUgcGFja2FnZSBpcyBpbiB1c2UsIHdlIG5lZWQgdG8gYWRkIGFsbG93IHJ1bGVzIHRoYXQgcmV0dXJuXG4gIC8vIHRydWUuIE90aGVyd2lzZSwgaXQgd291bGQgc2VlbWluZ2x5IHR1cm4gb2ZmIGluc2VjdXJlIG1vZGUuXG4gIGlmIChQYWNrYWdlICYmIFBhY2thZ2UuaW5zZWN1cmUgJiYgIWFscmVhZHlJbnNlY3VyZWRbYy5fbmFtZV0pIHtcbiAgICBjLmFsbG93KHtcbiAgICAgIGluc2VydDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfSxcbiAgICAgIHVwZGF0ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfSxcbiAgICAgIHJlbW92ZTogZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH0sXG4gICAgICBmZXRjaDogW10sXG4gICAgICB0cmFuc2Zvcm06IG51bGxcbiAgICB9KTtcbiAgICBhbHJlYWR5SW5zZWN1cmVkW2MuX25hbWVdID0gdHJ1ZTtcbiAgfVxuICAvLyBJZiBpbnNlY3VyZSBwYWNrYWdlIGlzIE5PVCBpbiB1c2UsIHRoZW4gYWRkaW5nIHRoZSB0d28gZGVueSBmdW5jdGlvbnNcbiAgLy8gZG9lcyBub3QgaGF2ZSBhbnkgZWZmZWN0IG9uIHRoZSBtYWluIGFwcCdzIHNlY3VyaXR5IHBhcmFkaWdtLiBUaGVcbiAgLy8gdXNlciB3aWxsIHN0aWxsIGJlIHJlcXVpcmVkIHRvIGFkZCBhdCBsZWFzdCBvbmUgYWxsb3cgZnVuY3Rpb24gb2YgaGVyXG4gIC8vIG93biBmb3IgZWFjaCBvcGVyYXRpb24gZm9yIHRoaXMgY29sbGVjdGlvbi4gQW5kIHRoZSB1c2VyIG1heSBzdGlsbCBhZGRcbiAgLy8gYWRkaXRpb25hbCBkZW55IGZ1bmN0aW9ucywgYnV0IGRvZXMgbm90IGhhdmUgdG8uXG59XG5cbnZhciBhbHJlYWR5RGVmaW5lZCA9IHt9O1xuZnVuY3Rpb24gZGVmaW5lRGVueShjLCBvcHRpb25zKSB7XG4gIGlmICghYWxyZWFkeURlZmluZWRbYy5fbmFtZV0pIHtcblxuICAgIHZhciBpc0xvY2FsQ29sbGVjdGlvbiA9IChjLl9jb25uZWN0aW9uID09PSBudWxsKTtcblxuICAgIC8vIEZpcnN0IGRlZmluZSBkZW55IGZ1bmN0aW9ucyB0byBleHRlbmQgZG9jIHdpdGggdGhlIHJlc3VsdHMgb2YgY2xlYW5cbiAgICAvLyBhbmQgYXV0b3ZhbHVlcy4gVGhpcyBtdXN0IGJlIGRvbmUgd2l0aCBcInRyYW5zZm9ybTogbnVsbFwiIG9yIHdlIHdvdWxkIGJlXG4gICAgLy8gZXh0ZW5kaW5nIGEgY2xvbmUgb2YgZG9jIGFuZCB0aGVyZWZvcmUgaGF2ZSBubyBlZmZlY3QuXG4gICAgYy5kZW55KHtcbiAgICAgIGluc2VydDogZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcbiAgICAgICAgLy8gUmVmZXJlbmNlZCBkb2MgaXMgY2xlYW5lZCBpbiBwbGFjZVxuICAgICAgICBjLnNpbXBsZVNjaGVtYShkb2MpLmNsZWFuKGRvYywge1xuICAgICAgICAgIG11dGF0ZTogdHJ1ZSxcbiAgICAgICAgICBpc01vZGlmaWVyOiBmYWxzZSxcbiAgICAgICAgICAvLyBXZSBkb24ndCBkbyB0aGVzZSBoZXJlIGJlY2F1c2UgdGhleSBhcmUgZG9uZSBvbiB0aGUgY2xpZW50IGlmIGRlc2lyZWRcbiAgICAgICAgICBmaWx0ZXI6IGZhbHNlLFxuICAgICAgICAgIGF1dG9Db252ZXJ0OiBmYWxzZSxcbiAgICAgICAgICByZW1vdmVFbXB0eVN0cmluZ3M6IGZhbHNlLFxuICAgICAgICAgIHRyaW1TdHJpbmdzOiBmYWxzZSxcbiAgICAgICAgICBleHRlbmRBdXRvVmFsdWVDb250ZXh0OiB7XG4gICAgICAgICAgICBpc0luc2VydDogdHJ1ZSxcbiAgICAgICAgICAgIGlzVXBkYXRlOiBmYWxzZSxcbiAgICAgICAgICAgIGlzVXBzZXJ0OiBmYWxzZSxcbiAgICAgICAgICAgIHVzZXJJZDogdXNlcklkLFxuICAgICAgICAgICAgaXNGcm9tVHJ1c3RlZENvZGU6IGZhbHNlLFxuICAgICAgICAgICAgZG9jSWQ6IGRvYy5faWQsXG4gICAgICAgICAgICBpc0xvY2FsQ29sbGVjdGlvbjogaXNMb2NhbENvbGxlY3Rpb25cbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH0sXG4gICAgICB1cGRhdGU6IGZ1bmN0aW9uKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKSB7XG4gICAgICAgIC8vIFJlZmVyZW5jZWQgbW9kaWZpZXIgaXMgY2xlYW5lZCBpbiBwbGFjZVxuICAgICAgICBjLnNpbXBsZVNjaGVtYShtb2RpZmllcikuY2xlYW4obW9kaWZpZXIsIHtcbiAgICAgICAgICBtdXRhdGU6IHRydWUsXG4gICAgICAgICAgaXNNb2RpZmllcjogdHJ1ZSxcbiAgICAgICAgICAvLyBXZSBkb24ndCBkbyB0aGVzZSBoZXJlIGJlY2F1c2UgdGhleSBhcmUgZG9uZSBvbiB0aGUgY2xpZW50IGlmIGRlc2lyZWRcbiAgICAgICAgICBmaWx0ZXI6IGZhbHNlLFxuICAgICAgICAgIGF1dG9Db252ZXJ0OiBmYWxzZSxcbiAgICAgICAgICByZW1vdmVFbXB0eVN0cmluZ3M6IGZhbHNlLFxuICAgICAgICAgIHRyaW1TdHJpbmdzOiBmYWxzZSxcbiAgICAgICAgICBleHRlbmRBdXRvVmFsdWVDb250ZXh0OiB7XG4gICAgICAgICAgICBpc0luc2VydDogZmFsc2UsXG4gICAgICAgICAgICBpc1VwZGF0ZTogdHJ1ZSxcbiAgICAgICAgICAgIGlzVXBzZXJ0OiBmYWxzZSxcbiAgICAgICAgICAgIHVzZXJJZDogdXNlcklkLFxuICAgICAgICAgICAgaXNGcm9tVHJ1c3RlZENvZGU6IGZhbHNlLFxuICAgICAgICAgICAgZG9jSWQ6IGRvYyAmJiBkb2MuX2lkLFxuICAgICAgICAgICAgaXNMb2NhbENvbGxlY3Rpb246IGlzTG9jYWxDb2xsZWN0aW9uXG4gICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9LFxuICAgICAgZmV0Y2g6IFsnX2lkJ10sXG4gICAgICB0cmFuc2Zvcm06IG51bGxcbiAgICB9KTtcblxuICAgIC8vIFNlY29uZCBkZWZpbmUgZGVueSBmdW5jdGlvbnMgdG8gdmFsaWRhdGUgYWdhaW4gb24gdGhlIHNlcnZlclxuICAgIC8vIGZvciBjbGllbnQtaW5pdGlhdGVkIGluc2VydHMgYW5kIHVwZGF0ZXMuIFRoZXNlIHNob3VsZCBiZVxuICAgIC8vIGNhbGxlZCBhZnRlciB0aGUgY2xlYW4vYXV0b3ZhbHVlIGZ1bmN0aW9ucyBzaW5jZSB3ZSdyZSBhZGRpbmdcbiAgICAvLyB0aGVtIGFmdGVyLiBUaGVzZSBtdXN0ICpub3QqIGhhdmUgXCJ0cmFuc2Zvcm06IG51bGxcIiBpZiBvcHRpb25zLnRyYW5zZm9ybSBpcyB0cnVlIGJlY2F1c2VcbiAgICAvLyB3ZSBuZWVkIHRvIHBhc3MgdGhlIGRvYyB0aHJvdWdoIGFueSB0cmFuc2Zvcm1zIHRvIGJlIHN1cmVcbiAgICAvLyB0aGF0IGN1c3RvbSB0eXBlcyBhcmUgcHJvcGVybHkgcmVjb2duaXplZCBmb3IgdHlwZSB2YWxpZGF0aW9uLlxuICAgIGMuZGVueShfLmV4dGVuZCh7XG4gICAgICBpbnNlcnQ6IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG4gICAgICAgIC8vIFdlIHBhc3MgdGhlIGZhbHNlIG9wdGlvbnMgYmVjYXVzZSB3ZSB3aWxsIGhhdmUgZG9uZSB0aGVtIG9uIGNsaWVudCBpZiBkZXNpcmVkXG4gICAgICAgIGRvVmFsaWRhdGUuY2FsbChcbiAgICAgICAgICBjLFxuICAgICAgICAgIFwiaW5zZXJ0XCIsXG4gICAgICAgICAgW1xuICAgICAgICAgICAgZG9jLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICB0cmltU3RyaW5nczogZmFsc2UsXG4gICAgICAgICAgICAgIHJlbW92ZUVtcHR5U3RyaW5nczogZmFsc2UsXG4gICAgICAgICAgICAgIGZpbHRlcjogZmFsc2UsXG4gICAgICAgICAgICAgIGF1dG9Db252ZXJ0OiBmYWxzZVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGZ1bmN0aW9uKGVycm9yKSB7XG4gICAgICAgICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCAnSU5WQUxJRCcsIEVKU09OLnN0cmluZ2lmeShlcnJvci5pbnZhbGlkS2V5cykpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgXSxcbiAgICAgICAgICBmYWxzZSwgLy8gZ2V0QXV0b1ZhbHVlc1xuICAgICAgICAgIHVzZXJJZCxcbiAgICAgICAgICBmYWxzZSAvLyBpc0Zyb21UcnVzdGVkQ29kZVxuICAgICAgICApO1xuXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH0sXG4gICAgICB1cGRhdGU6IGZ1bmN0aW9uKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKSB7XG4gICAgICAgIC8vIE5PVEU6IFRoaXMgd2lsbCBuZXZlciBiZSBhbiB1cHNlcnQgYmVjYXVzZSBjbGllbnQtc2lkZSB1cHNlcnRzXG4gICAgICAgIC8vIGFyZSBub3QgYWxsb3dlZCBvbmNlIHlvdSBkZWZpbmUgYWxsb3cvZGVueSBmdW5jdGlvbnMuXG4gICAgICAgIC8vIFdlIHBhc3MgdGhlIGZhbHNlIG9wdGlvbnMgYmVjYXVzZSB3ZSB3aWxsIGhhdmUgZG9uZSB0aGVtIG9uIGNsaWVudCBpZiBkZXNpcmVkXG4gICAgICAgIGRvVmFsaWRhdGUuY2FsbChcbiAgICAgICAgICBjLFxuICAgICAgICAgIFwidXBkYXRlXCIsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge19pZDogZG9jICYmIGRvYy5faWR9LFxuICAgICAgICAgICAgbW9kaWZpZXIsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHRyaW1TdHJpbmdzOiBmYWxzZSxcbiAgICAgICAgICAgICAgcmVtb3ZlRW1wdHlTdHJpbmdzOiBmYWxzZSxcbiAgICAgICAgICAgICAgZmlsdGVyOiBmYWxzZSxcbiAgICAgICAgICAgICAgYXV0b0NvbnZlcnQ6IGZhbHNlXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZnVuY3Rpb24oZXJyb3IpIHtcbiAgICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDAsICdJTlZBTElEJywgRUpTT04uc3RyaW5naWZ5KGVycm9yLmludmFsaWRLZXlzKSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICBdLFxuICAgICAgICAgIGZhbHNlLCAvLyBnZXRBdXRvVmFsdWVzXG4gICAgICAgICAgdXNlcklkLFxuICAgICAgICAgIGZhbHNlIC8vIGlzRnJvbVRydXN0ZWRDb2RlXG4gICAgICAgICk7XG5cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfSxcbiAgICAgIGZldGNoOiBbJ19pZCddXG4gICAgfSwgb3B0aW9ucy50cmFuc2Zvcm0gPT09IHRydWUgPyB7fSA6IHt0cmFuc2Zvcm06IG51bGx9KSk7XG5cbiAgICAvLyBub3RlIHRoYXQgd2UndmUgYWxyZWFkeSBkb25lIHRoaXMgY29sbGVjdGlvbiBzbyB0aGF0IHdlIGRvbid0IGRvIGl0IGFnYWluXG4gICAgLy8gaWYgYXR0YWNoU2NoZW1hIGlzIGNhbGxlZCBhZ2FpblxuICAgIGFscmVhZHlEZWZpbmVkW2MuX25hbWVdID0gdHJ1ZTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBDb2xsZWN0aW9uMjtcbiJdfQ==
