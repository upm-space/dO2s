### This is my Markdown page

I can type **any** Markdown I want into this file and it will ultimately be `parsed` as HTML by dO2s's `utility.getPage` Method.

To learn more, you can [read about this Method here](http://cleverbeagle.com/pup/v1/the-basics/methods#utility-methods).
