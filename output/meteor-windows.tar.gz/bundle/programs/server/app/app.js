var require = meteorInstall({"imports":{"api":{"Batteries":{"server":{"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Batteries/server/publications.js                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);
var Batteries = void 0;
module.watch(require("../Batteries"), {
  default: function _default(v) {
    Batteries = v;
  }
}, 2);

_Meteor.publish('batteries', function batteries() {
  return Batteries.find({
    owner: this.userId
  });
}); // Note: batteries.view is also used when editing an existing document.


_Meteor.publish('batteries.view', function batteriesView(batteryId) {
  _check(batteryId, String);

  return Batteries.find({
    _id: batteryId,
    owner: this.userId
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Batteries.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Batteries/Batteries.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Mongo = void 0;

module.watch(require("meteor/mongo"), {
  Mongo: function Mongo(v) {
    _Mongo = v;
  }
}, 0);
var SimpleSchema = void 0;
module.watch(require("simpl-schema"), {
  default: function _default(v) {
    SimpleSchema = v;
  }
}, 1);
var Batteries = new _Mongo.Collection('Batteries');
Batteries.allow({
  insert: function insert() {
    return false;
  },
  update: function update() {
    return false;
  },
  remove: function remove() {
    return false;
  }
});
Batteries.deny({
  insert: function insert() {
    return true;
  },
  update: function update() {
    return true;
  },
  remove: function remove() {
    return true;
  }
});
Batteries.schema = new SimpleSchema({
  owner: {
    type: String,
    label: 'The ID of the user this battery belongs to.'
  },
  createdAt: {
    type: String,
    label: 'The date this battery was created in the database.',
    autoValue: function autoValue() {
      if (this.isInsert) return new Date().toISOString();
    }
  },
  updatedAt: {
    type: String,
    label: 'The date this battery was last updated.',
    autoValue: function autoValue() {
      if (this.isInsert || this.isUpdate) return new Date().toISOString();
    }
  },
  name: {
    type: String,
    label: 'A name to identify the battery.'
  },
  model: {
    type: String,
    label: 'The model of the battery.'
  },
  registrationNumber: {
    type: String,
    label: 'The serial number to identify the battery.'
  },
  amperes: {
    type: Number,
    label: 'The power this battery provides in Amperes.',
    min: 0
  },
  cellNumber: {
    type: SimpleSchema.Integer,
    label: 'The number of cells this battery has.',
    min: 0
  },
  weight: {
    type: Number,
    label: 'The weight of this battery in grams.',
    min: 0,
    optional: true
  },
  deleted: {
    type: String,
    label: 'The date the battery was deleted.',
    autoValue: function autoValue() {
      if (this.isInsert) return 'no';
    }
  },
  logData: {
    type: Object,
    optional: true,
    blackbox: true,
    label: 'Th log data for this battery, for maintenance purposes'
  }
});
Batteries.attachSchema(Batteries.schema);
module.exportDefault(Batteries);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Batteries/methods.js                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _extends2 = require("babel-runtime/helpers/extends");

var _extends3 = _interopRequireDefault(_extends2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);
var Batteries = void 0;
module.watch(require("./Batteries"), {
  default: function _default(v) {
    Batteries = v;
  }
}, 2);
var rateLimit = void 0;
module.watch(require("../../modules/rate-limit"), {
  default: function _default(v) {
    rateLimit = v;
  }
}, 3);
var newBatterySchema = Batteries.schema.pick('name', 'model', 'registrationNumber', 'amperes', 'cellNumber', 'weight');
var editBatterySchema = Batteries.schema.pick('name', 'model', 'registrationNumber', 'amperes', 'cellNumber', 'weight');
editBatterySchema.extend({
  _id: String
});

_Meteor.methods({
  'batteries.insert': function batteriesInsert(battery) {
    try {
      newBatterySchema.validate(battery);
      return Batteries.insert((0, _extends3.default)({
        owner: this.userId
      }, battery));
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'batteries.update': function batteriesUpdate(battery) {
    try {
      editBatterySchema.validate(battery);
      var batteryId = battery._id;
      Batteries.update(batteryId, {
        $set: battery
      });
      return batteryId; // Return _id so we can redirect to battery after update.
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'batteries.softDelete': function batteriesSoftDelete(batteryId) {
    _check(batteryId, String);

    try {
      Batteries.update(batteryId, {
        $set: {
          deleted: new Date().toISOString()
        }
      });
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'batteries.restore': function batteriesRestore(batteryId) {
    _check(batteryId, String);

    try {
      Batteries.update(batteryId, {
        $set: {
          deleted: 'no'
        }
      });
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'batteries.hardDelete': function batteriesHardDelete(batteryId) {
    _check(batteryId, String);

    try {
      return Batteries.remove(batteryId);
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  }
});

rateLimit({
  methods: ['batteries.insert', 'batteries.update', 'batteries.softDelete', 'batteries.restore', 'batteries.hardDelete'],
  limit: 5,
  timeRange: 1000
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"FlieTransferUtilities":{"server":{"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/FlieTransferUtilities/server/methods.js                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);
var path = void 0;
module.watch(require("path"), {
  default: function _default(v) {
    path = v;
  }
}, 2);
var fs = void 0;
module.watch(require("fs"), {
  default: function _default(v) {
    fs = v;
  }
}, 3);
var rateLimit = void 0;
module.watch(require("../../../modules/rate-limit"), {
  default: function _default(v) {
    rateLimit = v;
  }
}, 4);

var _saveFileFrombuffer = void 0,
    _deleteFile = void 0,
    _getFileList = void 0;

module.watch(require("../../../modules/server/file-system"), {
  saveFileFrombuffer: function saveFileFrombuffer(v) {
    _saveFileFrombuffer = v;
  },
  deleteFile: function deleteFile(v) {
    _deleteFile = v;
  },
  getFileList: function getFileList(v) {
    _getFileList = v;
  }
}, 5);

var Future = require('fibers/future');

_Meteor.methods({
  'fileTransfer.saveFile': function fileTransferSaveFile(buffer, missionId, fileName) {
    _check(buffer, Uint8Array);

    _check(missionId, String);

    _check(fileName, String);

    try {
      var missionDir = path.join(_Meteor.settings.private.config.missionsPath, missionId + "/");
      var future = new Future();

      _saveFileFrombuffer(buffer, missionDir, fileName, function (objJson) {
        future.return(objJson);
      });

      return future.wait();
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'fileTransfer.deleteFile': function fileTransferDeleteFile(missionId, fileName) {
    _check(missionId, String);

    _check(fileName, String);

    try {
      var missionDir = path.join(_Meteor.settings.private.config.missionsPath, missionId + "/");
      var future = new Future();

      _deleteFile(missionDir, fileName, function (objJson) {
        future.return(objJson);
      });

      return future.wait();
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'fileTransfer.saveFolder': function fileTransferSaveFolder(missionId, dirPath) {
    _check(missionId, String);

    _check(dirPath, String);

    try {
      var future = new Future();

      if (fs.existsSync(dirPath)) {
        var missionDir = path.join(_Meteor.settings.private.config.missionsPath, missionId + "/");

        _getFileList(dirPath, function (array) {
          array.forEach(function (fileName) {
            var filePath = path.join(dirPath, fileName);
            var newFilePath = path.join(missionDir, fileName);
            fs.copyFileSync(filePath, newFilePath);
          });
        });
      } else {
        throw Error('Directory not found');
      }

      return future.wait();
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  }
});

rateLimit({
  methods: ['fileTransfer.saveFile', 'fileTransfer.deleteFile', 'fileTransfer.saveFolder'],
  limit: 5,
  timeRange: 1000
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"Missions":{"server":{"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Missions/server/publications.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);
var Missions = void 0;
module.watch(require("../Missions"), {
  default: function _default(v) {
    Missions = v;
  }
}, 2);

_Meteor.publish('missions', function missions(projectId) {
  _check(projectId, String);

  return Missions.find({
    owner: this.userId,
    project: projectId
  });
}); // Note: missions.view is also used when editing an existing mission.


_Meteor.publish('missions.view', function missionsView(projectId, missionId) {
  _check(missionId, String);

  _check(projectId, String);

  return Missions.find({
    _id: missionId,
    owner: this.userId,
    project: projectId
  });
});

_Meteor.publish('missions.export', function missionsExport() {
  return Missions.find({
    owner: this.userId
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Missions.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Missions/Missions.js                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Mongo = void 0;

module.watch(require("meteor/mongo"), {
  Mongo: function Mongo(v) {
    _Mongo = v;
  }
}, 0);
var SimpleSchema = void 0;
module.watch(require("simpl-schema"), {
  default: function _default(v) {
    SimpleSchema = v;
  }
}, 1);

var _FeaturePoint = void 0,
    _FeaturePolygon = void 0,
    _FeatureLineString = void 0,
    _FeatureCollectionPoints = void 0;

module.watch(require("../SchemaUtilities/GeoJSONSchema.js"), {
  FeaturePoint: function FeaturePoint(v) {
    _FeaturePoint = v;
  },
  FeaturePolygon: function FeaturePolygon(v) {
    _FeaturePolygon = v;
  },
  FeatureLineString: function FeatureLineString(v) {
    _FeatureLineString = v;
  },
  FeatureCollectionPoints: function FeatureCollectionPoints(v) {
    _FeatureCollectionPoints = v;
  }
}, 2);
var Missions = new _Mongo.Collection('Missions');
Missions.allow({
  insert: function insert() {
    return false;
  },
  update: function update() {
    return false;
  },
  remove: function remove() {
    return false;
  }
});
Missions.deny({
  insert: function insert() {
    return true;
  },
  update: function update() {
    return true;
  },
  remove: function remove() {
    return true;
  }
});
var flightParametersSchema = new SimpleSchema({
  height: {
    type: Number,
    label: 'The altitude of the flight in meters',
    min: 0
  },
  speed: {
    type: Number,
    label: 'The speed of the flight in meters per second',
    min: 0
  },
  entryMargin: {
    type: Number,
    label: 'The entry margin for the fixed wing rpa in meters',
    min: 0
  },
  axisBuffer: {
    type: Number,
    label: 'The entry axis buffer for the linear mission in meters',
    min: 0,
    optional: true
  }
});
var pictureGridSchema = new SimpleSchema({
  overlap: {
    type: Number,
    label: 'The overlap in %',
    min: 0,
    max: 100
  },
  sidelap: {
    type: Number,
    label: 'The sidelap in %',
    min: 0,
    max: 100
  }
});
var missionCalculatedDataSchema = new SimpleSchema({
  flightTime: {
    type: String,
    label: 'The time it takes to complete the mission',
    min: 0,
    optional: true
  },
  flightTimeMinutes: {
    type: Number,
    label: 'The time it takes to complete the mission in minutes',
    min: 0,
    optional: true
  },
  pathLength: {
    type: Number,
    label: 'The length the rpa is going to travel in meters',
    min: 0,
    optional: true
  },
  resolution: {
    type: Number,
    label: 'The ground resolution obtained in cm/px',
    min: 0,
    optional: true
  },
  shootTime: {
    type: Number,
    label: 'Time betweeen photos in seconds',
    min: 0,
    optional: true
  },
  totalArea: {
    type: Number,
    label: 'The total area for the photogrametric image in hectares',
    min: 0,
    optional: true
  },
  distPics: {
    type: Number,
    label: 'Distance betweeen photos in meters',
    min: 0,
    optional: true
  }
});
var missionCalculationSchema = new SimpleSchema({
  waypointList: {
    type: _FeatureCollectionPoints,
    label: 'Feature Collection representing the waypoints for the mission',
    optional: true
  },
  missionCalculatedData: {
    type: missionCalculatedDataSchema,
    label: 'This is the data obtained from calculating the mission',
    optional: true
  }
});
Missions.schema = new SimpleSchema({
  owner: {
    type: String,
    label: 'The ID of the user this mission belongs to.'
  },
  project: {
    type: String,
    label: 'The ID of the project this mission belongs to.'
  },
  createdAt: {
    type: String,
    label: 'The date this mission was created.',
    autoValue: function autoValue() {
      if (this.isInsert) return new Date().toISOString();
    }
  },
  updatedAt: {
    type: String,
    label: 'The date this mission was last updated.',
    autoValue: function autoValue() {
      if (this.isInsert || this.isUpdate) return new Date().toISOString();
    }
  },
  name: {
    type: String,
    label: 'The name of the mission.'
  },
  description: {
    type: String,
    label: 'The description of the mission.',
    optional: true
  },
  rpa: {
    type: String,
    label: 'The ID of the remote propelled aircraft used.'
  },
  payload: {
    type: String,
    label: 'The ID of the payload used.'
  },
  missionType: {
    type: String,
    label: 'The mission type',
    allowedValues: ['Surface Area', 'Linear Area']
  },
  layers: {
    type: Array,
    label: 'The layers requested for the mission',
    optional: true
  },
  'layers.$': {
    type: String,
    label: 'The name of the layer requested for the mission'
  },
  flightPlan: {
    type: Object,
    label: 'All the data related to the flight',
    optional: true
  },
  'flightPlan.takeOffPoint': {
    type: _FeaturePoint,
    label: 'The take off point for the flight',
    optional: true
  },
  'flightPlan.landingPoint': {
    type: _FeaturePoint,
    label: 'The landing point for the flight',
    optional: true
  },
  'flightPlan.missionArea': {
    type: _FeaturePolygon,
    label: 'All the data related to the area for the flight',
    optional: true
  },
  'flightPlan.missionAxis': {
    type: _FeatureLineString,
    label: 'All the data related to the axis for the flight',
    optional: true
  },
  'flightPlan.flightParameters': {
    type: flightParametersSchema,
    label: 'Data related to the flight',
    optional: true
  },
  'flightPlan.pictureGrid': {
    type: pictureGridSchema,
    label: 'All the data related to the area for the flight',
    optional: true
  },
  'flightPlan.missionCalculation': {
    type: missionCalculationSchema,
    label: 'This is where we store the data from the waypoint calculation',
    optional: true
  },
  'flightPlan.landingBearing': {
    type: _FeatureLineString,
    label: 'This is a geoJSON feature representing the angle for the landing path',
    optional: true
  },
  deleted: {
    type: String,
    label: 'The date the mission was deleted.',
    autoValue: function autoValue() {
      if (this.isInsert) return 'no';
    }
  },
  done: {
    type: Boolean,
    label: 'Is the mission done?',
    autoValue: function autoValue() {
      if (this.isInsert) return false;
    }
  },
  status: {
    type: String,
    label: 'How is the mission doing?',
    optional: true
  }
});
Missions.attachSchema(Missions.schema);
module.exportDefault(Missions);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Missions/methods.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _extends2 = require("babel-runtime/helpers/extends");

var _extends3 = _interopRequireDefault(_extends2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);
var fs = void 0;
module.watch(require("fs"), {
  default: function _default(v) {
    fs = v;
  }
}, 2);
var path = void 0;
module.watch(require("path"), {
  default: function _default(v) {
    path = v;
  }
}, 3);
var Missions = void 0;
module.watch(require("./Missions"), {
  default: function _default(v) {
    Missions = v;
  }
}, 4);
var rateLimit = void 0;
module.watch(require("../../modules/rate-limit"), {
  default: function _default(v) {
    rateLimit = v;
  }
}, 5);

var _deleteFolderRecursiveSync = void 0;

module.watch(require("../../modules/server/file-system"), {
  deleteFolderRecursiveSync: function deleteFolderRecursiveSync(v) {
    _deleteFolderRecursiveSync = v;
  }
}, 6);

var _FeaturePoint = void 0,
    _FeaturePolygon = void 0,
    _FeatureLineString = void 0,
    _FeatureCollectionPoints = void 0;

module.watch(require("../SchemaUtilities/GeoJSONSchema.js"), {
  FeaturePoint: function FeaturePoint(v) {
    _FeaturePoint = v;
  },
  FeaturePolygon: function FeaturePolygon(v) {
    _FeaturePolygon = v;
  },
  FeatureLineString: function FeatureLineString(v) {
    _FeatureLineString = v;
  },
  FeatureCollectionPoints: function FeatureCollectionPoints(v) {
    _FeatureCollectionPoints = v;
  }
}, 7);
var newMissionSchema = Missions.schema.pick('name', 'project', 'rpa', 'missionType', 'description', 'payload');
var importMissionSchema = Missions.schema.pick('name', 'project', 'rpa', 'missionType', 'description', 'payload', 'flightPlan');
var editMissionSchema = Missions.schema.pick('name', 'project', 'rpa', 'missionType', 'description', 'payload');
editMissionSchema.extend({
  _id: String
});

_Meteor.methods({
  'missions.insert': function missionsInsert(mission) {
    try {
      newMissionSchema.validate(mission);
      var newMissionID = Missions.insert((0, _extends3.default)({
        owner: this.userId
      }, mission));
      var missionDir = path.join(_Meteor.settings.private.config.missionsPath, newMissionID);
      fs.mkdirSync(missionDir);
      return newMissionID;
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.import': function missionsImport(mission) {
    try {
      importMissionSchema.validate(mission);
      return Missions.insert((0, _extends3.default)({
        owner: this.userId
      }, mission));
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.update': function missionsUpdate(mission) {
    try {
      editMissionSchema.validate(mission);
      var missionId = mission._id;
      Missions.update(missionId, {
        $set: mission
      });
      return missionId; // Return _id so we can redirect to document after update.
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.softDelete': function missionsSoftDelete(missionId) {
    _check(missionId, String);

    try {
      Missions.update(missionId, {
        $set: {
          deleted: new Date().toISOString()
        }
      });
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.restore': function missionsRestore(missionId) {
    _check(missionId, String);

    try {
      Missions.update(missionId, {
        $set: {
          deleted: 'no'
        }
      });
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.hardDelete': function missionsHardDelete(missionId) {
    _check(missionId, String);

    try {
      var missionDir = path.join(_Meteor.settings.private.config.missionsPath, missionId);

      _deleteFolderRecursiveSync(missionDir, true);

      return Missions.remove(missionId);
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.setDone': function missionsSetDone(missionId, setDone) {
    _check(missionId, String);

    _check(setDone, Boolean);

    try {
      Missions.update(missionId, {
        $set: {
          done: setDone
        }
      });
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.setTakeOffPoint': function missionsSetTakeOffPoint(missionId, takeOffPoint) {
    _check(missionId, String);

    try {
      _FeaturePoint.validate(takeOffPoint);

      Missions.update(missionId, {
        $set: {
          'flightPlan.takeOffPoint': takeOffPoint
        }
      });
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.setLandingPoint': function missionsSetLandingPoint(missionId, landingPoint) {
    _check(missionId, String);

    try {
      _FeaturePoint.validate(landingPoint);

      Missions.update(missionId, {
        $set: {
          'flightPlan.landingPoint': landingPoint
        }
      });
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.setMissionGeometry': function missionsSetMissionGeometry(missionId, missionGeometry) {
    _check(missionId, String);

    try {
      var mission = Missions.findOne(missionId);

      if (missionGeometry) {
        if (mission.missionType === 'Surface Area') {
          _FeaturePolygon.validate(missionGeometry);

          Missions.update(missionId, {
            $set: {
              'flightPlan.missionArea': missionGeometry
            }
          });
        } else if (mission.missionType === 'Linear Area') {
          _FeatureLineString.validate(missionGeometry);

          Missions.update(missionId, {
            $set: {
              'flightPlan.missionAxis': missionGeometry
            }
          });
        }
      } else if (!missionGeometry) {
        if (mission.missionType === 'Surface Area') {
          Missions.update(missionId, {
            $unset: {
              'flightPlan.missionArea': ''
            }
          });
        } else if (mission.missionType === 'Linear Area') {
          Missions.update(missionId, {
            $unset: {
              'flightPlan.missionAxis': ''
            }
          });
        }
      }
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.setFlightParams': function missionsSetFlightParams(missionId, flightParameters) {
    _check(missionId, String);

    try {
      var flightParamsSchema = Missions.schema.getObjectSchema('flightPlan.flightParameters');
      flightParamsSchema.validate(flightParameters);
      Missions.update(missionId, {
        $set: {
          'flightPlan.flightParameters': flightParameters
        }
      });
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.setPictureGrid': function missionsSetPictureGrid(missionId, pictureGrid) {
    _check(missionId, String);

    try {
      var pictureGridSchema = Missions.schema.getObjectSchema('flightPlan.pictureGrid');
      pictureGridSchema.validate(pictureGrid);
      Missions.update(missionId, {
        $set: {
          'flightPlan.pictureGrid': pictureGrid
        }
      });
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.setMissionCalculations': function missionsSetMissionCalculations(missionId, missionCalculationsData) {
    try {
      var missionCalculatedDataSchema = Missions.schema.getObjectSchema('flightPlan.missionCalculation.missionCalculatedData');
      missionCalculatedDataSchema.validate(missionCalculationsData.missionCalculatedData);

      _FeatureCollectionPoints.validate(missionCalculationsData.waypointList);

      Missions.update(missionId, {
        $set: {
          'flightPlan.missionCalculation': missionCalculationsData
        }
      });
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.editWayPointList': function missionsEditWaypointList(missionId, newWayPointList) {
    _check(missionId, String);

    try {
      _FeatureCollectionPoints.validate(newWayPointList);

      Missions.update(missionId, {
        $set: {
          'flightPlan.missionCalculation.waypointList': newWayPointList
        }
      });
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.clearWayPoints': function missionsClearWayPoints(missionId) {
    try {
      Missions.update(missionId, {
        $unset: {
          'flightPlan.takeOffPoint': ''
        }
      });
      Missions.update(missionId, {
        $unset: {
          'flightPlan.landingPoint': ''
        }
      });
      Missions.update(missionId, {
        $unset: {
          'flightPlan.missionArea': ''
        }
      });
      Missions.update(missionId, {
        $unset: {
          'flightPlan.missionAxis': ''
        }
      });
      Missions.update(missionId, {
        $unset: {
          'flightPlan.missionCalculation': ''
        }
      });
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.editWayPointAltRelative': function missionsEditWaypointList(missionId, waypointIndex, newWayPointAltRelative) {
    _check(missionId, String);

    _check(waypointIndex, Number);

    _check(newWayPointAltRelative, Number);

    try {
      Missions.update({
        _id: missionId,
        'flightPlan.missionCalculation.waypointList.features.properties.totalNumber': waypointIndex
      }, {
        $set: {
          'flightPlan.missionCalculation.waypointList.features.$.properties.altRelative': newWayPointAltRelative
        }
      });
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'missions.setLandingBearing': function missionsSetLandingBearing(missionId, landingBearing) {
    _check(missionId, String);

    try {
      if (landingBearing) {
        _FeatureLineString.validate(landingBearing);

        Missions.update(missionId, {
          $set: {
            'flightPlan.landingBearing': landingBearing
          }
        });
      } else if (!landingBearing) {
        Missions.update(missionId, {
          $unset: {
            'flightPlan.landingBearing': ''
          }
        });
      }
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  }
});

rateLimit({
  methods: ['missions.insert', 'missions.import', 'missions.update', 'missions.softDelete', 'missions.restore', 'missions.hardDelete', 'missions.setDone', 'missions.setLandingPoint', 'missions.setTakeOffPoint', 'missions.setMissionGeometry', 'missions.setFlightParams', 'missions.setPictureGrid', 'missions.setMissionCalculations', 'missions.editWayPointList', 'missions.clearWayPoints', 'missions.editWayPointAltRelative', 'missions.setLandingBearing'],
  limit: 5,
  timeRange: 1000
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"OAuth":{"server":{"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/OAuth/server/methods.js                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);

var _ServiceConfiguration = void 0;

module.watch(require("meteor/service-configuration"), {
  ServiceConfiguration: function ServiceConfiguration(v) {
    _ServiceConfiguration = v;
  }
}, 2);
var rateLimit = void 0;
module.watch(require("../../../modules/rate-limit"), {
  default: function _default(v) {
    rateLimit = v;
  }
}, 3);

_Meteor.methods({
  'oauth.verifyConfiguration': function oauthVerifyConfiguration(services) {
    _check(services, Array);

    try {
      var verifiedServices = [];
      services.forEach(function (service) {
        if (_ServiceConfiguration.configurations.findOne({
          service: service
        })) {
          verifiedServices.push(service);
        }
      });
      return verifiedServices.sort();
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  }
});

rateLimit({
  methods: ['oauth.verifyConfiguration'],
  limit: 5,
  timeRange: 1000
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"Payloads":{"server":{"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Payloads/server/publications.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);
var Payloads = void 0;
module.watch(require("../Payloads"), {
  default: function _default(v) {
    Payloads = v;
  }
}, 2);

_Meteor.publish('payloads', function payloads() {
  return Payloads.find({
    owner: this.userId
  });
}); // Note: payloads.view is also used when editing an existing document.


_Meteor.publish('payloads.view', function payloadsView(payloadId) {
  _check(payloadId, String);

  return Payloads.find({
    _id: payloadId,
    owner: this.userId
  });
});

_Meteor.publish('payloads.mission', function payloadsMission() {
  return Payloads.find({
    owner: this.userId
  }, {
    fields: {
      name: 1,
      model: 1
    }
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Payloads.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Payloads/Payloads.js                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Mongo = void 0;

module.watch(require("meteor/mongo"), {
  Mongo: function Mongo(v) {
    _Mongo = v;
  }
}, 0);
var SimpleSchema = void 0;
module.watch(require("simpl-schema"), {
  default: function _default(v) {
    SimpleSchema = v;
  }
}, 1);
var Payloads = new _Mongo.Collection('Payloads');
Payloads.allow({
  insert: function insert() {
    return false;
  },
  update: function update() {
    return false;
  },
  remove: function remove() {
    return false;
  }
});
Payloads.deny({
  insert: function insert() {
    return true;
  },
  update: function update() {
    return true;
  },
  remove: function remove() {
    return true;
  }
});
var cameraParametersSchema = new SimpleSchema({
  focalLength: {
    type: Number,
    label: 'The focal length of the camera in milimeters',
    min: 1
  },
  sensorWidth: {
    type: Number,
    label: 'The sensor width in milimeters',
    min: 1
  },
  sensorHeight: {
    type: Number,
    label: 'The sensor height in milimeters',
    min: 1
  },
  imageWidth: {
    type: Number,
    label: 'The image width in pixels',
    min: 1
  },
  imageHeight: {
    type: Number,
    label: 'The image height in pixels',
    min: 1
  }
});
Payloads.schema = new SimpleSchema({
  owner: {
    type: String,
    label: 'The ID of the user this payload belongs to.'
  },
  createdAt: {
    type: String,
    label: 'The date this payload was created.',
    autoValue: function autoValue() {
      if (this.isInsert) return new Date().toISOString();
    }
  },
  updatedAt: {
    type: String,
    label: 'The date this payload was last updated.',
    autoValue: function autoValue() {
      if (this.isInsert || this.isUpdate) return new Date().toISOString();
    }
  },
  name: {
    type: String,
    label: 'A name to identify the payload.'
  },
  registrationNumber: {
    type: String,
    label: 'The serial number to identify the payload.',
    optional: true
  },
  model: {
    type: String,
    label: 'The model of the payload.'
  },
  weight: {
    type: Number,
    label: 'The weight of this payload in grams.',
    min: 0,
    optional: true
  },
  payloadType: {
    type: String,
    allowedValues: ['Camera'],
    label: 'The type of sensor of the payload.'
  },
  deleted: {
    type: String,
    label: 'The date the payload was deleted.',
    autoValue: function autoValue() {
      if (this.isInsert) return 'no';
    }
  },
  sensorParameters: {
    type: SimpleSchema.oneOf(cameraParametersSchema),
    label: 'The parameters for the payload sensor.'
  }
});
Payloads.attachSchema(Payloads.schema);
module.exportDefault(Payloads);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Payloads/methods.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _extends2 = require("babel-runtime/helpers/extends");

var _extends3 = _interopRequireDefault(_extends2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);
var Payloads = void 0;
module.watch(require("./Payloads"), {
  default: function _default(v) {
    Payloads = v;
  }
}, 2);
var rateLimit = void 0;
module.watch(require("../../modules/rate-limit"), {
  default: function _default(v) {
    rateLimit = v;
  }
}, 3);
var newPayloadSchema = Payloads.schema.pick('name', 'registrationNumber', 'model', 'weight', 'payloadType', 'sensorParameters');
var editPayloadSchema = Payloads.schema.pick('name', 'registrationNumber', 'model', 'weight', 'payloadType', 'sensorParameters');
editPayloadSchema.extend({
  _id: String
});

_Meteor.methods({
  'payloads.insert': function payloadsInsert(payload) {
    try {
      newPayloadSchema.validate(payload);
      return Payloads.insert((0, _extends3.default)({
        owner: this.userId
      }, payload));
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'payloads.update': function payloadsUpdate(payload) {
    try {
      editPayloadSchema.validate(payload);
      var payloadId = payload._id;
      Payloads.update(payloadId, {
        $set: payload
      });
      return payloadId; // Return _id so we can redirect to payload after update.
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'payloads.softDelete': function payloadsSoftDelete(payloadId) {
    _check(payloadId, String);

    try {
      Payloads.update(payloadId, {
        $set: {
          deleted: new Date().toISOString()
        }
      });
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'payloads.restore': function payloadsRestore(payloadId) {
    _check(payloadId, String);

    try {
      Payloads.update(payloadId, {
        $set: {
          deleted: 'no'
        }
      });
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'payloads.hardDelete': function payloadsHardDelete(payloadId) {
    _check(payloadId, String);

    try {
      return Payloads.remove(payloadId);
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  }
});

rateLimit({
  methods: ['payloads.insert', 'payloads.update', 'payloads.softDelete', 'payloads.restore', 'payloads.hardDelete'],
  limit: 5,
  timeRange: 1000
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Projects":{"server":{"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Projects/server/publications.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);
var Projects = void 0;
module.watch(require("../Projects"), {
  default: function _default(v) {
    Projects = v;
  }
}, 2);

_Meteor.publish('projects', function projects() {
  return Projects.find({
    owner: this.userId
  });
}); // Note: projects.view is also used when editing an existing document.


_Meteor.publish('projects.view', function projectsView(projectId) {
  _check(projectId, String);

  return Projects.find({
    _id: projectId,
    owner: this.userId
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Projects.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Projects/Projects.js                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Mongo = void 0;

module.watch(require("meteor/mongo"), {
  Mongo: function Mongo(v) {
    _Mongo = v;
  }
}, 0);
var SimpleSchema = void 0;
module.watch(require("simpl-schema"), {
  default: function _default(v) {
    SimpleSchema = v;
  }
}, 1);

var _FeaturePoint = void 0;

module.watch(require("../SchemaUtilities/GeoJSONSchema.js"), {
  FeaturePoint: function FeaturePoint(v) {
    _FeaturePoint = v;
  }
}, 2);
var Projects = new _Mongo.Collection('Projects');
Projects.allow({
  insert: function insert() {
    return false;
  },
  update: function update() {
    return false;
  },
  remove: function remove() {
    return false;
  }
});
Projects.deny({
  insert: function insert() {
    return true;
  },
  update: function update() {
    return true;
  },
  remove: function remove() {
    return true;
  }
});
Projects.schema = new SimpleSchema({
  owner: {
    type: String,
    label: 'The ID of the user this project belongs to.'
  },
  createdAt: {
    type: String,
    label: 'The date this project was created.',
    autoValue: function autoValue() {
      if (this.isInsert) return new Date().toISOString();
    }
  },
  updatedAt: {
    type: String,
    label: 'The date this project was last updated.',
    autoValue: function autoValue() {
      if (this.isInsert || this.isUpdate) return new Date().toISOString();
    }
  },
  name: {
    type: String,
    label: 'The name of the project.'
  },
  description: {
    type: String,
    optional: true,
    label: 'The description of the project.'
  },
  mapLocation: {
    type: _FeaturePoint,
    label: 'The location of the project for the map.'
  },
  deleted: {
    type: String,
    label: 'The date the project was deleted.',
    autoValue: function autoValue() {
      if (this.isInsert) return 'no';
    }
  },
  done: {
    type: Boolean,
    label: 'Is the project done?',
    autoValue: function autoValue() {
      if (this.isInsert) return false;
    }
  }
});
Projects.attachSchema(Projects.schema);
module.exportDefault(Projects);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Projects/methods.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _extends2 = require("babel-runtime/helpers/extends");

var _extends3 = _interopRequireDefault(_extends2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);
var Projects = void 0;
module.watch(require("./Projects"), {
  default: function _default(v) {
    Projects = v;
  }
}, 2);
var rateLimit = void 0;
module.watch(require("../../modules/rate-limit"), {
  default: function _default(v) {
    rateLimit = v;
  }
}, 3);
var newProjectSchema = Projects.schema.pick('name', 'description', 'mapLocation');
var editProjectSchema = Projects.schema.pick('name', 'description', 'mapLocation');
editProjectSchema.extend({
  _id: String
});

_Meteor.methods({
  'projects.insert': function projectsInsert(project) {
    try {
      newProjectSchema.validate(project);
      return Projects.insert((0, _extends3.default)({
        owner: this.userId
      }, project));
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'projects.update': function projectsUpdate(project) {
    try {
      editProjectSchema.validate(project);
      var projectId = project._id;
      Projects.update(projectId, {
        $set: project
      });
      return projectId; // Return _id so we can redirect to project after update.
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'projects.softDelete': function projectsSoftDelete(projectId) {
    _check(projectId, String);

    try {
      Projects.update(projectId, {
        $set: {
          deleted: new Date().toISOString()
        }
      });
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'projects.restore': function projectsRestore(projectId) {
    _check(projectId, String);

    try {
      Projects.update(projectId, {
        $set: {
          deleted: 'no'
        }
      });
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'projects.hardDelete': function projectsHardDelete(projectId) {
    _check(projectId, String);

    try {
      return Projects.remove(projectId);
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'projects.setDone': function projectsSetDone(projectId, setDone) {
    _check(projectId, String);

    _check(setDone, Boolean);

    try {
      Projects.update(projectId, {
        $set: {
          done: setDone
        }
      });
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  }
});

rateLimit({
  methods: ['projects.insert', 'projects.update', 'projects.softDelete', 'projects.restore', 'projects.hardDelete', 'projects.setDone'],
  limit: 5,
  timeRange: 1000
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"RPAs":{"server":{"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/RPAs/server/publications.js                                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);
var RPAs = void 0;
module.watch(require("../RPAs"), {
  default: function _default(v) {
    RPAs = v;
  }
}, 2);

_Meteor.publish('rpas', function rpas() {
  return RPAs.find({
    owner: this.userId
  });
}); // Note: documents.view is also used when editing an existing document.


_Meteor.publish('rpas.view', function rpasView(rpaId) {
  _check(rpaId, String);

  return RPAs.find({
    _id: rpaId,
    owner: this.userId
  });
});

_Meteor.publish('rpas.mission', function rpasMission() {
  return RPAs.find({
    owner: this.userId
  }, {
    fields: {
      name: 1,
      rpaType: 1
    }
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"RPAs.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/RPAs/RPAs.js                                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Mongo = void 0;

module.watch(require("meteor/mongo"), {
  Mongo: function Mongo(v) {
    _Mongo = v;
  }
}, 0);
var SimpleSchema = void 0;
module.watch(require("simpl-schema"), {
  default: function _default(v) {
    SimpleSchema = v;
  }
}, 1);
var RPAs = new _Mongo.Collection('RPAs');
RPAs.allow({
  insert: function insert() {
    return false;
  },
  update: function update() {
    return false;
  },
  remove: function remove() {
    return false;
  }
});
RPAs.deny({
  insert: function insert() {
    return true;
  },
  update: function update() {
    return true;
  },
  remove: function remove() {
    return true;
  }
});
var flightParametersSchema = new SimpleSchema({
  maxDescendSlope: {
    type: SimpleSchema.Integer,
    label: 'The max slope for the descend of the rpas in %',
    min: 0,
    max: 100
  },
  maxAscendSlope: {
    type: SimpleSchema.Integer,
    label: 'The max slope for the descend of the rpas in %',
    min: 0,
    max: 100
  },
  optimalLandingSlope: {
    type: SimpleSchema.Integer,
    label: 'The optimal slope for the landing the rpas in %',
    min: 0,
    max: 100
  },
  optimalTakeOffSlope: {
    type: SimpleSchema.Integer,
    label: 'The optimal slope for the takeoff of the rpas in %',
    min: 0,
    max: 100
  },
  maxLandSpeed: {
    type: SimpleSchema.Integer,
    label: 'The max landing speed for the copter rpas in cm/s',
    min: 0,
    max: 200
  }
});
RPAs.schema = new SimpleSchema({
  owner: {
    type: String,
    label: 'The ID of the user this rpas belongs to.'
  },
  createdAt: {
    type: String,
    label: 'The date this rpas was created.',
    autoValue: function autoValue() {
      if (this.isInsert) return new Date().toISOString();
    }
  },
  updatedAt: {
    type: String,
    label: 'The date this rpas was last updated.',
    autoValue: function autoValue() {
      if (this.isInsert || this.isUpdate) return new Date().toISOString();
    }
  },
  name: {
    type: String,
    label: 'The name of the rpas.'
  },
  rpaType: {
    type: String,
    label: 'The type of the rpas.',
    allowedValues: ['Plane', 'MultiCopter']
  },
  model: {
    type: String,
    label: 'The model of the rpas.',
    optional: true
  },
  registrationNumber: {
    type: String,
    label: 'The registration number of this rpas.',
    optional: true
  },
  constructionDate: {
    type: String,
    label: 'The date this rpas was built.',
    optional: true
  },
  serialNumber: {
    type: String,
    label: 'The serial number of this rpas.',
    optional: true
  },
  weight: {
    type: Number,
    label: 'The weight of this rpas in grams.',
    min: 0,
    optional: true
  },
  flightParameters: {
    type: flightParametersSchema,
    label: 'The parameters for the rpas flight.'
  },
  deleted: {
    type: String,
    label: 'The date the rpas was deleted.',
    autoValue: function autoValue() {
      if (this.isInsert) return 'no';
    }
  }
});
RPAs.attachSchema(RPAs.schema);
module.exportDefault(RPAs);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/RPAs/methods.js                                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _extends2 = require("babel-runtime/helpers/extends");

var _extends3 = _interopRequireDefault(_extends2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);
var RPAs = void 0;
module.watch(require("./RPAs"), {
  default: function _default(v) {
    RPAs = v;
  }
}, 2);
var rateLimit = void 0;
module.watch(require("../../modules/rate-limit"), {
  default: function _default(v) {
    rateLimit = v;
  }
}, 3);
var newRPASchema = RPAs.schema.pick('name', 'rpaType', 'model', 'registrationNumber', 'constructionDate', 'serialNumber', 'weight', 'flightParameters');
var editRPASchema = RPAs.schema.pick('name', 'rpaType', 'model', 'registrationNumber', 'constructionDate', 'serialNumber', 'weight', 'flightParameters');
editRPASchema.extend({
  _id: String
});

_Meteor.methods({
  'rpas.insert': function rpasInsert(rpa) {
    try {
      newRPASchema.validate(rpa);
      return RPAs.insert((0, _extends3.default)({
        owner: this.userId
      }, rpa));
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'rpas.update': function rpasUpdate(rpa) {
    try {
      editRPASchema.validate(rpa);
      var rpaId = rpa._id;
      RPAs.update(rpaId, {
        $set: rpa
      });
      return rpaId; // Return _id so we can redirect to document after update.
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'rpas.softDelete': function rpasSoftDelete(rpaId) {
    _check(rpaId, String);

    try {
      RPAs.update(rpaId, {
        $set: {
          deleted: new Date().toISOString()
        }
      });
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'rpas.restore': function rpasRestore(rpaId) {
    _check(rpaId, String);

    try {
      RPAs.update(rpaId, {
        $set: {
          deleted: 'no'
        }
      });
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'rpas.hardDelete': function rpasHardDelete(rpasId) {
    _check(rpasId, String);

    try {
      return RPAs.remove(rpasId);
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  }
});

rateLimit({
  methods: ['rpas.insert', 'rpas.update', 'rpas.softDelete', 'rpas.restore', 'rpas.hardDelete'],
  limit: 5,
  timeRange: 1000
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Users":{"server":{"edit-profile.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Users/server/edit-profile.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _Accounts = void 0;

module.watch(require("meteor/accounts-base"), {
  Accounts: function Accounts(v) {
    _Accounts = v;
  }
}, 1);
var action = void 0;

var updateUser = function updateUser(userId, _ref) {
  var emailAddress = _ref.emailAddress,
      profile = _ref.profile;
  console.log(userId, emailAddress, JSON.stringify(profile));

  try {
    var currentEmail = _Meteor.users.find({
      _id: userId
    }, {
      fields: {
        emails: 1
      }
    }).fetch()[0].emails[0].address;

    if (emailAddress === currentEmail) {
      _Meteor.users.update(userId, {
        $set: {
          profile: profile
        }
      });
    } else {
      _Meteor.users.update(userId, {
        $set: {
          'emails.0.address': emailAddress,
          'emails.0.verified': false,
          profile: profile
        }
      }, function (error) {
        if (error) {
          throw new _Meteor.Error('500', error.reason);
        } else {
          _Accounts.sendVerificationEmail(userId);
        }
      });
    }
  } catch (exception) {
    action.reject("[editProfile.updateUser] " + exception);
  }
};

var editProfile = function editProfile(_ref2, promise) {
  var userId = _ref2.userId,
      profile = _ref2.profile;
  console.log('calls inside edit-profile');
  console.log(userId, JSON.stringify(profile));

  try {
    action = promise;
    updateUser(userId, profile);
    action.resolve();
  } catch (exception) {
    action.reject("[editProfile.handler] " + exception);
  }
};

module.exportDefault(function (options) {
  return new Promise(function (resolve, reject) {
    return editProfile(options, {
      resolve: resolve,
      reject: reject
    });
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Users/server/methods.js                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);

var _Accounts = void 0;

module.watch(require("meteor/accounts-base"), {
  Accounts: function Accounts(v) {
    _Accounts = v;
  }
}, 2);

var _Roles = void 0;

module.watch(require("meteor/alanning:roles"), {
  Roles: function Roles(v) {
    _Roles = v;
  }
}, 3);
var SimpleSchema = void 0;
module.watch(require("simpl-schema"), {
  default: function _default(v) {
    SimpleSchema = v;
  }
}, 4);
var editProfile = void 0;
module.watch(require("./edit-profile"), {
  default: function _default(v) {
    editProfile = v;
  }
}, 5);
var rateLimit = void 0;
module.watch(require("../../../modules/rate-limit"), {
  default: function _default(v) {
    rateLimit = v;
  }
}, 6);
var newUserSchema = new SimpleSchema({
  profile: {
    type: Object
  },
  'profile.name': {
    type: Object
  },
  'profile.name.first': {
    type: String
  },
  'profile.name.last': {
    type: String
  },
  email: {
    type: String,
    regEx: SimpleSchema.RegEx.Email
  },
  password: {
    type: String,
    min: 6
  }
});
var editUserSchema = new SimpleSchema({
  profile: {
    type: Object
  },
  'profile.name': {
    type: Object
  },
  'profile.name.first': {
    type: String
  },
  'profile.name.last': {
    type: String
  },
  email: {
    type: String,
    regEx: SimpleSchema.RegEx.Email
  },
  _id: String
});

_Meteor.methods({
  'users.changeRole': function usersChangeRole(userId, newRole) {
    _check(userId, String);

    _check(newRole, String);

    if (_Roles.userIsInRole(this.userId, ['admin'])) {
      _Roles.setUserRoles(userId, newRole);
    } else if (_Roles.userIsInRole(userId, ['admin'])) {
      throw new _Meteor.Error('500', 'No way Jose');
    } else {
      throw new _Meteor.Error('500', 'Ha! Nice try, slick.');
    }
  },
  'users.sendVerificationEmail': function sendVerificationEmail(userId) {
    return _Accounts.sendVerificationEmail(userId);
  },
  'users.setPassword': function usersSetPassword(userId) {
    try {
      return _Accounts.setPassword(userId, 'password');
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'users.editProfile': function usersEditProfile(profile) {
    _check(profile, {
      emailAddress: String,
      profile: {
        name: {
          first: String,
          last: String
        }
      }
    });

    return editProfile({
      userId: this.userId,
      profile: profile
    }).then(function (response) {
      return response;
    }).catch(function (exception) {
      throw new _Meteor.Error('500', exception);
    });
  },
  'users.softDelete': function usersSoftDelete(userId) {
    _check(userId, String);

    try {
      if (_Roles.userIsInRole(this.userId, ['admin'])) {
        _Meteor.users.update(userId, {
          $set: {
            deleted: new Date().toISOString()
          }
        });
      } else if (_Roles.userIsInRole(userId, ['admin'])) {
        throw new _Meteor.Error('500', 'No way Jose');
      } else {
        throw new _Meteor.Error('500', 'Ha! Nice try, slick.');
      }
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'users.restore': function projectsRestore(userId) {
    _check(userId, String);

    try {
      if (_Roles.userIsInRole(this.userId, ['admin'])) {
        _Meteor.users.update(userId, {
          $set: {
            deleted: 'no'
          }
        });
      } else {
        throw new _Meteor.Error('500', 'Ha! Nice try, slick.');
      }
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'users.hardDelete': function usersHardDelete(userId) {
    _check(userId, String);

    try {
      if (_Roles.userIsInRole(this.userId, ['admin'])) {
        _Meteor.users.remove(userId);
      } else if (_Roles.userIsInRole(userId, ['admin'])) {
        throw new _Meteor.Error('500', 'No way Jose');
      } else {
        throw new _Meteor.Error('500', 'Ha! Nice try, slick.');
      }
    } catch (exception) {
      throw new _Meteor.Error('500', exception);
    }
  },
  'users.insert': function usersInsert(user) {
    try {
      newUserSchema.validate(user);
      return _Accounts.createUser(user);
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  },
  'users.update': function usersUpdate(user) {
    console.log('calling users.update');
    console.log(JSON.stringify(user));

    try {
      editUserSchema.validate(user);
      var userProfile = {
        emailAddress: user.email,
        profile: {
          name: {
            first: user.profile.name.first,
            last: user.profile.name.last
          }
        }
      };
      console.log("userProfile " + JSON.stringify(userProfile));
      return editProfile({
        userId: user._id,
        userProfile: userProfile
      }).then(function (response) {
        return response;
      }).catch(function (exception) {
        throw new _Meteor.Error('500', exception);
      });
    } catch (exception) {
      if (exception.error === 'validation-error') {
        throw new _Meteor.Error(500, exception.message);
      }

      throw new _Meteor.Error('500', exception);
    }
  }
});

rateLimit({
  methods: ['users.editProfile', 'users.sendVerificationEmail', 'users.changeRole', 'users.softDelete', 'users.restore', 'users.hardDelete', 'users.insert'],
  limit: 5,
  timeRange: 1000
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Users/server/publications.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);

var _Roles = void 0;

module.watch(require("meteor/alanning:roles"), {
  Roles: function Roles(v) {
    _Roles = v;
  }
}, 2);

_Meteor.publish('users.management', function usersManagement() {
  if (_Roles.userIsInRole(this.userId, ['admin'])) {
    return _Meteor.users.find({}, {
      fields: {
        emails: 1,
        roles: 1,
        profile: 1,
        services: 1,
        deleted: 1,
        createdAt: 1
      }
    });
  }
});

_Meteor.publish('users.editProfile', function usersProfile() {
  return _Meteor.users.find({
    _id: this.userId
  }, {
    fields: {
      emails: 1,
      profile: 1,
      services: 1
    }
  });
});

_Meteor.publish('users.view', function (userId) {
  _check(userId, String);

  return _Meteor.users.find({
    _id: userId
  }, {
    fields: {
      emails: 1,
      profile: 1,
      services: 1,
      createdAt: 1,
      roles: 1,
      deleted: 1
    }
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"send-welcome-email.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Users/server/send-welcome-email.js                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);
var sendEmail = void 0;
module.watch(require("../../../modules/server/send-email"), {
  default: function _default(v) {
    sendEmail = v;
  }
}, 1);
var getOAuthProfile = void 0;
module.watch(require("../../../modules/get-oauth-profile"), {
  default: function _default(v) {
    getOAuthProfile = v;
  }
}, 2);
module.exportDefault(function (options, user) {
  var OAuthProfile = getOAuthProfile(options, user);
  var applicationName = 'Ipsilum';
  var firstName = OAuthProfile ? OAuthProfile.name.first : options.profile.name.first;
  var emailAddress = OAuthProfile ? OAuthProfile.email : options.email;
  return sendEmail({
    to: emailAddress,
    from: applicationName + " <info@srmconsulting.es>",
    subject: "[" + applicationName + "] Welcome, " + firstName + "!",
    template: 'welcome',
    templateVars: {
      applicationName: applicationName,
      firstName: firstName,
      welcomeUrl: _Meteor.absoluteUrl('projects') // e.g., returns http://localhost:3000/projects

    }
  }).catch(function (error) {
    throw new _Meteor.Error('500', "" + error);
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"Utility":{"server":{"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/Utility/server/methods.js                                                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _check = void 0;

module.watch(require("meteor/check"), {
  check: function check(v) {
    _check = v;
  }
}, 1);
var getPrivateFile = void 0;
module.watch(require("../../../modules/server/get-private-file"), {
  default: function _default(v) {
    getPrivateFile = v;
  }
}, 2);
var parseMarkdown = void 0;
module.watch(require("../../../modules/parse-markdown"), {
  default: function _default(v) {
    parseMarkdown = v;
  }
}, 3);

_Meteor.methods({
  'utility.getPage': function utilityGetPage(fileName) {
    _check(fileName, String);

    return parseMarkdown(getPrivateFile("pages/" + fileName + ".md"));
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"SchemaUtilities":{"GeoJSONSchema.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/SchemaUtilities/GeoJSONSchema.js                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
module.export({
  Point: function Point() {
    return _Point;
  },
  LineString: function LineString() {
    return _LineString;
  },
  Polygon: function Polygon() {
    return _Polygon;
  },
  MultiPoint: function MultiPoint() {
    return _MultiPoint;
  },
  MultiLineString: function MultiLineString() {
    return _MultiLineString;
  },
  MultiPolygon: function MultiPolygon() {
    return _MultiPolygon;
  },
  GeometryCollection: function GeometryCollection() {
    return _GeometryCollection;
  },
  Feature: function Feature() {
    return _Feature;
  },
  FeatureCollection: function FeatureCollection() {
    return _FeatureCollection;
  },
  GeoJSONSchemaDef: function GeoJSONSchemaDef() {
    return _GeoJSONSchemaDef;
  },
  FeaturePoint: function FeaturePoint() {
    return _FeaturePoint;
  },
  FeatureLineString: function FeatureLineString() {
    return _FeatureLineString;
  },
  FeaturePolygon: function FeaturePolygon() {
    return _FeaturePolygon;
  },
  FeatureCollectionPoints: function FeatureCollectionPoints() {
    return _FeatureCollectionPoints;
  },
  FeatureCollectionLineStrings: function FeatureCollectionLineStrings() {
    return _FeatureCollectionLineStrings;
  },
  FeatureCollectionPolygons: function FeatureCollectionPolygons() {
    return _FeatureCollectionPolygons;
  }
});
var SimpleSchema = void 0;
exports.Point = _Point;
module.watch(require("simpl-schema"), {
  default: function _default(v) {
    SimpleSchema = v;
  }
}, 0);

// Geometry Primitives
var _Point = new SimpleSchema({
  type: {
    type: String,
    label: 'The type of the feature.',
    allowedValues: ['Point']
  },
  coordinates: {
    type: Array,
    label: 'A single position. Fundamental geometry construct. The order for the elements is longitude (easting) and latitude (northing), in that precise order, altitude or elevation MAY be included.',
    minCount: 2,
    maxCount: 3
  },
  'coordinates.$': {
    type: Number,
    label: 'A number representing longitude (easting), latitude (northing), altitude or elevation'
  }
});

var _LineString = new SimpleSchema({
  type: {
    type: String,
    label: 'The type of the feature.',
    allowedValues: ['LineString']
  },
  coordinates: {
    type: Array,
    label: 'An array of two or more positions',
    minCount: 2
  },
  'coordinates.$': {
    type: Array,
    label: 'A single position.',
    minCount: 2,
    maxCount: 3
  },
  'coordinates.$.$': {
    type: Number,
    label: 'A number representing longitude (easting), latitude (northing), altitude or elevation'
  }
});

var _Polygon = new SimpleSchema({
  type: {
    type: String,
    label: 'The type of the feature.',
    allowedValues: ['Polygon']
  },
  coordinates: {
    type: Array,
    label: 'An array of linear rings, the first must be the exterior ring, any others must be the interior rings'
  },
  'coordinates.$': {
    type: Array,
    label: 'A linear Ring. An array of four or more positions where the first equals the last, follows right-hand rule in respect with the area it bounds. Exterior rings are counterclockwise and holes are clockwise',
    minCount: 4,
    custom: function custom() {
      var lastPositionIndex = this.value.length - 1;

      if (this.value[0].length !== this.value[lastPositionIndex].length) {
        return 'Positions do not have same number of items';
      }

      for (var i = 0; i < this.value[0].length; i += 1) {
        if (this.value[0][i] !== this.value[lastPositionIndex][i]) {
          return 'First and Last Point must be equal.';
        }
      }
    }
  },
  'coordinates.$.$': {
    type: Array,
    label: 'A single position.',
    minCount: 2,
    maxCount: 3
  },
  'coordinates.$.$.$': {
    type: Number,
    label: 'A number representing longitude (easting), latitude (northing), altitude or elevation'
  }
});

var _MultiPoint = new SimpleSchema({
  type: {
    type: String,
    label: 'The type of the feature.',
    allowedValues: ['MultiPoint']
  },
  coordinates: {
    type: Array,
    label: 'An array of positions'
  },
  'coordinates.$': {
    type: Array,
    label: 'A single position.',
    minCount: 2,
    maxCount: 3
  },
  'coordinates.$.$': {
    type: Number,
    label: 'A number representing longitude (easting), latitude (northing), altitude or elevation'
  }
});

var _MultiLineString = new SimpleSchema({
  type: {
    type: String,
    label: 'The type of the feature.',
    allowedValues: ['MultiLineString']
  },
  coordinates: {
    type: Array,
    label: 'An array of lineStrings'
  },
  'coordinates.$': {
    type: Array,
    label: 'A single lineString. An array of two or more positions',
    minCount: 2
  },
  'coordinates.$.$': {
    type: Array,
    label: 'A single position.',
    minCount: 2,
    maxCount: 3
  },
  'coordinates.$.$.$': {
    type: Number,
    label: 'A number representing longitude (easting), latitude (northing), altitude or elevation'
  }
});

var _MultiPolygon = new SimpleSchema({
  type: {
    type: String,
    label: 'The type of the feature.',
    allowedValues: ['MultiPolygon']
  },
  coordinates: {
    type: Array,
    label: 'An array of polygons'
  },
  'coordinates.$': {
    type: Array,
    label: 'A single polygon. An array of linear rings, the first must be the exterior ring, any others must be the interior rings'
  },
  'coordinates.$.$': {
    type: Array,
    label: 'A linearRing. An array of four or more positions where the first equals the last, follows right-hand rule in respect with the area it bounds. Exterior rings are counterclockwise and holes are clockwise',
    minCount: 4,
    custom: function custom() {
      var lastPositionIndex = this.value.length - 1;

      if (this.value[0].length !== this.value[lastPositionIndex].length) {
        return 'Positions do not have same number of items';
      }

      for (var i = 0; i < this.value[0].length; i += 1) {
        if (this.value[0][i] !== this.value[lastPositionIndex][i]) {
          return 'First and Last Point must be equal.';
        }
      }
    }
  },
  'coordinates.$.$.$': {
    type: Array,
    label: 'A single position.',
    minCount: 2,
    maxCount: 3
  },
  'coordinates.$.$.$.$': {
    type: Number,
    label: 'A number representing longitude (easting), latitude (northing), altitude or elevation'
  }
});

var _GeometryCollection = new SimpleSchema({
  type: {
    type: String,
    label: 'A GeometryCollection has a member with the name "geometries". Each element of this array is a GeoJSON Geometry object. GeometryCollections composed of a single part or a number of parts of a single type SHOULD be avoided',
    allowedValues: ['GeometryCollection']
  },
  bbox: {
    type: Array,
    label: 'Includes information on the coordinate range. Length 2*n where n is the number of dimensions represented in the contained geometries. Axes order of bbox follows the axes order of geometries. The values of a "bbox" array are "[west, south, east, north]", not "[minx, miny, maxx, maxy]".',
    optional: true
  },
  'bbox.$': {
    type: Number
  },
  geometries: {
    type: Array,
    label: 'An array of GeoJSON Geometry objects'
  },
  'geometries.$': {
    // BUG does not work - SimpleSchema only keeps the last schema
    type: SimpleSchema.oneOf(_Point, _MultiPoint, _LineString, _MultiLineString, _Polygon, _MultiPolygon),
    label: 'GeoJSON Geometry objects'
  }
});

var _Feature = new SimpleSchema({
  type: {
    type: String,
    label: 'A Feature object represents a spatially bounded entity.',
    allowedValues: ['Feature']
  },
  id: {
    type: SimpleSchema.oneOf(String, Number),
    label: 'Commonly used identifier',
    optional: true
  },
  bbox: {
    type: Array,
    label: 'Includes information on the coordinate range. Length 2*n where n is the number of dimensions represented in the contained geometries. Axes order of bbox follows the axes order of geometries',
    optional: true
  },
  'bbox.$': {
    type: Number
  },
  geometry: {
    // BUG does not work - SimpleSchema only keeps the last schema
    type: SimpleSchema.oneOf(_Point, _MultiPoint, _LineString, _MultiLineString, _Polygon, _MultiPolygon, _GeometryCollection),
    label: 'The value of the geometry member SHALL be either a Geometry object as defined above or, in the case that the Feature is unlocated, a JSON null value.'
  },
  properties: {
    type: Object,
    label: 'Extra properties for the feature',
    blackbox: true
  }
});

var _FeatureCollection = new SimpleSchema({
  type: {
    type: String,
    label: 'The type of the feature.',
    allowedValues: ['FeatureCollection']
  },
  bbox: {
    type: Array,
    label: 'Includes information on the coordinate range. Length 2*n where n is the number of dimensions represented in the contained geometries. Axes order of bbox follows the axes order of geometries',
    optional: true
  },
  'bbox.$': {
    type: Number
  },
  features: {
    type: Array,
    label: 'An array of the features'
  },
  'features.$': {
    // BUG does not work - SimpleSchema only keeps the last schema
    type: _Feature,
    label: 'A feature object'
  }
});

var _GeoJSONSchemaDef = new SimpleSchema({
  // BUG does not work - SimpleSchema only keeps the last schema
  GeoJSON: {
    type: SimpleSchema.oneOf(_Point, _LineString, _Polygon, _MultiPoint, _MultiLineString, _MultiPolygon, _GeometryCollection, _Feature, _FeatureCollection)
  }
});

var _FeaturePoint = new SimpleSchema({
  type: {
    type: String,
    label: 'A Feature object represents a spatially bounded entity.',
    allowedValues: ['Feature']
  },
  id: {
    type: SimpleSchema.oneOf(String, Number),
    label: 'Commonly used identifier',
    optional: true
  },
  bbox: {
    type: Array,
    label: 'Includes information on the coordinate range. Length 2*n where n is the number of dimensions represented in the contained geometries. Axes order of bbox follows the axes order of geometries',
    optional: true
  },
  'bbox.$': {
    type: Number
  },
  geometry: {
    type: SimpleSchema.oneOf(_Point),
    label: 'The value of the geometry member SHALL be either a Geometry object as defined above or, in the case that the Feature is unlocated, a JSON null value.'
  },
  properties: {
    type: Object,
    label: 'Extra properties for the feature',
    blackbox: true
  }
});

var _FeatureLineString = new SimpleSchema({
  type: {
    type: String,
    label: 'A Feature object represents a spatially bounded entity.',
    allowedValues: ['Feature']
  },
  id: {
    type: SimpleSchema.oneOf(String, Number),
    label: 'Commonly used identifier',
    optional: true
  },
  bbox: {
    type: Array,
    label: 'Includes information on the coordinate range. Length 2*n where n is the number of dimensions represented in the contained geometries. Axes order of bbox follows the axes order of geometries',
    optional: true
  },
  'bbox.$': {
    type: Number
  },
  geometry: {
    type: SimpleSchema.oneOf(_LineString),
    label: 'The value of the geometry member SHALL be either a Geometry object as defined above or, in the case that the Feature is unlocated, a JSON null value.'
  },
  properties: {
    type: Object,
    label: 'Extra properties for the feature',
    blackbox: true
  }
});

var _FeaturePolygon = new SimpleSchema({
  type: {
    type: String,
    label: 'A Feature object represents a spatially bounded entity.',
    allowedValues: ['Feature']
  },
  id: {
    type: SimpleSchema.oneOf(String, Number),
    label: 'Commonly used identifier',
    optional: true
  },
  bbox: {
    type: Array,
    label: 'Includes information on the coordinate range. Length 2*n where n is the number of dimensions represented in the contained geometries. Axes order of bbox follows the axes order of geometries',
    optional: true
  },
  'bbox.$': {
    type: Number
  },
  geometry: {
    type: SimpleSchema.oneOf(_Polygon),
    label: 'The value of the geometry member SHALL be either a Geometry object as defined above or, in the case that the Feature is unlocated, a JSON null value.'
  },
  properties: {
    type: Object,
    label: 'Extra properties for the feature',
    blackbox: true
  }
});

var _FeatureCollectionPoints = new SimpleSchema({
  type: {
    type: String,
    label: 'The type of the feature.',
    allowedValues: ['FeatureCollection']
  },
  bbox: {
    type: Array,
    label: 'Includes information on the coordinate range. Length 2*n where n is the number of dimensions represented in the contained geometries. Axes order of bbox follows the axes order of geometries',
    optional: true
  },
  'bbox.$': {
    type: Number
  },
  features: {
    type: Array,
    label: 'An array of the features'
  },
  'features.$': {
    type: _FeaturePoint,
    label: 'A feature object'
  }
});

var _FeatureCollectionLineStrings = new SimpleSchema({
  type: {
    type: String,
    label: 'The type of the feature.',
    allowedValues: ['FeatureCollection']
  },
  bbox: {
    type: Array,
    label: 'Includes information on the coordinate range. Length 2*n where n is the number of dimensions represented in the contained geometries. Axes order of bbox follows the axes order of geometries',
    optional: true
  },
  'bbox.$': {
    type: Number
  },
  features: {
    type: Array,
    label: 'An array of the features'
  },
  'features.$': {
    type: _FeatureLineString,
    label: 'A feature object'
  }
});

var _FeatureCollectionPolygons = new SimpleSchema({
  type: {
    type: String,
    label: 'The type of the feature.',
    allowedValues: ['FeatureCollection']
  },
  bbox: {
    type: Array,
    label: 'Includes information on the coordinate range. Length 2*n where n is the number of dimensions represented in the contained geometries. Axes order of bbox follows the axes order of geometries',
    optional: true
  },
  'bbox.$': {
    type: Number
  },
  features: {
    type: Array,
    label: 'An array of the features'
  },
  'features.$': {
    type: _FeaturePolygon,
    label: 'A feature object'
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"server":{"accounts":{"email-templates.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/accounts/email-templates.js                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _Accounts = void 0;

module.watch(require("meteor/accounts-base"), {
  Accounts: function Accounts(v) {
    _Accounts = v;
  }
}, 1);
var getPrivateFile = void 0;
module.watch(require("../../../modules/server/get-private-file"), {
  default: function _default(v) {
    getPrivateFile = v;
  }
}, 2);
var templateToHTML = void 0;
module.watch(require("../../../modules/server/handlebars-email-to-html"), {
  default: function _default(v) {
    templateToHTML = v;
  }
}, 3);
var templateToText = void 0;
module.watch(require("../../../modules/server/handlebars-email-to-text"), {
  default: function _default(v) {
    templateToText = v;
  }
}, 4);
var name = 'Ipsilum';
var email = '<info@srmconsulting.es>';
var from = name + " " + email;
var _Accounts2 = _Accounts,
    emailTemplates = _Accounts2.emailTemplates;
emailTemplates.siteName = name;
emailTemplates.from = from;
emailTemplates.resetPassword = {
  subject: function subject() {
    return "[" + name + "] Reset Your Password";
  },
  html: function html(user, url) {
    return templateToHTML(getPrivateFile('email-templates/reset-password.html'), {
      firstName: user.profile.name.first,
      applicationName: name,
      emailAddress: user.emails[0].address,
      resetUrl: url.replace('#/', '')
    });
  },
  text: function text(user, url) {
    var urlWithoutHash = url.replace('#/', '');
    if (_Meteor.isDevelopment) console.info("Reset Password Link: " + urlWithoutHash); // eslint-disable-line

    return templateToText(getPrivateFile('email-templates/reset-password.txt'), {
      firstName: user.profile.name.first,
      applicationName: name,
      emailAddress: user.emails[0].address,
      resetUrl: urlWithoutHash
    });
  }
};
emailTemplates.verifyEmail = {
  subject: function subject() {
    return "[" + name + "] Verify Your Email Address";
  },
  html: function html(user, url) {
    return templateToHTML(getPrivateFile('email-templates/verify-email.html'), {
      applicationName: name,
      firstName: user.profile.name.first,
      verifyUrl: url.replace('#/', '')
    });
  },
  text: function text(user, url) {
    var urlWithoutHash = url.replace('#/', '');
    if (_Meteor.isDevelopment) console.info("Verify Email Link: " + urlWithoutHash); // eslint-disable-line

    return templateToText(getPrivateFile('email-templates/verify-email.txt'), {
      applicationName: name,
      firstName: user.profile.name.first,
      verifyUrl: urlWithoutHash
    });
  }
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/accounts/index.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

module.watch(require("./email-templates"));
module.watch(require("./oauth"));
module.watch(require("./roles"));
module.watch(require("./on-create-user"));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"oauth.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/accounts/oauth.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _ServiceConfiguration = void 0;

module.watch(require("meteor/service-configuration"), {
  ServiceConfiguration: function ServiceConfiguration(v) {
    _ServiceConfiguration = v;
  }
}, 1);
var OAuthSettings = {
  facebook: {
    appId: '',
    secret: '',
    loginStyle: 'popup'
  },
  google: {
    clientId: '',
    secret: '',
    loginStyle: 'popup'
  }
};

if (_Meteor.settings && _Meteor.settings.private && _Meteor.settings.private.OAuth) {
  OAuthSettings = _Meteor.settings.private.OAuth;
}

if (OAuthSettings) {
  Object.keys(OAuthSettings).forEach(function (service) {
    _ServiceConfiguration.configurations.upsert({
      service: service
    }, {
      $set: OAuthSettings[service]
    });
  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"on-create-user.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/accounts/on-create-user.js                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Accounts = void 0;

module.watch(require("meteor/accounts-base"), {
  Accounts: function Accounts(v) {
    _Accounts = v;
  }
}, 0);
var sendWelcomeEmail = void 0;
module.watch(require("../../../api/Users/server/send-welcome-email"), {
  default: function _default(v) {
    sendWelcomeEmail = v;
  }
}, 1);

_Accounts.onCreateUser(function (options, user) {
  var userToCreate = user;

  if (!userToCreate.roles) {
    userToCreate.roles = ['free-user'];
  } else {
    userToCreate.roles.push('free-user');
  }

  if (options.profile) userToCreate.profile = options.profile;
  userToCreate.deleted = 'no';
  sendWelcomeEmail(options, user);
  return userToCreate;
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"roles.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/accounts/roles.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _Roles = void 0;

module.watch(require("meteor/alanning:roles"), {
  Roles: function Roles(v) {
    _Roles = v;
  }
}, 1);

var _2 = void 0;

module.watch(require("meteor/underscore"), {
  _: function _(v) {
    _2 = v;
  }
}, 2);

// This reocnciles the Roles collection in MongoDB to ensure we've recorded all of the possible
// user roles. We do this because we're manually adding roles to users and the alanning:roles
// package doesn't detect this.
var reconcileRoles = function reconcileRoles() {
  var users = _Meteor.users.find({}, {
    roles: 1
  }).fetch();

  var roles = [];
  users.forEach(function (user) {
    return roles = _2.uniq(roles.concat(user.roles));
  });
  roles.map(function (name) {
    return !_Meteor.roles.findOne({
      name: name
    }) ? _Roles.createRole(name) : null;
  });
};

reconcileRoles();

_Meteor.users.find({}).observe({
  added: function added() {
    reconcileRoles();
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"api.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/api.js                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

module.watch(require("../../api/Projects/methods"));
module.watch(require("../../api/Projects/server/publications"));
module.watch(require("../../api/Missions/methods"));
module.watch(require("../../api/Missions/server/publications"));
module.watch(require("../../api/RPAs/methods"));
module.watch(require("../../api/RPAs/server/publications"));
module.watch(require("../../api/Payloads/methods"));
module.watch(require("../../api/Payloads/server/publications"));
module.watch(require("../../api/Batteries/methods"));
module.watch(require("../../api/Batteries/server/publications"));
module.watch(require("../../api/Users/server/methods"));
module.watch(require("../../api/Users/server/publications"));
module.watch(require("../../api/OAuth/server/methods"));
module.watch(require("../../api/Utility/server/methods"));
module.watch(require("../../api/FlieTransferUtilities/server/methods"));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"email.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/email.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);
if (_Meteor.isDevelopment) process.env.MAIL_URL = _Meteor.settings.private.env.MAIL_URL;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"fixtures.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/fixtures.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var seeder = void 0;
module.watch(require("@cleverbeagle/seeder"), {
  default: function _default(v) {
    seeder = v;
  }
}, 0);

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 1);
var faker = void 0;
module.watch(require("faker"), {
  default: function _default(v) {
    faker = v;
  }
}, 2);
var Projects = void 0;
module.watch(require("../../api/Projects/Projects"), {
  default: function _default(v) {
    Projects = v;
  }
}, 3);
var Missions = void 0;
module.watch(require("../../api/Missions/Missions"), {
  default: function _default(v) {
    Missions = v;
  }
}, 4);
var RPAs = void 0;
module.watch(require("../../api/RPAs/RPAs"), {
  default: function _default(v) {
    RPAs = v;
  }
}, 5);
var Payloads = void 0;
module.watch(require("../../api/Payloads/Payloads"), {
  default: function _default(v) {
    Payloads = v;
  }
}, 6);
var Batteries = void 0;
module.watch(require("../../api/Batteries/Batteries"), {
  default: function _default(v) {
    Batteries = v;
  }
}, 7);

var GeoDroneRPA = function GeoDroneRPA(userId) {
  var RPAsVector = [];

  for (var i = 0; i < 5; i += 1) {
    if (i === 0) {
      RPAsVector.push({
        owner: userId,
        name: 'GeoDrone Conyca',
        rpaType: 'Plane',
        model: 1,
        registrationNumber: 12345,
        constructionDate: new Date().toISOString(),
        serialNumber: 12345,
        weight: 5,
        flightParameters: {
          maxDescendSlope: 0,
          maxAscendSlope: 0,
          optimalLandingSlope: 7,
          optimalTakeOffSlope: 0,
          maxLandSpeed: 0
        }
      });
    }

    RPAsVector.push({
      owner: userId,
      name: faker.commerce.productName(),
      rpaType: faker.random.arrayElement(['Plane', 'MultiCopter']),
      model: faker.commerce.productAdjective(),
      registrationNumber: faker.random.number(),
      constructionDate: faker.date.past().toISOString(),
      serialNumber: faker.random.number(),
      weight: faker.random.number({
        min: 0,
        max: 1000
      }),
      flightParameters: {
        maxDescendSlope: faker.random.number({
          min: 0,
          max: 100
        }),
        maxAscendSlope: faker.random.number({
          min: 0,
          max: 100
        }),
        optimalLandingSlope: faker.random.number({
          min: 0,
          max: 100
        }),
        optimalTakeOffSlope: faker.random.number({
          min: 0,
          max: 100
        }),
        maxLandSpeed: faker.random.number({
          min: 0,
          max: 100
        })
      }
    });
  }

  return RPAsVector;
};

var CamerasVector = function CamerasVector(userId) {
  var camerasVector = [];

  for (var i = 0; i < 5; i += 1) {
    if (i === 0) {
      camerasVector.push({
        owner: userId,
        name: 'Sony',
        registrationNumber: 12343,
        model: 'Next 7',
        weight: 500,
        payloadType: 'Camera',
        sensorParameters: {
          focalLength: 16,
          sensorWidth: 23.5,
          sensorHeight: 15.6,
          imageWidth: 6000,
          imageHeight: 4000
        }
      });
    }

    camerasVector.push({
      owner: userId,
      name: faker.commerce.productName(),
      registrationNumber: faker.random.number(),
      model: faker.commerce.productAdjective(),
      weight: faker.random.number({
        min: 0,
        max: 100
      }),
      payloadType: 'Camera',
      sensorParameters: {
        focalLength: faker.random.number({
          min: 1,
          max: 50
        }),
        sensorWidth: faker.random.number({
          min: 1,
          max: 50
        }),
        sensorHeight: faker.random.number({
          min: 1,
          max: 50
        }),
        imageWidth: faker.random.number({
          min: 400,
          max: 10000
        }),
        imageHeight: faker.random.number({
          min: 600,
          max: 10000
        })
      }
    });
  }

  return camerasVector;
};

var batteriesSeed = function batteriesSeed(userId) {
  var batteriesVector = [];

  for (var i = 0; i < 5; i += 1) {
    batteriesVector.push({
      owner: userId,
      name: faker.commerce.productName(),
      model: faker.commerce.productAdjective(),
      registrationNumber: faker.random.number(),
      amperes: faker.random.number({
        min: 0,
        max: 100
      }),
      cellNumber: faker.random.number({
        min: 0,
        max: 50
      }),
      weight: faker.random.number({
        min: 0,
        max: 500
      })
    });
  }

  return batteriesVector;
};

var missionsSeed = function missionsSeed(userId, projectId, rpasPayloadsIDS) {
  return {
    collection: Missions,
    environments: ['development', 'staging', 'production'],
    noLimit: true,
    modelCount: 5,
    model: function model(dataIndex, faker) {
      return {
        owner: userId,
        project: projectId,
        name: "Mission #" + (dataIndex + 1),
        description: "This is the description of Mission #" + (dataIndex + 1),
        rpa: faker.random.arrayElement(rpasPayloadsIDS.rpasIds),
        payload: faker.random.arrayElement(rpasPayloadsIDS.payloadIds),
        missionType: faker.random.arrayElement(['Surface Area', 'Linear Area'])
      };
    }
  };
};

var projectsSeed = function projectsSeed(userId, rpasPayloadsIDS) {
  return {
    collection: Projects,
    environments: ['development', 'staging'],
    noLimit: true,
    modelCount: 5,
    model: function model(dataIndex, faker) {
      return {
        owner: userId,
        name: "Project #" + (dataIndex + 1),
        description: "This is the description of Project #" + (dataIndex + 1),
        mapLocation: {
          type: 'Feature',
          geometry: {
            type: 'Point',
            coordinates: [faker.address.longitude(), faker.address.latitude()]
          },
          properties: {
            zoom: faker.random.number({
              min: 0,
              max: 15
            })
          }
        },
        data: function data(projectId) {
          return missionsSeed(userId, projectId, rpasPayloadsIDS);
        }
      };
    }
  };
};

var insertOtherData = function insertOtherData(userId) {
  var userRPASPayloads = {
    rpasIds: [],
    payloadIds: []
  };
  GeoDroneRPA(userId).forEach(function (rpa) {
    var rpaID = RPAs.insert(rpa);
    userRPASPayloads.rpasIds.push(rpaID);
  });
  CamerasVector(userId).forEach(function (camera) {
    var payloadID = Payloads.insert(camera);
    userRPASPayloads.payloadIds.push(payloadID);
  });
  batteriesSeed(userId).forEach(function (battery) {
    Batteries.insert(battery);
  });
  return userRPASPayloads;
};

seeder(_Meteor.users, {
  environments: ['development', 'staging'],
  noLimit: true,
  data: [{
    email: 'admin@admin.com',
    password: 'password',
    profile: {
      name: {
        first: 'Admin',
        last: 'User'
      }
    },
    roles: ['admin'],
    data: function data(userId) {
      var userItemIDS = insertOtherData(userId);
      return projectsSeed(userId, userItemIDS);
    }
  }],
  modelCount: 5,
  model: function model(index, faker) {
    var userCount = index + 1;
    return {
      email: "user+" + userCount + "@test.com",
      password: 'password',
      profile: {
        name: {
          first: faker.name.firstName(),
          last: faker.name.lastName()
        }
      },
      roles: ['free-user'],
      data: function data(userId) {
        var userItemIDS = insertOtherData(userId);
        return projectsSeed(userId, userItemIDS);
      }
    };
  }
});

if (!_Meteor.isProduction) {
  var userExists = _Meteor.users.findOne({
    'emails.0.address': 'admin@admin.com'
  });

  if (!userExists.emails[0].verified) {
    _Meteor.users.update({
      _id: userExists._id
    }, {
      $set: {
        'emails.0.verified': true
      }
    });
  }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/index.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

module.watch(require("./accounts"));
module.watch(require("./api"));
module.watch(require("./fixtures"));
module.watch(require("./email"));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"modules":{"server":{"file-system.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/modules/server/file-system.js                                                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

module.export({
  deleteFolderRecursiveSync: function deleteFolderRecursiveSync() {
    return _deleteFolderRecursiveSync;
  },
  buildCompletePath: function buildCompletePath() {
    return _buildCompletePath;
  },
  getFileList: function getFileList() {
    return _getFileList;
  },
  getFilesInDirByExtension: function getFilesInDirByExtension() {
    return _getFilesInDirByExtension;
  },
  deleteFile: function deleteFile() {
    return _deleteFile;
  },
  saveFileFrombuffer: function saveFileFrombuffer() {
    return _saveFileFrombuffer;
  },
  createDirectory: function createDirectory() {
    return _createDirectory;
  },
  getFolderSize: function getFolderSize() {
    return _getFolderSize;
  },
  getFileSize: function getFileSize() {
    return _getFileSize;
  }
});

/*-----------------------------------------------------------------------------------------*/ /* File System basic function for nodejs            Compilation made by Luis Izquierdo Mesa */ /*-----------------------------------------------------------------------------------------*/var fs = require('fs'); // let zipFolder = require('zip-folder');


var _require = require('child_process'),
    spawn = _require.spawn;

var path = require('path'); // let Future = Npm.require( 'fibers/future' );
/**
 * Builds a complete path taking care about the last character of
 * the @param dir. If this does not have a slash the function will add one
 * @param {string} dir - directory with or without last slash
 * @param {string} fileName - filename
 * @returns {string}
 */

var _buildCompletePath = function _buildCompletePath(dir, fileName) {
  var lastChar = dir.substr(dir.length - 1);
  var slash = '';
  if (lastChar !== '/') slash = '/';
  return dir + slash + fileName;
}; /**
    * Delete files and directories in a folder. This method is syncronous
    * @param {string} path
    * @param {int} nivel de recursividad - Siempre hay que meter 0.
    Es la manera que tiene la función recursiva de detectar la primera
     iteración y así no borrar el directorio inicial.
    */

var deletedFiles = 0;
var numberOfFolders = 0;

var _deleteFolderRecursiveSync = function _deleteFolderRecursiveSync(pathDir, root) {
  var files = [];

  if (fs.existsSync(pathDir)) {
    files = fs.readdirSync(pathDir);
    files.forEach(function (file) {
      var curPath = _buildCompletePath(pathDir, file);

      if (fs.lstatSync(curPath).isDirectory()) {
        // recurse
        _deleteFolderRecursiveSync(curPath, false);
      } else {
        // delete file
        deletedFiles += 1;
        fs.unlinkSync(curPath);
      }
    });
  }

  if (!root) {
    fs.rmdirSync(pathDir);
  } else {
    return {
      deletedFiles: deletedFiles,
      folders: numberOfFolders
    };
  }
}; /**
    * Get all the files from a directory
    * @param {string} path
    * @returns {[]} - array of files
    */

var _getFileList = function _getFileList(pathDir, callback) {
  var filesArr = []; // let future = new Future();

  fs.readdir(pathDir, function (err, files) {
    files.forEach(function (file) {
      filesArr.push(file);
    });
    callback(filesArr); // future.return({files:filesArr})
  }); // return future.wait();
}; /**
    * Get files in a directory by an extension
    * @param {string } dir
    * @param {string} extension - can be upper-case or lower-case, this function is case insensitive
    * @param {function} callback - callback with one argument that returns
       and array of files filered by its extension
    */

var _getFilesInDirByExtension = function _getFilesInDirByExtension(dir, extension, callback) {
  var filesArr = [];
  var re = new RegExp(extension, 'i');
  var extensionLenght = extension.length;
  fs.readdir(dir, function (err, files) {
    files.filter(function (file) {
      return file.substr(-extensionLenght).match(re);
    }).forEach(function (file) {
      filesArr.push(file);
    });
    callback(filesArr);
  });
}; /**
    * Get files in a directory by a prefix
    * @param {string }dir
    * @param {string} prefix - can be upper-case or lower-case, this function is case insensitive
    * @param {function} callback - callback with one argument that
      returns and array of files filered by its extension
    */

var getFilesInDirByPrefix = function getFilesInDirByPrefix(dir, prefix, callback) {
  var filesArr = [];
  var re = new RegExp(prefix, 'i');
  var prefixLenght = prefix.length;
  fs.readdir(dir, function (err, files) {
    files.filter(function (file) {
      return file.substr(0, prefixLenght).match(re);
    }).forEach(function (file) {
      filesArr.push(file);
    });
    callback(filesArr);
  });
}; /**
    * Delete a file in a given directory
    * @param {string} dir - directory
    * @param {string} fileName
    * @returns {*} - a json object with three parameters; result ('error' or 'ok'), dir and filename
    */

var _deleteFile = function _deleteFile(dir, fileName, callback) {
  var completePath = _buildCompletePath(dir, fileName); // let future = new Future();


  fs.unlink(completePath, function (err) {
    if (err) {
      callback({
        result: 'error',
        dir: dir,
        fileName: fileName
      });
    } else {
      callback({
        result: 'ok',
        dir: dir,
        fileName: fileName
      });
    }
  }); // return future.wait();
}; /**
    * Method that save a file from a buffer. This
    method is used for a meteor.call, saving a file from client.
    * This method use Future, so it does not return anything until it finish
    * @param {binary} buffer - binary content of the file
    * @param {string} dir - directory where we want to store the file
    * @param {string} fileName - name of the file
    * @returns {*} - a json object with three parameters; result ('error' or 'ok'), dir and filename
    */

var _saveFileFrombuffer = function _saveFileFrombuffer(buffer, dir, fileName, callback) {
  var fullFileName = dir + fileName; // let future = new Future();

  fs.stat(dir, function (error, stats) {
    if (error) {
      setTimeout(function () {
        callback({
          result: 'error',
          dir: dir,
          fileName: fileName
        }); // future.return({result:'error',dir:dir,fileName:fileName});
      }, 1000); // return meteorError;
    } else if (stats.isDirectory()) {
      fs.writeFile(fullFileName, new Buffer(buffer), 'binary', function (error2) {
        if (error2) {
          callback({
            result: 'error',
            dir: dir,
            fileName: fileName
          }); // future.return({result:'error',dir:dir,fileName:fileName});
        } else {
          callback({
            result: 'ok',
            dir: dir,
            fileName: fileName
          }); // future.return({result:'ok',dir:dir,fileName:fileName});
        }
      });
    } else {
      // future.return({result:'error'});
      callback({
        result: 'error'
      });
    }
  }); // return future.wait();
}; /**
    * create a directory with a permission type 777
    * @param {string} path
    */

var _createDirectory = function _createDirectory(pathDir, callback) {
  // path = missionDirectory + path;
  console.log("dir created at " + pathDir);
  fs.exists(pathDir, function (exists) {
    console.log("bool val " + exists);

    if (!exists) {
      fs.mkdir(pathDir, '0777', function () {
        console.log("dir created at " + pathDir);
        callback(true);
      });
    } else {
      callback(false);
    }
  });
}; /**
    * Zip a complete folder
    * @param {string} folderPath
    * @param {string} zipPath
    * @param {function} callback - passing a bool argument
    (true if everything is ok, false if an error happens)
    */

var zipACompleteFolder = function zipACompleteFolder(folderPath, zipPath, callback) {
  zipFolder(folderPath, zipPath, function (err) {
    if (err) {
      callback(false);
    } else {
      callback(true);
    }
  });
};

var _getFileSize = function _getFileSize(filename) {
  var stats = fs.statSync(filename);
  var fileSizeInBytes = stats.size;
  return fileSizeInBytes;
};

var _getFolderSize = function _getFolderSize(folder, callback) {
  var folderSize = 0;
  fs.readdir(folder, function (err, files) {
    files.forEach(function (file) {
      folderSize += _getFileSize(path.join(folder, file));
    });
    callback(folderSize);
  });
};

var getFolderSize_old = function getFolderSize_old(pathDir, callback) {
  var size = spawn('du', ['-sh', pathDir]);
  var result = {};
  var totalSize = 0;
  size.stdout.on('data', function (data) {
    result.data = data;
    data.forEach(function (item) {
      totalSize += item;
    });
    callback(totalSize);
  });
  size.stderr.on('data', function (data) {
    result.error = data;
    callback(result);
  });
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"get-private-file.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/modules/server/get-private-file.js                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var fs = void 0;
module.watch(require("fs"), {
  default: function _default(v) {
    fs = v;
  }
}, 0);
module.exportDefault(function (path) {
  return fs.readFileSync("assets/app/" + path, 'utf8');
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"handlebars-email-to-html.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/modules/server/handlebars-email-to-html.js                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var handlebars = void 0;
module.watch(require("handlebars"), {
  default: function _default(v) {
    handlebars = v;
  }
}, 0);
var juice = void 0;
module.watch(require("juice"), {
  default: function _default(v) {
    juice = v;
  }
}, 1);
module.exportDefault(function (handlebarsMarkup, context, options) {
  if (handlebarsMarkup && context) {
    var template = handlebars.compile(handlebarsMarkup);
    return options && !options.inlineCss ? template(context) : juice(template(context)); // Use juice to inline CSS <style></style> styles from <head> unless disabled.
  }

  throw new Error('Please pass Handlebars markup to compile and a context object with data mapping to the Handlebars expressions used in your template.');
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"handlebars-email-to-text.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/modules/server/handlebars-email-to-text.js                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var handlebars = void 0;
module.watch(require("handlebars"), {
  default: function _default(v) {
    handlebars = v;
  }
}, 0);
module.exportDefault(function (handlebarsMarkup, context) {
  if (handlebarsMarkup && context) {
    var template = handlebars.compile(handlebarsMarkup);
    return template(context);
  }

  throw new Error('Please pass Handlebars markup to compile and a context object with data mapping to the Handlebars expressions used in your template.');
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"send-email.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/modules/server/send-email.js                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _extends2 = require("babel-runtime/helpers/extends");

var _extends3 = _interopRequireDefault(_extends2);

var _objectWithoutProperties2 = require("babel-runtime/helpers/objectWithoutProperties");

var _objectWithoutProperties3 = _interopRequireDefault(_objectWithoutProperties2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _Email = void 0;

module.watch(require("meteor/email"), {
  Email: function Email(v) {
    _Email = v;
  }
}, 0);

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 1);
var getPrivateFile = void 0;
module.watch(require("./get-private-file"), {
  default: function _default(v) {
    getPrivateFile = v;
  }
}, 2);
var templateToText = void 0;
module.watch(require("./handlebars-email-to-text"), {
  default: function _default(v) {
    templateToText = v;
  }
}, 3);
var templateToHTML = void 0;
module.watch(require("./handlebars-email-to-html"), {
  default: function _default(v) {
    templateToHTML = v;
  }
}, 4);

var sendEmail = function sendEmail(options, _ref) {
  var resolve = _ref.resolve,
      reject = _ref.reject;

  try {
    _Meteor.defer(function () {
      _Email.send(options);

      resolve();
    });
  } catch (exception) {
    reject(exception);
  }
};

module.exportDefault(function (_ref2) {
  var text = _ref2.text,
      html = _ref2.html,
      template = _ref2.template,
      templateVars = _ref2.templateVars,
      rest = (0, _objectWithoutProperties3.default)(_ref2, ["text", "html", "template", "templateVars"]);

  if (text || html || template) {
    return new Promise(function (resolve, reject) {
      sendEmail((0, _extends3.default)({}, rest, {
        text: template ? templateToText(getPrivateFile("email-templates/" + template + ".txt"), templateVars || {}) : text,
        html: template ? templateToHTML(getPrivateFile("email-templates/" + template + ".html"), templateVars || {}) : html
      }), {
        resolve: resolve,
        reject: reject
      });
    });
  }

  throw new Error('Please pass an HTML string, text, or template name to compile for your message\'s body.');
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"get-oauth-profile.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/modules/get-oauth-profile.js                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var parseGoogleData = function parseGoogleData(service) {
  return {
    email: service.email,
    name: {
      first: service.given_name,
      last: service.family_name
    }
  };
};

var parseFacebookData = function parseFacebookData(service) {
  return {
    email: service.email,
    name: {
      first: service.first_name,
      last: service.last_name
    }
  };
};

var getDataForService = function getDataForService(profile, services) {
  if (services.facebook) return parseFacebookData(services.facebook);
  if (services.google) return parseGoogleData(services.google);
};

module.exportDefault(function (options, user) {
  var isOAuth = !options.password;
  var serviceData = isOAuth ? getDataForService(options.profile, user.services) : null;
  return isOAuth ? serviceData : null;
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"parse-markdown.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/modules/parse-markdown.js                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Parser = void 0,
    _HtmlRenderer = void 0;

module.watch(require("commonmark"), {
  Parser: function Parser(v) {
    _Parser = v;
  },
  HtmlRenderer: function HtmlRenderer(v) {
    _HtmlRenderer = v;
  }
}, 0);
module.exportDefault(function (markdown, options) {
  var reader = new _Parser();
  var writer = options ? new _HtmlRenderer(options) : new _HtmlRenderer();
  var parsed = reader.parse(markdown);
  return writer.render(parsed);
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"rate-limit.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/modules/rate-limit.js                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

var _Meteor = void 0;

module.watch(require("meteor/meteor"), {
  Meteor: function Meteor(v) {
    _Meteor = v;
  }
}, 0);

var _DDPRateLimiter = void 0;

module.watch(require("meteor/ddp-rate-limiter"), {
  DDPRateLimiter: function DDPRateLimiter(v) {
    _DDPRateLimiter = v;
  }
}, 1);
module.exportDefault(function (_ref) {
  var methods = _ref.methods,
      limit = _ref.limit,
      timeRange = _ref.timeRange;

  if (_Meteor.isServer) {
    _DDPRateLimiter.addRule({
      name: function name(_name) {
        return methods.indexOf(_name) > -1;
      },
      connectionId: function connectionId() {
        return true;
      }
    }, limit, timeRange);
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/main.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
"use strict";

module.watch(require("../imports/startup/server"));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvQmF0dGVyaWVzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL0JhdHRlcmllcy9CYXR0ZXJpZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL0JhdHRlcmllcy9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9GbGllVHJhbnNmZXJVdGlsaXRpZXMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL01pc3Npb25zL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL01pc3Npb25zL01pc3Npb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9NaXNzaW9ucy9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9PQXV0aC9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvUGF5bG9hZHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvUGF5bG9hZHMvUGF5bG9hZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL1BheWxvYWRzL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL1Byb2plY3RzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL1Byb2plY3RzL1Byb2plY3RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9Qcm9qZWN0cy9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9SUEFzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL1JQQXMvUlBBcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvUlBBcy9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9Vc2Vycy9zZXJ2ZXIvZWRpdC1wcm9maWxlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9Vc2Vycy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvVXNlcnMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvVXNlcnMvc2VydmVyL3NlbmQtd2VsY29tZS1lbWFpbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvVXRpbGl0eS9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvU2NoZW1hVXRpbGl0aWVzL0dlb0pTT05TY2hlbWEuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvYWNjb3VudHMvZW1haWwtdGVtcGxhdGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL2FjY291bnRzL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL2FjY291bnRzL29hdXRoLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL2FjY291bnRzL29uLWNyZWF0ZS11c2VyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL2FjY291bnRzL3JvbGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL2FwaS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9lbWFpbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9maXh0dXJlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9tb2R1bGVzL3NlcnZlci9maWxlLXN5c3RlbS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9tb2R1bGVzL3NlcnZlci9nZXQtcHJpdmF0ZS1maWxlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL21vZHVsZXMvc2VydmVyL2hhbmRsZWJhcnMtZW1haWwtdG8taHRtbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9tb2R1bGVzL3NlcnZlci9oYW5kbGViYXJzLWVtYWlsLXRvLXRleHQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvbW9kdWxlcy9zZXJ2ZXIvc2VuZC1lbWFpbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9tb2R1bGVzL2dldC1vYXV0aC1wcm9maWxlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL21vZHVsZXMvcGFyc2UtbWFya2Rvd24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvbW9kdWxlcy9yYXRlLWxpbWl0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJNZXRlb3IiLCJtb2R1bGUiLCJ3YXRjaCIsInJlcXVpcmUiLCJ2IiwiY2hlY2siLCJCYXR0ZXJpZXMiLCJkZWZhdWx0IiwicHVibGlzaCIsImJhdHRlcmllcyIsImZpbmQiLCJvd25lciIsInVzZXJJZCIsImJhdHRlcmllc1ZpZXciLCJiYXR0ZXJ5SWQiLCJTdHJpbmciLCJfaWQiLCJNb25nbyIsIlNpbXBsZVNjaGVtYSIsIkNvbGxlY3Rpb24iLCJhbGxvdyIsImluc2VydCIsInVwZGF0ZSIsInJlbW92ZSIsImRlbnkiLCJzY2hlbWEiLCJ0eXBlIiwibGFiZWwiLCJjcmVhdGVkQXQiLCJhdXRvVmFsdWUiLCJpc0luc2VydCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInVwZGF0ZWRBdCIsImlzVXBkYXRlIiwibmFtZSIsIm1vZGVsIiwicmVnaXN0cmF0aW9uTnVtYmVyIiwiYW1wZXJlcyIsIk51bWJlciIsIm1pbiIsImNlbGxOdW1iZXIiLCJJbnRlZ2VyIiwid2VpZ2h0Iiwib3B0aW9uYWwiLCJkZWxldGVkIiwibG9nRGF0YSIsIk9iamVjdCIsImJsYWNrYm94IiwiYXR0YWNoU2NoZW1hIiwiZXhwb3J0RGVmYXVsdCIsInJhdGVMaW1pdCIsIm5ld0JhdHRlcnlTY2hlbWEiLCJwaWNrIiwiZWRpdEJhdHRlcnlTY2hlbWEiLCJleHRlbmQiLCJtZXRob2RzIiwiYmF0dGVyaWVzSW5zZXJ0IiwiYmF0dGVyeSIsInZhbGlkYXRlIiwiZXhjZXB0aW9uIiwiZXJyb3IiLCJFcnJvciIsIm1lc3NhZ2UiLCJiYXR0ZXJpZXNVcGRhdGUiLCIkc2V0IiwiYmF0dGVyaWVzU29mdERlbGV0ZSIsImJhdHRlcmllc1Jlc3RvcmUiLCJiYXR0ZXJpZXNIYXJkRGVsZXRlIiwibGltaXQiLCJ0aW1lUmFuZ2UiLCJwYXRoIiwiZnMiLCJzYXZlRmlsZUZyb21idWZmZXIiLCJkZWxldGVGaWxlIiwiZ2V0RmlsZUxpc3QiLCJGdXR1cmUiLCJidWZmZXIiLCJtaXNzaW9uSWQiLCJmaWxlTmFtZSIsIlVpbnQ4QXJyYXkiLCJtaXNzaW9uRGlyIiwiam9pbiIsInNldHRpbmdzIiwicHJpdmF0ZSIsImNvbmZpZyIsIm1pc3Npb25zUGF0aCIsImZ1dHVyZSIsIm9iakpzb24iLCJyZXR1cm4iLCJ3YWl0IiwiZGlyUGF0aCIsImV4aXN0c1N5bmMiLCJhcnJheSIsImZvckVhY2giLCJmaWxlUGF0aCIsIm5ld0ZpbGVQYXRoIiwiY29weUZpbGVTeW5jIiwiTWlzc2lvbnMiLCJtaXNzaW9ucyIsInByb2plY3RJZCIsInByb2plY3QiLCJtaXNzaW9uc1ZpZXciLCJtaXNzaW9uc0V4cG9ydCIsIkZlYXR1cmVQb2ludCIsIkZlYXR1cmVQb2x5Z29uIiwiRmVhdHVyZUxpbmVTdHJpbmciLCJGZWF0dXJlQ29sbGVjdGlvblBvaW50cyIsImZsaWdodFBhcmFtZXRlcnNTY2hlbWEiLCJoZWlnaHQiLCJzcGVlZCIsImVudHJ5TWFyZ2luIiwiYXhpc0J1ZmZlciIsInBpY3R1cmVHcmlkU2NoZW1hIiwib3ZlcmxhcCIsIm1heCIsInNpZGVsYXAiLCJtaXNzaW9uQ2FsY3VsYXRlZERhdGFTY2hlbWEiLCJmbGlnaHRUaW1lIiwiZmxpZ2h0VGltZU1pbnV0ZXMiLCJwYXRoTGVuZ3RoIiwicmVzb2x1dGlvbiIsInNob290VGltZSIsInRvdGFsQXJlYSIsImRpc3RQaWNzIiwibWlzc2lvbkNhbGN1bGF0aW9uU2NoZW1hIiwid2F5cG9pbnRMaXN0IiwibWlzc2lvbkNhbGN1bGF0ZWREYXRhIiwiZGVzY3JpcHRpb24iLCJycGEiLCJwYXlsb2FkIiwibWlzc2lvblR5cGUiLCJhbGxvd2VkVmFsdWVzIiwibGF5ZXJzIiwiQXJyYXkiLCJmbGlnaHRQbGFuIiwiZG9uZSIsIkJvb2xlYW4iLCJzdGF0dXMiLCJkZWxldGVGb2xkZXJSZWN1cnNpdmVTeW5jIiwibmV3TWlzc2lvblNjaGVtYSIsImltcG9ydE1pc3Npb25TY2hlbWEiLCJlZGl0TWlzc2lvblNjaGVtYSIsIm1pc3Npb25zSW5zZXJ0IiwibWlzc2lvbiIsIm5ld01pc3Npb25JRCIsIm1rZGlyU3luYyIsIm1pc3Npb25zSW1wb3J0IiwibWlzc2lvbnNVcGRhdGUiLCJtaXNzaW9uc1NvZnREZWxldGUiLCJtaXNzaW9uc1Jlc3RvcmUiLCJtaXNzaW9uc0hhcmREZWxldGUiLCJtaXNzaW9uc1NldERvbmUiLCJzZXREb25lIiwibWlzc2lvbnNTZXRUYWtlT2ZmUG9pbnQiLCJ0YWtlT2ZmUG9pbnQiLCJtaXNzaW9uc1NldExhbmRpbmdQb2ludCIsImxhbmRpbmdQb2ludCIsIm1pc3Npb25zU2V0TWlzc2lvbkdlb21ldHJ5IiwibWlzc2lvbkdlb21ldHJ5IiwiZmluZE9uZSIsIiR1bnNldCIsIm1pc3Npb25zU2V0RmxpZ2h0UGFyYW1zIiwiZmxpZ2h0UGFyYW1ldGVycyIsImZsaWdodFBhcmFtc1NjaGVtYSIsImdldE9iamVjdFNjaGVtYSIsIm1pc3Npb25zU2V0UGljdHVyZUdyaWQiLCJwaWN0dXJlR3JpZCIsIm1pc3Npb25zU2V0TWlzc2lvbkNhbGN1bGF0aW9ucyIsIm1pc3Npb25DYWxjdWxhdGlvbnNEYXRhIiwibWlzc2lvbnNFZGl0V2F5cG9pbnRMaXN0IiwibmV3V2F5UG9pbnRMaXN0IiwibWlzc2lvbnNDbGVhcldheVBvaW50cyIsIndheXBvaW50SW5kZXgiLCJuZXdXYXlQb2ludEFsdFJlbGF0aXZlIiwibWlzc2lvbnNTZXRMYW5kaW5nQmVhcmluZyIsImxhbmRpbmdCZWFyaW5nIiwiU2VydmljZUNvbmZpZ3VyYXRpb24iLCJvYXV0aFZlcmlmeUNvbmZpZ3VyYXRpb24iLCJzZXJ2aWNlcyIsInZlcmlmaWVkU2VydmljZXMiLCJzZXJ2aWNlIiwiY29uZmlndXJhdGlvbnMiLCJwdXNoIiwic29ydCIsIlBheWxvYWRzIiwicGF5bG9hZHMiLCJwYXlsb2Fkc1ZpZXciLCJwYXlsb2FkSWQiLCJwYXlsb2Fkc01pc3Npb24iLCJmaWVsZHMiLCJjYW1lcmFQYXJhbWV0ZXJzU2NoZW1hIiwiZm9jYWxMZW5ndGgiLCJzZW5zb3JXaWR0aCIsInNlbnNvckhlaWdodCIsImltYWdlV2lkdGgiLCJpbWFnZUhlaWdodCIsInBheWxvYWRUeXBlIiwic2Vuc29yUGFyYW1ldGVycyIsIm9uZU9mIiwibmV3UGF5bG9hZFNjaGVtYSIsImVkaXRQYXlsb2FkU2NoZW1hIiwicGF5bG9hZHNJbnNlcnQiLCJwYXlsb2Fkc1VwZGF0ZSIsInBheWxvYWRzU29mdERlbGV0ZSIsInBheWxvYWRzUmVzdG9yZSIsInBheWxvYWRzSGFyZERlbGV0ZSIsIlByb2plY3RzIiwicHJvamVjdHMiLCJwcm9qZWN0c1ZpZXciLCJtYXBMb2NhdGlvbiIsIm5ld1Byb2plY3RTY2hlbWEiLCJlZGl0UHJvamVjdFNjaGVtYSIsInByb2plY3RzSW5zZXJ0IiwicHJvamVjdHNVcGRhdGUiLCJwcm9qZWN0c1NvZnREZWxldGUiLCJwcm9qZWN0c1Jlc3RvcmUiLCJwcm9qZWN0c0hhcmREZWxldGUiLCJwcm9qZWN0c1NldERvbmUiLCJSUEFzIiwicnBhcyIsInJwYXNWaWV3IiwicnBhSWQiLCJycGFzTWlzc2lvbiIsInJwYVR5cGUiLCJtYXhEZXNjZW5kU2xvcGUiLCJtYXhBc2NlbmRTbG9wZSIsIm9wdGltYWxMYW5kaW5nU2xvcGUiLCJvcHRpbWFsVGFrZU9mZlNsb3BlIiwibWF4TGFuZFNwZWVkIiwiY29uc3RydWN0aW9uRGF0ZSIsInNlcmlhbE51bWJlciIsIm5ld1JQQVNjaGVtYSIsImVkaXRSUEFTY2hlbWEiLCJycGFzSW5zZXJ0IiwicnBhc1VwZGF0ZSIsInJwYXNTb2Z0RGVsZXRlIiwicnBhc1Jlc3RvcmUiLCJycGFzSGFyZERlbGV0ZSIsInJwYXNJZCIsIkFjY291bnRzIiwiYWN0aW9uIiwidXBkYXRlVXNlciIsImVtYWlsQWRkcmVzcyIsInByb2ZpbGUiLCJjb25zb2xlIiwibG9nIiwiSlNPTiIsInN0cmluZ2lmeSIsImN1cnJlbnRFbWFpbCIsInVzZXJzIiwiZW1haWxzIiwiZmV0Y2giLCJhZGRyZXNzIiwicmVhc29uIiwic2VuZFZlcmlmaWNhdGlvbkVtYWlsIiwicmVqZWN0IiwiZWRpdFByb2ZpbGUiLCJwcm9taXNlIiwicmVzb2x2ZSIsIlByb21pc2UiLCJvcHRpb25zIiwiUm9sZXMiLCJuZXdVc2VyU2NoZW1hIiwiZW1haWwiLCJyZWdFeCIsIlJlZ0V4IiwiRW1haWwiLCJwYXNzd29yZCIsImVkaXRVc2VyU2NoZW1hIiwidXNlcnNDaGFuZ2VSb2xlIiwibmV3Um9sZSIsInVzZXJJc0luUm9sZSIsInNldFVzZXJSb2xlcyIsInVzZXJzU2V0UGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXJzRWRpdFByb2ZpbGUiLCJmaXJzdCIsImxhc3QiLCJ0aGVuIiwicmVzcG9uc2UiLCJjYXRjaCIsInVzZXJzU29mdERlbGV0ZSIsInVzZXJzSGFyZERlbGV0ZSIsInVzZXJzSW5zZXJ0IiwidXNlciIsImNyZWF0ZVVzZXIiLCJ1c2Vyc1VwZGF0ZSIsInVzZXJQcm9maWxlIiwidXNlcnNNYW5hZ2VtZW50Iiwicm9sZXMiLCJ1c2Vyc1Byb2ZpbGUiLCJzZW5kRW1haWwiLCJnZXRPQXV0aFByb2ZpbGUiLCJPQXV0aFByb2ZpbGUiLCJhcHBsaWNhdGlvbk5hbWUiLCJmaXJzdE5hbWUiLCJ0byIsImZyb20iLCJzdWJqZWN0IiwidGVtcGxhdGUiLCJ0ZW1wbGF0ZVZhcnMiLCJ3ZWxjb21lVXJsIiwiYWJzb2x1dGVVcmwiLCJnZXRQcml2YXRlRmlsZSIsInBhcnNlTWFya2Rvd24iLCJ1dGlsaXR5R2V0UGFnZSIsImV4cG9ydCIsIlBvaW50IiwiTGluZVN0cmluZyIsIlBvbHlnb24iLCJNdWx0aVBvaW50IiwiTXVsdGlMaW5lU3RyaW5nIiwiTXVsdGlQb2x5Z29uIiwiR2VvbWV0cnlDb2xsZWN0aW9uIiwiRmVhdHVyZSIsIkZlYXR1cmVDb2xsZWN0aW9uIiwiR2VvSlNPTlNjaGVtYURlZiIsIkZlYXR1cmVDb2xsZWN0aW9uTGluZVN0cmluZ3MiLCJGZWF0dXJlQ29sbGVjdGlvblBvbHlnb25zIiwiY29vcmRpbmF0ZXMiLCJtaW5Db3VudCIsIm1heENvdW50IiwiY3VzdG9tIiwibGFzdFBvc2l0aW9uSW5kZXgiLCJ2YWx1ZSIsImxlbmd0aCIsImkiLCJiYm94IiwiZ2VvbWV0cmllcyIsImlkIiwiZ2VvbWV0cnkiLCJwcm9wZXJ0aWVzIiwiZmVhdHVyZXMiLCJHZW9KU09OIiwidGVtcGxhdGVUb0hUTUwiLCJ0ZW1wbGF0ZVRvVGV4dCIsImVtYWlsVGVtcGxhdGVzIiwic2l0ZU5hbWUiLCJyZXNldFBhc3N3b3JkIiwiaHRtbCIsInVybCIsInJlc2V0VXJsIiwicmVwbGFjZSIsInRleHQiLCJ1cmxXaXRob3V0SGFzaCIsImlzRGV2ZWxvcG1lbnQiLCJpbmZvIiwidmVyaWZ5RW1haWwiLCJ2ZXJpZnlVcmwiLCJPQXV0aFNldHRpbmdzIiwiZmFjZWJvb2siLCJhcHBJZCIsInNlY3JldCIsImxvZ2luU3R5bGUiLCJnb29nbGUiLCJjbGllbnRJZCIsIk9BdXRoIiwia2V5cyIsInVwc2VydCIsInNlbmRXZWxjb21lRW1haWwiLCJvbkNyZWF0ZVVzZXIiLCJ1c2VyVG9DcmVhdGUiLCJfIiwicmVjb25jaWxlUm9sZXMiLCJ1bmlxIiwiY29uY2F0IiwibWFwIiwiY3JlYXRlUm9sZSIsIm9ic2VydmUiLCJhZGRlZCIsInByb2Nlc3MiLCJlbnYiLCJNQUlMX1VSTCIsInNlZWRlciIsImZha2VyIiwiR2VvRHJvbmVSUEEiLCJSUEFzVmVjdG9yIiwiY29tbWVyY2UiLCJwcm9kdWN0TmFtZSIsInJhbmRvbSIsImFycmF5RWxlbWVudCIsInByb2R1Y3RBZGplY3RpdmUiLCJudW1iZXIiLCJkYXRlIiwicGFzdCIsIkNhbWVyYXNWZWN0b3IiLCJjYW1lcmFzVmVjdG9yIiwiYmF0dGVyaWVzU2VlZCIsImJhdHRlcmllc1ZlY3RvciIsIm1pc3Npb25zU2VlZCIsInJwYXNQYXlsb2Fkc0lEUyIsImNvbGxlY3Rpb24iLCJlbnZpcm9ubWVudHMiLCJub0xpbWl0IiwibW9kZWxDb3VudCIsImRhdGFJbmRleCIsInJwYXNJZHMiLCJwYXlsb2FkSWRzIiwicHJvamVjdHNTZWVkIiwibG9uZ2l0dWRlIiwibGF0aXR1ZGUiLCJ6b29tIiwiZGF0YSIsImluc2VydE90aGVyRGF0YSIsInVzZXJSUEFTUGF5bG9hZHMiLCJycGFJRCIsImNhbWVyYSIsInBheWxvYWRJRCIsInVzZXJJdGVtSURTIiwiaW5kZXgiLCJ1c2VyQ291bnQiLCJsYXN0TmFtZSIsImlzUHJvZHVjdGlvbiIsInVzZXJFeGlzdHMiLCJ2ZXJpZmllZCIsImJ1aWxkQ29tcGxldGVQYXRoIiwiZ2V0RmlsZXNJbkRpckJ5RXh0ZW5zaW9uIiwiY3JlYXRlRGlyZWN0b3J5IiwiZ2V0Rm9sZGVyU2l6ZSIsImdldEZpbGVTaXplIiwic3Bhd24iLCJkaXIiLCJsYXN0Q2hhciIsInN1YnN0ciIsInNsYXNoIiwiZGVsZXRlZEZpbGVzIiwibnVtYmVyT2ZGb2xkZXJzIiwicGF0aERpciIsInJvb3QiLCJmaWxlcyIsInJlYWRkaXJTeW5jIiwiZmlsZSIsImN1clBhdGgiLCJsc3RhdFN5bmMiLCJpc0RpcmVjdG9yeSIsInVubGlua1N5bmMiLCJybWRpclN5bmMiLCJmb2xkZXJzIiwiY2FsbGJhY2siLCJmaWxlc0FyciIsInJlYWRkaXIiLCJlcnIiLCJleHRlbnNpb24iLCJyZSIsIlJlZ0V4cCIsImV4dGVuc2lvbkxlbmdodCIsImZpbHRlciIsIm1hdGNoIiwiZ2V0RmlsZXNJbkRpckJ5UHJlZml4IiwicHJlZml4IiwicHJlZml4TGVuZ2h0IiwiY29tcGxldGVQYXRoIiwidW5saW5rIiwicmVzdWx0IiwiZnVsbEZpbGVOYW1lIiwic3RhdCIsInN0YXRzIiwic2V0VGltZW91dCIsIndyaXRlRmlsZSIsIkJ1ZmZlciIsImVycm9yMiIsImV4aXN0cyIsIm1rZGlyIiwiemlwQUNvbXBsZXRlRm9sZGVyIiwiZm9sZGVyUGF0aCIsInppcFBhdGgiLCJ6aXBGb2xkZXIiLCJmaWxlbmFtZSIsInN0YXRTeW5jIiwiZmlsZVNpemVJbkJ5dGVzIiwic2l6ZSIsImZvbGRlciIsImZvbGRlclNpemUiLCJnZXRGb2xkZXJTaXplX29sZCIsInRvdGFsU2l6ZSIsInN0ZG91dCIsIm9uIiwiaXRlbSIsInN0ZGVyciIsInJlYWRGaWxlU3luYyIsImhhbmRsZWJhcnMiLCJqdWljZSIsImhhbmRsZWJhcnNNYXJrdXAiLCJjb250ZXh0IiwiY29tcGlsZSIsImlubGluZUNzcyIsImRlZmVyIiwic2VuZCIsInJlc3QiLCJwYXJzZUdvb2dsZURhdGEiLCJnaXZlbl9uYW1lIiwiZmFtaWx5X25hbWUiLCJwYXJzZUZhY2Vib29rRGF0YSIsImZpcnN0X25hbWUiLCJsYXN0X25hbWUiLCJnZXREYXRhRm9yU2VydmljZSIsImlzT0F1dGgiLCJzZXJ2aWNlRGF0YSIsIlBhcnNlciIsIkh0bWxSZW5kZXJlciIsIm1hcmtkb3duIiwicmVhZGVyIiwid3JpdGVyIiwicGFyc2VkIiwicGFyc2UiLCJyZW5kZXIiLCJERFBSYXRlTGltaXRlciIsImlzU2VydmVyIiwiYWRkUnVsZSIsImluZGV4T2YiLCJjb25uZWN0aW9uSWQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSxJQUFJQSxnQkFBSjs7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxRQUFELGtCQUFRSSxDQUFSLEVBQVU7QUFBQ0osY0FBT0ksQ0FBUDtBQUFTO0FBQXBCLENBQXRDLEVBQTRELENBQTVEOztBQUErRCxJQUFJQyxlQUFKOztBQUFVSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLE9BQUQsaUJBQU9ELENBQVAsRUFBUztBQUFDQyxhQUFNRCxDQUFOO0FBQVE7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUUsa0JBQUo7QUFBY0wsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQ0UsZ0JBQVVGLENBQVY7QUFBWTtBQUF4QixDQUFyQyxFQUErRCxDQUEvRDs7QUFJOUpKLFFBQU9RLE9BQVAsQ0FBZSxXQUFmLEVBQTRCLFNBQVNDLFNBQVQsR0FBcUI7QUFDL0MsU0FBT0gsVUFBVUksSUFBVixDQUFlO0FBQUVDLFdBQU8sS0FBS0M7QUFBZCxHQUFmLENBQVA7QUFDRCxDQUZELEUsQ0FJQTs7O0FBQ0FaLFFBQU9RLE9BQVAsQ0FBZSxnQkFBZixFQUFpQyxTQUFTSyxhQUFULENBQXVCQyxTQUF2QixFQUFrQztBQUNqRVQsU0FBTVMsU0FBTixFQUFpQkMsTUFBakI7O0FBQ0EsU0FBT1QsVUFBVUksSUFBVixDQUFlO0FBQUVNLFNBQUtGLFNBQVA7QUFBa0JILFdBQU8sS0FBS0M7QUFBOUIsR0FBZixDQUFQO0FBQ0QsQ0FIRCxFOzs7Ozs7Ozs7Ozs7O0FDVEEsSUFBSUssZUFBSjs7QUFBVWhCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ2MsT0FBRCxpQkFBT2IsQ0FBUCxFQUFTO0FBQUNhLGFBQU1iLENBQU47QUFBUTtBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJYyxxQkFBSjtBQUFpQmpCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ksU0FBRCxvQkFBU0gsQ0FBVCxFQUFXO0FBQUNjLG1CQUFhZCxDQUFiO0FBQWU7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFLdkYsSUFBTUUsWUFBWSxJQUFJVyxPQUFNRSxVQUFWLENBQXFCLFdBQXJCLENBQWxCO0FBRUFiLFVBQVVjLEtBQVYsQ0FBZ0I7QUFDZEMsVUFBUTtBQUFBLFdBQU0sS0FBTjtBQUFBLEdBRE07QUFFZEMsVUFBUTtBQUFBLFdBQU0sS0FBTjtBQUFBLEdBRk07QUFHZEMsVUFBUTtBQUFBLFdBQU0sS0FBTjtBQUFBO0FBSE0sQ0FBaEI7QUFNQWpCLFVBQVVrQixJQUFWLENBQWU7QUFDYkgsVUFBUTtBQUFBLFdBQU0sSUFBTjtBQUFBLEdBREs7QUFFYkMsVUFBUTtBQUFBLFdBQU0sSUFBTjtBQUFBLEdBRks7QUFHYkMsVUFBUTtBQUFBLFdBQU0sSUFBTjtBQUFBO0FBSEssQ0FBZjtBQU9BakIsVUFBVW1CLE1BQVYsR0FBbUIsSUFBSVAsWUFBSixDQUFpQjtBQUNsQ1AsU0FBTztBQUNMZSxVQUFNWCxNQUREO0FBRUxZLFdBQU87QUFGRixHQUQyQjtBQUtsQ0MsYUFBVztBQUNURixVQUFNWCxNQURHO0FBRVRZLFdBQU8sb0RBRkU7QUFHVEUsYUFIUyx1QkFHRztBQUNWLFVBQUksS0FBS0MsUUFBVCxFQUFtQixPQUFRLElBQUlDLElBQUosRUFBRCxDQUFhQyxXQUFiLEVBQVA7QUFDcEI7QUFMUSxHQUx1QjtBQVlsQ0MsYUFBVztBQUNUUCxVQUFNWCxNQURHO0FBRVRZLFdBQU8seUNBRkU7QUFHVEUsYUFIUyx1QkFHRztBQUNWLFVBQUksS0FBS0MsUUFBTCxJQUFpQixLQUFLSSxRQUExQixFQUFvQyxPQUFRLElBQUlILElBQUosRUFBRCxDQUFhQyxXQUFiLEVBQVA7QUFDckM7QUFMUSxHQVp1QjtBQW1CbENHLFFBQU07QUFDSlQsVUFBTVgsTUFERjtBQUVKWSxXQUFPO0FBRkgsR0FuQjRCO0FBdUJsQ1MsU0FBTztBQUNMVixVQUFNWCxNQUREO0FBRUxZLFdBQU87QUFGRixHQXZCMkI7QUEyQmxDVSxzQkFBb0I7QUFDbEJYLFVBQU1YLE1BRFk7QUFFbEJZLFdBQU87QUFGVyxHQTNCYztBQStCbENXLFdBQVM7QUFDUFosVUFBTWEsTUFEQztBQUVQWixXQUFPLDZDQUZBO0FBR1BhLFNBQUs7QUFIRSxHQS9CeUI7QUFvQ2xDQyxjQUFZO0FBQ1ZmLFVBQU1SLGFBQWF3QixPQURUO0FBRVZmLFdBQU8sdUNBRkc7QUFHVmEsU0FBSztBQUhLLEdBcENzQjtBQXlDbENHLFVBQVE7QUFDTmpCLFVBQU1hLE1BREE7QUFFTlosV0FBTyxzQ0FGRDtBQUdOYSxTQUFLLENBSEM7QUFJTkksY0FBVTtBQUpKLEdBekMwQjtBQStDbENDLFdBQVM7QUFDUG5CLFVBQU1YLE1BREM7QUFFUFksV0FBTyxtQ0FGQTtBQUdQRSxhQUhPLHVCQUdLO0FBQ1YsVUFBSSxLQUFLQyxRQUFULEVBQW1CLE9BQU8sSUFBUDtBQUNwQjtBQUxNLEdBL0N5QjtBQXNEbENnQixXQUFTO0FBQ1BwQixVQUFNcUIsTUFEQztBQUVQSCxjQUFVLElBRkg7QUFHUEksY0FBVSxJQUhIO0FBSVByQixXQUFPO0FBSkE7QUF0RHlCLENBQWpCLENBQW5CO0FBOERBckIsVUFBVTJDLFlBQVYsQ0FBdUIzQyxVQUFVbUIsTUFBakM7QUFsRkF4QixPQUFPaUQsYUFBUCxDQW9GZTVDLFNBcEZmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQSxJQUFJTixnQkFBSjs7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxRQUFELGtCQUFRSSxDQUFSLEVBQVU7QUFBQ0osY0FBT0ksQ0FBUDtBQUFTO0FBQXBCLENBQXRDLEVBQTRELENBQTVEOztBQUErRCxJQUFJQyxlQUFKOztBQUFVSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLE9BQUQsaUJBQU9ELENBQVAsRUFBUztBQUFDQyxhQUFNRCxDQUFOO0FBQVE7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUUsa0JBQUo7QUFBY0wsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQ0UsZ0JBQVVGLENBQVY7QUFBWTtBQUF4QixDQUFwQyxFQUE4RCxDQUE5RDtBQUFpRSxJQUFJK0Msa0JBQUo7QUFBY2xELE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDK0MsZ0JBQVUvQyxDQUFWO0FBQVk7QUFBeEIsQ0FBakQsRUFBMkUsQ0FBM0U7QUFNN08sSUFBTWdELG1CQUFtQjlDLFVBQVVtQixNQUFWLENBQWlCNEIsSUFBakIsQ0FBc0IsTUFBdEIsRUFBOEIsT0FBOUIsRUFBdUMsb0JBQXZDLEVBQTZELFNBQTdELEVBQXdFLFlBQXhFLEVBQXNGLFFBQXRGLENBQXpCO0FBRUEsSUFBTUMsb0JBQW9CaEQsVUFBVW1CLE1BQVYsQ0FBaUI0QixJQUFqQixDQUFzQixNQUF0QixFQUE4QixPQUE5QixFQUF1QyxvQkFBdkMsRUFBNkQsU0FBN0QsRUFBd0UsWUFBeEUsRUFBc0YsUUFBdEYsQ0FBMUI7QUFDQUMsa0JBQWtCQyxNQUFsQixDQUF5QjtBQUFFdkMsT0FBS0Q7QUFBUCxDQUF6Qjs7QUFFQWYsUUFBT3dELE9BQVAsQ0FBZTtBQUNiLHNCQUFvQixTQUFTQyxlQUFULENBQXlCQyxPQUF6QixFQUFrQztBQUNwRCxRQUFJO0FBQ0ZOLHVCQUFpQk8sUUFBakIsQ0FBMEJELE9BQTFCO0FBQ0EsYUFBT3BELFVBQVVlLE1BQVY7QUFBbUJWLGVBQU8sS0FBS0M7QUFBL0IsU0FBMEM4QyxPQUExQyxFQUFQO0FBQ0QsS0FIRCxDQUdFLE9BQU9FLFNBQVAsRUFBa0I7QUFDbEIsVUFBSUEsVUFBVUMsS0FBVixLQUFvQixrQkFBeEIsRUFBNEM7QUFDMUMsY0FBTSxJQUFJN0QsUUFBTzhELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0JGLFVBQVVHLE9BQWhDLENBQU47QUFDRDs7QUFDRCxZQUFNLElBQUkvRCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0YsR0FYWTtBQVliLHNCQUFvQixTQUFTSSxlQUFULENBQXlCTixPQUF6QixFQUFrQztBQUNwRCxRQUFJO0FBQ0ZKLHdCQUFrQkssUUFBbEIsQ0FBMkJELE9BQTNCO0FBQ0EsVUFBTTVDLFlBQVk0QyxRQUFRMUMsR0FBMUI7QUFDQVYsZ0JBQVVnQixNQUFWLENBQWlCUixTQUFqQixFQUE0QjtBQUFFbUQsY0FBTVA7QUFBUixPQUE1QjtBQUNBLGFBQU81QyxTQUFQLENBSkUsQ0FLRjtBQUNELEtBTkQsQ0FNRSxPQUFPOEMsU0FBUCxFQUFrQjtBQUNsQixVQUFJQSxVQUFVQyxLQUFWLEtBQW9CLGtCQUF4QixFQUE0QztBQUMxQyxjQUFNLElBQUk3RCxRQUFPOEQsS0FBWCxDQUFpQixHQUFqQixFQUFzQkYsVUFBVUcsT0FBaEMsQ0FBTjtBQUNEOztBQUNELFlBQU0sSUFBSS9ELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQXpCWTtBQTBCYiwwQkFBd0IsU0FBU00sbUJBQVQsQ0FBNkJwRCxTQUE3QixFQUF3QztBQUM5RFQsV0FBTVMsU0FBTixFQUFpQkMsTUFBakI7O0FBQ0EsUUFBSTtBQUNGVCxnQkFBVWdCLE1BQVYsQ0FBaUJSLFNBQWpCLEVBQTRCO0FBQUVtRCxjQUFNO0FBQUVwQixtQkFBVSxJQUFJZCxJQUFKLEVBQUQsQ0FBYUMsV0FBYjtBQUFYO0FBQVIsT0FBNUI7QUFDRCxLQUZELENBRUUsT0FBTzRCLFNBQVAsRUFBa0I7QUFDbEIsWUFBTSxJQUFJNUQsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGLEdBakNZO0FBa0NiLHVCQUFxQixTQUFTTyxnQkFBVCxDQUEwQnJELFNBQTFCLEVBQXFDO0FBQ3hEVCxXQUFNUyxTQUFOLEVBQWlCQyxNQUFqQjs7QUFDQSxRQUFJO0FBQ0ZULGdCQUFVZ0IsTUFBVixDQUFpQlIsU0FBakIsRUFBNEI7QUFBRW1ELGNBQU07QUFBRXBCLG1CQUFTO0FBQVg7QUFBUixPQUE1QjtBQUNELEtBRkQsQ0FFRSxPQUFPZSxTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTVELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQXpDWTtBQTBDYiwwQkFBd0IsU0FBU1EsbUJBQVQsQ0FBNkJ0RCxTQUE3QixFQUF3QztBQUM5RFQsV0FBTVMsU0FBTixFQUFpQkMsTUFBakI7O0FBQ0EsUUFBSTtBQUNGLGFBQU9ULFVBQVVpQixNQUFWLENBQWlCVCxTQUFqQixDQUFQO0FBQ0QsS0FGRCxDQUVFLE9BQU84QyxTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTVELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRjtBQWpEWSxDQUFmOztBQW9EQVQsVUFBVTtBQUNSSyxXQUFTLENBQ1Asa0JBRE8sRUFFUCxrQkFGTyxFQUdQLHNCQUhPLEVBSVAsbUJBSk8sRUFLUCxzQkFMTyxDQUREO0FBUVJhLFNBQU8sQ0FSQztBQVNSQyxhQUFXO0FBVEgsQ0FBVixFOzs7Ozs7Ozs7Ozs7O0FDL0RBLElBQUl0RSxnQkFBSjs7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxRQUFELGtCQUFRSSxDQUFSLEVBQVU7QUFBQ0osY0FBT0ksQ0FBUDtBQUFTO0FBQXBCLENBQXRDLEVBQTRELENBQTVEOztBQUErRCxJQUFJQyxlQUFKOztBQUFVSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLE9BQUQsaUJBQU9ELENBQVAsRUFBUztBQUFDQyxhQUFNRCxDQUFOO0FBQVE7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSW1FLGFBQUo7QUFBU3RFLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0ksU0FBRCxvQkFBU0gsQ0FBVCxFQUFXO0FBQUNtRSxXQUFLbkUsQ0FBTDtBQUFPO0FBQW5CLENBQTdCLEVBQWtELENBQWxEO0FBQXFELElBQUlvRSxXQUFKO0FBQU92RSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsSUFBUixDQUFiLEVBQTJCO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDb0UsU0FBR3BFLENBQUg7QUFBSztBQUFqQixDQUEzQixFQUE4QyxDQUE5QztBQUFpRCxJQUFJK0Msa0JBQUo7QUFBY2xELE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDK0MsZ0JBQVUvQyxDQUFWO0FBQVk7QUFBeEIsQ0FBcEQsRUFBOEUsQ0FBOUU7O0FBQWlGLElBQUlxRSw0QkFBSjtBQUFBLElBQXVCQyxvQkFBdkI7QUFBQSxJQUFrQ0MscUJBQWxDOztBQUE4QzFFLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxxQ0FBUixDQUFiLEVBQTREO0FBQUNzRSxvQkFBRCw4QkFBb0JyRSxDQUFwQixFQUFzQjtBQUFDcUUsMEJBQW1CckUsQ0FBbkI7QUFBcUIsR0FBNUM7QUFBNkNzRSxZQUE3QyxzQkFBd0R0RSxDQUF4RCxFQUEwRDtBQUFDc0Usa0JBQVd0RSxDQUFYO0FBQWEsR0FBeEU7QUFBeUV1RSxhQUF6RSx1QkFBcUZ2RSxDQUFyRixFQUF1RjtBQUFDdUUsbUJBQVl2RSxDQUFaO0FBQWM7QUFBdEcsQ0FBNUQsRUFBb0ssQ0FBcEs7O0FBT25aLElBQU13RSxTQUFTekUsUUFBUSxlQUFSLENBQWY7O0FBRUFILFFBQU93RCxPQUFQLENBQWU7QUFDYiwyQkFBeUIsOEJBQUNxQixNQUFELEVBQVNDLFNBQVQsRUFBb0JDLFFBQXBCLEVBQWlDO0FBQ3hEMUUsV0FBTXdFLE1BQU4sRUFBY0csVUFBZDs7QUFDQTNFLFdBQU15RSxTQUFOLEVBQWlCL0QsTUFBakI7O0FBQ0FWLFdBQU0wRSxRQUFOLEVBQWdCaEUsTUFBaEI7O0FBQ0EsUUFBSTtBQUNGLFVBQU1rRSxhQUFhVixLQUFLVyxJQUFMLENBQVVsRixRQUFPbUYsUUFBUCxDQUFnQkMsT0FBaEIsQ0FBd0JDLE1BQXhCLENBQStCQyxZQUF6QyxFQUEwRFIsU0FBMUQsT0FBbkI7QUFDQSxVQUFNUyxTQUFTLElBQUlYLE1BQUosRUFBZjs7QUFDQUgsMEJBQW1CSSxNQUFuQixFQUEyQkksVUFBM0IsRUFBdUNGLFFBQXZDLEVBQWlELFVBQUNTLE9BQUQsRUFBYTtBQUM1REQsZUFBT0UsTUFBUCxDQUFjRCxPQUFkO0FBQ0QsT0FGRDs7QUFHQSxhQUFPRCxPQUFPRyxJQUFQLEVBQVA7QUFDRCxLQVBELENBT0UsT0FBTzlCLFNBQVAsRUFBa0I7QUFDbEIsWUFBTSxJQUFJNUQsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGLEdBZlk7QUFpQmIsNkJBQTJCLGdDQUFDa0IsU0FBRCxFQUFZQyxRQUFaLEVBQXlCO0FBQ2xEMUUsV0FBTXlFLFNBQU4sRUFBaUIvRCxNQUFqQjs7QUFDQVYsV0FBTTBFLFFBQU4sRUFBZ0JoRSxNQUFoQjs7QUFDQSxRQUFJO0FBQ0YsVUFBTWtFLGFBQWFWLEtBQUtXLElBQUwsQ0FBVWxGLFFBQU9tRixRQUFQLENBQWdCQyxPQUFoQixDQUF3QkMsTUFBeEIsQ0FBK0JDLFlBQXpDLEVBQTBEUixTQUExRCxPQUFuQjtBQUNBLFVBQU1TLFNBQVMsSUFBSVgsTUFBSixFQUFmOztBQUNBRixrQkFBV08sVUFBWCxFQUF1QkYsUUFBdkIsRUFBaUMsVUFBQ1MsT0FBRCxFQUFhO0FBQzVDRCxlQUFPRSxNQUFQLENBQWNELE9BQWQ7QUFDRCxPQUZEOztBQUdBLGFBQU9ELE9BQU9HLElBQVAsRUFBUDtBQUNELEtBUEQsQ0FPRSxPQUFPOUIsU0FBUCxFQUFrQjtBQUNsQixZQUFNLElBQUk1RCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0YsR0E5Qlk7QUFnQ2IsNkJBQTJCLGdDQUFDa0IsU0FBRCxFQUFZYSxPQUFaLEVBQXdCO0FBQ2pEdEYsV0FBTXlFLFNBQU4sRUFBaUIvRCxNQUFqQjs7QUFDQVYsV0FBTXNGLE9BQU4sRUFBZTVFLE1BQWY7O0FBQ0EsUUFBSTtBQUNGLFVBQU13RSxTQUFTLElBQUlYLE1BQUosRUFBZjs7QUFDQSxVQUFJSixHQUFHb0IsVUFBSCxDQUFjRCxPQUFkLENBQUosRUFBNEI7QUFDMUIsWUFBTVYsYUFBYVYsS0FBS1csSUFBTCxDQUFVbEYsUUFBT21GLFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCQyxNQUF4QixDQUErQkMsWUFBekMsRUFBMERSLFNBQTFELE9BQW5COztBQUNBSCxxQkFBWWdCLE9BQVosRUFBcUIsVUFBQ0UsS0FBRCxFQUFXO0FBQzlCQSxnQkFBTUMsT0FBTixDQUFjLFVBQUNmLFFBQUQsRUFBYztBQUMxQixnQkFBTWdCLFdBQVd4QixLQUFLVyxJQUFMLENBQVVTLE9BQVYsRUFBbUJaLFFBQW5CLENBQWpCO0FBQ0EsZ0JBQU1pQixjQUFjekIsS0FBS1csSUFBTCxDQUFVRCxVQUFWLEVBQXNCRixRQUF0QixDQUFwQjtBQUNBUCxlQUFHeUIsWUFBSCxDQUFnQkYsUUFBaEIsRUFBMEJDLFdBQTFCO0FBQ0QsV0FKRDtBQUtELFNBTkQ7QUFPRCxPQVRELE1BU087QUFDTCxjQUFNbEMsTUFBTSxxQkFBTixDQUFOO0FBQ0Q7O0FBQ0QsYUFBT3lCLE9BQU9HLElBQVAsRUFBUDtBQUNELEtBZkQsQ0FlRSxPQUFPOUIsU0FBUCxFQUFrQjtBQUNsQixZQUFNLElBQUk1RCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0Y7QUFyRFksQ0FBZjs7QUF3REFULFVBQVU7QUFDUkssV0FBUyxDQUNQLHVCQURPLEVBRVAseUJBRk8sRUFHUCx5QkFITyxDQUREO0FBTVJhLFNBQU8sQ0FOQztBQU9SQyxhQUFXO0FBUEgsQ0FBVixFOzs7Ozs7Ozs7Ozs7O0FDakVBLElBQUl0RSxnQkFBSjs7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxRQUFELGtCQUFRSSxDQUFSLEVBQVU7QUFBQ0osY0FBT0ksQ0FBUDtBQUFTO0FBQXBCLENBQXRDLEVBQTRELENBQTVEOztBQUErRCxJQUFJQyxlQUFKOztBQUFVSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLE9BQUQsaUJBQU9ELENBQVAsRUFBUztBQUFDQyxhQUFNRCxDQUFOO0FBQVE7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSThGLGlCQUFKO0FBQWFqRyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDOEYsZUFBUzlGLENBQVQ7QUFBVztBQUF2QixDQUFwQyxFQUE2RCxDQUE3RDs7QUFLN0pKLFFBQU9RLE9BQVAsQ0FBZSxVQUFmLEVBQTJCLFNBQVMyRixRQUFULENBQWtCQyxTQUFsQixFQUE2QjtBQUN0RC9GLFNBQU0rRixTQUFOLEVBQWlCckYsTUFBakI7O0FBQ0EsU0FBT21GLFNBQVN4RixJQUFULENBQWM7QUFBRUMsV0FBTyxLQUFLQyxNQUFkO0FBQXNCeUYsYUFBU0Q7QUFBL0IsR0FBZCxDQUFQO0FBQ0QsQ0FIRCxFLENBS0E7OztBQUNBcEcsUUFBT1EsT0FBUCxDQUFlLGVBQWYsRUFBZ0MsU0FBUzhGLFlBQVQsQ0FBc0JGLFNBQXRCLEVBQWlDdEIsU0FBakMsRUFBNEM7QUFDMUV6RSxTQUFNeUUsU0FBTixFQUFpQi9ELE1BQWpCOztBQUNBVixTQUFNK0YsU0FBTixFQUFpQnJGLE1BQWpCOztBQUNBLFNBQU9tRixTQUFTeEYsSUFBVCxDQUFjO0FBQUVNLFNBQUs4RCxTQUFQO0FBQWtCbkUsV0FBTyxLQUFLQyxNQUE5QjtBQUFzQ3lGLGFBQVNEO0FBQS9DLEdBQWQsQ0FBUDtBQUNELENBSkQ7O0FBTUFwRyxRQUFPUSxPQUFQLENBQWUsaUJBQWYsRUFBa0MsU0FBUytGLGNBQVQsR0FBMEI7QUFDMUQsU0FBT0wsU0FBU3hGLElBQVQsQ0FBYztBQUFFQyxXQUFPLEtBQUtDO0FBQWQsR0FBZCxDQUFQO0FBQ0QsQ0FGRCxFOzs7Ozs7Ozs7Ozs7O0FDakJBLElBQUlLLGVBQUo7O0FBQVVoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNjLE9BQUQsaUJBQU9iLENBQVAsRUFBUztBQUFDYSxhQUFNYixDQUFOO0FBQVE7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSWMscUJBQUo7QUFBaUJqQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDYyxtQkFBYWQsQ0FBYjtBQUFlO0FBQTNCLENBQXJDLEVBQWtFLENBQWxFOztBQUFxRSxJQUFJb0csc0JBQUo7QUFBQSxJQUFpQkMsd0JBQWpCO0FBQUEsSUFBZ0NDLDJCQUFoQztBQUFBLElBQWtEQyxpQ0FBbEQ7O0FBQTBFMUcsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHFDQUFSLENBQWIsRUFBNEQ7QUFBQ3FHLGNBQUQsd0JBQWNwRyxDQUFkLEVBQWdCO0FBQUNvRyxvQkFBYXBHLENBQWI7QUFBZSxHQUFoQztBQUFpQ3FHLGdCQUFqQywwQkFBZ0RyRyxDQUFoRCxFQUFrRDtBQUFDcUcsc0JBQWVyRyxDQUFmO0FBQWlCLEdBQXBFO0FBQXFFc0csbUJBQXJFLDZCQUF1RnRHLENBQXZGLEVBQXlGO0FBQUNzRyx5QkFBa0J0RyxDQUFsQjtBQUFvQixHQUE5RztBQUErR3VHLHlCQUEvRyxtQ0FBdUl2RyxDQUF2SSxFQUF5STtBQUFDdUcsK0JBQXdCdkcsQ0FBeEI7QUFBMEI7QUFBcEssQ0FBNUQsRUFBa08sQ0FBbE87QUFNdE8sSUFBTThGLFdBQVcsSUFBSWpGLE9BQU1FLFVBQVYsQ0FBcUIsVUFBckIsQ0FBakI7QUFFQStFLFNBQVM5RSxLQUFULENBQWU7QUFDYkMsVUFBUTtBQUFBLFdBQU0sS0FBTjtBQUFBLEdBREs7QUFFYkMsVUFBUTtBQUFBLFdBQU0sS0FBTjtBQUFBLEdBRks7QUFHYkMsVUFBUTtBQUFBLFdBQU0sS0FBTjtBQUFBO0FBSEssQ0FBZjtBQU1BMkUsU0FBUzFFLElBQVQsQ0FBYztBQUNaSCxVQUFRO0FBQUEsV0FBTSxJQUFOO0FBQUEsR0FESTtBQUVaQyxVQUFRO0FBQUEsV0FBTSxJQUFOO0FBQUEsR0FGSTtBQUdaQyxVQUFRO0FBQUEsV0FBTSxJQUFOO0FBQUE7QUFISSxDQUFkO0FBTUEsSUFBTXFGLHlCQUF5QixJQUFJMUYsWUFBSixDQUFpQjtBQUM5QzJGLFVBQVE7QUFDTm5GLFVBQU1hLE1BREE7QUFFTlosV0FBTyxzQ0FGRDtBQUdOYSxTQUFLO0FBSEMsR0FEc0M7QUFNOUNzRSxTQUFPO0FBQ0xwRixVQUFNYSxNQUREO0FBRUxaLFdBQU8sOENBRkY7QUFHTGEsU0FBSztBQUhBLEdBTnVDO0FBVzlDdUUsZUFBYTtBQUNYckYsVUFBTWEsTUFESztBQUVYWixXQUFPLG1EQUZJO0FBR1hhLFNBQUs7QUFITSxHQVhpQztBQWdCOUN3RSxjQUFZO0FBQ1Z0RixVQUFNYSxNQURJO0FBRVZaLFdBQU8sd0RBRkc7QUFHVmEsU0FBSyxDQUhLO0FBSVZJLGNBQVU7QUFKQTtBQWhCa0MsQ0FBakIsQ0FBL0I7QUF3QkEsSUFBTXFFLG9CQUFvQixJQUFJL0YsWUFBSixDQUFpQjtBQUN6Q2dHLFdBQVM7QUFDUHhGLFVBQU1hLE1BREM7QUFFUFosV0FBTyxrQkFGQTtBQUdQYSxTQUFLLENBSEU7QUFJUDJFLFNBQUs7QUFKRSxHQURnQztBQU96Q0MsV0FBUztBQUNQMUYsVUFBTWEsTUFEQztBQUVQWixXQUFPLGtCQUZBO0FBR1BhLFNBQUssQ0FIRTtBQUlQMkUsU0FBSztBQUpFO0FBUGdDLENBQWpCLENBQTFCO0FBZUEsSUFBTUUsOEJBQThCLElBQUluRyxZQUFKLENBQWlCO0FBQ25Eb0csY0FBWTtBQUNWNUYsVUFBTVgsTUFESTtBQUVWWSxXQUFPLDJDQUZHO0FBR1ZhLFNBQUssQ0FISztBQUlWSSxjQUFVO0FBSkEsR0FEdUM7QUFPbkQyRSxxQkFBbUI7QUFDakI3RixVQUFNYSxNQURXO0FBRWpCWixXQUFPLHNEQUZVO0FBR2pCYSxTQUFLLENBSFk7QUFJakJJLGNBQVU7QUFKTyxHQVBnQztBQWFuRDRFLGNBQVk7QUFDVjlGLFVBQU1hLE1BREk7QUFFVlosV0FBTyxpREFGRztBQUdWYSxTQUFLLENBSEs7QUFJVkksY0FBVTtBQUpBLEdBYnVDO0FBbUJuRDZFLGNBQVk7QUFDVi9GLFVBQU1hLE1BREk7QUFFVlosV0FBTyx5Q0FGRztBQUdWYSxTQUFLLENBSEs7QUFJVkksY0FBVTtBQUpBLEdBbkJ1QztBQXlCbkQ4RSxhQUFXO0FBQ1RoRyxVQUFNYSxNQURHO0FBRVRaLFdBQU8saUNBRkU7QUFHVGEsU0FBSyxDQUhJO0FBSVRJLGNBQVU7QUFKRCxHQXpCd0M7QUErQm5EK0UsYUFBVztBQUNUakcsVUFBTWEsTUFERztBQUVUWixXQUFPLHlEQUZFO0FBR1RhLFNBQUssQ0FISTtBQUlUSSxjQUFVO0FBSkQsR0EvQndDO0FBcUNuRGdGLFlBQVU7QUFDUmxHLFVBQU1hLE1BREU7QUFFUlosV0FBTyxvQ0FGQztBQUdSYSxTQUFLLENBSEc7QUFJUkksY0FBVTtBQUpGO0FBckN5QyxDQUFqQixDQUFwQztBQTZDQSxJQUFNaUYsMkJBQTJCLElBQUkzRyxZQUFKLENBQWlCO0FBQ2hENEcsZ0JBQWM7QUFDWnBHLFVBQU1pRix3QkFETTtBQUVaaEYsV0FBTywrREFGSztBQUdaaUIsY0FBVTtBQUhFLEdBRGtDO0FBTWhEbUYseUJBQXVCO0FBQ3JCckcsVUFBTTJGLDJCQURlO0FBRXJCMUYsV0FBTyx3REFGYztBQUdyQmlCLGNBQVU7QUFIVztBQU55QixDQUFqQixDQUFqQztBQWFBc0QsU0FBU3pFLE1BQVQsR0FBa0IsSUFBSVAsWUFBSixDQUFpQjtBQUNqQ1AsU0FBTztBQUNMZSxVQUFNWCxNQUREO0FBRUxZLFdBQU87QUFGRixHQUQwQjtBQUtqQzBFLFdBQVM7QUFDUDNFLFVBQU1YLE1BREM7QUFFUFksV0FBTztBQUZBLEdBTHdCO0FBU2pDQyxhQUFXO0FBQ1RGLFVBQU1YLE1BREc7QUFFVFksV0FBTyxvQ0FGRTtBQUdURSxhQUhTLHVCQUdHO0FBQ1YsVUFBSSxLQUFLQyxRQUFULEVBQW1CLE9BQVEsSUFBSUMsSUFBSixFQUFELENBQWFDLFdBQWIsRUFBUDtBQUNwQjtBQUxRLEdBVHNCO0FBZ0JqQ0MsYUFBVztBQUNUUCxVQUFNWCxNQURHO0FBRVRZLFdBQU8seUNBRkU7QUFHVEUsYUFIUyx1QkFHRztBQUNWLFVBQUksS0FBS0MsUUFBTCxJQUFpQixLQUFLSSxRQUExQixFQUFvQyxPQUFRLElBQUlILElBQUosRUFBRCxDQUFhQyxXQUFiLEVBQVA7QUFDckM7QUFMUSxHQWhCc0I7QUF1QmpDRyxRQUFNO0FBQ0pULFVBQU1YLE1BREY7QUFFSlksV0FBTztBQUZILEdBdkIyQjtBQTJCakNxRyxlQUFhO0FBQ1h0RyxVQUFNWCxNQURLO0FBRVhZLFdBQU8saUNBRkk7QUFHWGlCLGNBQVU7QUFIQyxHQTNCb0I7QUFnQ2pDcUYsT0FBSztBQUNIdkcsVUFBTVgsTUFESDtBQUVIWSxXQUFPO0FBRkosR0FoQzRCO0FBb0NqQ3VHLFdBQVM7QUFDUHhHLFVBQU1YLE1BREM7QUFFUFksV0FBTztBQUZBLEdBcEN3QjtBQXdDakN3RyxlQUFhO0FBQ1h6RyxVQUFNWCxNQURLO0FBRVhZLFdBQU8sa0JBRkk7QUFHWHlHLG1CQUFlLENBQUMsY0FBRCxFQUFpQixhQUFqQjtBQUhKLEdBeENvQjtBQTZDakNDLFVBQVE7QUFDTjNHLFVBQU00RyxLQURBO0FBRU4zRyxXQUFPLHNDQUZEO0FBR05pQixjQUFVO0FBSEosR0E3Q3lCO0FBa0RqQyxjQUFZO0FBQ1ZsQixVQUFNWCxNQURJO0FBRVZZLFdBQU87QUFGRyxHQWxEcUI7QUFzRGpDNEcsY0FBWTtBQUNWN0csVUFBTXFCLE1BREk7QUFFVnBCLFdBQU8sb0NBRkc7QUFHVmlCLGNBQVU7QUFIQSxHQXREcUI7QUEyRGpDLDZCQUEyQjtBQUN6QmxCLFVBQU04RSxhQURtQjtBQUV6QjdFLFdBQU8sbUNBRmtCO0FBR3pCaUIsY0FBVTtBQUhlLEdBM0RNO0FBZ0VqQyw2QkFBMkI7QUFDekJsQixVQUFNOEUsYUFEbUI7QUFFekI3RSxXQUFPLGtDQUZrQjtBQUd6QmlCLGNBQVU7QUFIZSxHQWhFTTtBQXFFakMsNEJBQTBCO0FBQ3hCbEIsVUFBTStFLGVBRGtCO0FBRXhCOUUsV0FBTyxpREFGaUI7QUFHeEJpQixjQUFVO0FBSGMsR0FyRU87QUEwRWpDLDRCQUEwQjtBQUN4QmxCLFVBQU1nRixrQkFEa0I7QUFFeEIvRSxXQUFPLGlEQUZpQjtBQUd4QmlCLGNBQVU7QUFIYyxHQTFFTztBQStFakMsaUNBQStCO0FBQzdCbEIsVUFBTWtGLHNCQUR1QjtBQUU3QmpGLFdBQU8sNEJBRnNCO0FBRzdCaUIsY0FBVTtBQUhtQixHQS9FRTtBQW9GakMsNEJBQTBCO0FBQ3hCbEIsVUFBTXVGLGlCQURrQjtBQUV4QnRGLFdBQU8saURBRmlCO0FBR3hCaUIsY0FBVTtBQUhjLEdBcEZPO0FBeUZqQyxtQ0FBaUM7QUFDL0JsQixVQUFNbUcsd0JBRHlCO0FBRS9CbEcsV0FBTywrREFGd0I7QUFHL0JpQixjQUFVO0FBSHFCLEdBekZBO0FBOEZqQywrQkFBNkI7QUFDM0JsQixVQUFNZ0Ysa0JBRHFCO0FBRTNCL0UsV0FBTyx1RUFGb0I7QUFHM0JpQixjQUFVO0FBSGlCLEdBOUZJO0FBbUdqQ0MsV0FBUztBQUNQbkIsVUFBTVgsTUFEQztBQUVQWSxXQUFPLG1DQUZBO0FBR1BFLGFBSE8sdUJBR0s7QUFDVixVQUFJLEtBQUtDLFFBQVQsRUFBbUIsT0FBTyxJQUFQO0FBQ3BCO0FBTE0sR0FuR3dCO0FBMEdqQzBHLFFBQU07QUFDSjlHLFVBQU0rRyxPQURGO0FBRUo5RyxXQUFPLHNCQUZIO0FBR0pFLGFBSEksdUJBR1E7QUFDVixVQUFJLEtBQUtDLFFBQVQsRUFBbUIsT0FBTyxLQUFQO0FBQ3BCO0FBTEcsR0ExRzJCO0FBaUhqQzRHLFVBQVE7QUFDTmhILFVBQU1YLE1BREE7QUFFTlksV0FBTywyQkFGRDtBQUdOaUIsY0FBVTtBQUhKO0FBakh5QixDQUFqQixDQUFsQjtBQXdIQXNELFNBQVNqRCxZQUFULENBQXNCaUQsU0FBU3pFLE1BQS9CO0FBN09BeEIsT0FBT2lELGFBQVAsQ0ErT2VnRCxRQS9PZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUEsSUFBSWxHLGdCQUFKOztBQUFXQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNILFFBQUQsa0JBQVFJLENBQVIsRUFBVTtBQUFDSixjQUFPSSxDQUFQO0FBQVM7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7O0FBQStELElBQUlDLGVBQUo7O0FBQVVKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0UsT0FBRCxpQkFBT0QsQ0FBUCxFQUFTO0FBQUNDLGFBQU1ELENBQU47QUFBUTtBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJb0UsV0FBSjtBQUFPdkUsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLElBQVIsQ0FBYixFQUEyQjtBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQ29FLFNBQUdwRSxDQUFIO0FBQUs7QUFBakIsQ0FBM0IsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSW1FLGFBQUo7QUFBU3RFLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0ksU0FBRCxvQkFBU0gsQ0FBVCxFQUFXO0FBQUNtRSxXQUFLbkUsQ0FBTDtBQUFPO0FBQW5CLENBQTdCLEVBQWtELENBQWxEO0FBQXFELElBQUk4RixpQkFBSjtBQUFhakcsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFlBQVIsQ0FBYixFQUFtQztBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQzhGLGVBQVM5RixDQUFUO0FBQVc7QUFBdkIsQ0FBbkMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSStDLGtCQUFKO0FBQWNsRCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQytDLGdCQUFVL0MsQ0FBVjtBQUFZO0FBQXhCLENBQWpELEVBQTJFLENBQTNFOztBQUE4RSxJQUFJdUksbUNBQUo7O0FBQThCMUksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGtDQUFSLENBQWIsRUFBeUQ7QUFBQ3dJLDJCQUFELHFDQUEyQnZJLENBQTNCLEVBQTZCO0FBQUN1SSxpQ0FBMEJ2SSxDQUExQjtBQUE0QjtBQUExRCxDQUF6RCxFQUFxSCxDQUFySDs7QUFBd0gsSUFBSW9HLHNCQUFKO0FBQUEsSUFBaUJDLHdCQUFqQjtBQUFBLElBQWdDQywyQkFBaEM7QUFBQSxJQUFrREMsaUNBQWxEOztBQUEwRTFHLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxxQ0FBUixDQUFiLEVBQTREO0FBQUNxRyxjQUFELHdCQUFjcEcsQ0FBZCxFQUFnQjtBQUFDb0csb0JBQWFwRyxDQUFiO0FBQWUsR0FBaEM7QUFBaUNxRyxnQkFBakMsMEJBQWdEckcsQ0FBaEQsRUFBa0Q7QUFBQ3FHLHNCQUFlckcsQ0FBZjtBQUFpQixHQUFwRTtBQUFxRXNHLG1CQUFyRSw2QkFBdUZ0RyxDQUF2RixFQUF5RjtBQUFDc0cseUJBQWtCdEcsQ0FBbEI7QUFBb0IsR0FBOUc7QUFBK0d1Ryx5QkFBL0csbUNBQXVJdkcsQ0FBdkksRUFBeUk7QUFBQ3VHLCtCQUF3QnZHLENBQXhCO0FBQTBCO0FBQXBLLENBQTVELEVBQWtPLENBQWxPO0FBVzlvQixJQUFNd0ksbUJBQW1CMUMsU0FBU3pFLE1BQVQsQ0FBZ0I0QixJQUFoQixDQUFxQixNQUFyQixFQUE2QixTQUE3QixFQUF3QyxLQUF4QyxFQUErQyxhQUEvQyxFQUE4RCxhQUE5RCxFQUE2RSxTQUE3RSxDQUF6QjtBQUVBLElBQU13RixzQkFBc0IzQyxTQUFTekUsTUFBVCxDQUFnQjRCLElBQWhCLENBQXFCLE1BQXJCLEVBQTZCLFNBQTdCLEVBQXdDLEtBQXhDLEVBQStDLGFBQS9DLEVBQThELGFBQTlELEVBQTZFLFNBQTdFLEVBQXdGLFlBQXhGLENBQTVCO0FBRUEsSUFBTXlGLG9CQUFvQjVDLFNBQVN6RSxNQUFULENBQWdCNEIsSUFBaEIsQ0FBcUIsTUFBckIsRUFBNkIsU0FBN0IsRUFBd0MsS0FBeEMsRUFBK0MsYUFBL0MsRUFBOEQsYUFBOUQsRUFBNkUsU0FBN0UsQ0FBMUI7QUFDQXlGLGtCQUFrQnZGLE1BQWxCLENBQXlCO0FBQUV2QyxPQUFLRDtBQUFQLENBQXpCOztBQUVBZixRQUFPd0QsT0FBUCxDQUFlO0FBQ2IscUJBQW1CLFNBQVN1RixjQUFULENBQXdCQyxPQUF4QixFQUFpQztBQUNsRCxRQUFJO0FBQ0ZKLHVCQUFpQmpGLFFBQWpCLENBQTBCcUYsT0FBMUI7QUFDQSxVQUFNQyxlQUFlL0MsU0FBUzdFLE1BQVQ7QUFBa0JWLGVBQU8sS0FBS0M7QUFBOUIsU0FBeUNvSSxPQUF6QyxFQUFyQjtBQUNBLFVBQU0vRCxhQUFhVixLQUFLVyxJQUFMLENBQVVsRixRQUFPbUYsUUFBUCxDQUFnQkMsT0FBaEIsQ0FBd0JDLE1BQXhCLENBQStCQyxZQUF6QyxFQUF1RDJELFlBQXZELENBQW5CO0FBQ0F6RSxTQUFHMEUsU0FBSCxDQUFhakUsVUFBYjtBQUNBLGFBQU9nRSxZQUFQO0FBQ0QsS0FORCxDQU1FLE9BQU9yRixTQUFQLEVBQWtCO0FBQ2xCLFVBQUlBLFVBQVVDLEtBQVYsS0FBb0Isa0JBQXhCLEVBQTRDO0FBQzFDLGNBQU0sSUFBSTdELFFBQU84RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCRixVQUFVRyxPQUFoQyxDQUFOO0FBQ0Q7O0FBQ0QsWUFBTSxJQUFJL0QsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGLEdBZFk7QUFlYixxQkFBbUIsU0FBU3VGLGNBQVQsQ0FBd0JILE9BQXhCLEVBQWlDO0FBQ2xELFFBQUk7QUFDRkgsMEJBQW9CbEYsUUFBcEIsQ0FBNkJxRixPQUE3QjtBQUNBLGFBQU85QyxTQUFTN0UsTUFBVDtBQUFrQlYsZUFBTyxLQUFLQztBQUE5QixTQUF5Q29JLE9BQXpDLEVBQVA7QUFDRCxLQUhELENBR0UsT0FBT3BGLFNBQVAsRUFBa0I7QUFDbEIsVUFBSUEsVUFBVUMsS0FBVixLQUFvQixrQkFBeEIsRUFBNEM7QUFDMUMsY0FBTSxJQUFJN0QsUUFBTzhELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0JGLFVBQVVHLE9BQWhDLENBQU47QUFDRDs7QUFDRCxZQUFNLElBQUkvRCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0YsR0F6Qlk7QUEwQmIscUJBQW1CLFNBQVN3RixjQUFULENBQXdCSixPQUF4QixFQUFpQztBQUNsRCxRQUFJO0FBQ0ZGLHdCQUFrQm5GLFFBQWxCLENBQTJCcUYsT0FBM0I7QUFDQSxVQUFNbEUsWUFBWWtFLFFBQVFoSSxHQUExQjtBQUNBa0YsZUFBUzVFLE1BQVQsQ0FBZ0J3RCxTQUFoQixFQUEyQjtBQUFFYixjQUFNK0U7QUFBUixPQUEzQjtBQUNBLGFBQU9sRSxTQUFQLENBSkUsQ0FJZ0I7QUFDbkIsS0FMRCxDQUtFLE9BQU9sQixTQUFQLEVBQWtCO0FBQ2xCLFVBQUlBLFVBQVVDLEtBQVYsS0FBb0Isa0JBQXhCLEVBQTRDO0FBQzFDLGNBQU0sSUFBSTdELFFBQU84RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCRixVQUFVRyxPQUFoQyxDQUFOO0FBQ0Q7O0FBQ0QsWUFBTSxJQUFJL0QsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGLEdBdENZO0FBdUNiLHlCQUF1QixTQUFTeUYsa0JBQVQsQ0FBNEJ2RSxTQUE1QixFQUF1QztBQUM1RHpFLFdBQU15RSxTQUFOLEVBQWlCL0QsTUFBakI7O0FBQ0EsUUFBSTtBQUNGbUYsZUFBUzVFLE1BQVQsQ0FBZ0J3RCxTQUFoQixFQUEyQjtBQUFFYixjQUFNO0FBQUVwQixtQkFBVSxJQUFJZCxJQUFKLEVBQUQsQ0FBYUMsV0FBYjtBQUFYO0FBQVIsT0FBM0I7QUFDRCxLQUZELENBRUUsT0FBTzRCLFNBQVAsRUFBa0I7QUFDbEIsWUFBTSxJQUFJNUQsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGLEdBOUNZO0FBK0NiLHNCQUFvQixTQUFTMEYsZUFBVCxDQUF5QnhFLFNBQXpCLEVBQW9DO0FBQ3REekUsV0FBTXlFLFNBQU4sRUFBaUIvRCxNQUFqQjs7QUFDQSxRQUFJO0FBQ0ZtRixlQUFTNUUsTUFBVCxDQUFnQndELFNBQWhCLEVBQTJCO0FBQUViLGNBQU07QUFBRXBCLG1CQUFTO0FBQVg7QUFBUixPQUEzQjtBQUNELEtBRkQsQ0FFRSxPQUFPZSxTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTVELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQXREWTtBQXVEYix5QkFBdUIsU0FBUzJGLGtCQUFULENBQTRCekUsU0FBNUIsRUFBdUM7QUFDNUR6RSxXQUFNeUUsU0FBTixFQUFpQi9ELE1BQWpCOztBQUNBLFFBQUk7QUFDRixVQUFNa0UsYUFBYVYsS0FBS1csSUFBTCxDQUFVbEYsUUFBT21GLFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCQyxNQUF4QixDQUErQkMsWUFBekMsRUFBdURSLFNBQXZELENBQW5COztBQUNBNkQsaUNBQTBCMUQsVUFBMUIsRUFBc0MsSUFBdEM7O0FBQ0EsYUFBT2lCLFNBQVMzRSxNQUFULENBQWdCdUQsU0FBaEIsQ0FBUDtBQUNELEtBSkQsQ0FJRSxPQUFPbEIsU0FBUCxFQUFrQjtBQUNsQixZQUFNLElBQUk1RCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0YsR0FoRVk7QUFpRWIsc0JBQW9CLFNBQVM0RixlQUFULENBQXlCMUUsU0FBekIsRUFBb0MyRSxPQUFwQyxFQUE2QztBQUMvRHBKLFdBQU15RSxTQUFOLEVBQWlCL0QsTUFBakI7O0FBQ0FWLFdBQU1vSixPQUFOLEVBQWVoQixPQUFmOztBQUNBLFFBQUk7QUFDRnZDLGVBQVM1RSxNQUFULENBQWdCd0QsU0FBaEIsRUFBMkI7QUFBRWIsY0FBTTtBQUFFdUUsZ0JBQU1pQjtBQUFSO0FBQVIsT0FBM0I7QUFDRCxLQUZELENBRUUsT0FBTzdGLFNBQVAsRUFBa0I7QUFDbEIsWUFBTSxJQUFJNUQsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGLEdBekVZO0FBMEViLDhCQUE0QixTQUFTOEYsdUJBQVQsQ0FBaUM1RSxTQUFqQyxFQUE0QzZFLFlBQTVDLEVBQTBEO0FBQ3BGdEosV0FBTXlFLFNBQU4sRUFBaUIvRCxNQUFqQjs7QUFDQSxRQUFJO0FBQ0Z5RixvQkFBYTdDLFFBQWIsQ0FBc0JnRyxZQUF0Qjs7QUFDQXpELGVBQVM1RSxNQUFULENBQWdCd0QsU0FBaEIsRUFBMkI7QUFBRWIsY0FBTTtBQUFFLHFDQUEyQjBGO0FBQTdCO0FBQVIsT0FBM0I7QUFDRCxLQUhELENBR0UsT0FBTy9GLFNBQVAsRUFBa0I7QUFDbEIsVUFBSUEsVUFBVUMsS0FBVixLQUFvQixrQkFBeEIsRUFBNEM7QUFDMUMsY0FBTSxJQUFJN0QsUUFBTzhELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0JGLFVBQVVHLE9BQWhDLENBQU47QUFDRDs7QUFDRCxZQUFNLElBQUkvRCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0YsR0FyRlk7QUFzRmIsOEJBQTRCLFNBQVNnRyx1QkFBVCxDQUFpQzlFLFNBQWpDLEVBQTRDK0UsWUFBNUMsRUFBMEQ7QUFDcEZ4SixXQUFNeUUsU0FBTixFQUFpQi9ELE1BQWpCOztBQUNBLFFBQUk7QUFDRnlGLG9CQUFhN0MsUUFBYixDQUFzQmtHLFlBQXRCOztBQUNBM0QsZUFBUzVFLE1BQVQsQ0FBZ0J3RCxTQUFoQixFQUEyQjtBQUFFYixjQUFNO0FBQUUscUNBQTJCNEY7QUFBN0I7QUFBUixPQUEzQjtBQUNELEtBSEQsQ0FHRSxPQUFPakcsU0FBUCxFQUFrQjtBQUNsQixVQUFJQSxVQUFVQyxLQUFWLEtBQW9CLGtCQUF4QixFQUE0QztBQUMxQyxjQUFNLElBQUk3RCxRQUFPOEQsS0FBWCxDQUFpQixHQUFqQixFQUFzQkYsVUFBVUcsT0FBaEMsQ0FBTjtBQUNEOztBQUNELFlBQU0sSUFBSS9ELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQWpHWTtBQWtHYixpQ0FBK0IsU0FBU2tHLDBCQUFULENBQW9DaEYsU0FBcEMsRUFBK0NpRixlQUEvQyxFQUFnRTtBQUM3RjFKLFdBQU15RSxTQUFOLEVBQWlCL0QsTUFBakI7O0FBQ0EsUUFBSTtBQUNGLFVBQU1pSSxVQUFVOUMsU0FBUzhELE9BQVQsQ0FBaUJsRixTQUFqQixDQUFoQjs7QUFDQSxVQUFJaUYsZUFBSixFQUFxQjtBQUNuQixZQUFJZixRQUFRYixXQUFSLEtBQXdCLGNBQTVCLEVBQTRDO0FBQzFDMUIsMEJBQWU5QyxRQUFmLENBQXdCb0csZUFBeEI7O0FBQ0E3RCxtQkFBUzVFLE1BQVQsQ0FBZ0J3RCxTQUFoQixFQUEyQjtBQUFFYixrQkFBTTtBQUFFLHdDQUEwQjhGO0FBQTVCO0FBQVIsV0FBM0I7QUFDRCxTQUhELE1BR08sSUFBSWYsUUFBUWIsV0FBUixLQUF3QixhQUE1QixFQUEyQztBQUNoRHpCLDZCQUFrQi9DLFFBQWxCLENBQTJCb0csZUFBM0I7O0FBQ0E3RCxtQkFBUzVFLE1BQVQsQ0FBZ0J3RCxTQUFoQixFQUEyQjtBQUFFYixrQkFBTTtBQUFFLHdDQUEwQjhGO0FBQTVCO0FBQVIsV0FBM0I7QUFDRDtBQUNGLE9BUkQsTUFRTyxJQUFJLENBQUNBLGVBQUwsRUFBc0I7QUFDM0IsWUFBSWYsUUFBUWIsV0FBUixLQUF3QixjQUE1QixFQUE0QztBQUMxQ2pDLG1CQUFTNUUsTUFBVCxDQUFnQndELFNBQWhCLEVBQTJCO0FBQUVtRixvQkFBUTtBQUFFLHdDQUEwQjtBQUE1QjtBQUFWLFdBQTNCO0FBQ0QsU0FGRCxNQUVPLElBQUlqQixRQUFRYixXQUFSLEtBQXdCLGFBQTVCLEVBQTJDO0FBQ2hEakMsbUJBQVM1RSxNQUFULENBQWdCd0QsU0FBaEIsRUFBMkI7QUFBRW1GLG9CQUFRO0FBQUUsd0NBQTBCO0FBQTVCO0FBQVYsV0FBM0I7QUFDRDtBQUNGO0FBQ0YsS0FqQkQsQ0FpQkUsT0FBT3JHLFNBQVAsRUFBa0I7QUFDbEIsVUFBSUEsVUFBVUMsS0FBVixLQUFvQixrQkFBeEIsRUFBNEM7QUFDMUMsY0FBTSxJQUFJN0QsUUFBTzhELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0JGLFVBQVVHLE9BQWhDLENBQU47QUFDRDs7QUFDRCxZQUFNLElBQUkvRCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0YsR0EzSFk7QUE0SGIsOEJBQTRCLFNBQVNzRyx1QkFBVCxDQUFpQ3BGLFNBQWpDLEVBQTRDcUYsZ0JBQTVDLEVBQThEO0FBQ3hGOUosV0FBTXlFLFNBQU4sRUFBaUIvRCxNQUFqQjs7QUFDQSxRQUFJO0FBQ0YsVUFBTXFKLHFCQUFxQmxFLFNBQVN6RSxNQUFULENBQWdCNEksZUFBaEIsQ0FBZ0MsNkJBQWhDLENBQTNCO0FBQ0FELHlCQUFtQnpHLFFBQW5CLENBQTRCd0csZ0JBQTVCO0FBQ0FqRSxlQUFTNUUsTUFBVCxDQUFnQndELFNBQWhCLEVBQTJCO0FBQ3pCYixjQUFNO0FBQUUseUNBQStCa0c7QUFBakM7QUFEbUIsT0FBM0I7QUFHRCxLQU5ELENBTUUsT0FBT3ZHLFNBQVAsRUFBa0I7QUFDbEIsVUFBSUEsVUFBVUMsS0FBVixLQUFvQixrQkFBeEIsRUFBNEM7QUFDMUMsY0FBTSxJQUFJN0QsUUFBTzhELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0JGLFVBQVVHLE9BQWhDLENBQU47QUFDRDs7QUFDRCxZQUFNLElBQUkvRCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0YsR0ExSVk7QUEySWIsNkJBQTJCLFNBQVMwRyxzQkFBVCxDQUFnQ3hGLFNBQWhDLEVBQTJDeUYsV0FBM0MsRUFBd0Q7QUFDakZsSyxXQUFNeUUsU0FBTixFQUFpQi9ELE1BQWpCOztBQUNBLFFBQUk7QUFDRixVQUFNa0csb0JBQW9CZixTQUFTekUsTUFBVCxDQUFnQjRJLGVBQWhCLENBQWdDLHdCQUFoQyxDQUExQjtBQUNBcEQsd0JBQWtCdEQsUUFBbEIsQ0FBMkI0RyxXQUEzQjtBQUNBckUsZUFBUzVFLE1BQVQsQ0FBZ0J3RCxTQUFoQixFQUEyQjtBQUN6QmIsY0FBTTtBQUFFLG9DQUEwQnNHO0FBQTVCO0FBRG1CLE9BQTNCO0FBR0QsS0FORCxDQU1FLE9BQU8zRyxTQUFQLEVBQWtCO0FBQ2xCLFVBQUlBLFVBQVVDLEtBQVYsS0FBb0Isa0JBQXhCLEVBQTRDO0FBQzFDLGNBQU0sSUFBSTdELFFBQU84RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCRixVQUFVRyxPQUFoQyxDQUFOO0FBQ0Q7O0FBQ0QsWUFBTSxJQUFJL0QsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGLEdBekpZO0FBMkpiLHFDQUFtQyxTQUFTNEcsOEJBQVQsQ0FBd0MxRixTQUF4QyxFQUFtRDJGLHVCQUFuRCxFQUE0RTtBQUM3RyxRQUFJO0FBQ0YsVUFBTXBELDhCQUE4Qm5CLFNBQVN6RSxNQUFULENBQWdCNEksZUFBaEIsQ0FBZ0MscURBQWhDLENBQXBDO0FBQ0FoRCxrQ0FBNEIxRCxRQUE1QixDQUFxQzhHLHdCQUF3QjFDLHFCQUE3RDs7QUFDQXBCLCtCQUF3QmhELFFBQXhCLENBQWlDOEcsd0JBQXdCM0MsWUFBekQ7O0FBRUE1QixlQUFTNUUsTUFBVCxDQUFnQndELFNBQWhCLEVBQTJCO0FBQ3pCYixjQUFNO0FBQUUsMkNBQWlDd0c7QUFBbkM7QUFEbUIsT0FBM0I7QUFHRCxLQVJELENBUUUsT0FBTzdHLFNBQVAsRUFBa0I7QUFDbEIsVUFBSUEsVUFBVUMsS0FBVixLQUFvQixrQkFBeEIsRUFBNEM7QUFDMUMsY0FBTSxJQUFJN0QsUUFBTzhELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0JGLFVBQVVHLE9BQWhDLENBQU47QUFDRDs7QUFDRCxZQUFNLElBQUkvRCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0YsR0ExS1k7QUEyS2IsK0JBQTZCLFNBQVM4Ryx3QkFBVCxDQUFrQzVGLFNBQWxDLEVBQTZDNkYsZUFBN0MsRUFBOEQ7QUFDekZ0SyxXQUFNeUUsU0FBTixFQUFpQi9ELE1BQWpCOztBQUNBLFFBQUk7QUFDRjRGLCtCQUF3QmhELFFBQXhCLENBQWlDZ0gsZUFBakM7O0FBQ0F6RSxlQUFTNUUsTUFBVCxDQUFnQndELFNBQWhCLEVBQTJCO0FBQ3pCYixjQUFNO0FBQUUsd0RBQThDMEc7QUFBaEQ7QUFEbUIsT0FBM0I7QUFHRCxLQUxELENBS0UsT0FBTy9HLFNBQVAsRUFBa0I7QUFDbEIsVUFBSUEsVUFBVUMsS0FBVixLQUFvQixrQkFBeEIsRUFBNEM7QUFDMUMsY0FBTSxJQUFJN0QsUUFBTzhELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0JGLFVBQVVHLE9BQWhDLENBQU47QUFDRDs7QUFDRCxZQUFNLElBQUkvRCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0YsR0F4TFk7QUF5TGIsNkJBQTJCLFNBQVNnSCxzQkFBVCxDQUFnQzlGLFNBQWhDLEVBQTJDO0FBQ3BFLFFBQUk7QUFDRm9CLGVBQVM1RSxNQUFULENBQWdCd0QsU0FBaEIsRUFBMkI7QUFBRW1GLGdCQUFRO0FBQUUscUNBQTJCO0FBQTdCO0FBQVYsT0FBM0I7QUFDQS9ELGVBQVM1RSxNQUFULENBQWdCd0QsU0FBaEIsRUFBMkI7QUFBRW1GLGdCQUFRO0FBQUUscUNBQTJCO0FBQTdCO0FBQVYsT0FBM0I7QUFDQS9ELGVBQVM1RSxNQUFULENBQWdCd0QsU0FBaEIsRUFBMkI7QUFBRW1GLGdCQUFRO0FBQUUsb0NBQTBCO0FBQTVCO0FBQVYsT0FBM0I7QUFDQS9ELGVBQVM1RSxNQUFULENBQWdCd0QsU0FBaEIsRUFBMkI7QUFBRW1GLGdCQUFRO0FBQUUsb0NBQTBCO0FBQTVCO0FBQVYsT0FBM0I7QUFDQS9ELGVBQVM1RSxNQUFULENBQWdCd0QsU0FBaEIsRUFBMkI7QUFBRW1GLGdCQUFRO0FBQUUsMkNBQWlDO0FBQW5DO0FBQVYsT0FBM0I7QUFDRCxLQU5ELENBTUUsT0FBT3JHLFNBQVAsRUFBa0I7QUFDbEIsVUFBSUEsVUFBVUMsS0FBVixLQUFvQixrQkFBeEIsRUFBNEM7QUFDMUMsY0FBTSxJQUFJN0QsUUFBTzhELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0JGLFVBQVVHLE9BQWhDLENBQU47QUFDRDs7QUFDRCxZQUFNLElBQUkvRCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0YsR0F0TVk7QUF1TWIsc0NBQW9DLFNBQVM4Ryx3QkFBVCxDQUFrQzVGLFNBQWxDLEVBQTZDK0YsYUFBN0MsRUFBNERDLHNCQUE1RCxFQUFvRjtBQUN0SHpLLFdBQU15RSxTQUFOLEVBQWlCL0QsTUFBakI7O0FBQ0FWLFdBQU13SyxhQUFOLEVBQXFCdEksTUFBckI7O0FBQ0FsQyxXQUFNeUssc0JBQU4sRUFBOEJ2SSxNQUE5Qjs7QUFDQSxRQUFJO0FBQ0YyRCxlQUFTNUUsTUFBVCxDQUNFO0FBQUVOLGFBQUs4RCxTQUFQO0FBQWtCLHNGQUE4RStGO0FBQWhHLE9BREYsRUFFRTtBQUFFNUcsY0FBTTtBQUFFLDBGQUFnRjZHO0FBQWxGO0FBQVIsT0FGRjtBQUlELEtBTEQsQ0FLRSxPQUFPbEgsU0FBUCxFQUFrQjtBQUNsQixVQUFJQSxVQUFVQyxLQUFWLEtBQW9CLGtCQUF4QixFQUE0QztBQUMxQyxjQUFNLElBQUk3RCxRQUFPOEQsS0FBWCxDQUFpQixHQUFqQixFQUFzQkYsVUFBVUcsT0FBaEMsQ0FBTjtBQUNEOztBQUNELFlBQU0sSUFBSS9ELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQXROWTtBQXVOYixnQ0FBOEIsU0FBU21ILHlCQUFULENBQW1DakcsU0FBbkMsRUFBOENrRyxjQUE5QyxFQUE4RDtBQUMxRjNLLFdBQU15RSxTQUFOLEVBQWlCL0QsTUFBakI7O0FBQ0EsUUFBSTtBQUNGLFVBQUlpSyxjQUFKLEVBQW9CO0FBQ2xCdEUsMkJBQWtCL0MsUUFBbEIsQ0FBMkJxSCxjQUEzQjs7QUFDQTlFLGlCQUFTNUUsTUFBVCxDQUFnQndELFNBQWhCLEVBQTJCO0FBQUViLGdCQUFNO0FBQUUseUNBQTZCK0c7QUFBL0I7QUFBUixTQUEzQjtBQUNELE9BSEQsTUFHTyxJQUFJLENBQUNBLGNBQUwsRUFBcUI7QUFDMUI5RSxpQkFBUzVFLE1BQVQsQ0FBZ0J3RCxTQUFoQixFQUEyQjtBQUFFbUYsa0JBQVE7QUFBRSx5Q0FBNkI7QUFBL0I7QUFBVixTQUEzQjtBQUNEO0FBQ0YsS0FQRCxDQU9FLE9BQU9yRyxTQUFQLEVBQWtCO0FBQ2xCLFVBQUlBLFVBQVVDLEtBQVYsS0FBb0Isa0JBQXhCLEVBQTRDO0FBQzFDLGNBQU0sSUFBSTdELFFBQU84RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCRixVQUFVRyxPQUFoQyxDQUFOO0FBQ0Q7O0FBQ0QsWUFBTSxJQUFJL0QsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGO0FBdE9ZLENBQWY7O0FBeU9BVCxVQUFVO0FBQ1JLLFdBQVMsQ0FDUCxpQkFETyxFQUVQLGlCQUZPLEVBR1AsaUJBSE8sRUFJUCxxQkFKTyxFQUtQLGtCQUxPLEVBTVAscUJBTk8sRUFPUCxrQkFQTyxFQVFQLDBCQVJPLEVBU1AsMEJBVE8sRUFVUCw2QkFWTyxFQVdQLDBCQVhPLEVBWVAseUJBWk8sRUFhUCxpQ0FiTyxFQWNQLDJCQWRPLEVBZVAseUJBZk8sRUFnQlAsa0NBaEJPLEVBaUJQLDRCQWpCTyxDQUREO0FBb0JSYSxTQUFPLENBcEJDO0FBcUJSQyxhQUFXO0FBckJILENBQVYsRTs7Ozs7Ozs7Ozs7OztBQzNQQSxJQUFJdEUsZ0JBQUo7O0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsUUFBRCxrQkFBUUksQ0FBUixFQUFVO0FBQUNKLGNBQU9JLENBQVA7QUFBUztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFBK0QsSUFBSUMsZUFBSjs7QUFBVUosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRSxPQUFELGlCQUFPRCxDQUFQLEVBQVM7QUFBQ0MsYUFBTUQsQ0FBTjtBQUFRO0FBQWxCLENBQXJDLEVBQXlELENBQXpEOztBQUE0RCxJQUFJNkssOEJBQUo7O0FBQXlCaEwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDhCQUFSLENBQWIsRUFBcUQ7QUFBQzhLLHNCQUFELGdDQUFzQjdLLENBQXRCLEVBQXdCO0FBQUM2Syw0QkFBcUI3SyxDQUFyQjtBQUF1QjtBQUFoRCxDQUFyRCxFQUF1RyxDQUF2RztBQUEwRyxJQUFJK0Msa0JBQUo7QUFBY2xELE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDK0MsZ0JBQVUvQyxDQUFWO0FBQVk7QUFBeEIsQ0FBcEQsRUFBOEUsQ0FBOUU7O0FBS2pTSixRQUFPd0QsT0FBUCxDQUFlO0FBQ2IsK0JBQTZCLFNBQVMwSCx3QkFBVCxDQUFrQ0MsUUFBbEMsRUFBNEM7QUFDdkU5SyxXQUFNOEssUUFBTixFQUFnQjdDLEtBQWhCOztBQUVBLFFBQUk7QUFDRixVQUFNOEMsbUJBQW1CLEVBQXpCO0FBQ0FELGVBQVNyRixPQUFULENBQWlCLFVBQUN1RixPQUFELEVBQWE7QUFDNUIsWUFBSUosc0JBQXFCSyxjQUFyQixDQUFvQ3RCLE9BQXBDLENBQTRDO0FBQUVxQjtBQUFGLFNBQTVDLENBQUosRUFBOEQ7QUFDNURELDJCQUFpQkcsSUFBakIsQ0FBc0JGLE9BQXRCO0FBQ0Q7QUFDRixPQUpEO0FBS0EsYUFBT0QsaUJBQWlCSSxJQUFqQixFQUFQO0FBQ0QsS0FSRCxDQVFFLE9BQU81SCxTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTVELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRjtBQWZZLENBQWY7O0FBa0JBVCxVQUFVO0FBQ1JLLFdBQVMsQ0FDUCwyQkFETyxDQUREO0FBSVJhLFNBQU8sQ0FKQztBQUtSQyxhQUFXO0FBTEgsQ0FBVixFOzs7Ozs7Ozs7Ozs7O0FDdkJBLElBQUl0RSxnQkFBSjs7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxRQUFELGtCQUFRSSxDQUFSLEVBQVU7QUFBQ0osY0FBT0ksQ0FBUDtBQUFTO0FBQXBCLENBQXRDLEVBQTRELENBQTVEOztBQUErRCxJQUFJQyxlQUFKOztBQUFVSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLE9BQUQsaUJBQU9ELENBQVAsRUFBUztBQUFDQyxhQUFNRCxDQUFOO0FBQVE7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXFMLGlCQUFKO0FBQWF4TCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDcUwsZUFBU3JMLENBQVQ7QUFBVztBQUF2QixDQUFwQyxFQUE2RCxDQUE3RDs7QUFJN0pKLFFBQU9RLE9BQVAsQ0FBZSxVQUFmLEVBQTJCLFNBQVNrTCxRQUFULEdBQW9CO0FBQzdDLFNBQU9ELFNBQVMvSyxJQUFULENBQWM7QUFBRUMsV0FBTyxLQUFLQztBQUFkLEdBQWQsQ0FBUDtBQUNELENBRkQsRSxDQUlBOzs7QUFDQVosUUFBT1EsT0FBUCxDQUFlLGVBQWYsRUFBZ0MsU0FBU21MLFlBQVQsQ0FBc0JDLFNBQXRCLEVBQWlDO0FBQy9EdkwsU0FBTXVMLFNBQU4sRUFBaUI3SyxNQUFqQjs7QUFDQSxTQUFPMEssU0FBUy9LLElBQVQsQ0FBYztBQUFFTSxTQUFLNEssU0FBUDtBQUFrQmpMLFdBQU8sS0FBS0M7QUFBOUIsR0FBZCxDQUFQO0FBQ0QsQ0FIRDs7QUFLQVosUUFBT1EsT0FBUCxDQUFlLGtCQUFmLEVBQW1DLFNBQVNxTCxlQUFULEdBQTJCO0FBQzVELFNBQU9KLFNBQVMvSyxJQUFULENBQWM7QUFBRUMsV0FBTyxLQUFLQztBQUFkLEdBQWQsRUFBc0M7QUFDM0NrTCxZQUFRO0FBQUUzSixZQUFNLENBQVI7QUFBV0MsYUFBTztBQUFsQjtBQURtQyxHQUF0QyxDQUFQO0FBR0QsQ0FKRCxFOzs7Ozs7Ozs7Ozs7O0FDZEEsSUFBSW5CLGVBQUo7O0FBQVVoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNjLE9BQUQsaUJBQU9iLENBQVAsRUFBUztBQUFDYSxhQUFNYixDQUFOO0FBQVE7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSWMscUJBQUo7QUFBaUJqQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDYyxtQkFBYWQsQ0FBYjtBQUFlO0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBS3ZGLElBQU1xTCxXQUFXLElBQUl4SyxPQUFNRSxVQUFWLENBQXFCLFVBQXJCLENBQWpCO0FBRUFzSyxTQUFTckssS0FBVCxDQUFlO0FBQ2JDLFVBQVE7QUFBQSxXQUFNLEtBQU47QUFBQSxHQURLO0FBRWJDLFVBQVE7QUFBQSxXQUFNLEtBQU47QUFBQSxHQUZLO0FBR2JDLFVBQVE7QUFBQSxXQUFNLEtBQU47QUFBQTtBQUhLLENBQWY7QUFNQWtLLFNBQVNqSyxJQUFULENBQWM7QUFDWkgsVUFBUTtBQUFBLFdBQU0sSUFBTjtBQUFBLEdBREk7QUFFWkMsVUFBUTtBQUFBLFdBQU0sSUFBTjtBQUFBLEdBRkk7QUFHWkMsVUFBUTtBQUFBLFdBQU0sSUFBTjtBQUFBO0FBSEksQ0FBZDtBQU1BLElBQU13Syx5QkFBeUIsSUFBSTdLLFlBQUosQ0FBaUI7QUFDOUM4SyxlQUFhO0FBQ1h0SyxVQUFNYSxNQURLO0FBRVhaLFdBQU8sOENBRkk7QUFHWGEsU0FBSztBQUhNLEdBRGlDO0FBTTlDeUosZUFBYTtBQUNYdkssVUFBTWEsTUFESztBQUVYWixXQUFPLGdDQUZJO0FBR1hhLFNBQUs7QUFITSxHQU5pQztBQVc5QzBKLGdCQUFjO0FBQ1p4SyxVQUFNYSxNQURNO0FBRVpaLFdBQU8saUNBRks7QUFHWmEsU0FBSztBQUhPLEdBWGdDO0FBZ0I5QzJKLGNBQVk7QUFDVnpLLFVBQU1hLE1BREk7QUFFVlosV0FBTywyQkFGRztBQUdWYSxTQUFLO0FBSEssR0FoQmtDO0FBcUI5QzRKLGVBQWE7QUFDWDFLLFVBQU1hLE1BREs7QUFFWFosV0FBTyw0QkFGSTtBQUdYYSxTQUFLO0FBSE07QUFyQmlDLENBQWpCLENBQS9CO0FBNEJBaUosU0FBU2hLLE1BQVQsR0FBa0IsSUFBSVAsWUFBSixDQUFpQjtBQUNqQ1AsU0FBTztBQUNMZSxVQUFNWCxNQUREO0FBRUxZLFdBQU87QUFGRixHQUQwQjtBQUtqQ0MsYUFBVztBQUNURixVQUFNWCxNQURHO0FBRVRZLFdBQU8sb0NBRkU7QUFHVEUsYUFIUyx1QkFHRztBQUNWLFVBQUksS0FBS0MsUUFBVCxFQUFtQixPQUFRLElBQUlDLElBQUosRUFBRCxDQUFhQyxXQUFiLEVBQVA7QUFDcEI7QUFMUSxHQUxzQjtBQVlqQ0MsYUFBVztBQUNUUCxVQUFNWCxNQURHO0FBRVRZLFdBQU8seUNBRkU7QUFHVEUsYUFIUyx1QkFHRztBQUNWLFVBQUksS0FBS0MsUUFBTCxJQUFpQixLQUFLSSxRQUExQixFQUFvQyxPQUFRLElBQUlILElBQUosRUFBRCxDQUFhQyxXQUFiLEVBQVA7QUFDckM7QUFMUSxHQVpzQjtBQW1CakNHLFFBQU07QUFDSlQsVUFBTVgsTUFERjtBQUVKWSxXQUFPO0FBRkgsR0FuQjJCO0FBdUJqQ1Usc0JBQW9CO0FBQ2xCWCxVQUFNWCxNQURZO0FBRWxCWSxXQUFPLDRDQUZXO0FBR2xCaUIsY0FBVTtBQUhRLEdBdkJhO0FBNEJqQ1IsU0FBTztBQUNMVixVQUFNWCxNQUREO0FBRUxZLFdBQU87QUFGRixHQTVCMEI7QUFnQ2pDZ0IsVUFBUTtBQUNOakIsVUFBTWEsTUFEQTtBQUVOWixXQUFPLHNDQUZEO0FBR05hLFNBQUssQ0FIQztBQUlOSSxjQUFVO0FBSkosR0FoQ3lCO0FBc0NqQ3lKLGVBQWE7QUFDWDNLLFVBQU1YLE1BREs7QUFFWHFILG1CQUFlLENBQUMsUUFBRCxDQUZKO0FBR1h6RyxXQUFPO0FBSEksR0F0Q29CO0FBMkNqQ2tCLFdBQVM7QUFDUG5CLFVBQU1YLE1BREM7QUFFUFksV0FBTyxtQ0FGQTtBQUdQRSxhQUhPLHVCQUdLO0FBQ1YsVUFBSSxLQUFLQyxRQUFULEVBQW1CLE9BQU8sSUFBUDtBQUNwQjtBQUxNLEdBM0N3QjtBQWtEakN3SyxvQkFBa0I7QUFDaEI1SyxVQUFNUixhQUFhcUwsS0FBYixDQUFtQlIsc0JBQW5CLENBRFU7QUFFaEJwSyxXQUFPO0FBRlM7QUFsRGUsQ0FBakIsQ0FBbEI7QUF3REE4SixTQUFTeEksWUFBVCxDQUFzQndJLFNBQVNoSyxNQUEvQjtBQXZHQXhCLE9BQU9pRCxhQUFQLENBeUdldUksUUF6R2YsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBLElBQUl6TCxnQkFBSjs7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxRQUFELGtCQUFRSSxDQUFSLEVBQVU7QUFBQ0osY0FBT0ksQ0FBUDtBQUFTO0FBQXBCLENBQXRDLEVBQTRELENBQTVEOztBQUErRCxJQUFJQyxlQUFKOztBQUFVSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLE9BQUQsaUJBQU9ELENBQVAsRUFBUztBQUFDQyxhQUFNRCxDQUFOO0FBQVE7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXFMLGlCQUFKO0FBQWF4TCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsWUFBUixDQUFiLEVBQW1DO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDcUwsZUFBU3JMLENBQVQ7QUFBVztBQUF2QixDQUFuQyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJK0Msa0JBQUo7QUFBY2xELE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDK0MsZ0JBQVUvQyxDQUFWO0FBQVk7QUFBeEIsQ0FBakQsRUFBMkUsQ0FBM0U7QUFNMU8sSUFBTW9NLG1CQUFtQmYsU0FBU2hLLE1BQVQsQ0FBZ0I0QixJQUFoQixDQUFxQixNQUFyQixFQUE2QixvQkFBN0IsRUFBbUQsT0FBbkQsRUFBNEQsUUFBNUQsRUFBc0UsYUFBdEUsRUFBcUYsa0JBQXJGLENBQXpCO0FBRUEsSUFBTW9KLG9CQUFvQmhCLFNBQVNoSyxNQUFULENBQWdCNEIsSUFBaEIsQ0FBcUIsTUFBckIsRUFBNkIsb0JBQTdCLEVBQW1ELE9BQW5ELEVBQTRELFFBQTVELEVBQXNFLGFBQXRFLEVBQXFGLGtCQUFyRixDQUExQjtBQUNBb0osa0JBQWtCbEosTUFBbEIsQ0FBeUI7QUFBRXZDLE9BQUtEO0FBQVAsQ0FBekI7O0FBRUFmLFFBQU93RCxPQUFQLENBQWU7QUFDYixxQkFBbUIsU0FBU2tKLGNBQVQsQ0FBd0J4RSxPQUF4QixFQUFpQztBQUNsRCxRQUFJO0FBQ0ZzRSx1QkFBaUI3SSxRQUFqQixDQUEwQnVFLE9BQTFCO0FBQ0EsYUFBT3VELFNBQVNwSyxNQUFUO0FBQWtCVixlQUFPLEtBQUtDO0FBQTlCLFNBQXlDc0gsT0FBekMsRUFBUDtBQUNELEtBSEQsQ0FHRSxPQUFPdEUsU0FBUCxFQUFrQjtBQUNsQixVQUFJQSxVQUFVQyxLQUFWLEtBQW9CLGtCQUF4QixFQUE0QztBQUMxQyxjQUFNLElBQUk3RCxRQUFPOEQsS0FBWCxDQUFpQixHQUFqQixFQUFzQkYsVUFBVUcsT0FBaEMsQ0FBTjtBQUNEOztBQUNELFlBQU0sSUFBSS9ELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQVhZO0FBWWIscUJBQW1CLFNBQVMrSSxjQUFULENBQXdCekUsT0FBeEIsRUFBaUM7QUFDbEQsUUFBSTtBQUNGdUUsd0JBQWtCOUksUUFBbEIsQ0FBMkJ1RSxPQUEzQjtBQUNBLFVBQU0wRCxZQUFZMUQsUUFBUWxILEdBQTFCO0FBQ0F5SyxlQUFTbkssTUFBVCxDQUFnQnNLLFNBQWhCLEVBQTJCO0FBQUUzSCxjQUFNaUU7QUFBUixPQUEzQjtBQUNBLGFBQU8wRCxTQUFQLENBSkUsQ0FLRjtBQUNELEtBTkQsQ0FNRSxPQUFPaEksU0FBUCxFQUFrQjtBQUNsQixVQUFJQSxVQUFVQyxLQUFWLEtBQW9CLGtCQUF4QixFQUE0QztBQUMxQyxjQUFNLElBQUk3RCxRQUFPOEQsS0FBWCxDQUFpQixHQUFqQixFQUFzQkYsVUFBVUcsT0FBaEMsQ0FBTjtBQUNEOztBQUNELFlBQU0sSUFBSS9ELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQXpCWTtBQTBCYix5QkFBdUIsU0FBU2dKLGtCQUFULENBQTRCaEIsU0FBNUIsRUFBdUM7QUFDNUR2TCxXQUFNdUwsU0FBTixFQUFpQjdLLE1BQWpCOztBQUNBLFFBQUk7QUFDRjBLLGVBQVNuSyxNQUFULENBQWdCc0ssU0FBaEIsRUFBMkI7QUFBRTNILGNBQU07QUFBRXBCLG1CQUFVLElBQUlkLElBQUosRUFBRCxDQUFhQyxXQUFiO0FBQVg7QUFBUixPQUEzQjtBQUNELEtBRkQsQ0FFRSxPQUFPNEIsU0FBUCxFQUFrQjtBQUNsQixZQUFNLElBQUk1RCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0YsR0FqQ1k7QUFrQ2Isc0JBQW9CLFNBQVNpSixlQUFULENBQXlCakIsU0FBekIsRUFBb0M7QUFDdER2TCxXQUFNdUwsU0FBTixFQUFpQjdLLE1BQWpCOztBQUNBLFFBQUk7QUFDRjBLLGVBQVNuSyxNQUFULENBQWdCc0ssU0FBaEIsRUFBMkI7QUFBRTNILGNBQU07QUFBRXBCLG1CQUFTO0FBQVg7QUFBUixPQUEzQjtBQUNELEtBRkQsQ0FFRSxPQUFPZSxTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTVELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQXpDWTtBQTBDYix5QkFBdUIsU0FBU2tKLGtCQUFULENBQTRCbEIsU0FBNUIsRUFBdUM7QUFDNUR2TCxXQUFNdUwsU0FBTixFQUFpQjdLLE1BQWpCOztBQUNBLFFBQUk7QUFDRixhQUFPMEssU0FBU2xLLE1BQVQsQ0FBZ0JxSyxTQUFoQixDQUFQO0FBQ0QsS0FGRCxDQUVFLE9BQU9oSSxTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTVELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRjtBQWpEWSxDQUFmOztBQW9EQVQsVUFBVTtBQUNSSyxXQUFTLENBQ1AsaUJBRE8sRUFFUCxpQkFGTyxFQUdQLHFCQUhPLEVBSVAsa0JBSk8sRUFLUCxxQkFMTyxDQUREO0FBUVJhLFNBQU8sQ0FSQztBQVNSQyxhQUFXO0FBVEgsQ0FBVixFOzs7Ozs7Ozs7Ozs7O0FDL0RBLElBQUl0RSxnQkFBSjs7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxRQUFELGtCQUFRSSxDQUFSLEVBQVU7QUFBQ0osY0FBT0ksQ0FBUDtBQUFTO0FBQXBCLENBQXRDLEVBQTRELENBQTVEOztBQUErRCxJQUFJQyxlQUFKOztBQUFVSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLE9BQUQsaUJBQU9ELENBQVAsRUFBUztBQUFDQyxhQUFNRCxDQUFOO0FBQVE7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSTJNLGlCQUFKO0FBQWE5TSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDMk0sZUFBUzNNLENBQVQ7QUFBVztBQUF2QixDQUFwQyxFQUE2RCxDQUE3RDs7QUFJN0pKLFFBQU9RLE9BQVAsQ0FBZSxVQUFmLEVBQTJCLFNBQVN3TSxRQUFULEdBQW9CO0FBQzdDLFNBQU9ELFNBQVNyTSxJQUFULENBQWM7QUFBRUMsV0FBTyxLQUFLQztBQUFkLEdBQWQsQ0FBUDtBQUNELENBRkQsRSxDQUlBOzs7QUFDQVosUUFBT1EsT0FBUCxDQUFlLGVBQWYsRUFBZ0MsU0FBU3lNLFlBQVQsQ0FBc0I3RyxTQUF0QixFQUFpQztBQUMvRC9GLFNBQU0rRixTQUFOLEVBQWlCckYsTUFBakI7O0FBQ0EsU0FBT2dNLFNBQVNyTSxJQUFULENBQWM7QUFBRU0sU0FBS29GLFNBQVA7QUFBa0J6RixXQUFPLEtBQUtDO0FBQTlCLEdBQWQsQ0FBUDtBQUNELENBSEQsRTs7Ozs7Ozs7Ozs7OztBQ1RBLElBQUlLLGVBQUo7O0FBQVVoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNjLE9BQUQsaUJBQU9iLENBQVAsRUFBUztBQUFDYSxhQUFNYixDQUFOO0FBQVE7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSWMscUJBQUo7QUFBaUJqQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDYyxtQkFBYWQsQ0FBYjtBQUFlO0FBQTNCLENBQXJDLEVBQWtFLENBQWxFOztBQUFxRSxJQUFJb0csc0JBQUo7O0FBQWlCdkcsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHFDQUFSLENBQWIsRUFBNEQ7QUFBQ3FHLGNBQUQsd0JBQWNwRyxDQUFkLEVBQWdCO0FBQUNvRyxvQkFBYXBHLENBQWI7QUFBZTtBQUFoQyxDQUE1RCxFQUE4RixDQUE5RjtBQUs3SyxJQUFNMk0sV0FBVyxJQUFJOUwsT0FBTUUsVUFBVixDQUFxQixVQUFyQixDQUFqQjtBQUVBNEwsU0FBUzNMLEtBQVQsQ0FBZTtBQUNiQyxVQUFRO0FBQUEsV0FBTSxLQUFOO0FBQUEsR0FESztBQUViQyxVQUFRO0FBQUEsV0FBTSxLQUFOO0FBQUEsR0FGSztBQUdiQyxVQUFRO0FBQUEsV0FBTSxLQUFOO0FBQUE7QUFISyxDQUFmO0FBTUF3TCxTQUFTdkwsSUFBVCxDQUFjO0FBQ1pILFVBQVE7QUFBQSxXQUFNLElBQU47QUFBQSxHQURJO0FBRVpDLFVBQVE7QUFBQSxXQUFNLElBQU47QUFBQSxHQUZJO0FBR1pDLFVBQVE7QUFBQSxXQUFNLElBQU47QUFBQTtBQUhJLENBQWQ7QUFNQXdMLFNBQVN0TCxNQUFULEdBQWtCLElBQUlQLFlBQUosQ0FBaUI7QUFDakNQLFNBQU87QUFDTGUsVUFBTVgsTUFERDtBQUVMWSxXQUFPO0FBRkYsR0FEMEI7QUFLakNDLGFBQVc7QUFDVEYsVUFBTVgsTUFERztBQUVUWSxXQUFPLG9DQUZFO0FBR1RFLGFBSFMsdUJBR0c7QUFDVixVQUFJLEtBQUtDLFFBQVQsRUFBbUIsT0FBUSxJQUFJQyxJQUFKLEVBQUQsQ0FBYUMsV0FBYixFQUFQO0FBQ3BCO0FBTFEsR0FMc0I7QUFZakNDLGFBQVc7QUFDVFAsVUFBTVgsTUFERztBQUVUWSxXQUFPLHlDQUZFO0FBR1RFLGFBSFMsdUJBR0c7QUFDVixVQUFJLEtBQUtDLFFBQUwsSUFBaUIsS0FBS0ksUUFBMUIsRUFBb0MsT0FBUSxJQUFJSCxJQUFKLEVBQUQsQ0FBYUMsV0FBYixFQUFQO0FBQ3JDO0FBTFEsR0Fac0I7QUFtQmpDRyxRQUFNO0FBQ0pULFVBQU1YLE1BREY7QUFFSlksV0FBTztBQUZILEdBbkIyQjtBQXVCakNxRyxlQUFhO0FBQ1h0RyxVQUFNWCxNQURLO0FBRVg2QixjQUFVLElBRkM7QUFHWGpCLFdBQU87QUFISSxHQXZCb0I7QUE0QmpDdUwsZUFBYTtBQUNYeEwsVUFBTThFLGFBREs7QUFFWDdFLFdBQU87QUFGSSxHQTVCb0I7QUFnQ2pDa0IsV0FBUztBQUNQbkIsVUFBTVgsTUFEQztBQUVQWSxXQUFPLG1DQUZBO0FBR1BFLGFBSE8sdUJBR0s7QUFDVixVQUFJLEtBQUtDLFFBQVQsRUFBbUIsT0FBTyxJQUFQO0FBQ3BCO0FBTE0sR0FoQ3dCO0FBdUNqQzBHLFFBQU07QUFDSjlHLFVBQU0rRyxPQURGO0FBRUo5RyxXQUFPLHNCQUZIO0FBR0pFLGFBSEksdUJBR1E7QUFDVixVQUFJLEtBQUtDLFFBQVQsRUFBbUIsT0FBTyxLQUFQO0FBQ3BCO0FBTEc7QUF2QzJCLENBQWpCLENBQWxCO0FBZ0RBaUwsU0FBUzlKLFlBQVQsQ0FBc0I4SixTQUFTdEwsTUFBL0I7QUFuRUF4QixPQUFPaUQsYUFBUCxDQXFFZTZKLFFBckVmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQSxJQUFJL00sZ0JBQUo7O0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsUUFBRCxrQkFBUUksQ0FBUixFQUFVO0FBQUNKLGNBQU9JLENBQVA7QUFBUztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFBK0QsSUFBSUMsZUFBSjs7QUFBVUosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRSxPQUFELGlCQUFPRCxDQUFQLEVBQVM7QUFBQ0MsYUFBTUQsQ0FBTjtBQUFRO0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUkyTSxpQkFBSjtBQUFhOU0sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFlBQVIsQ0FBYixFQUFtQztBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQzJNLGVBQVMzTSxDQUFUO0FBQVc7QUFBdkIsQ0FBbkMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSStDLGtCQUFKO0FBQWNsRCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQytDLGdCQUFVL0MsQ0FBVjtBQUFZO0FBQXhCLENBQWpELEVBQTJFLENBQTNFO0FBTTFPLElBQU0rTSxtQkFBbUJKLFNBQVN0TCxNQUFULENBQWdCNEIsSUFBaEIsQ0FBcUIsTUFBckIsRUFBNkIsYUFBN0IsRUFBNEMsYUFBNUMsQ0FBekI7QUFFQSxJQUFNK0osb0JBQW9CTCxTQUFTdEwsTUFBVCxDQUFnQjRCLElBQWhCLENBQXFCLE1BQXJCLEVBQTZCLGFBQTdCLEVBQTRDLGFBQTVDLENBQTFCO0FBQ0ErSixrQkFBa0I3SixNQUFsQixDQUF5QjtBQUFFdkMsT0FBS0Q7QUFBUCxDQUF6Qjs7QUFFQWYsUUFBT3dELE9BQVAsQ0FBZTtBQUNiLHFCQUFtQixTQUFTNkosY0FBVCxDQUF3QmhILE9BQXhCLEVBQWlDO0FBQ2xELFFBQUk7QUFDRjhHLHVCQUFpQnhKLFFBQWpCLENBQTBCMEMsT0FBMUI7QUFDQSxhQUFPMEcsU0FBUzFMLE1BQVQ7QUFBa0JWLGVBQU8sS0FBS0M7QUFBOUIsU0FBeUN5RixPQUF6QyxFQUFQO0FBQ0QsS0FIRCxDQUdFLE9BQU96QyxTQUFQLEVBQWtCO0FBQ2xCLFVBQUlBLFVBQVVDLEtBQVYsS0FBb0Isa0JBQXhCLEVBQTRDO0FBQzFDLGNBQU0sSUFBSTdELFFBQU84RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCRixVQUFVRyxPQUFoQyxDQUFOO0FBQ0Q7O0FBQ0QsWUFBTSxJQUFJL0QsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGLEdBWFk7QUFZYixxQkFBbUIsU0FBUzBKLGNBQVQsQ0FBd0JqSCxPQUF4QixFQUFpQztBQUNsRCxRQUFJO0FBQ0YrRyx3QkFBa0J6SixRQUFsQixDQUEyQjBDLE9BQTNCO0FBQ0EsVUFBTUQsWUFBWUMsUUFBUXJGLEdBQTFCO0FBQ0ErTCxlQUFTekwsTUFBVCxDQUFnQjhFLFNBQWhCLEVBQTJCO0FBQUVuQyxjQUFNb0M7QUFBUixPQUEzQjtBQUNBLGFBQU9ELFNBQVAsQ0FKRSxDQUtGO0FBQ0QsS0FORCxDQU1FLE9BQU94QyxTQUFQLEVBQWtCO0FBQ2xCLFVBQUlBLFVBQVVDLEtBQVYsS0FBb0Isa0JBQXhCLEVBQTRDO0FBQzFDLGNBQU0sSUFBSTdELFFBQU84RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCRixVQUFVRyxPQUFoQyxDQUFOO0FBQ0Q7O0FBQ0QsWUFBTSxJQUFJL0QsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGLEdBekJZO0FBMEJiLHlCQUF1QixTQUFTMkosa0JBQVQsQ0FBNEJuSCxTQUE1QixFQUF1QztBQUM1RC9GLFdBQU0rRixTQUFOLEVBQWlCckYsTUFBakI7O0FBQ0EsUUFBSTtBQUNGZ00sZUFBU3pMLE1BQVQsQ0FBZ0I4RSxTQUFoQixFQUEyQjtBQUFFbkMsY0FBTTtBQUFFcEIsbUJBQVUsSUFBSWQsSUFBSixFQUFELENBQWFDLFdBQWI7QUFBWDtBQUFSLE9BQTNCO0FBQ0QsS0FGRCxDQUVFLE9BQU80QixTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTVELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQWpDWTtBQWtDYixzQkFBb0IsU0FBUzRKLGVBQVQsQ0FBeUJwSCxTQUF6QixFQUFvQztBQUN0RC9GLFdBQU0rRixTQUFOLEVBQWlCckYsTUFBakI7O0FBQ0EsUUFBSTtBQUNGZ00sZUFBU3pMLE1BQVQsQ0FBZ0I4RSxTQUFoQixFQUEyQjtBQUFFbkMsY0FBTTtBQUFFcEIsbUJBQVM7QUFBWDtBQUFSLE9BQTNCO0FBQ0QsS0FGRCxDQUVFLE9BQU9lLFNBQVAsRUFBa0I7QUFDbEIsWUFBTSxJQUFJNUQsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGLEdBekNZO0FBMENiLHlCQUF1QixTQUFTNkosa0JBQVQsQ0FBNEJySCxTQUE1QixFQUF1QztBQUM1RC9GLFdBQU0rRixTQUFOLEVBQWlCckYsTUFBakI7O0FBQ0EsUUFBSTtBQUNGLGFBQU9nTSxTQUFTeEwsTUFBVCxDQUFnQjZFLFNBQWhCLENBQVA7QUFDRCxLQUZELENBRUUsT0FBT3hDLFNBQVAsRUFBa0I7QUFDbEIsWUFBTSxJQUFJNUQsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGLEdBakRZO0FBa0RiLHNCQUFvQixTQUFTOEosZUFBVCxDQUF5QnRILFNBQXpCLEVBQW9DcUQsT0FBcEMsRUFBNkM7QUFDL0RwSixXQUFNK0YsU0FBTixFQUFpQnJGLE1BQWpCOztBQUNBVixXQUFNb0osT0FBTixFQUFlaEIsT0FBZjs7QUFDQSxRQUFJO0FBQ0ZzRSxlQUFTekwsTUFBVCxDQUFnQjhFLFNBQWhCLEVBQTJCO0FBQUVuQyxjQUFNO0FBQUV1RSxnQkFBTWlCO0FBQVI7QUFBUixPQUEzQjtBQUNELEtBRkQsQ0FFRSxPQUFPN0YsU0FBUCxFQUFrQjtBQUNsQixZQUFNLElBQUk1RCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0Y7QUExRFksQ0FBZjs7QUE2REFULFVBQVU7QUFDUkssV0FBUyxDQUNQLGlCQURPLEVBRVAsaUJBRk8sRUFHUCxxQkFITyxFQUlQLGtCQUpPLEVBS1AscUJBTE8sRUFNUCxrQkFOTyxDQUREO0FBU1JhLFNBQU8sQ0FUQztBQVVSQyxhQUFXO0FBVkgsQ0FBVixFOzs7Ozs7Ozs7Ozs7O0FDeEVBLElBQUl0RSxnQkFBSjs7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxRQUFELGtCQUFRSSxDQUFSLEVBQVU7QUFBQ0osY0FBT0ksQ0FBUDtBQUFTO0FBQXBCLENBQXRDLEVBQTRELENBQTVEOztBQUErRCxJQUFJQyxlQUFKOztBQUFVSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLE9BQUQsaUJBQU9ELENBQVAsRUFBUztBQUFDQyxhQUFNRCxDQUFOO0FBQVE7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXVOLGFBQUo7QUFBUzFOLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ0ksU0FBRCxvQkFBU0gsQ0FBVCxFQUFXO0FBQUN1TixXQUFLdk4sQ0FBTDtBQUFPO0FBQW5CLENBQWhDLEVBQXFELENBQXJEOztBQUl6SkosUUFBT1EsT0FBUCxDQUFlLE1BQWYsRUFBdUIsU0FBU29OLElBQVQsR0FBZ0I7QUFDckMsU0FBT0QsS0FBS2pOLElBQUwsQ0FBVTtBQUFFQyxXQUFPLEtBQUtDO0FBQWQsR0FBVixDQUFQO0FBQ0QsQ0FGRCxFLENBSUE7OztBQUNBWixRQUFPUSxPQUFQLENBQWUsV0FBZixFQUE0QixTQUFTcU4sUUFBVCxDQUFrQkMsS0FBbEIsRUFBeUI7QUFDbkR6TixTQUFNeU4sS0FBTixFQUFhL00sTUFBYjs7QUFDQSxTQUFPNE0sS0FBS2pOLElBQUwsQ0FBVTtBQUFFTSxTQUFLOE0sS0FBUDtBQUFjbk4sV0FBTyxLQUFLQztBQUExQixHQUFWLENBQVA7QUFDRCxDQUhEOztBQUtBWixRQUFPUSxPQUFQLENBQWUsY0FBZixFQUErQixTQUFTdU4sV0FBVCxHQUF1QjtBQUNwRCxTQUFPSixLQUFLak4sSUFBTCxDQUFVO0FBQUVDLFdBQU8sS0FBS0M7QUFBZCxHQUFWLEVBQWtDO0FBQ3ZDa0wsWUFBUTtBQUFFM0osWUFBTSxDQUFSO0FBQVc2TCxlQUFTO0FBQXBCO0FBRCtCLEdBQWxDLENBQVA7QUFHRCxDQUpELEU7Ozs7Ozs7Ozs7Ozs7QUNkQSxJQUFJL00sZUFBSjs7QUFBVWhCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ2MsT0FBRCxpQkFBT2IsQ0FBUCxFQUFTO0FBQUNhLGFBQU1iLENBQU47QUFBUTtBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJYyxxQkFBSjtBQUFpQmpCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ksU0FBRCxvQkFBU0gsQ0FBVCxFQUFXO0FBQUNjLG1CQUFhZCxDQUFiO0FBQWU7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFJdkYsSUFBTXVOLE9BQU8sSUFBSTFNLE9BQU1FLFVBQVYsQ0FBcUIsTUFBckIsQ0FBYjtBQUVBd00sS0FBS3ZNLEtBQUwsQ0FBVztBQUNUQyxVQUFRO0FBQUEsV0FBTSxLQUFOO0FBQUEsR0FEQztBQUVUQyxVQUFRO0FBQUEsV0FBTSxLQUFOO0FBQUEsR0FGQztBQUdUQyxVQUFRO0FBQUEsV0FBTSxLQUFOO0FBQUE7QUFIQyxDQUFYO0FBTUFvTSxLQUFLbk0sSUFBTCxDQUFVO0FBQ1JILFVBQVE7QUFBQSxXQUFNLElBQU47QUFBQSxHQURBO0FBRVJDLFVBQVE7QUFBQSxXQUFNLElBQU47QUFBQSxHQUZBO0FBR1JDLFVBQVE7QUFBQSxXQUFNLElBQU47QUFBQTtBQUhBLENBQVY7QUFNQSxJQUFNcUYseUJBQXlCLElBQUkxRixZQUFKLENBQWlCO0FBQzlDK00sbUJBQWlCO0FBQ2Z2TSxVQUFNUixhQUFhd0IsT0FESjtBQUVmZixXQUFPLGdEQUZRO0FBR2ZhLFNBQUssQ0FIVTtBQUlmMkUsU0FBSztBQUpVLEdBRDZCO0FBTzlDK0csa0JBQWdCO0FBQ2R4TSxVQUFNUixhQUFhd0IsT0FETDtBQUVkZixXQUFPLGdEQUZPO0FBR2RhLFNBQUssQ0FIUztBQUlkMkUsU0FBSztBQUpTLEdBUDhCO0FBYTlDZ0gsdUJBQXFCO0FBQ25Cek0sVUFBTVIsYUFBYXdCLE9BREE7QUFFbkJmLFdBQU8saURBRlk7QUFHbkJhLFNBQUssQ0FIYztBQUluQjJFLFNBQUs7QUFKYyxHQWJ5QjtBQW1COUNpSCx1QkFBcUI7QUFDbkIxTSxVQUFNUixhQUFhd0IsT0FEQTtBQUVuQmYsV0FBTyxvREFGWTtBQUduQmEsU0FBSyxDQUhjO0FBSW5CMkUsU0FBSztBQUpjLEdBbkJ5QjtBQXlCOUNrSCxnQkFBYztBQUNaM00sVUFBTVIsYUFBYXdCLE9BRFA7QUFFWmYsV0FBTyxtREFGSztBQUdaYSxTQUFLLENBSE87QUFJWjJFLFNBQUs7QUFKTztBQXpCZ0MsQ0FBakIsQ0FBL0I7QUFpQ0F3RyxLQUFLbE0sTUFBTCxHQUFjLElBQUlQLFlBQUosQ0FBaUI7QUFDN0JQLFNBQU87QUFDTGUsVUFBTVgsTUFERDtBQUVMWSxXQUFPO0FBRkYsR0FEc0I7QUFLN0JDLGFBQVc7QUFDVEYsVUFBTVgsTUFERztBQUVUWSxXQUFPLGlDQUZFO0FBR1RFLGFBSFMsdUJBR0c7QUFDVixVQUFJLEtBQUtDLFFBQVQsRUFBbUIsT0FBUSxJQUFJQyxJQUFKLEVBQUQsQ0FBYUMsV0FBYixFQUFQO0FBQ3BCO0FBTFEsR0FMa0I7QUFZN0JDLGFBQVc7QUFDVFAsVUFBTVgsTUFERztBQUVUWSxXQUFPLHNDQUZFO0FBR1RFLGFBSFMsdUJBR0c7QUFDVixVQUFJLEtBQUtDLFFBQUwsSUFBaUIsS0FBS0ksUUFBMUIsRUFBb0MsT0FBUSxJQUFJSCxJQUFKLEVBQUQsQ0FBYUMsV0FBYixFQUFQO0FBQ3JDO0FBTFEsR0Faa0I7QUFtQjdCRyxRQUFNO0FBQ0pULFVBQU1YLE1BREY7QUFFSlksV0FBTztBQUZILEdBbkJ1QjtBQXVCN0JxTSxXQUFTO0FBQ1B0TSxVQUFNWCxNQURDO0FBRVBZLFdBQU8sdUJBRkE7QUFHUHlHLG1CQUFlLENBQUMsT0FBRCxFQUFVLGFBQVY7QUFIUixHQXZCb0I7QUE0QjdCaEcsU0FBTztBQUNMVixVQUFNWCxNQUREO0FBRUxZLFdBQU8sd0JBRkY7QUFHTGlCLGNBQVU7QUFITCxHQTVCc0I7QUFpQzdCUCxzQkFBb0I7QUFDbEJYLFVBQU1YLE1BRFk7QUFFbEJZLFdBQU8sdUNBRlc7QUFHbEJpQixjQUFVO0FBSFEsR0FqQ1M7QUFzQzdCMEwsb0JBQWtCO0FBQ2hCNU0sVUFBTVgsTUFEVTtBQUVoQlksV0FBTywrQkFGUztBQUdoQmlCLGNBQVU7QUFITSxHQXRDVztBQTJDN0IyTCxnQkFBYztBQUNaN00sVUFBTVgsTUFETTtBQUVaWSxXQUFPLGlDQUZLO0FBR1ppQixjQUFVO0FBSEUsR0EzQ2U7QUFnRDdCRCxVQUFRO0FBQ05qQixVQUFNYSxNQURBO0FBRU5aLFdBQU8sbUNBRkQ7QUFHTmEsU0FBSyxDQUhDO0FBSU5JLGNBQVU7QUFKSixHQWhEcUI7QUFzRDdCdUgsb0JBQWtCO0FBQ2hCekksVUFBTWtGLHNCQURVO0FBRWhCakYsV0FBTztBQUZTLEdBdERXO0FBMEQ3QmtCLFdBQVM7QUFDUG5CLFVBQU1YLE1BREM7QUFFUFksV0FBTyxnQ0FGQTtBQUdQRSxhQUhPLHVCQUdLO0FBQ1YsVUFBSSxLQUFLQyxRQUFULEVBQW1CLE9BQU8sSUFBUDtBQUNwQjtBQUxNO0FBMURvQixDQUFqQixDQUFkO0FBbUVBNkwsS0FBSzFLLFlBQUwsQ0FBa0IwSyxLQUFLbE0sTUFBdkI7QUF0SEF4QixPQUFPaUQsYUFBUCxDQXdIZXlLLElBeEhmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQSxJQUFJM04sZ0JBQUo7O0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsUUFBRCxrQkFBUUksQ0FBUixFQUFVO0FBQUNKLGNBQU9JLENBQVA7QUFBUztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFBK0QsSUFBSUMsZUFBSjs7QUFBVUosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRSxPQUFELGlCQUFPRCxDQUFQLEVBQVM7QUFBQ0MsYUFBTUQsQ0FBTjtBQUFRO0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUl1TixhQUFKO0FBQVMxTixPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDdU4sV0FBS3ZOLENBQUw7QUFBTztBQUFuQixDQUEvQixFQUFvRCxDQUFwRDtBQUF1RCxJQUFJK0Msa0JBQUo7QUFBY2xELE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDK0MsZ0JBQVUvQyxDQUFWO0FBQVk7QUFBeEIsQ0FBakQsRUFBMkUsQ0FBM0U7QUFNOU4sSUFBTW9PLGVBQWViLEtBQUtsTSxNQUFMLENBQVk0QixJQUFaLENBQWlCLE1BQWpCLEVBQXlCLFNBQXpCLEVBQW9DLE9BQXBDLEVBQTZDLG9CQUE3QyxFQUFtRSxrQkFBbkUsRUFBdUYsY0FBdkYsRUFBdUcsUUFBdkcsRUFBaUgsa0JBQWpILENBQXJCO0FBRUEsSUFBTW9MLGdCQUFnQmQsS0FBS2xNLE1BQUwsQ0FBWTRCLElBQVosQ0FBaUIsTUFBakIsRUFBeUIsU0FBekIsRUFBb0MsT0FBcEMsRUFBNkMsb0JBQTdDLEVBQW1FLGtCQUFuRSxFQUF1RixjQUF2RixFQUF1RyxRQUF2RyxFQUFpSCxrQkFBakgsQ0FBdEI7QUFDQW9MLGNBQWNsTCxNQUFkLENBQXFCO0FBQUV2QyxPQUFLRDtBQUFQLENBQXJCOztBQUVBZixRQUFPd0QsT0FBUCxDQUFlO0FBQ2IsaUJBQWUsU0FBU2tMLFVBQVQsQ0FBb0J6RyxHQUFwQixFQUF5QjtBQUN0QyxRQUFJO0FBQ0Z1RyxtQkFBYTdLLFFBQWIsQ0FBc0JzRSxHQUF0QjtBQUNBLGFBQU8wRixLQUFLdE0sTUFBTDtBQUFjVixlQUFPLEtBQUtDO0FBQTFCLFNBQXFDcUgsR0FBckMsRUFBUDtBQUNELEtBSEQsQ0FHRSxPQUFPckUsU0FBUCxFQUFrQjtBQUNsQixVQUFJQSxVQUFVQyxLQUFWLEtBQW9CLGtCQUF4QixFQUE0QztBQUMxQyxjQUFNLElBQUk3RCxRQUFPOEQsS0FBWCxDQUFpQixHQUFqQixFQUFzQkYsVUFBVUcsT0FBaEMsQ0FBTjtBQUNEOztBQUNELFlBQU0sSUFBSS9ELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQVhZO0FBWWIsaUJBQWUsU0FBUytLLFVBQVQsQ0FBb0IxRyxHQUFwQixFQUF5QjtBQUN0QyxRQUFJO0FBQ0Z3RyxvQkFBYzlLLFFBQWQsQ0FBdUJzRSxHQUF2QjtBQUNBLFVBQU02RixRQUFRN0YsSUFBSWpILEdBQWxCO0FBQ0EyTSxXQUFLck0sTUFBTCxDQUFZd00sS0FBWixFQUFtQjtBQUFFN0osY0FBTWdFO0FBQVIsT0FBbkI7QUFDQSxhQUFPNkYsS0FBUCxDQUpFLENBS0Y7QUFDRCxLQU5ELENBTUUsT0FBT2xLLFNBQVAsRUFBa0I7QUFDbEIsVUFBSUEsVUFBVUMsS0FBVixLQUFvQixrQkFBeEIsRUFBNEM7QUFDMUMsY0FBTSxJQUFJN0QsUUFBTzhELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0JGLFVBQVVHLE9BQWhDLENBQU47QUFDRDs7QUFDRCxZQUFNLElBQUkvRCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0YsR0F6Qlk7QUEwQmIscUJBQW1CLFNBQVNnTCxjQUFULENBQXdCZCxLQUF4QixFQUErQjtBQUNoRHpOLFdBQU15TixLQUFOLEVBQWEvTSxNQUFiOztBQUNBLFFBQUk7QUFDRjRNLFdBQUtyTSxNQUFMLENBQVl3TSxLQUFaLEVBQW1CO0FBQUU3SixjQUFNO0FBQUVwQixtQkFBVSxJQUFJZCxJQUFKLEVBQUQsQ0FBYUMsV0FBYjtBQUFYO0FBQVIsT0FBbkI7QUFDRCxLQUZELENBRUUsT0FBTzRCLFNBQVAsRUFBa0I7QUFDbEIsWUFBTSxJQUFJNUQsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGLEdBakNZO0FBa0NiLGtCQUFnQixTQUFTaUwsV0FBVCxDQUFxQmYsS0FBckIsRUFBNEI7QUFDMUN6TixXQUFNeU4sS0FBTixFQUFhL00sTUFBYjs7QUFDQSxRQUFJO0FBQ0Y0TSxXQUFLck0sTUFBTCxDQUFZd00sS0FBWixFQUFtQjtBQUFFN0osY0FBTTtBQUFFcEIsbUJBQVM7QUFBWDtBQUFSLE9BQW5CO0FBQ0QsS0FGRCxDQUVFLE9BQU9lLFNBQVAsRUFBa0I7QUFDbEIsWUFBTSxJQUFJNUQsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGLEdBekNZO0FBMENiLHFCQUFtQixTQUFTa0wsY0FBVCxDQUF3QkMsTUFBeEIsRUFBZ0M7QUFDakQxTyxXQUFNME8sTUFBTixFQUFjaE8sTUFBZDs7QUFDQSxRQUFJO0FBQ0YsYUFBTzRNLEtBQUtwTSxNQUFMLENBQVl3TixNQUFaLENBQVA7QUFDRCxLQUZELENBRUUsT0FBT25MLFNBQVAsRUFBa0I7QUFDbEIsWUFBTSxJQUFJNUQsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGO0FBakRZLENBQWY7O0FBb0RBVCxVQUFVO0FBQ1JLLFdBQVMsQ0FDUCxhQURPLEVBRVAsYUFGTyxFQUdQLGlCQUhPLEVBSVAsY0FKTyxFQUtQLGlCQUxPLENBREQ7QUFRUmEsU0FBTyxDQVJDO0FBU1JDLGFBQVc7QUFUSCxDQUFWLEU7Ozs7Ozs7Ozs7Ozs7QUMvREEsSUFBSXRFLGdCQUFKOztBQUFXQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNILFFBQUQsa0JBQVFJLENBQVIsRUFBVTtBQUFDSixjQUFPSSxDQUFQO0FBQVM7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7O0FBQStELElBQUk0TyxrQkFBSjs7QUFBYS9PLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEVBQTZDO0FBQUM2TyxVQUFELG9CQUFVNU8sQ0FBVixFQUFZO0FBQUM0TyxnQkFBUzVPLENBQVQ7QUFBVztBQUF4QixDQUE3QyxFQUF1RSxDQUF2RTtBQUt2RixJQUFJNk8sZUFBSjs7QUFFQSxJQUFNQyxhQUFhLFNBQWJBLFVBQWEsQ0FBQ3RPLE1BQUQsUUFBdUM7QUFBQSxNQUE1QnVPLFlBQTRCLFFBQTVCQSxZQUE0QjtBQUFBLE1BQWRDLE9BQWMsUUFBZEEsT0FBYztBQUN4REMsVUFBUUMsR0FBUixDQUFZMU8sTUFBWixFQUFvQnVPLFlBQXBCLEVBQWtDSSxLQUFLQyxTQUFMLENBQWVKLE9BQWYsQ0FBbEM7O0FBQ0EsTUFBSTtBQUNGLFFBQU1LLGVBQWV6UCxRQUFPMFAsS0FBUCxDQUFhaFAsSUFBYixDQUNuQjtBQUFFTSxXQUFLSjtBQUFQLEtBRG1CLEVBRW5CO0FBQ0VrTCxjQUFRO0FBQ042RCxnQkFBUTtBQURGO0FBRFYsS0FGbUIsRUFPbkJDLEtBUG1CLEdBT1gsQ0FQVyxFQU9SRCxNQVBRLENBT0QsQ0FQQyxFQU9FRSxPQVB2Qjs7QUFRQSxRQUFJVixpQkFBaUJNLFlBQXJCLEVBQW1DO0FBQ2pDelAsY0FBTzBQLEtBQVAsQ0FBYXBPLE1BQWIsQ0FBb0JWLE1BQXBCLEVBQTRCO0FBQzFCcUQsY0FBTTtBQUFFbUw7QUFBRjtBQURvQixPQUE1QjtBQUdELEtBSkQsTUFJTztBQUNMcFAsY0FBTzBQLEtBQVAsQ0FBYXBPLE1BQWIsQ0FBb0JWLE1BQXBCLEVBQTRCO0FBQzFCcUQsY0FBTTtBQUNKLDhCQUFvQmtMLFlBRGhCO0FBRUosK0JBQXFCLEtBRmpCO0FBR0pDO0FBSEk7QUFEb0IsT0FBNUIsRUFNRyxVQUFDdkwsS0FBRCxFQUFXO0FBQ1osWUFBSUEsS0FBSixFQUFXO0FBQ1QsZ0JBQU0sSUFBSTdELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRCxNQUFNaU0sTUFBOUIsQ0FBTjtBQUNELFNBRkQsTUFFTztBQUNMZCxvQkFBU2UscUJBQVQsQ0FBK0JuUCxNQUEvQjtBQUNEO0FBQ0YsT0FaRDtBQWFEO0FBQ0YsR0E1QkQsQ0E0QkUsT0FBT2dELFNBQVAsRUFBa0I7QUFDbEJxTCxXQUFPZSxNQUFQLCtCQUEwQ3BNLFNBQTFDO0FBQ0Q7QUFDRixDQWpDRDs7QUFtQ0EsSUFBTXFNLGNBQWMsU0FBZEEsV0FBYyxRQUFzQkMsT0FBdEIsRUFBa0M7QUFBQSxNQUEvQnRQLE1BQStCLFNBQS9CQSxNQUErQjtBQUFBLE1BQXZCd08sT0FBdUIsU0FBdkJBLE9BQXVCO0FBQ3BEQyxVQUFRQyxHQUFSLENBQVksMkJBQVo7QUFDQUQsVUFBUUMsR0FBUixDQUFZMU8sTUFBWixFQUFvQjJPLEtBQUtDLFNBQUwsQ0FBZUosT0FBZixDQUFwQjs7QUFDQSxNQUFJO0FBQ0ZILGFBQVNpQixPQUFUO0FBQ0FoQixlQUFXdE8sTUFBWCxFQUFtQndPLE9BQW5CO0FBQ0FILFdBQU9rQixPQUFQO0FBQ0QsR0FKRCxDQUlFLE9BQU92TSxTQUFQLEVBQWtCO0FBQ2xCcUwsV0FBT2UsTUFBUCw0QkFBdUNwTSxTQUF2QztBQUNEO0FBQ0YsQ0FWRDs7QUExQ0EzRCxPQUFPaUQsYUFBUCxDQXNEZTtBQUFBLFNBQ2IsSUFBSWtOLE9BQUosQ0FBWSxVQUFDRCxPQUFELEVBQVVILE1BQVY7QUFBQSxXQUNWQyxZQUFZSSxPQUFaLEVBQXFCO0FBQUVGLHNCQUFGO0FBQVdIO0FBQVgsS0FBckIsQ0FEVTtBQUFBLEdBQVosQ0FEYTtBQUFBLENBdERmLEU7Ozs7Ozs7Ozs7Ozs7QUNBQSxJQUFJaFEsZ0JBQUo7O0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsUUFBRCxrQkFBUUksQ0FBUixFQUFVO0FBQUNKLGNBQU9JLENBQVA7QUFBUztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFBK0QsSUFBSUMsZUFBSjs7QUFBVUosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRSxPQUFELGlCQUFPRCxDQUFQLEVBQVM7QUFBQ0MsYUFBTUQsQ0FBTjtBQUFRO0FBQWxCLENBQXJDLEVBQXlELENBQXpEOztBQUE0RCxJQUFJNE8sa0JBQUo7O0FBQWEvTyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYixFQUE2QztBQUFDNk8sVUFBRCxvQkFBVTVPLENBQVYsRUFBWTtBQUFDNE8sZ0JBQVM1TyxDQUFUO0FBQVc7QUFBeEIsQ0FBN0MsRUFBdUUsQ0FBdkU7O0FBQTBFLElBQUlrUSxlQUFKOztBQUFVclEsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ21RLE9BQUQsaUJBQU9sUSxDQUFQLEVBQVM7QUFBQ2tRLGFBQU1sUSxDQUFOO0FBQVE7QUFBbEIsQ0FBOUMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSWMscUJBQUo7QUFBaUJqQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDYyxtQkFBYWQsQ0FBYjtBQUFlO0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBQXFFLElBQUk2UCxvQkFBSjtBQUFnQmhRLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxnQkFBUixDQUFiLEVBQXVDO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDNlAsa0JBQVk3UCxDQUFaO0FBQWM7QUFBMUIsQ0FBdkMsRUFBbUUsQ0FBbkU7QUFBc0UsSUFBSStDLGtCQUFKO0FBQWNsRCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQytDLGdCQUFVL0MsQ0FBVjtBQUFZO0FBQXhCLENBQXBELEVBQThFLENBQTlFO0FBVWhmLElBQU1tUSxnQkFBZ0IsSUFBSXJQLFlBQUosQ0FBaUI7QUFDckNrTyxXQUFTO0FBQ1AxTixVQUFNcUI7QUFEQyxHQUQ0QjtBQUlyQyxrQkFBZ0I7QUFDZHJCLFVBQU1xQjtBQURRLEdBSnFCO0FBT3JDLHdCQUFzQjtBQUNwQnJCLFVBQU1YO0FBRGMsR0FQZTtBQVVyQyx1QkFBcUI7QUFDbkJXLFVBQU1YO0FBRGEsR0FWZ0I7QUFhckN5UCxTQUFPO0FBQ0w5TyxVQUFNWCxNQUREO0FBRUwwUCxXQUFPdlAsYUFBYXdQLEtBQWIsQ0FBbUJDO0FBRnJCLEdBYjhCO0FBaUJyQ0MsWUFBVTtBQUNSbFAsVUFBTVgsTUFERTtBQUVSeUIsU0FBSztBQUZHO0FBakIyQixDQUFqQixDQUF0QjtBQXVCQSxJQUFNcU8saUJBQWlCLElBQUkzUCxZQUFKLENBQWlCO0FBQ3RDa08sV0FBUztBQUNQMU4sVUFBTXFCO0FBREMsR0FENkI7QUFJdEMsa0JBQWdCO0FBQ2RyQixVQUFNcUI7QUFEUSxHQUpzQjtBQU90Qyx3QkFBc0I7QUFDcEJyQixVQUFNWDtBQURjLEdBUGdCO0FBVXRDLHVCQUFxQjtBQUNuQlcsVUFBTVg7QUFEYSxHQVZpQjtBQWF0Q3lQLFNBQU87QUFDTDlPLFVBQU1YLE1BREQ7QUFFTDBQLFdBQU92UCxhQUFhd1AsS0FBYixDQUFtQkM7QUFGckIsR0FiK0I7QUFpQnRDM1AsT0FBS0Q7QUFqQmlDLENBQWpCLENBQXZCOztBQXFCQWYsUUFBT3dELE9BQVAsQ0FBZTtBQUNiLHNCQUFvQixTQUFTc04sZUFBVCxDQUF5QmxRLE1BQXpCLEVBQWlDbVEsT0FBakMsRUFBMEM7QUFDNUQxUSxXQUFNTyxNQUFOLEVBQWNHLE1BQWQ7O0FBQ0FWLFdBQU0wUSxPQUFOLEVBQWVoUSxNQUFmOztBQUVBLFFBQUl1UCxPQUFNVSxZQUFOLENBQW1CLEtBQUtwUSxNQUF4QixFQUFnQyxDQUFDLE9BQUQsQ0FBaEMsQ0FBSixFQUFnRDtBQUM5QzBQLGFBQU1XLFlBQU4sQ0FBbUJyUSxNQUFuQixFQUEyQm1RLE9BQTNCO0FBQ0QsS0FGRCxNQUVPLElBQUlULE9BQU1VLFlBQU4sQ0FBbUJwUSxNQUFuQixFQUEyQixDQUFDLE9BQUQsQ0FBM0IsQ0FBSixFQUEyQztBQUNoRCxZQUFNLElBQUlaLFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCLGFBQXhCLENBQU47QUFDRCxLQUZNLE1BRUE7QUFDTCxZQUFNLElBQUk5RCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QixzQkFBeEIsQ0FBTjtBQUNEO0FBQ0YsR0FaWTtBQWNiLGlDQUErQixTQUFTaU0scUJBQVQsQ0FBK0JuUCxNQUEvQixFQUF1QztBQUNwRSxXQUFPb08sVUFBU2UscUJBQVQsQ0FBK0JuUCxNQUEvQixDQUFQO0FBQ0QsR0FoQlk7QUFrQmIsdUJBQXFCLFNBQVNzUSxnQkFBVCxDQUEwQnRRLE1BQTFCLEVBQWtDO0FBQ3JELFFBQUk7QUFDRixhQUFPb08sVUFBU21DLFdBQVQsQ0FBcUJ2USxNQUFyQixFQUE2QixVQUE3QixDQUFQO0FBQ0QsS0FGRCxDQUVFLE9BQU9nRCxTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTVELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQXhCWTtBQTBCYix1QkFBcUIsU0FBU3dOLGdCQUFULENBQTBCaEMsT0FBMUIsRUFBbUM7QUFDdEQvTyxXQUFNK08sT0FBTixFQUFlO0FBQ2JELG9CQUFjcE8sTUFERDtBQUVicU8sZUFBUztBQUNQak4sY0FBTTtBQUNKa1AsaUJBQU90USxNQURIO0FBRUp1USxnQkFBTXZRO0FBRkY7QUFEQztBQUZJLEtBQWY7O0FBU0EsV0FBT2tQLFlBQVk7QUFBRXJQLGNBQVEsS0FBS0EsTUFBZjtBQUF1QndPO0FBQXZCLEtBQVosRUFDSm1DLElBREksQ0FDQztBQUFBLGFBQVlDLFFBQVo7QUFBQSxLQURELEVBRUpDLEtBRkksQ0FFRSxVQUFDN04sU0FBRCxFQUFlO0FBQ3BCLFlBQU0sSUFBSTVELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0QsS0FKSSxDQUFQO0FBS0QsR0F6Q1k7QUEwQ2Isc0JBQW9CLFNBQVM4TixlQUFULENBQXlCOVEsTUFBekIsRUFBaUM7QUFDbkRQLFdBQU1PLE1BQU4sRUFBY0csTUFBZDs7QUFDQSxRQUFJO0FBQ0YsVUFBSXVQLE9BQU1VLFlBQU4sQ0FBbUIsS0FBS3BRLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxDQUFoQyxDQUFKLEVBQWdEO0FBQzlDWixnQkFBTzBQLEtBQVAsQ0FBYXBPLE1BQWIsQ0FBb0JWLE1BQXBCLEVBQTRCO0FBQUVxRCxnQkFBTTtBQUFFcEIscUJBQVUsSUFBSWQsSUFBSixFQUFELENBQWFDLFdBQWI7QUFBWDtBQUFSLFNBQTVCO0FBQ0QsT0FGRCxNQUVPLElBQUlzTyxPQUFNVSxZQUFOLENBQW1CcFEsTUFBbkIsRUFBMkIsQ0FBQyxPQUFELENBQTNCLENBQUosRUFBMkM7QUFDaEQsY0FBTSxJQUFJWixRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QixhQUF4QixDQUFOO0FBQ0QsT0FGTSxNQUVBO0FBQ0wsY0FBTSxJQUFJOUQsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0Isc0JBQXhCLENBQU47QUFDRDtBQUNGLEtBUkQsQ0FRRSxPQUFPRixTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTVELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQXZEWTtBQXdEYixtQkFBaUIsU0FBUzRKLGVBQVQsQ0FBeUI1TSxNQUF6QixFQUFpQztBQUNoRFAsV0FBTU8sTUFBTixFQUFjRyxNQUFkOztBQUNBLFFBQUk7QUFDRixVQUFJdVAsT0FBTVUsWUFBTixDQUFtQixLQUFLcFEsTUFBeEIsRUFBZ0MsQ0FBQyxPQUFELENBQWhDLENBQUosRUFBZ0Q7QUFDOUNaLGdCQUFPMFAsS0FBUCxDQUFhcE8sTUFBYixDQUFvQlYsTUFBcEIsRUFBNEI7QUFBRXFELGdCQUFNO0FBQUVwQixxQkFBUztBQUFYO0FBQVIsU0FBNUI7QUFDRCxPQUZELE1BRU87QUFDTCxjQUFNLElBQUk3QyxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QixzQkFBeEIsQ0FBTjtBQUNEO0FBQ0YsS0FORCxDQU1FLE9BQU9GLFNBQVAsRUFBa0I7QUFDbEIsWUFBTSxJQUFJNUQsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGLEdBbkVZO0FBb0ViLHNCQUFvQixTQUFTK04sZUFBVCxDQUF5Qi9RLE1BQXpCLEVBQWlDO0FBQ25EUCxXQUFNTyxNQUFOLEVBQWNHLE1BQWQ7O0FBQ0EsUUFBSTtBQUNGLFVBQUl1UCxPQUFNVSxZQUFOLENBQW1CLEtBQUtwUSxNQUF4QixFQUFnQyxDQUFDLE9BQUQsQ0FBaEMsQ0FBSixFQUFnRDtBQUM5Q1osZ0JBQU8wUCxLQUFQLENBQWFuTyxNQUFiLENBQW9CWCxNQUFwQjtBQUNELE9BRkQsTUFFTyxJQUFJMFAsT0FBTVUsWUFBTixDQUFtQnBRLE1BQW5CLEVBQTJCLENBQUMsT0FBRCxDQUEzQixDQUFKLEVBQTJDO0FBQ2hELGNBQU0sSUFBSVosUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0IsYUFBeEIsQ0FBTjtBQUNELE9BRk0sTUFFQTtBQUNMLGNBQU0sSUFBSTlELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCLHNCQUF4QixDQUFOO0FBQ0Q7QUFDRixLQVJELENBUUUsT0FBT0YsU0FBUCxFQUFrQjtBQUNsQixZQUFNLElBQUk1RCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixFQUF3QkYsU0FBeEIsQ0FBTjtBQUNEO0FBQ0YsR0FqRlk7QUFrRmIsa0JBQWdCLFNBQVNnTyxXQUFULENBQXFCQyxJQUFyQixFQUEyQjtBQUN6QyxRQUFJO0FBQ0Z0QixvQkFBYzVNLFFBQWQsQ0FBdUJrTyxJQUF2QjtBQUNBLGFBQU83QyxVQUFTOEMsVUFBVCxDQUFvQkQsSUFBcEIsQ0FBUDtBQUNELEtBSEQsQ0FHRSxPQUFPak8sU0FBUCxFQUFrQjtBQUNsQixVQUFJQSxVQUFVQyxLQUFWLEtBQW9CLGtCQUF4QixFQUE0QztBQUMxQyxjQUFNLElBQUk3RCxRQUFPOEQsS0FBWCxDQUFpQixHQUFqQixFQUFzQkYsVUFBVUcsT0FBaEMsQ0FBTjtBQUNEOztBQUNELFlBQU0sSUFBSS9ELFFBQU84RCxLQUFYLENBQWlCLEtBQWpCLEVBQXdCRixTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQTVGWTtBQTZGYixrQkFBZ0IsU0FBU21PLFdBQVQsQ0FBcUJGLElBQXJCLEVBQTJCO0FBQ3pDeEMsWUFBUUMsR0FBUixDQUFZLHNCQUFaO0FBQ0FELFlBQVFDLEdBQVIsQ0FBWUMsS0FBS0MsU0FBTCxDQUFlcUMsSUFBZixDQUFaOztBQUNBLFFBQUk7QUFDRmhCLHFCQUFlbE4sUUFBZixDQUF3QmtPLElBQXhCO0FBQ0EsVUFBTUcsY0FBYztBQUNsQjdDLHNCQUFjMEMsS0FBS3JCLEtBREQ7QUFFbEJwQixpQkFBUztBQUNQak4sZ0JBQU07QUFDSmtQLG1CQUFPUSxLQUFLekMsT0FBTCxDQUFhak4sSUFBYixDQUFrQmtQLEtBRHJCO0FBRUpDLGtCQUFNTyxLQUFLekMsT0FBTCxDQUFhak4sSUFBYixDQUFrQm1QO0FBRnBCO0FBREM7QUFGUyxPQUFwQjtBQVNBakMsY0FBUUMsR0FBUixrQkFBMkJDLEtBQUtDLFNBQUwsQ0FBZXdDLFdBQWYsQ0FBM0I7QUFDQSxhQUFPL0IsWUFBWTtBQUFFclAsZ0JBQVFpUixLQUFLN1EsR0FBZjtBQUFvQmdSO0FBQXBCLE9BQVosRUFDSlQsSUFESSxDQUNDO0FBQUEsZUFBWUMsUUFBWjtBQUFBLE9BREQsRUFFSkMsS0FGSSxDQUVFLFVBQUM3TixTQUFELEVBQWU7QUFDcEIsY0FBTSxJQUFJNUQsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRCxPQUpJLENBQVA7QUFLRCxLQWpCRCxDQWlCRSxPQUFPQSxTQUFQLEVBQWtCO0FBQ2xCLFVBQUlBLFVBQVVDLEtBQVYsS0FBb0Isa0JBQXhCLEVBQTRDO0FBQzFDLGNBQU0sSUFBSTdELFFBQU84RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCRixVQUFVRyxPQUFoQyxDQUFOO0FBQ0Q7O0FBQ0QsWUFBTSxJQUFJL0QsUUFBTzhELEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JGLFNBQXhCLENBQU47QUFDRDtBQUNGO0FBdkhZLENBQWY7O0FBeUhBVCxVQUFVO0FBQ1JLLFdBQVMsQ0FDUCxtQkFETyxFQUVQLDZCQUZPLEVBR1Asa0JBSE8sRUFJUCxrQkFKTyxFQUtQLGVBTE8sRUFNUCxrQkFOTyxFQU9QLGNBUE8sQ0FERDtBQVVSYSxTQUFPLENBVkM7QUFXUkMsYUFBVztBQVhILENBQVYsRTs7Ozs7Ozs7Ozs7OztBQy9LQSxJQUFJdEUsZ0JBQUo7O0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsUUFBRCxrQkFBUUksQ0FBUixFQUFVO0FBQUNKLGNBQU9JLENBQVA7QUFBUztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFBK0QsSUFBSUMsZUFBSjs7QUFBVUosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRSxPQUFELGlCQUFPRCxDQUFQLEVBQVM7QUFBQ0MsYUFBTUQsQ0FBTjtBQUFRO0FBQWxCLENBQXJDLEVBQXlELENBQXpEOztBQUE0RCxJQUFJa1EsZUFBSjs7QUFBVXJRLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNtUSxPQUFELGlCQUFPbFEsQ0FBUCxFQUFTO0FBQUNrUSxhQUFNbFEsQ0FBTjtBQUFRO0FBQWxCLENBQTlDLEVBQWtFLENBQWxFOztBQUsxSkosUUFBT1EsT0FBUCxDQUFlLGtCQUFmLEVBQW1DLFNBQVN5UixlQUFULEdBQTJCO0FBQzVELE1BQUkzQixPQUFNVSxZQUFOLENBQW1CLEtBQUtwUSxNQUF4QixFQUFnQyxDQUFDLE9BQUQsQ0FBaEMsQ0FBSixFQUFnRDtBQUM5QyxXQUFPWixRQUFPMFAsS0FBUCxDQUFhaFAsSUFBYixDQUFrQixFQUFsQixFQUFzQjtBQUMzQm9MLGNBQVE7QUFDTjZELGdCQUFRLENBREY7QUFFTnVDLGVBQU8sQ0FGRDtBQUdOOUMsaUJBQVMsQ0FISDtBQUlOakUsa0JBQVUsQ0FKSjtBQUtOdEksaUJBQVMsQ0FMSDtBQU1OakIsbUJBQVc7QUFOTDtBQURtQixLQUF0QixDQUFQO0FBVUQ7QUFDRixDQWJEOztBQWVBNUIsUUFBT1EsT0FBUCxDQUFlLG1CQUFmLEVBQW9DLFNBQVMyUixZQUFULEdBQXdCO0FBQzFELFNBQU9uUyxRQUFPMFAsS0FBUCxDQUFhaFAsSUFBYixDQUFrQjtBQUFFTSxTQUFLLEtBQUtKO0FBQVosR0FBbEIsRUFBd0M7QUFDN0NrTCxZQUFRO0FBQ042RCxjQUFRLENBREY7QUFFTlAsZUFBUyxDQUZIO0FBR05qRSxnQkFBVTtBQUhKO0FBRHFDLEdBQXhDLENBQVA7QUFPRCxDQVJEOztBQVVBbkwsUUFBT1EsT0FBUCxDQUFlLFlBQWYsRUFBNkIsVUFBQ0ksTUFBRCxFQUFZO0FBQ3ZDUCxTQUFNTyxNQUFOLEVBQWNHLE1BQWQ7O0FBQ0EsU0FBT2YsUUFBTzBQLEtBQVAsQ0FBYWhQLElBQWIsQ0FBa0I7QUFBRU0sU0FBS0o7QUFBUCxHQUFsQixFQUFtQztBQUN4Q2tMLFlBQVE7QUFDTjZELGNBQVEsQ0FERjtBQUVOUCxlQUFTLENBRkg7QUFHTmpFLGdCQUFVLENBSEo7QUFJTnZKLGlCQUFXLENBSkw7QUFLTnNRLGFBQU8sQ0FMRDtBQU1OclAsZUFBUztBQU5IO0FBRGdDLEdBQW5DLENBQVA7QUFVRCxDQVpELEU7Ozs7Ozs7Ozs7Ozs7QUM5QkEsSUFBSTdDLGdCQUFKOztBQUFXQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNILFFBQUQsa0JBQVFJLENBQVIsRUFBVTtBQUFDSixjQUFPSSxDQUFQO0FBQVM7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSWdTLGtCQUFKO0FBQWNuUyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsb0NBQVIsQ0FBYixFQUEyRDtBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQ2dTLGdCQUFVaFMsQ0FBVjtBQUFZO0FBQXhCLENBQTNELEVBQXFGLENBQXJGO0FBQXdGLElBQUlpUyx3QkFBSjtBQUFvQnBTLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxvQ0FBUixDQUFiLEVBQTJEO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDaVMsc0JBQWdCalMsQ0FBaEI7QUFBa0I7QUFBOUIsQ0FBM0QsRUFBMkYsQ0FBM0Y7QUFBcE1ILE9BQU9pRCxhQUFQLENBSWUsVUFBQ21OLE9BQUQsRUFBVXdCLElBQVYsRUFBbUI7QUFDaEMsTUFBTVMsZUFBZUQsZ0JBQWdCaEMsT0FBaEIsRUFBeUJ3QixJQUF6QixDQUFyQjtBQUVBLE1BQU1VLGtCQUFrQixTQUF4QjtBQUNBLE1BQU1DLFlBQVlGLGVBQWVBLGFBQWFuUSxJQUFiLENBQWtCa1AsS0FBakMsR0FBeUNoQixRQUFRakIsT0FBUixDQUFnQmpOLElBQWhCLENBQXFCa1AsS0FBaEY7QUFDQSxNQUFNbEMsZUFBZW1ELGVBQWVBLGFBQWE5QixLQUE1QixHQUFvQ0gsUUFBUUcsS0FBakU7QUFFQSxTQUFPNEIsVUFBVTtBQUNmSyxRQUFJdEQsWUFEVztBQUVmdUQsVUFBU0gsZUFBVCw2QkFGZTtBQUdmSSxtQkFBYUosZUFBYixtQkFBMENDLFNBQTFDLE1BSGU7QUFJZkksY0FBVSxTQUpLO0FBS2ZDLGtCQUFjO0FBQ1pOLHNDQURZO0FBRVpDLDBCQUZZO0FBR1pNLGtCQUFZOVMsUUFBTytTLFdBQVAsQ0FBbUIsVUFBbkIsQ0FIQSxDQUdnQzs7QUFIaEM7QUFMQyxHQUFWLEVBV0p0QixLQVhJLENBV0UsVUFBQzVOLEtBQUQsRUFBVztBQUNoQixVQUFNLElBQUk3RCxRQUFPOEQsS0FBWCxDQUFpQixLQUFqQixPQUEyQkQsS0FBM0IsQ0FBTjtBQUNELEdBYkksQ0FBUDtBQWNELENBekJELEU7Ozs7Ozs7Ozs7Ozs7QUNBQSxJQUFJN0QsZ0JBQUo7O0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsUUFBRCxrQkFBUUksQ0FBUixFQUFVO0FBQUNKLGNBQU9JLENBQVA7QUFBUztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFBK0QsSUFBSUMsZUFBSjs7QUFBVUosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRSxPQUFELGlCQUFPRCxDQUFQLEVBQVM7QUFBQ0MsYUFBTUQsQ0FBTjtBQUFRO0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUk0Uyx1QkFBSjtBQUFtQi9TLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQ0FBUixDQUFiLEVBQWlFO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDNFMscUJBQWU1UyxDQUFmO0FBQWlCO0FBQTdCLENBQWpFLEVBQWdHLENBQWhHO0FBQW1HLElBQUk2UyxzQkFBSjtBQUFrQmhULE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxpQ0FBUixDQUFiLEVBQXdEO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDNlMsb0JBQWM3UyxDQUFkO0FBQWdCO0FBQTVCLENBQXhELEVBQXNGLENBQXRGOztBQUt4UkosUUFBT3dELE9BQVAsQ0FBZTtBQUNiLHFCQUFtQixTQUFTMFAsY0FBVCxDQUF3Qm5PLFFBQXhCLEVBQWtDO0FBQ25EMUUsV0FBTTBFLFFBQU4sRUFBZ0JoRSxNQUFoQjs7QUFDQSxXQUFPa1MsY0FBY0QsMEJBQXdCak8sUUFBeEIsU0FBZCxDQUFQO0FBQ0Q7QUFKWSxDQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7QUNMQTlFLE9BQU9rVCxNQUFQLENBQWM7QUFBQ0MsU0FBTTtBQUFBLFdBQUlBLE1BQUo7QUFBQSxHQUFQO0FBQWlCQyxjQUFXO0FBQUEsV0FBSUEsV0FBSjtBQUFBLEdBQTVCO0FBQTJDQyxXQUFRO0FBQUEsV0FBSUEsUUFBSjtBQUFBLEdBQW5EO0FBQStEQyxjQUFXO0FBQUEsV0FBSUEsV0FBSjtBQUFBLEdBQTFFO0FBQXlGQyxtQkFBZ0I7QUFBQSxXQUFJQSxnQkFBSjtBQUFBLEdBQXpHO0FBQTZIQyxnQkFBYTtBQUFBLFdBQUlBLGFBQUo7QUFBQSxHQUExSTtBQUEySkMsc0JBQW1CO0FBQUEsV0FBSUEsbUJBQUo7QUFBQSxHQUE5SztBQUFxTUMsV0FBUTtBQUFBLFdBQUlBLFFBQUo7QUFBQSxHQUE3TTtBQUF5TkMscUJBQWtCO0FBQUEsV0FBSUEsa0JBQUo7QUFBQSxHQUEzTztBQUFpUUMsb0JBQWlCO0FBQUEsV0FBSUEsaUJBQUo7QUFBQSxHQUFsUjtBQUF1U3JOLGdCQUFhO0FBQUEsV0FBSUEsYUFBSjtBQUFBLEdBQXBUO0FBQXFVRSxxQkFBa0I7QUFBQSxXQUFJQSxrQkFBSjtBQUFBLEdBQXZWO0FBQTZXRCxrQkFBZTtBQUFBLFdBQUlBLGVBQUo7QUFBQSxHQUE1WDtBQUErWUUsMkJBQXdCO0FBQUEsV0FBSUEsd0JBQUo7QUFBQSxHQUF2YTtBQUFtY21OLGdDQUE2QjtBQUFBLFdBQUlBLDZCQUFKO0FBQUEsR0FBaGU7QUFBaWdCQyw2QkFBMEI7QUFBQSxXQUFJQSwwQkFBSjtBQUFBO0FBQTNoQixDQUFkO0FBQXlrQixJQUFJN1MscUJBQUo7O0FBQWlCakIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQ2MsbUJBQWFkLENBQWI7QUFBZTtBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTs7QUFHMWxCO0FBQ08sSUFBTWdULFNBQVEsSUFBSWxTLFlBQUosQ0FBaUI7QUFDcENRLFFBQU07QUFDSkEsVUFBTVgsTUFERjtBQUVKWSxXQUFPLDBCQUZIO0FBR0p5RyxtQkFBZSxDQUFDLE9BQUQ7QUFIWCxHQUQ4QjtBQU1wQzRMLGVBQWE7QUFDWHRTLFVBQU00RyxLQURLO0FBRVgzRyxXQUFPLDZMQUZJO0FBR1hzUyxjQUFVLENBSEM7QUFJWEMsY0FBVTtBQUpDLEdBTnVCO0FBWXBDLG1CQUFpQjtBQUNmeFMsVUFBTWEsTUFEUztBQUVmWixXQUFPO0FBRlE7QUFabUIsQ0FBakIsQ0FBZDs7QUFrQkEsSUFBTTBSLGNBQWEsSUFBSW5TLFlBQUosQ0FBaUI7QUFDekNRLFFBQU07QUFDSkEsVUFBTVgsTUFERjtBQUVKWSxXQUFPLDBCQUZIO0FBR0p5RyxtQkFBZSxDQUFDLFlBQUQ7QUFIWCxHQURtQztBQU16QzRMLGVBQWE7QUFDWHRTLFVBQU00RyxLQURLO0FBRVgzRyxXQUFPLG1DQUZJO0FBR1hzUyxjQUFVO0FBSEMsR0FONEI7QUFXekMsbUJBQWlCO0FBQ2Z2UyxVQUFNNEcsS0FEUztBQUVmM0csV0FBTyxvQkFGUTtBQUdmc1MsY0FBVSxDQUhLO0FBSWZDLGNBQVU7QUFKSyxHQVh3QjtBQWlCekMscUJBQW1CO0FBQ2pCeFMsVUFBTWEsTUFEVztBQUVqQlosV0FBTztBQUZVO0FBakJzQixDQUFqQixDQUFuQjs7QUF1QkEsSUFBTTJSLFdBQVUsSUFBSXBTLFlBQUosQ0FBaUI7QUFDdENRLFFBQU07QUFDSkEsVUFBTVgsTUFERjtBQUVKWSxXQUFPLDBCQUZIO0FBR0p5RyxtQkFBZSxDQUFDLFNBQUQ7QUFIWCxHQURnQztBQU10QzRMLGVBQWE7QUFDWHRTLFVBQU00RyxLQURLO0FBRVgzRyxXQUFPO0FBRkksR0FOeUI7QUFVdEMsbUJBQWlCO0FBQ2ZELFVBQU00RyxLQURTO0FBRWYzRyxXQUFPLDRNQUZRO0FBR2ZzUyxjQUFVLENBSEs7QUFJZkUsVUFKZSxvQkFJTjtBQUNQLFVBQU1DLG9CQUFvQixLQUFLQyxLQUFMLENBQVdDLE1BQVgsR0FBb0IsQ0FBOUM7O0FBQ0EsVUFBSSxLQUFLRCxLQUFMLENBQVcsQ0FBWCxFQUFjQyxNQUFkLEtBQXlCLEtBQUtELEtBQUwsQ0FBV0QsaUJBQVgsRUFBOEJFLE1BQTNELEVBQW1FO0FBQ2pFLGVBQU8sNENBQVA7QUFDRDs7QUFDRCxXQUFLLElBQUlDLElBQUksQ0FBYixFQUFnQkEsSUFBSSxLQUFLRixLQUFMLENBQVcsQ0FBWCxFQUFjQyxNQUFsQyxFQUEwQ0MsS0FBSyxDQUEvQyxFQUFrRDtBQUNoRCxZQUFJLEtBQUtGLEtBQUwsQ0FBVyxDQUFYLEVBQWNFLENBQWQsTUFBcUIsS0FBS0YsS0FBTCxDQUFXRCxpQkFBWCxFQUE4QkcsQ0FBOUIsQ0FBekIsRUFBMkQ7QUFDekQsaUJBQU8scUNBQVA7QUFDRDtBQUNGO0FBQ0Y7QUFkYyxHQVZxQjtBQTBCdEMscUJBQW1CO0FBQ2pCN1MsVUFBTTRHLEtBRFc7QUFFakIzRyxXQUFPLG9CQUZVO0FBR2pCc1MsY0FBVSxDQUhPO0FBSWpCQyxjQUFVO0FBSk8sR0ExQm1CO0FBZ0N0Qyx1QkFBcUI7QUFDbkJ4UyxVQUFNYSxNQURhO0FBRW5CWixXQUFPO0FBRlk7QUFoQ2lCLENBQWpCLENBQWhCOztBQXVDQSxJQUFNNFIsY0FBYSxJQUFJclMsWUFBSixDQUFpQjtBQUN6Q1EsUUFBTTtBQUNKQSxVQUFNWCxNQURGO0FBRUpZLFdBQU8sMEJBRkg7QUFHSnlHLG1CQUFlLENBQUMsWUFBRDtBQUhYLEdBRG1DO0FBTXpDNEwsZUFBYTtBQUNYdFMsVUFBTTRHLEtBREs7QUFFWDNHLFdBQU87QUFGSSxHQU40QjtBQVV6QyxtQkFBaUI7QUFDZkQsVUFBTTRHLEtBRFM7QUFFZjNHLFdBQU8sb0JBRlE7QUFHZnNTLGNBQVUsQ0FISztBQUlmQyxjQUFVO0FBSkssR0FWd0I7QUFnQnpDLHFCQUFtQjtBQUNqQnhTLFVBQU1hLE1BRFc7QUFFakJaLFdBQU87QUFGVTtBQWhCc0IsQ0FBakIsQ0FBbkI7O0FBc0JBLElBQU02UixtQkFBa0IsSUFBSXRTLFlBQUosQ0FBaUI7QUFDOUNRLFFBQU07QUFDSkEsVUFBTVgsTUFERjtBQUVKWSxXQUFPLDBCQUZIO0FBR0p5RyxtQkFBZSxDQUFDLGlCQUFEO0FBSFgsR0FEd0M7QUFNOUM0TCxlQUFhO0FBQ1h0UyxVQUFNNEcsS0FESztBQUVYM0csV0FBTztBQUZJLEdBTmlDO0FBVTlDLG1CQUFpQjtBQUNmRCxVQUFNNEcsS0FEUztBQUVmM0csV0FBTyx3REFGUTtBQUdmc1MsY0FBVTtBQUhLLEdBVjZCO0FBZTlDLHFCQUFtQjtBQUNqQnZTLFVBQU00RyxLQURXO0FBRWpCM0csV0FBTyxvQkFGVTtBQUdqQnNTLGNBQVUsQ0FITztBQUlqQkMsY0FBVTtBQUpPLEdBZjJCO0FBcUI5Qyx1QkFBcUI7QUFDbkJ4UyxVQUFNYSxNQURhO0FBRW5CWixXQUFPO0FBRlk7QUFyQnlCLENBQWpCLENBQXhCOztBQTJCQSxJQUFNOFIsZ0JBQWUsSUFBSXZTLFlBQUosQ0FBaUI7QUFDM0NRLFFBQU07QUFDSkEsVUFBTVgsTUFERjtBQUVKWSxXQUFPLDBCQUZIO0FBR0p5RyxtQkFBZSxDQUFDLGNBQUQ7QUFIWCxHQURxQztBQU0zQzRMLGVBQWE7QUFDWHRTLFVBQU00RyxLQURLO0FBRVgzRyxXQUFPO0FBRkksR0FOOEI7QUFVM0MsbUJBQWlCO0FBQ2ZELFVBQU00RyxLQURTO0FBRWYzRyxXQUFPO0FBRlEsR0FWMEI7QUFjM0MscUJBQW1CO0FBQ2pCRCxVQUFNNEcsS0FEVztBQUVqQjNHLFdBQU8sMk1BRlU7QUFHakJzUyxjQUFVLENBSE87QUFJakJFLFVBSmlCLG9CQUlSO0FBQ1AsVUFBTUMsb0JBQW9CLEtBQUtDLEtBQUwsQ0FBV0MsTUFBWCxHQUFvQixDQUE5Qzs7QUFDQSxVQUFJLEtBQUtELEtBQUwsQ0FBVyxDQUFYLEVBQWNDLE1BQWQsS0FBeUIsS0FBS0QsS0FBTCxDQUFXRCxpQkFBWCxFQUE4QkUsTUFBM0QsRUFBbUU7QUFDakUsZUFBTyw0Q0FBUDtBQUNEOztBQUNELFdBQUssSUFBSUMsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLEtBQUtGLEtBQUwsQ0FBVyxDQUFYLEVBQWNDLE1BQWxDLEVBQTBDQyxLQUFLLENBQS9DLEVBQWtEO0FBQ2hELFlBQUksS0FBS0YsS0FBTCxDQUFXLENBQVgsRUFBY0UsQ0FBZCxNQUFxQixLQUFLRixLQUFMLENBQVdELGlCQUFYLEVBQThCRyxDQUE5QixDQUF6QixFQUEyRDtBQUN6RCxpQkFBTyxxQ0FBUDtBQUNEO0FBQ0Y7QUFDRjtBQWRnQixHQWR3QjtBQThCM0MsdUJBQXFCO0FBQ25CN1MsVUFBTTRHLEtBRGE7QUFFbkIzRyxXQUFPLG9CQUZZO0FBR25Cc1MsY0FBVSxDQUhTO0FBSW5CQyxjQUFVO0FBSlMsR0E5QnNCO0FBb0MzQyx5QkFBdUI7QUFDckJ4UyxVQUFNYSxNQURlO0FBRXJCWixXQUFPO0FBRmM7QUFwQ29CLENBQWpCLENBQXJCOztBQTJDQSxJQUFNK1Isc0JBQXFCLElBQUl4UyxZQUFKLENBQWlCO0FBQ2pEUSxRQUFNO0FBQ0pBLFVBQU1YLE1BREY7QUFFSlksV0FBTyw4TkFGSDtBQUdKeUcsbUJBQWUsQ0FBQyxvQkFBRDtBQUhYLEdBRDJDO0FBTWpEb00sUUFBTTtBQUNKOVMsVUFBTTRHLEtBREY7QUFFSjNHLFdBQU8sK1JBRkg7QUFHSmlCLGNBQVU7QUFITixHQU4yQztBQVdqRCxZQUFVO0FBQ1JsQixVQUFNYTtBQURFLEdBWHVDO0FBY2pEa1MsY0FBWTtBQUNWL1MsVUFBTTRHLEtBREk7QUFFVjNHLFdBQU87QUFGRyxHQWRxQztBQWtCakQsa0JBQWdCO0FBQ2Q7QUFDQUQsVUFBTVIsYUFBYXFMLEtBQWIsQ0FBbUI2RyxNQUFuQixFQUEwQkcsV0FBMUIsRUFBc0NGLFdBQXRDLEVBQWtERyxnQkFBbEQsRUFBbUVGLFFBQW5FLEVBQTRFRyxhQUE1RSxDQUZRO0FBR2Q5UixXQUFPO0FBSE87QUFsQmlDLENBQWpCLENBQTNCOztBQXlCQSxJQUFNZ1MsV0FBVSxJQUFJelMsWUFBSixDQUFpQjtBQUN0Q1EsUUFBTTtBQUNKQSxVQUFNWCxNQURGO0FBRUpZLFdBQU8seURBRkg7QUFHSnlHLG1CQUFlLENBQUMsU0FBRDtBQUhYLEdBRGdDO0FBTXRDc00sTUFBSTtBQUNGaFQsVUFBTVIsYUFBYXFMLEtBQWIsQ0FBbUJ4TCxNQUFuQixFQUEyQndCLE1BQTNCLENBREo7QUFFRlosV0FBTywwQkFGTDtBQUdGaUIsY0FBVTtBQUhSLEdBTmtDO0FBV3RDNFIsUUFBTTtBQUNKOVMsVUFBTTRHLEtBREY7QUFFSjNHLFdBQU8sK0xBRkg7QUFHSmlCLGNBQVU7QUFITixHQVhnQztBQWdCdEMsWUFBVTtBQUNSbEIsVUFBTWE7QUFERSxHQWhCNEI7QUFtQnRDb1MsWUFBVTtBQUNSO0FBQ0FqVCxVQUFNUixhQUFhcUwsS0FBYixDQUFtQjZHLE1BQW5CLEVBQTBCRyxXQUExQixFQUFzQ0YsV0FBdEMsRUFBa0RHLGdCQUFsRCxFQUFtRUYsUUFBbkUsRUFBNEVHLGFBQTVFLEVBQTBGQyxtQkFBMUYsQ0FGRTtBQUdSL1IsV0FBTztBQUhDLEdBbkI0QjtBQXdCdENpVCxjQUFZO0FBQ1ZsVCxVQUFNcUIsTUFESTtBQUVWcEIsV0FBTyxrQ0FGRztBQUdWcUIsY0FBVTtBQUhBO0FBeEIwQixDQUFqQixDQUFoQjs7QUErQkEsSUFBTTRRLHFCQUFvQixJQUFJMVMsWUFBSixDQUFpQjtBQUNoRFEsUUFBTTtBQUNKQSxVQUFNWCxNQURGO0FBRUpZLFdBQU8sMEJBRkg7QUFHSnlHLG1CQUFlLENBQUMsbUJBQUQ7QUFIWCxHQUQwQztBQU1oRG9NLFFBQU07QUFDSjlTLFVBQU00RyxLQURGO0FBRUozRyxXQUFPLCtMQUZIO0FBR0ppQixjQUFVO0FBSE4sR0FOMEM7QUFXaEQsWUFBVTtBQUNSbEIsVUFBTWE7QUFERSxHQVhzQztBQWNoRHNTLFlBQVU7QUFDUm5ULFVBQU00RyxLQURFO0FBRVIzRyxXQUFPO0FBRkMsR0Fkc0M7QUFrQmhELGdCQUFjO0FBQ1o7QUFDQUQsVUFBTWlTLFFBRk07QUFHWmhTLFdBQU87QUFISztBQWxCa0MsQ0FBakIsQ0FBMUI7O0FBMEJBLElBQU1rUyxvQkFBbUIsSUFBSTNTLFlBQUosQ0FBaUI7QUFDL0M7QUFDQTRULFdBQVM7QUFDUHBULFVBQU1SLGFBQWFxTCxLQUFiLENBQW1CNkcsTUFBbkIsRUFBMEJDLFdBQTFCLEVBQXNDQyxRQUF0QyxFQUErQ0MsV0FBL0MsRUFBMkRDLGdCQUEzRCxFQUE0RUMsYUFBNUUsRUFBMEZDLG1CQUExRixFQUE4R0MsUUFBOUcsRUFBdUhDLGtCQUF2SDtBQURDO0FBRnNDLENBQWpCLENBQXpCOztBQVVBLElBQU1wTixnQkFBZSxJQUFJdEYsWUFBSixDQUFpQjtBQUMzQ1EsUUFBTTtBQUNKQSxVQUFNWCxNQURGO0FBRUpZLFdBQU8seURBRkg7QUFHSnlHLG1CQUFlLENBQUMsU0FBRDtBQUhYLEdBRHFDO0FBTTNDc00sTUFBSTtBQUNGaFQsVUFBTVIsYUFBYXFMLEtBQWIsQ0FBbUJ4TCxNQUFuQixFQUEyQndCLE1BQTNCLENBREo7QUFFRlosV0FBTywwQkFGTDtBQUdGaUIsY0FBVTtBQUhSLEdBTnVDO0FBVzNDNFIsUUFBTTtBQUNKOVMsVUFBTTRHLEtBREY7QUFFSjNHLFdBQU8sK0xBRkg7QUFHSmlCLGNBQVU7QUFITixHQVhxQztBQWdCM0MsWUFBVTtBQUNSbEIsVUFBTWE7QUFERSxHQWhCaUM7QUFtQjNDb1MsWUFBVTtBQUNSalQsVUFBTVIsYUFBYXFMLEtBQWIsQ0FBbUI2RyxNQUFuQixDQURFO0FBRVJ6UixXQUFPO0FBRkMsR0FuQmlDO0FBdUIzQ2lULGNBQVk7QUFDVmxULFVBQU1xQixNQURJO0FBRVZwQixXQUFPLGtDQUZHO0FBR1ZxQixjQUFVO0FBSEE7QUF2QitCLENBQWpCLENBQXJCOztBQThCQSxJQUFNMEQscUJBQW9CLElBQUl4RixZQUFKLENBQWlCO0FBQ2hEUSxRQUFNO0FBQ0pBLFVBQU1YLE1BREY7QUFFSlksV0FBTyx5REFGSDtBQUdKeUcsbUJBQWUsQ0FBQyxTQUFEO0FBSFgsR0FEMEM7QUFNaERzTSxNQUFJO0FBQ0ZoVCxVQUFNUixhQUFhcUwsS0FBYixDQUFtQnhMLE1BQW5CLEVBQTJCd0IsTUFBM0IsQ0FESjtBQUVGWixXQUFPLDBCQUZMO0FBR0ZpQixjQUFVO0FBSFIsR0FONEM7QUFXaEQ0UixRQUFNO0FBQ0o5UyxVQUFNNEcsS0FERjtBQUVKM0csV0FBTywrTEFGSDtBQUdKaUIsY0FBVTtBQUhOLEdBWDBDO0FBZ0JoRCxZQUFVO0FBQ1JsQixVQUFNYTtBQURFLEdBaEJzQztBQW1CaERvUyxZQUFVO0FBQ1JqVCxVQUFNUixhQUFhcUwsS0FBYixDQUFtQjhHLFdBQW5CLENBREU7QUFFUjFSLFdBQU87QUFGQyxHQW5Cc0M7QUF1QmhEaVQsY0FBWTtBQUNWbFQsVUFBTXFCLE1BREk7QUFFVnBCLFdBQU8sa0NBRkc7QUFHVnFCLGNBQVU7QUFIQTtBQXZCb0MsQ0FBakIsQ0FBMUI7O0FBOEJBLElBQU15RCxrQkFBaUIsSUFBSXZGLFlBQUosQ0FBaUI7QUFDN0NRLFFBQU07QUFDSkEsVUFBTVgsTUFERjtBQUVKWSxXQUFPLHlEQUZIO0FBR0p5RyxtQkFBZSxDQUFDLFNBQUQ7QUFIWCxHQUR1QztBQU03Q3NNLE1BQUk7QUFDRmhULFVBQU1SLGFBQWFxTCxLQUFiLENBQW1CeEwsTUFBbkIsRUFBMkJ3QixNQUEzQixDQURKO0FBRUZaLFdBQU8sMEJBRkw7QUFHRmlCLGNBQVU7QUFIUixHQU55QztBQVc3QzRSLFFBQU07QUFDSjlTLFVBQU00RyxLQURGO0FBRUozRyxXQUFPLCtMQUZIO0FBR0ppQixjQUFVO0FBSE4sR0FYdUM7QUFnQjdDLFlBQVU7QUFDUmxCLFVBQU1hO0FBREUsR0FoQm1DO0FBbUI3Q29TLFlBQVU7QUFDUmpULFVBQU1SLGFBQWFxTCxLQUFiLENBQW1CK0csUUFBbkIsQ0FERTtBQUVSM1IsV0FBTztBQUZDLEdBbkJtQztBQXVCN0NpVCxjQUFZO0FBQ1ZsVCxVQUFNcUIsTUFESTtBQUVWcEIsV0FBTyxrQ0FGRztBQUdWcUIsY0FBVTtBQUhBO0FBdkJpQyxDQUFqQixDQUF2Qjs7QUE4QkEsSUFBTTJELDJCQUEwQixJQUFJekYsWUFBSixDQUFpQjtBQUN0RFEsUUFBTTtBQUNKQSxVQUFNWCxNQURGO0FBRUpZLFdBQU8sMEJBRkg7QUFHSnlHLG1CQUFlLENBQUMsbUJBQUQ7QUFIWCxHQURnRDtBQU10RG9NLFFBQU07QUFDSjlTLFVBQU00RyxLQURGO0FBRUozRyxXQUFPLCtMQUZIO0FBR0ppQixjQUFVO0FBSE4sR0FOZ0Q7QUFXdEQsWUFBVTtBQUNSbEIsVUFBTWE7QUFERSxHQVg0QztBQWN0RHNTLFlBQVU7QUFDUm5ULFVBQU00RyxLQURFO0FBRVIzRyxXQUFPO0FBRkMsR0FkNEM7QUFrQnRELGdCQUFjO0FBQ1pELFVBQU04RSxhQURNO0FBRVo3RSxXQUFPO0FBRks7QUFsQndDLENBQWpCLENBQWhDOztBQXdCQSxJQUFNbVMsZ0NBQStCLElBQUk1UyxZQUFKLENBQWlCO0FBQzNEUSxRQUFNO0FBQ0pBLFVBQU1YLE1BREY7QUFFSlksV0FBTywwQkFGSDtBQUdKeUcsbUJBQWUsQ0FBQyxtQkFBRDtBQUhYLEdBRHFEO0FBTTNEb00sUUFBTTtBQUNKOVMsVUFBTTRHLEtBREY7QUFFSjNHLFdBQU8sK0xBRkg7QUFHSmlCLGNBQVU7QUFITixHQU5xRDtBQVczRCxZQUFVO0FBQ1JsQixVQUFNYTtBQURFLEdBWGlEO0FBYzNEc1MsWUFBVTtBQUNSblQsVUFBTTRHLEtBREU7QUFFUjNHLFdBQU87QUFGQyxHQWRpRDtBQWtCM0QsZ0JBQWM7QUFDWkQsVUFBTWdGLGtCQURNO0FBRVovRSxXQUFPO0FBRks7QUFsQjZDLENBQWpCLENBQXJDOztBQXdCQSxJQUFNb1MsNkJBQTRCLElBQUk3UyxZQUFKLENBQWlCO0FBQ3hEUSxRQUFNO0FBQ0pBLFVBQU1YLE1BREY7QUFFSlksV0FBTywwQkFGSDtBQUdKeUcsbUJBQWUsQ0FBQyxtQkFBRDtBQUhYLEdBRGtEO0FBTXhEb00sUUFBTTtBQUNKOVMsVUFBTTRHLEtBREY7QUFFSjNHLFdBQU8sK0xBRkg7QUFHSmlCLGNBQVU7QUFITixHQU5rRDtBQVd4RCxZQUFVO0FBQ1JsQixVQUFNYTtBQURFLEdBWDhDO0FBY3hEc1MsWUFBVTtBQUNSblQsVUFBTTRHLEtBREU7QUFFUjNHLFdBQU87QUFGQyxHQWQ4QztBQWtCeEQsZ0JBQWM7QUFDWkQsVUFBTStFLGVBRE07QUFFWjlFLFdBQU87QUFGSztBQWxCMEMsQ0FBakIsQ0FBbEMsQzs7Ozs7Ozs7Ozs7OztBQ3RaUCxJQUFJM0IsZ0JBQUo7O0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsUUFBRCxrQkFBUUksQ0FBUixFQUFVO0FBQUNKLGNBQU9JLENBQVA7QUFBUztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFBK0QsSUFBSTRPLGtCQUFKOztBQUFhL08sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHNCQUFSLENBQWIsRUFBNkM7QUFBQzZPLFVBQUQsb0JBQVU1TyxDQUFWLEVBQVk7QUFBQzRPLGdCQUFTNU8sQ0FBVDtBQUFXO0FBQXhCLENBQTdDLEVBQXVFLENBQXZFO0FBQTBFLElBQUk0Uyx1QkFBSjtBQUFtQi9TLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQ0FBUixDQUFiLEVBQWlFO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDNFMscUJBQWU1UyxDQUFmO0FBQWlCO0FBQTdCLENBQWpFLEVBQWdHLENBQWhHO0FBQW1HLElBQUkyVSx1QkFBSjtBQUFtQjlVLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrREFBUixDQUFiLEVBQXlFO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDMlUscUJBQWUzVSxDQUFmO0FBQWlCO0FBQTdCLENBQXpFLEVBQXdHLENBQXhHO0FBQTJHLElBQUk0VSx1QkFBSjtBQUFtQi9VLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrREFBUixDQUFiLEVBQXlFO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDNFUscUJBQWU1VSxDQUFmO0FBQWlCO0FBQTdCLENBQXpFLEVBQXdHLENBQXhHO0FBTXhhLElBQU0rQixPQUFPLFNBQWI7QUFDQSxJQUFNcU8sUUFBUSx5QkFBZDtBQUNBLElBQU1rQyxPQUFVdlEsSUFBVixTQUFrQnFPLEtBQXhCO2lCQUMyQnhCLFM7SUFBbkJpRyxjLGNBQUFBLGM7QUFFUkEsZUFBZUMsUUFBZixHQUEwQi9TLElBQTFCO0FBQ0E4UyxlQUFldkMsSUFBZixHQUFzQkEsSUFBdEI7QUFFQXVDLGVBQWVFLGFBQWYsR0FBK0I7QUFDN0J4QyxTQUQ2QixxQkFDbkI7QUFDUixpQkFBV3hRLElBQVg7QUFDRCxHQUg0QjtBQUk3QmlULE1BSjZCLGdCQUl4QnZELElBSndCLEVBSWxCd0QsR0FKa0IsRUFJYjtBQUNkLFdBQU9OLGVBQWUvQixlQUFlLHFDQUFmLENBQWYsRUFBc0U7QUFDM0VSLGlCQUFXWCxLQUFLekMsT0FBTCxDQUFhak4sSUFBYixDQUFrQmtQLEtBRDhDO0FBRTNFa0IsdUJBQWlCcFEsSUFGMEQ7QUFHM0VnTixvQkFBYzBDLEtBQUtsQyxNQUFMLENBQVksQ0FBWixFQUFlRSxPQUg4QztBQUkzRXlGLGdCQUFVRCxJQUFJRSxPQUFKLENBQVksSUFBWixFQUFrQixFQUFsQjtBQUppRSxLQUF0RSxDQUFQO0FBTUQsR0FYNEI7QUFZN0JDLE1BWjZCLGdCQVl4QjNELElBWndCLEVBWWxCd0QsR0Faa0IsRUFZYjtBQUNkLFFBQU1JLGlCQUFpQkosSUFBSUUsT0FBSixDQUFZLElBQVosRUFBa0IsRUFBbEIsQ0FBdkI7QUFDQSxRQUFJdlYsUUFBTzBWLGFBQVgsRUFBMEJyRyxRQUFRc0csSUFBUiwyQkFBcUNGLGNBQXJDLEVBRlosQ0FFb0U7O0FBQ2xGLFdBQU9ULGVBQWVoQyxlQUFlLG9DQUFmLENBQWYsRUFBcUU7QUFDMUVSLGlCQUFXWCxLQUFLekMsT0FBTCxDQUFhak4sSUFBYixDQUFrQmtQLEtBRDZDO0FBRTFFa0IsdUJBQWlCcFEsSUFGeUQ7QUFHMUVnTixvQkFBYzBDLEtBQUtsQyxNQUFMLENBQVksQ0FBWixFQUFlRSxPQUg2QztBQUkxRXlGLGdCQUFVRztBQUpnRSxLQUFyRSxDQUFQO0FBTUQ7QUFyQjRCLENBQS9CO0FBd0JBUixlQUFlVyxXQUFmLEdBQTZCO0FBQzNCakQsU0FEMkIscUJBQ2pCO0FBQ1IsaUJBQVd4USxJQUFYO0FBQ0QsR0FIMEI7QUFJM0JpVCxNQUoyQixnQkFJdEJ2RCxJQUpzQixFQUloQndELEdBSmdCLEVBSVg7QUFDZCxXQUFPTixlQUFlL0IsZUFBZSxtQ0FBZixDQUFmLEVBQW9FO0FBQ3pFVCx1QkFBaUJwUSxJQUR3RDtBQUV6RXFRLGlCQUFXWCxLQUFLekMsT0FBTCxDQUFhak4sSUFBYixDQUFrQmtQLEtBRjRDO0FBR3pFd0UsaUJBQVdSLElBQUlFLE9BQUosQ0FBWSxJQUFaLEVBQWtCLEVBQWxCO0FBSDhELEtBQXBFLENBQVA7QUFLRCxHQVYwQjtBQVczQkMsTUFYMkIsZ0JBV3RCM0QsSUFYc0IsRUFXaEJ3RCxHQVhnQixFQVdYO0FBQ2QsUUFBTUksaUJBQWlCSixJQUFJRSxPQUFKLENBQVksSUFBWixFQUFrQixFQUFsQixDQUF2QjtBQUNBLFFBQUl2VixRQUFPMFYsYUFBWCxFQUEwQnJHLFFBQVFzRyxJQUFSLHlCQUFtQ0YsY0FBbkMsRUFGWixDQUVrRTs7QUFDaEYsV0FBT1QsZUFBZWhDLGVBQWUsa0NBQWYsQ0FBZixFQUFtRTtBQUN4RVQsdUJBQWlCcFEsSUFEdUQ7QUFFeEVxUSxpQkFBV1gsS0FBS3pDLE9BQUwsQ0FBYWpOLElBQWIsQ0FBa0JrUCxLQUYyQztBQUd4RXdFLGlCQUFXSjtBQUg2RCxLQUFuRSxDQUFQO0FBS0Q7QUFuQjBCLENBQTdCLEM7Ozs7Ozs7Ozs7Ozs7QUN0Q0F4VixPQUFPQyxLQUFQLENBQWFDLFFBQVEsbUJBQVIsQ0FBYjtBQUEyQ0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFNBQVIsQ0FBYjtBQUFpQ0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFNBQVIsQ0FBYjtBQUFpQ0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGtCQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7OztBQ0E3RyxJQUFJSCxnQkFBSjs7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxRQUFELGtCQUFRSSxDQUFSLEVBQVU7QUFBQ0osY0FBT0ksQ0FBUDtBQUFTO0FBQXBCLENBQXRDLEVBQTRELENBQTVEOztBQUErRCxJQUFJNkssOEJBQUo7O0FBQXlCaEwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDhCQUFSLENBQWIsRUFBcUQ7QUFBQzhLLHNCQUFELGdDQUFzQjdLLENBQXRCLEVBQXdCO0FBQUM2Syw0QkFBcUI3SyxDQUFyQjtBQUF1QjtBQUFoRCxDQUFyRCxFQUF1RyxDQUF2RztBQUluRyxJQUFJMFYsZ0JBQWdCO0FBQ2xCQyxZQUFVO0FBQUVDLFdBQU8sRUFBVDtBQUFhQyxZQUFRLEVBQXJCO0FBQXlCQyxnQkFBWTtBQUFyQyxHQURRO0FBRWxCQyxVQUFRO0FBQUVDLGNBQVUsRUFBWjtBQUFnQkgsWUFBUSxFQUF4QjtBQUE0QkMsZ0JBQVk7QUFBeEM7QUFGVSxDQUFwQjs7QUFNQSxJQUFJbFcsUUFBT21GLFFBQVAsSUFBbUJuRixRQUFPbUYsUUFBUCxDQUFnQkMsT0FBbkMsSUFBOENwRixRQUFPbUYsUUFBUCxDQUFnQkMsT0FBaEIsQ0FBd0JpUixLQUExRSxFQUFpRjtBQUMvRVAsa0JBQWdCOVYsUUFBT21GLFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCaVIsS0FBeEM7QUFDRDs7QUFFRCxJQUFJUCxhQUFKLEVBQW1CO0FBQ2pCL1MsU0FBT3VULElBQVAsQ0FBWVIsYUFBWixFQUEyQmhRLE9BQTNCLENBQW1DLFVBQUN1RixPQUFELEVBQWE7QUFDOUNKLDBCQUFxQkssY0FBckIsQ0FBb0NpTCxNQUFwQyxDQUNFO0FBQUVsTDtBQUFGLEtBREYsRUFFRTtBQUFFcEgsWUFBTTZSLGNBQWN6SyxPQUFkO0FBQVIsS0FGRjtBQUlELEdBTEQ7QUFNRCxDOzs7Ozs7Ozs7Ozs7O0FDckJELElBQUkyRCxrQkFBSjs7QUFBYS9PLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEVBQTZDO0FBQUM2TyxVQUFELG9CQUFVNU8sQ0FBVixFQUFZO0FBQUM0TyxnQkFBUzVPLENBQVQ7QUFBVztBQUF4QixDQUE3QyxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJb1cseUJBQUo7QUFBcUJ2VyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsOENBQVIsQ0FBYixFQUFxRTtBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQ29XLHVCQUFpQnBXLENBQWpCO0FBQW1CO0FBQS9CLENBQXJFLEVBQXNHLENBQXRHOztBQUc1RzRPLFVBQVN5SCxZQUFULENBQXNCLFVBQUNwRyxPQUFELEVBQVV3QixJQUFWLEVBQW1CO0FBQ3ZDLE1BQU02RSxlQUFlN0UsSUFBckI7O0FBRUEsTUFBSSxDQUFDNkUsYUFBYXhFLEtBQWxCLEVBQXlCO0FBQ3ZCd0UsaUJBQWF4RSxLQUFiLEdBQXFCLENBQUMsV0FBRCxDQUFyQjtBQUNELEdBRkQsTUFFTztBQUNMd0UsaUJBQWF4RSxLQUFiLENBQW1CM0csSUFBbkIsQ0FBd0IsV0FBeEI7QUFDRDs7QUFDRCxNQUFJOEUsUUFBUWpCLE9BQVosRUFBcUJzSCxhQUFhdEgsT0FBYixHQUF1QmlCLFFBQVFqQixPQUEvQjtBQUNyQnNILGVBQWE3VCxPQUFiLEdBQXVCLElBQXZCO0FBRUEyVCxtQkFBaUJuRyxPQUFqQixFQUEwQndCLElBQTFCO0FBQ0EsU0FBTzZFLFlBQVA7QUFDRCxDQWJELEU7Ozs7Ozs7Ozs7Ozs7QUNIQSxJQUFJMVcsZ0JBQUo7O0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsUUFBRCxrQkFBUUksQ0FBUixFQUFVO0FBQUNKLGNBQU9JLENBQVA7QUFBUztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFBK0QsSUFBSWtRLGVBQUo7O0FBQVVyUSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDbVEsT0FBRCxpQkFBT2xRLENBQVAsRUFBUztBQUFDa1EsYUFBTWxRLENBQU47QUFBUTtBQUFsQixDQUE5QyxFQUFrRSxDQUFsRTs7QUFBcUUsSUFBSXVXLFdBQUo7O0FBQU0xVyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsbUJBQVIsQ0FBYixFQUEwQztBQUFDd1csR0FBRCxhQUFHdlcsQ0FBSCxFQUFLO0FBQUN1VyxTQUFFdlcsQ0FBRjtBQUFJO0FBQVYsQ0FBMUMsRUFBc0QsQ0FBdEQ7O0FBSy9KO0FBQ0E7QUFDQTtBQUVBLElBQU13VyxpQkFBaUIsU0FBakJBLGNBQWlCLEdBQU07QUFDM0IsTUFBTWxILFFBQVExUCxRQUFPMFAsS0FBUCxDQUFhaFAsSUFBYixDQUFrQixFQUFsQixFQUFzQjtBQUFFd1IsV0FBTztBQUFULEdBQXRCLEVBQW9DdEMsS0FBcEMsRUFBZDs7QUFDQSxNQUFJc0MsUUFBUSxFQUFaO0FBQ0F4QyxRQUFNNUosT0FBTixDQUFjO0FBQUEsV0FBU29NLFFBQVF5RSxHQUFFRSxJQUFGLENBQU8zRSxNQUFNNEUsTUFBTixDQUFhakYsS0FBS0ssS0FBbEIsQ0FBUCxDQUFqQjtBQUFBLEdBQWQ7QUFDQUEsUUFBTTZFLEdBQU4sQ0FBVTtBQUFBLFdBQVMsQ0FBQy9XLFFBQU9rUyxLQUFQLENBQWFsSSxPQUFiLENBQXFCO0FBQUU3SDtBQUFGLEtBQXJCLENBQUQsR0FBa0NtTyxPQUFNMEcsVUFBTixDQUFpQjdVLElBQWpCLENBQWxDLEdBQTJELElBQXBFO0FBQUEsR0FBVjtBQUNELENBTEQ7O0FBT0F5VTs7QUFFQTVXLFFBQU8wUCxLQUFQLENBQWFoUCxJQUFiLENBQWtCLEVBQWxCLEVBQXNCdVcsT0FBdEIsQ0FBOEI7QUFDNUJDLE9BRDRCLG1CQUNwQjtBQUFFTjtBQUFtQjtBQURELENBQTlCLEU7Ozs7Ozs7Ozs7Ozs7QUNsQkEzVyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNEJBQVIsQ0FBYjtBQUFvREYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdDQUFSLENBQWI7QUFBZ0VGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw0QkFBUixDQUFiO0FBQW9ERixPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0NBQVIsQ0FBYjtBQUFnRUYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWI7QUFBZ0RGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxvQ0FBUixDQUFiO0FBQTRERixPQUFPQyxLQUFQLENBQWFDLFFBQVEsNEJBQVIsQ0FBYjtBQUFvREYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdDQUFSLENBQWI7QUFBZ0VGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiO0FBQXFERixPQUFPQyxLQUFQLENBQWFDLFFBQVEseUNBQVIsQ0FBYjtBQUFpRUYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGdDQUFSLENBQWI7QUFBd0RGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxxQ0FBUixDQUFiO0FBQTZERixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZ0NBQVIsQ0FBYjtBQUF3REYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGtDQUFSLENBQWI7QUFBMERGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxnREFBUixDQUFiLEU7Ozs7Ozs7Ozs7Ozs7QUNBcnlCLElBQUlILGdCQUFKOztBQUFXQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNILFFBQUQsa0JBQVFJLENBQVIsRUFBVTtBQUFDSixjQUFPSSxDQUFQO0FBQVM7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFFWCxJQUFJSixRQUFPMFYsYUFBWCxFQUEwQnlCLFFBQVFDLEdBQVIsQ0FBWUMsUUFBWixHQUF1QnJYLFFBQU9tRixRQUFQLENBQWdCQyxPQUFoQixDQUF3QmdTLEdBQXhCLENBQTRCQyxRQUFuRCxDOzs7Ozs7Ozs7Ozs7O0FDRjFCLElBQUlDLGVBQUo7QUFBV3JYLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEVBQTZDO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDa1gsYUFBT2xYLENBQVA7QUFBUztBQUFyQixDQUE3QyxFQUFvRSxDQUFwRTs7QUFBdUUsSUFBSUosZ0JBQUo7O0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsUUFBRCxrQkFBUUksQ0FBUixFQUFVO0FBQUNKLGNBQU9JLENBQVA7QUFBUztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJbVgsY0FBSjtBQUFVdFgsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE9BQVIsQ0FBYixFQUE4QjtBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQ21YLFlBQU1uWCxDQUFOO0FBQVE7QUFBcEIsQ0FBOUIsRUFBb0QsQ0FBcEQ7QUFBdUQsSUFBSTJNLGlCQUFKO0FBQWE5TSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQzJNLGVBQVMzTSxDQUFUO0FBQVc7QUFBdkIsQ0FBcEQsRUFBNkUsQ0FBN0U7QUFBZ0YsSUFBSThGLGlCQUFKO0FBQWFqRyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQzhGLGVBQVM5RixDQUFUO0FBQVc7QUFBdkIsQ0FBcEQsRUFBNkUsQ0FBN0U7QUFBZ0YsSUFBSXVOLGFBQUo7QUFBUzFOLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxxQkFBUixDQUFiLEVBQTRDO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDdU4sV0FBS3ZOLENBQUw7QUFBTztBQUFuQixDQUE1QyxFQUFpRSxDQUFqRTtBQUFvRSxJQUFJcUwsaUJBQUo7QUFBYXhMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDcUwsZUFBU3JMLENBQVQ7QUFBVztBQUF2QixDQUFwRCxFQUE2RSxDQUE3RTtBQUFnRixJQUFJRSxrQkFBSjtBQUFjTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsK0JBQVIsQ0FBYixFQUFzRDtBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQ0UsZ0JBQVVGLENBQVY7QUFBWTtBQUF4QixDQUF0RCxFQUFnRixDQUFoRjs7QUFVL2tCLElBQU1vWCxjQUFjLFNBQWRBLFdBQWMsQ0FBQzVXLE1BQUQsRUFBWTtBQUM5QixNQUFNNlcsYUFBYSxFQUFuQjs7QUFDQSxPQUFLLElBQUlsRCxJQUFJLENBQWIsRUFBZ0JBLElBQUksQ0FBcEIsRUFBdUJBLEtBQUssQ0FBNUIsRUFBK0I7QUFDN0IsUUFBSUEsTUFBTSxDQUFWLEVBQWE7QUFDWGtELGlCQUFXbE0sSUFBWCxDQUFnQjtBQUNkNUssZUFBT0MsTUFETztBQUVkdUIsY0FBTSxpQkFGUTtBQUdkNkwsaUJBQVMsT0FISztBQUlkNUwsZUFBTyxDQUpPO0FBS2RDLDRCQUFvQixLQUxOO0FBTWRpTSwwQkFBbUIsSUFBSXZNLElBQUosRUFBRCxDQUFhQyxXQUFiLEVBTko7QUFPZHVNLHNCQUFjLEtBUEE7QUFRZDVMLGdCQUFRLENBUk07QUFTZHdILDBCQUFrQjtBQUNoQjhELDJCQUFpQixDQUREO0FBRWhCQywwQkFBZ0IsQ0FGQTtBQUdoQkMsK0JBQXFCLENBSEw7QUFJaEJDLCtCQUFxQixDQUpMO0FBS2hCQyx3QkFBYztBQUxFO0FBVEosT0FBaEI7QUFpQkQ7O0FBQ0RvSixlQUFXbE0sSUFBWCxDQUFnQjtBQUNkNUssYUFBT0MsTUFETztBQUVkdUIsWUFBTW9WLE1BQU1HLFFBQU4sQ0FBZUMsV0FBZixFQUZRO0FBR2QzSixlQUFTdUosTUFBTUssTUFBTixDQUFhQyxZQUFiLENBQTBCLENBQUMsT0FBRCxFQUFVLGFBQVYsQ0FBMUIsQ0FISztBQUlkelYsYUFBT21WLE1BQU1HLFFBQU4sQ0FBZUksZ0JBQWYsRUFKTztBQUtkelYsMEJBQW9Ca1YsTUFBTUssTUFBTixDQUFhRyxNQUFiLEVBTE47QUFNZHpKLHdCQUFrQmlKLE1BQU1TLElBQU4sQ0FBV0MsSUFBWCxHQUFrQmpXLFdBQWxCLEVBTko7QUFPZHVNLG9CQUFjZ0osTUFBTUssTUFBTixDQUFhRyxNQUFiLEVBUEE7QUFRZHBWLGNBQVE0VSxNQUFNSyxNQUFOLENBQWFHLE1BQWIsQ0FBb0I7QUFBRXZWLGFBQUssQ0FBUDtBQUFVMkUsYUFBSztBQUFmLE9BQXBCLENBUk07QUFTZGdELHdCQUFrQjtBQUNoQjhELHlCQUFpQnNKLE1BQU1LLE1BQU4sQ0FBYUcsTUFBYixDQUFvQjtBQUFFdlYsZUFBSyxDQUFQO0FBQVUyRSxlQUFLO0FBQWYsU0FBcEIsQ0FERDtBQUVoQitHLHdCQUFnQnFKLE1BQU1LLE1BQU4sQ0FBYUcsTUFBYixDQUFvQjtBQUFFdlYsZUFBSyxDQUFQO0FBQVUyRSxlQUFLO0FBQWYsU0FBcEIsQ0FGQTtBQUdoQmdILDZCQUFxQm9KLE1BQU1LLE1BQU4sQ0FBYUcsTUFBYixDQUFvQjtBQUFFdlYsZUFBSyxDQUFQO0FBQVUyRSxlQUFLO0FBQWYsU0FBcEIsQ0FITDtBQUloQmlILDZCQUFxQm1KLE1BQU1LLE1BQU4sQ0FBYUcsTUFBYixDQUFvQjtBQUFFdlYsZUFBSyxDQUFQO0FBQVUyRSxlQUFLO0FBQWYsU0FBcEIsQ0FKTDtBQUtoQmtILHNCQUFja0osTUFBTUssTUFBTixDQUFhRyxNQUFiLENBQW9CO0FBQUV2VixlQUFLLENBQVA7QUFBVTJFLGVBQUs7QUFBZixTQUFwQjtBQUxFO0FBVEosS0FBaEI7QUFpQkQ7O0FBQ0QsU0FBT3NRLFVBQVA7QUFDRCxDQXpDRDs7QUE0Q0EsSUFBTVMsZ0JBQWdCLFNBQWhCQSxhQUFnQixDQUFDdFgsTUFBRCxFQUFZO0FBQ2hDLE1BQU11WCxnQkFBZ0IsRUFBdEI7O0FBQ0EsT0FBSyxJQUFJNUQsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLENBQXBCLEVBQXVCQSxLQUFLLENBQTVCLEVBQStCO0FBQzdCLFFBQUlBLE1BQU0sQ0FBVixFQUFhO0FBQ1g0RCxvQkFBYzVNLElBQWQsQ0FBbUI7QUFDakI1SyxlQUFPQyxNQURVO0FBRWpCdUIsY0FBTSxNQUZXO0FBR2pCRSw0QkFBb0IsS0FISDtBQUlqQkQsZUFBTyxRQUpVO0FBS2pCTyxnQkFBUSxHQUxTO0FBTWpCMEoscUJBQWEsUUFOSTtBQU9qQkMsMEJBQWtCO0FBQ2hCTix1QkFBYSxFQURHO0FBRWhCQyx1QkFBYSxJQUZHO0FBR2hCQyx3QkFBYyxJQUhFO0FBSWhCQyxzQkFBWSxJQUpJO0FBS2hCQyx1QkFBYTtBQUxHO0FBUEQsT0FBbkI7QUFlRDs7QUFDRCtMLGtCQUFjNU0sSUFBZCxDQUFtQjtBQUNqQjVLLGFBQU9DLE1BRFU7QUFFakJ1QixZQUFNb1YsTUFBTUcsUUFBTixDQUFlQyxXQUFmLEVBRlc7QUFHakJ0ViwwQkFBb0JrVixNQUFNSyxNQUFOLENBQWFHLE1BQWIsRUFISDtBQUlqQjNWLGFBQU9tVixNQUFNRyxRQUFOLENBQWVJLGdCQUFmLEVBSlU7QUFLakJuVixjQUFRNFUsTUFBTUssTUFBTixDQUFhRyxNQUFiLENBQW9CO0FBQUV2VixhQUFLLENBQVA7QUFBVTJFLGFBQUs7QUFBZixPQUFwQixDQUxTO0FBTWpCa0YsbUJBQWEsUUFOSTtBQU9qQkMsd0JBQWtCO0FBQ2hCTixxQkFBYXVMLE1BQU1LLE1BQU4sQ0FBYUcsTUFBYixDQUFvQjtBQUFFdlYsZUFBSyxDQUFQO0FBQVUyRSxlQUFLO0FBQWYsU0FBcEIsQ0FERztBQUVoQjhFLHFCQUFhc0wsTUFBTUssTUFBTixDQUFhRyxNQUFiLENBQW9CO0FBQUV2VixlQUFLLENBQVA7QUFBVTJFLGVBQUs7QUFBZixTQUFwQixDQUZHO0FBR2hCK0Usc0JBQWNxTCxNQUFNSyxNQUFOLENBQWFHLE1BQWIsQ0FBb0I7QUFBRXZWLGVBQUssQ0FBUDtBQUFVMkUsZUFBSztBQUFmLFNBQXBCLENBSEU7QUFJaEJnRixvQkFBWW9MLE1BQU1LLE1BQU4sQ0FBYUcsTUFBYixDQUFvQjtBQUFFdlYsZUFBSyxHQUFQO0FBQVkyRSxlQUFLO0FBQWpCLFNBQXBCLENBSkk7QUFLaEJpRixxQkFBYW1MLE1BQU1LLE1BQU4sQ0FBYUcsTUFBYixDQUFvQjtBQUFFdlYsZUFBSyxHQUFQO0FBQVkyRSxlQUFLO0FBQWpCLFNBQXBCO0FBTEc7QUFQRCxLQUFuQjtBQWVEOztBQUNELFNBQU9nUixhQUFQO0FBQ0QsQ0FyQ0Q7O0FBdUNBLElBQU1DLGdCQUFnQixTQUFoQkEsYUFBZ0IsQ0FBQ3hYLE1BQUQsRUFBWTtBQUNoQyxNQUFNeVgsa0JBQWtCLEVBQXhCOztBQUNBLE9BQUssSUFBSTlELElBQUksQ0FBYixFQUFnQkEsSUFBSSxDQUFwQixFQUF1QkEsS0FBSyxDQUE1QixFQUErQjtBQUM3QjhELG9CQUFnQjlNLElBQWhCLENBQXFCO0FBQ25CNUssYUFBT0MsTUFEWTtBQUVuQnVCLFlBQU1vVixNQUFNRyxRQUFOLENBQWVDLFdBQWYsRUFGYTtBQUduQnZWLGFBQU9tVixNQUFNRyxRQUFOLENBQWVJLGdCQUFmLEVBSFk7QUFJbkJ6ViwwQkFBb0JrVixNQUFNSyxNQUFOLENBQWFHLE1BQWIsRUFKRDtBQUtuQnpWLGVBQVNpVixNQUFNSyxNQUFOLENBQWFHLE1BQWIsQ0FBb0I7QUFBRXZWLGFBQUssQ0FBUDtBQUFVMkUsYUFBSztBQUFmLE9BQXBCLENBTFU7QUFNbkIxRSxrQkFBWThVLE1BQU1LLE1BQU4sQ0FBYUcsTUFBYixDQUFvQjtBQUFFdlYsYUFBSyxDQUFQO0FBQVUyRSxhQUFLO0FBQWYsT0FBcEIsQ0FOTztBQU9uQnhFLGNBQVE0VSxNQUFNSyxNQUFOLENBQWFHLE1BQWIsQ0FBb0I7QUFBRXZWLGFBQUssQ0FBUDtBQUFVMkUsYUFBSztBQUFmLE9BQXBCO0FBUFcsS0FBckI7QUFTRDs7QUFDRCxTQUFPa1IsZUFBUDtBQUNELENBZEQ7O0FBZ0JBLElBQU1DLGVBQWUsU0FBZkEsWUFBZSxDQUFDMVgsTUFBRCxFQUFTd0YsU0FBVCxFQUFvQm1TLGVBQXBCO0FBQUEsU0FBeUM7QUFDNURDLGdCQUFZdFMsUUFEZ0Q7QUFFNUR1UyxrQkFBYyxDQUFDLGFBQUQsRUFBZ0IsU0FBaEIsRUFBMkIsWUFBM0IsQ0FGOEM7QUFHNURDLGFBQVMsSUFIbUQ7QUFJNURDLGdCQUFZLENBSmdEO0FBSzVEdlcsU0FMNEQsaUJBS3REd1csU0FMc0QsRUFLM0NyQixLQUwyQyxFQUtwQztBQUN0QixhQUFPO0FBQ0w1VyxlQUFPQyxNQURGO0FBRUx5RixpQkFBU0QsU0FGSjtBQUdMakUsNkJBQWtCeVcsWUFBWSxDQUE5QixDQUhLO0FBSUw1USwrREFBb0Q0USxZQUFZLENBQWhFLENBSks7QUFLTDNRLGFBQUtzUCxNQUFNSyxNQUFOLENBQWFDLFlBQWIsQ0FBMEJVLGdCQUFnQk0sT0FBMUMsQ0FMQTtBQU1MM1EsaUJBQVNxUCxNQUFNSyxNQUFOLENBQWFDLFlBQWIsQ0FBMEJVLGdCQUFnQk8sVUFBMUMsQ0FOSjtBQU9MM1EscUJBQWFvUCxNQUFNSyxNQUFOLENBQWFDLFlBQWIsQ0FBMEIsQ0FBQyxjQUFELEVBQWlCLGFBQWpCLENBQTFCO0FBUFIsT0FBUDtBQVNEO0FBZjJELEdBQXpDO0FBQUEsQ0FBckI7O0FBbUJBLElBQU1rQixlQUFlLFNBQWZBLFlBQWUsQ0FBQ25ZLE1BQUQsRUFBUzJYLGVBQVQ7QUFBQSxTQUE4QjtBQUNqREMsZ0JBQVl6TCxRQURxQztBQUVqRDBMLGtCQUFjLENBQUMsYUFBRCxFQUFnQixTQUFoQixDQUZtQztBQUdqREMsYUFBUyxJQUh3QztBQUlqREMsZ0JBQVksQ0FKcUM7QUFLakR2VyxTQUxpRCxpQkFLM0N3VyxTQUwyQyxFQUtoQ3JCLEtBTGdDLEVBS3pCO0FBQ3RCLGFBQU87QUFDTDVXLGVBQU9DLE1BREY7QUFFTHVCLDZCQUFrQnlXLFlBQVksQ0FBOUIsQ0FGSztBQUdMNVEsK0RBQW9ENFEsWUFBWSxDQUFoRSxDQUhLO0FBSUwxTCxxQkFBYTtBQUNYeEwsZ0JBQU0sU0FESztBQUVYaVQsb0JBQVU7QUFDUmpULGtCQUFNLE9BREU7QUFFUnNTLHlCQUFhLENBQUN1RCxNQUFNMUgsT0FBTixDQUFjbUosU0FBZCxFQUFELEVBQTRCekIsTUFBTTFILE9BQU4sQ0FBY29KLFFBQWQsRUFBNUI7QUFGTCxXQUZDO0FBTVhyRSxzQkFBWTtBQUFFc0Usa0JBQU0zQixNQUFNSyxNQUFOLENBQWFHLE1BQWIsQ0FBb0I7QUFBRXZWLG1CQUFLLENBQVA7QUFBVTJFLG1CQUFLO0FBQWYsYUFBcEI7QUFBUjtBQU5ELFNBSlI7QUFZTGdTLFlBWkssZ0JBWUEvUyxTQVpBLEVBWVc7QUFDZCxpQkFBT2tTLGFBQWExWCxNQUFiLEVBQXFCd0YsU0FBckIsRUFBZ0NtUyxlQUFoQyxDQUFQO0FBQ0Q7QUFkSSxPQUFQO0FBZ0JEO0FBdEJnRCxHQUE5QjtBQUFBLENBQXJCOztBQXlCQSxJQUFNYSxrQkFBa0IsU0FBbEJBLGVBQWtCLENBQUN4WSxNQUFELEVBQVk7QUFDbEMsTUFBTXlZLG1CQUFtQjtBQUN2QlIsYUFBUyxFQURjO0FBRXZCQyxnQkFBWTtBQUZXLEdBQXpCO0FBSUF0QixjQUFZNVcsTUFBWixFQUFvQmtGLE9BQXBCLENBQTRCLFVBQUNtQyxHQUFELEVBQVM7QUFDbkMsUUFBTXFSLFFBQVEzTCxLQUFLdE0sTUFBTCxDQUFZNEcsR0FBWixDQUFkO0FBQ0FvUixxQkFBaUJSLE9BQWpCLENBQXlCdE4sSUFBekIsQ0FBOEIrTixLQUE5QjtBQUNELEdBSEQ7QUFJQXBCLGdCQUFjdFgsTUFBZCxFQUFzQmtGLE9BQXRCLENBQThCLFVBQUN5VCxNQUFELEVBQVk7QUFDeEMsUUFBTUMsWUFBWS9OLFNBQVNwSyxNQUFULENBQWdCa1ksTUFBaEIsQ0FBbEI7QUFDQUYscUJBQWlCUCxVQUFqQixDQUE0QnZOLElBQTVCLENBQWlDaU8sU0FBakM7QUFDRCxHQUhEO0FBSUFwQixnQkFBY3hYLE1BQWQsRUFBc0JrRixPQUF0QixDQUE4QixVQUFDcEMsT0FBRCxFQUFhO0FBQ3pDcEQsY0FBVWUsTUFBVixDQUFpQnFDLE9BQWpCO0FBQ0QsR0FGRDtBQUdBLFNBQU8yVixnQkFBUDtBQUNELENBakJEOztBQW1CQS9CLE9BQU90WCxRQUFPMFAsS0FBZCxFQUFxQjtBQUNuQitJLGdCQUFjLENBQUMsYUFBRCxFQUFnQixTQUFoQixDQURLO0FBRW5CQyxXQUFTLElBRlU7QUFHbkJTLFFBQU0sQ0FBQztBQUNMM0ksV0FBTyxpQkFERjtBQUVMSSxjQUFVLFVBRkw7QUFHTHhCLGFBQVM7QUFDUGpOLFlBQU07QUFDSmtQLGVBQU8sT0FESDtBQUVKQyxjQUFNO0FBRkY7QUFEQyxLQUhKO0FBU0xZLFdBQU8sQ0FBQyxPQUFELENBVEY7QUFVTGlILFFBVkssZ0JBVUF2WSxNQVZBLEVBVVE7QUFDWCxVQUFNNlksY0FBY0wsZ0JBQWdCeFksTUFBaEIsQ0FBcEI7QUFDQSxhQUFPbVksYUFBYW5ZLE1BQWIsRUFBcUI2WSxXQUFyQixDQUFQO0FBQ0Q7QUFiSSxHQUFELENBSGE7QUFrQm5CZCxjQUFZLENBbEJPO0FBbUJuQnZXLE9BbkJtQixpQkFtQmJzWCxLQW5CYSxFQW1CTm5DLEtBbkJNLEVBbUJDO0FBQ2xCLFFBQU1vQyxZQUFZRCxRQUFRLENBQTFCO0FBQ0EsV0FBTztBQUNMbEosdUJBQWVtSixTQUFmLGNBREs7QUFFTC9JLGdCQUFVLFVBRkw7QUFHTHhCLGVBQVM7QUFDUGpOLGNBQU07QUFDSmtQLGlCQUFPa0csTUFBTXBWLElBQU4sQ0FBV3FRLFNBQVgsRUFESDtBQUVKbEIsZ0JBQU1pRyxNQUFNcFYsSUFBTixDQUFXeVgsUUFBWDtBQUZGO0FBREMsT0FISjtBQVNMMUgsYUFBTyxDQUFDLFdBQUQsQ0FURjtBQVVMaUgsVUFWSyxnQkFVQXZZLE1BVkEsRUFVUTtBQUNYLFlBQU02WSxjQUFjTCxnQkFBZ0J4WSxNQUFoQixDQUFwQjtBQUNBLGVBQU9tWSxhQUFhblksTUFBYixFQUFxQjZZLFdBQXJCLENBQVA7QUFDRDtBQWJJLEtBQVA7QUFlRDtBQXBDa0IsQ0FBckI7O0FBdUNBLElBQUksQ0FBQ3paLFFBQU82WixZQUFaLEVBQTBCO0FBQ3hCLE1BQU1DLGFBQWE5WixRQUFPMFAsS0FBUCxDQUFhMUYsT0FBYixDQUFxQjtBQUFFLHdCQUFvQjtBQUF0QixHQUFyQixDQUFuQjs7QUFFQSxNQUFJLENBQUM4UCxXQUFXbkssTUFBWCxDQUFrQixDQUFsQixFQUFxQm9LLFFBQTFCLEVBQW9DO0FBQ2xDL1osWUFBTzBQLEtBQVAsQ0FBYXBPLE1BQWIsQ0FDRTtBQUFFTixXQUFLOFksV0FBVzlZO0FBQWxCLEtBREYsRUFFRTtBQUFFaUQsWUFBTTtBQUFFLDZCQUFxQjtBQUF2QjtBQUFSLEtBRkY7QUFJRDtBQUNGLEM7Ozs7Ozs7Ozs7Ozs7QUM1TkRoRSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsWUFBUixDQUFiO0FBQW9DRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsT0FBUixDQUFiO0FBQStCRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsWUFBUixDQUFiO0FBQW9DRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEU7Ozs7Ozs7Ozs7Ozs7QUNBdkdGLE9BQU9rVCxNQUFQLENBQWM7QUFBQ3hLLDZCQUEwQjtBQUFBLFdBQUlBLDBCQUFKO0FBQUEsR0FBM0I7QUFBeURxUixxQkFBa0I7QUFBQSxXQUFJQSxrQkFBSjtBQUFBLEdBQTNFO0FBQWlHclYsZUFBWTtBQUFBLFdBQUlBLFlBQUo7QUFBQSxHQUE3RztBQUE2SHNWLDRCQUF5QjtBQUFBLFdBQUlBLHlCQUFKO0FBQUEsR0FBdEo7QUFBbUx2VixjQUFXO0FBQUEsV0FBSUEsV0FBSjtBQUFBLEdBQTlMO0FBQTZNRCxzQkFBbUI7QUFBQSxXQUFJQSxtQkFBSjtBQUFBLEdBQWhPO0FBQXVQeVYsbUJBQWdCO0FBQUEsV0FBSUEsZ0JBQUo7QUFBQSxHQUF2UTtBQUEyUkMsaUJBQWM7QUFBQSxXQUFJQSxjQUFKO0FBQUEsR0FBelM7QUFBMlRDLGVBQVk7QUFBQSxXQUFJQSxZQUFKO0FBQUE7QUFBdlUsQ0FBZDs7QUFDQSw2RixDQUNBLDhGLENBQ0EsNkZBR0EsSUFBTTVWLEtBQUtyRSxRQUFRLElBQVIsQ0FBWCxDLENBQ0E7OztlQUNrQkEsUUFBUSxlQUFSLEM7SUFBVmthLEssWUFBQUEsSzs7QUFDUixJQUFNOVYsT0FBT3BFLFFBQVEsTUFBUixDQUFiLEMsQ0FFQTtBQUVBOzs7Ozs7OztBQVFBLElBQU02WixxQkFBb0IsU0FBcEJBLGtCQUFvQixDQUFDTSxHQUFELEVBQU12VixRQUFOLEVBQW1CO0FBQzNDLE1BQU13VixXQUFXRCxJQUFJRSxNQUFKLENBQVdGLElBQUloRyxNQUFKLEdBQWEsQ0FBeEIsQ0FBakI7QUFDQSxNQUFJbUcsUUFBUSxFQUFaO0FBQ0EsTUFBSUYsYUFBYSxHQUFqQixFQUFzQkUsUUFBUSxHQUFSO0FBQ3RCLFNBQU9ILE1BQU1HLEtBQU4sR0FBYzFWLFFBQXJCO0FBQ0QsQ0FMRCxDLENBT0E7Ozs7Ozs7O0FBT0EsSUFBSTJWLGVBQWUsQ0FBbkI7QUFDQSxJQUFNQyxrQkFBa0IsQ0FBeEI7O0FBQ0EsSUFBTWhTLDZCQUE0QixTQUE1QkEsMEJBQTRCLENBQUNpUyxPQUFELEVBQVVDLElBQVYsRUFBbUI7QUFDbkQsTUFBSUMsUUFBUSxFQUFaOztBQUNBLE1BQUl0VyxHQUFHb0IsVUFBSCxDQUFjZ1YsT0FBZCxDQUFKLEVBQTRCO0FBQzFCRSxZQUFRdFcsR0FBR3VXLFdBQUgsQ0FBZUgsT0FBZixDQUFSO0FBQ0FFLFVBQU1oVixPQUFOLENBQWMsVUFBQ2tWLElBQUQsRUFBVTtBQUN0QixVQUFNQyxVQUFVakIsbUJBQWtCWSxPQUFsQixFQUEyQkksSUFBM0IsQ0FBaEI7O0FBQ0EsVUFBSXhXLEdBQUcwVyxTQUFILENBQWFELE9BQWIsRUFBc0JFLFdBQXRCLEVBQUosRUFBeUM7QUFBRTtBQUN6Q3hTLG1DQUEwQnNTLE9BQTFCLEVBQW1DLEtBQW5DO0FBQ0QsT0FGRCxNQUVPO0FBQUU7QUFDUFAsd0JBQWdCLENBQWhCO0FBQ0FsVyxXQUFHNFcsVUFBSCxDQUFjSCxPQUFkO0FBQ0Q7QUFDRixLQVJEO0FBU0Q7O0FBQ0QsTUFBSSxDQUFDSixJQUFMLEVBQVc7QUFDVHJXLE9BQUc2VyxTQUFILENBQWFULE9BQWI7QUFDRCxHQUZELE1BRU87QUFDTCxXQUFPO0FBQUVGLGdDQUFGO0FBQWdCWSxlQUFTWDtBQUF6QixLQUFQO0FBQ0Q7QUFDRixDQW5CRCxDLENBc0JBOzs7Ozs7QUFLQSxJQUFNaFcsZUFBYyxTQUFkQSxZQUFjLENBQUNpVyxPQUFELEVBQVVXLFFBQVYsRUFBdUI7QUFDekMsTUFBTUMsV0FBVyxFQUFqQixDQUR5QyxDQUV6Qzs7QUFDQWhYLEtBQUdpWCxPQUFILENBQVdiLE9BQVgsRUFBb0IsVUFBQ2MsR0FBRCxFQUFNWixLQUFOLEVBQWdCO0FBQ2xDQSxVQUFNaFYsT0FBTixDQUFjLFVBQUNrVixJQUFELEVBQVU7QUFDdEJRLGVBQVNqUSxJQUFULENBQWN5UCxJQUFkO0FBQ0QsS0FGRDtBQUdBTyxhQUFTQyxRQUFULEVBSmtDLENBS2xDO0FBQ0QsR0FORCxFQUh5QyxDQVV6QztBQUNELENBWEQsQyxDQWFBOzs7Ozs7OztBQU9BLElBQU12Qiw0QkFBMkIsU0FBM0JBLHlCQUEyQixDQUFDSyxHQUFELEVBQU1xQixTQUFOLEVBQWlCSixRQUFqQixFQUE4QjtBQUM3RCxNQUFNQyxXQUFXLEVBQWpCO0FBQ0EsTUFBTUksS0FBSyxJQUFJQyxNQUFKLENBQVdGLFNBQVgsRUFBc0IsR0FBdEIsQ0FBWDtBQUNBLE1BQU1HLGtCQUFrQkgsVUFBVXJILE1BQWxDO0FBQ0E5UCxLQUFHaVgsT0FBSCxDQUFXbkIsR0FBWCxFQUFnQixVQUFDb0IsR0FBRCxFQUFNWixLQUFOLEVBQWdCO0FBQzlCQSxVQUNHaUIsTUFESCxDQUNVO0FBQUEsYUFBUWYsS0FBS1IsTUFBTCxDQUFZLENBQUNzQixlQUFiLEVBQThCRSxLQUE5QixDQUFvQ0osRUFBcEMsQ0FBUjtBQUFBLEtBRFYsRUFFRzlWLE9BRkgsQ0FFVyxVQUFDa1YsSUFBRCxFQUFVO0FBQ2pCUSxlQUFTalEsSUFBVCxDQUFjeVAsSUFBZDtBQUNELEtBSkg7QUFLQU8sYUFBU0MsUUFBVDtBQUNELEdBUEQ7QUFRRCxDQVpELEMsQ0FjQTs7Ozs7Ozs7QUFPQSxJQUFNUyx3QkFBd0IsU0FBeEJBLHFCQUF3QixDQUFDM0IsR0FBRCxFQUFNNEIsTUFBTixFQUFjWCxRQUFkLEVBQTJCO0FBQ3ZELE1BQU1DLFdBQVcsRUFBakI7QUFDQSxNQUFNSSxLQUFLLElBQUlDLE1BQUosQ0FBV0ssTUFBWCxFQUFtQixHQUFuQixDQUFYO0FBQ0EsTUFBTUMsZUFBZUQsT0FBTzVILE1BQTVCO0FBQ0E5UCxLQUFHaVgsT0FBSCxDQUFXbkIsR0FBWCxFQUFnQixVQUFDb0IsR0FBRCxFQUFNWixLQUFOLEVBQWdCO0FBQzlCQSxVQUNHaUIsTUFESCxDQUNVO0FBQUEsYUFBUWYsS0FBS1IsTUFBTCxDQUFZLENBQVosRUFBZTJCLFlBQWYsRUFBNkJILEtBQTdCLENBQW1DSixFQUFuQyxDQUFSO0FBQUEsS0FEVixFQUVHOVYsT0FGSCxDQUVXLFVBQUNrVixJQUFELEVBQVU7QUFDakJRLGVBQVNqUSxJQUFULENBQWN5UCxJQUFkO0FBQ0QsS0FKSDtBQUtBTyxhQUFTQyxRQUFUO0FBQ0QsR0FQRDtBQVFELENBWkQsQyxDQWNBOzs7Ozs7O0FBTUEsSUFBTTlXLGNBQWEsU0FBYkEsV0FBYSxDQUFDNFYsR0FBRCxFQUFNdlYsUUFBTixFQUFnQndXLFFBQWhCLEVBQTZCO0FBQzlDLE1BQU1hLGVBQWVwQyxtQkFBa0JNLEdBQWxCLEVBQXVCdlYsUUFBdkIsQ0FBckIsQ0FEOEMsQ0FFOUM7OztBQUNBUCxLQUFHNlgsTUFBSCxDQUFVRCxZQUFWLEVBQXdCLFVBQUNWLEdBQUQsRUFBUztBQUMvQixRQUFJQSxHQUFKLEVBQVM7QUFDUEgsZUFBUztBQUFFZSxnQkFBUSxPQUFWO0FBQW1CaEMsZ0JBQW5CO0FBQXdCdlY7QUFBeEIsT0FBVDtBQUNELEtBRkQsTUFFTztBQUNMd1csZUFBUztBQUFFZSxnQkFBUSxJQUFWO0FBQWdCaEMsZ0JBQWhCO0FBQXFCdlY7QUFBckIsT0FBVDtBQUNEO0FBQ0YsR0FORCxFQUg4QyxDQVU5QztBQUNELENBWEQsQyxDQWFBOzs7Ozs7Ozs7O0FBU0EsSUFBTU4sc0JBQXFCLFNBQXJCQSxtQkFBcUIsQ0FBQ0ksTUFBRCxFQUFTeVYsR0FBVCxFQUFjdlYsUUFBZCxFQUF3QndXLFFBQXhCLEVBQXFDO0FBQzlELE1BQU1nQixlQUFlakMsTUFBTXZWLFFBQTNCLENBRDhELENBRTlEOztBQUNBUCxLQUFHZ1ksSUFBSCxDQUFRbEMsR0FBUixFQUFhLFVBQUN6VyxLQUFELEVBQVE0WSxLQUFSLEVBQWtCO0FBQzdCLFFBQUk1WSxLQUFKLEVBQVc7QUFDVDZZLGlCQUFXLFlBQU07QUFDZm5CLGlCQUFTO0FBQUVlLGtCQUFRLE9BQVY7QUFBbUJoQyxrQkFBbkI7QUFBd0J2VjtBQUF4QixTQUFULEVBRGUsQ0FFZjtBQUNELE9BSEQsRUFHRyxJQUhILEVBRFMsQ0FLVDtBQUNELEtBTkQsTUFNTyxJQUFJMFgsTUFBTXRCLFdBQU4sRUFBSixFQUF5QjtBQUM5QjNXLFNBQUdtWSxTQUFILENBQWFKLFlBQWIsRUFBMkIsSUFBSUssTUFBSixDQUFXL1gsTUFBWCxDQUEzQixFQUErQyxRQUEvQyxFQUF5RCxVQUFDZ1ksTUFBRCxFQUFZO0FBQ25FLFlBQUlBLE1BQUosRUFBWTtBQUNWdEIsbUJBQVM7QUFBRWUsb0JBQVEsT0FBVjtBQUFtQmhDLG9CQUFuQjtBQUF3QnZWO0FBQXhCLFdBQVQsRUFEVSxDQUVWO0FBQ0QsU0FIRCxNQUdPO0FBQ0x3VyxtQkFBUztBQUFFZSxvQkFBUSxJQUFWO0FBQWdCaEMsb0JBQWhCO0FBQXFCdlY7QUFBckIsV0FBVCxFQURLLENBRUw7QUFDRDtBQUNGLE9BUkQ7QUFTRCxLQVZNLE1BVUE7QUFDTDtBQUNBd1csZUFBUztBQUFFZSxnQkFBUTtBQUFWLE9BQVQ7QUFDRDtBQUNGLEdBckJELEVBSDhELENBeUI5RDtBQUNELENBMUJELEMsQ0E0QkE7Ozs7O0FBSUEsSUFBTXBDLG1CQUFrQixTQUFsQkEsZ0JBQWtCLENBQUNVLE9BQUQsRUFBVVcsUUFBVixFQUF1QjtBQUM3QztBQUNBbE0sVUFBUUMsR0FBUixxQkFBOEJzTCxPQUE5QjtBQUNBcFcsS0FBR3NZLE1BQUgsQ0FBVWxDLE9BQVYsRUFBbUIsVUFBQ2tDLE1BQUQsRUFBWTtBQUM3QnpOLFlBQVFDLEdBQVIsZUFBd0J3TixNQUF4Qjs7QUFDQSxRQUFJLENBQUNBLE1BQUwsRUFBYTtBQUNYdFksU0FBR3VZLEtBQUgsQ0FBU25DLE9BQVQsRUFBa0IsTUFBbEIsRUFBMEIsWUFBTTtBQUM5QnZMLGdCQUFRQyxHQUFSLHFCQUE4QnNMLE9BQTlCO0FBQ0FXLGlCQUFTLElBQVQ7QUFDRCxPQUhEO0FBSUQsS0FMRCxNQUtPO0FBQ0xBLGVBQVMsS0FBVDtBQUNEO0FBQ0YsR0FWRDtBQVdELENBZEQsQyxDQWdCQTs7Ozs7Ozs7QUFPQSxJQUFNeUIscUJBQXFCLFNBQXJCQSxrQkFBcUIsQ0FBQ0MsVUFBRCxFQUFhQyxPQUFiLEVBQXNCM0IsUUFBdEIsRUFBbUM7QUFDNUQ0QixZQUFVRixVQUFWLEVBQXNCQyxPQUF0QixFQUErQixVQUFDeEIsR0FBRCxFQUFTO0FBQ3RDLFFBQUlBLEdBQUosRUFBUztBQUNQSCxlQUFTLEtBQVQ7QUFDRCxLQUZELE1BRU87QUFDTEEsZUFBUyxJQUFUO0FBQ0Q7QUFDRixHQU5EO0FBT0QsQ0FSRDs7QUFVQSxJQUFNbkIsZUFBYyxTQUFkQSxZQUFjLENBQUNnRCxRQUFELEVBQWM7QUFDaEMsTUFBTVgsUUFBUWpZLEdBQUc2WSxRQUFILENBQVlELFFBQVosQ0FBZDtBQUNBLE1BQU1FLGtCQUFrQmIsTUFBTWMsSUFBOUI7QUFDQSxTQUFPRCxlQUFQO0FBQ0QsQ0FKRDs7QUFNQSxJQUFNbkQsaUJBQWdCLFNBQWhCQSxjQUFnQixDQUFDcUQsTUFBRCxFQUFTakMsUUFBVCxFQUFzQjtBQUMxQyxNQUFJa0MsYUFBYSxDQUFqQjtBQUNBalosS0FBR2lYLE9BQUgsQ0FBVytCLE1BQVgsRUFBbUIsVUFBQzlCLEdBQUQsRUFBTVosS0FBTixFQUFnQjtBQUNqQ0EsVUFBTWhWLE9BQU4sQ0FBYyxVQUFDa1YsSUFBRCxFQUFVO0FBQ3RCeUMsb0JBQWNyRCxhQUFZN1YsS0FBS1csSUFBTCxDQUFVc1ksTUFBVixFQUFrQnhDLElBQWxCLENBQVosQ0FBZDtBQUNELEtBRkQ7QUFHQU8sYUFBU2tDLFVBQVQ7QUFDRCxHQUxEO0FBTUQsQ0FSRDs7QUFVQSxJQUFNQyxvQkFBb0IsU0FBcEJBLGlCQUFvQixDQUFDOUMsT0FBRCxFQUFVVyxRQUFWLEVBQXVCO0FBQy9DLE1BQU1nQyxPQUFPbEQsTUFBTSxJQUFOLEVBQVksQ0FBQyxLQUFELEVBQVFPLE9BQVIsQ0FBWixDQUFiO0FBQ0EsTUFBTTBCLFNBQVMsRUFBZjtBQUNBLE1BQUlxQixZQUFZLENBQWhCO0FBRUFKLE9BQUtLLE1BQUwsQ0FBWUMsRUFBWixDQUFlLE1BQWYsRUFBdUIsVUFBQzFFLElBQUQsRUFBVTtBQUMvQm1ELFdBQU9uRCxJQUFQLEdBQWNBLElBQWQ7QUFFQUEsU0FBS3JULE9BQUwsQ0FBYSxVQUFDZ1ksSUFBRCxFQUFVO0FBQ3JCSCxtQkFBYUcsSUFBYjtBQUNELEtBRkQ7QUFHQXZDLGFBQVNvQyxTQUFUO0FBQ0QsR0FQRDtBQVFBSixPQUFLUSxNQUFMLENBQVlGLEVBQVosQ0FBZSxNQUFmLEVBQXVCLFVBQUMxRSxJQUFELEVBQVU7QUFDL0JtRCxXQUFPelksS0FBUCxHQUFlc1YsSUFBZjtBQUNBb0MsYUFBU2UsTUFBVDtBQUNELEdBSEQ7QUFJRCxDQWpCRCxDOzs7Ozs7Ozs7Ozs7O0FDcE9BLElBQUk5WCxXQUFKO0FBQU92RSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsSUFBUixDQUFiLEVBQTJCO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDb0UsU0FBR3BFLENBQUg7QUFBSztBQUFqQixDQUEzQixFQUE4QyxDQUE5QztBQUFQSCxPQUFPaUQsYUFBUCxDQUVlO0FBQUEsU0FBUXNCLEdBQUd3WixZQUFILGlCQUE4QnpaLElBQTlCLEVBQXNDLE1BQXRDLENBQVI7QUFBQSxDQUZmLEU7Ozs7Ozs7Ozs7Ozs7QUNBQSxJQUFJMFosbUJBQUo7QUFBZWhlLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQ0ksU0FBRCxvQkFBU0gsQ0FBVCxFQUFXO0FBQUM2ZCxpQkFBVzdkLENBQVg7QUFBYTtBQUF6QixDQUFuQyxFQUE4RCxDQUE5RDtBQUFpRSxJQUFJOGQsY0FBSjtBQUFVamUsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE9BQVIsQ0FBYixFQUE4QjtBQUFDSSxTQUFELG9CQUFTSCxDQUFULEVBQVc7QUFBQzhkLFlBQU05ZCxDQUFOO0FBQVE7QUFBcEIsQ0FBOUIsRUFBb0QsQ0FBcEQ7QUFBMUZILE9BQU9pRCxhQUFQLENBR2UsVUFBQ2liLGdCQUFELEVBQW1CQyxPQUFuQixFQUE0Qi9OLE9BQTVCLEVBQXdDO0FBQ3JELE1BQUk4TixvQkFBb0JDLE9BQXhCLEVBQWlDO0FBQy9CLFFBQU14TCxXQUFXcUwsV0FBV0ksT0FBWCxDQUFtQkYsZ0JBQW5CLENBQWpCO0FBQ0EsV0FBTzlOLFdBQVcsQ0FBQ0EsUUFBUWlPLFNBQXBCLEdBQWdDMUwsU0FBU3dMLE9BQVQsQ0FBaEMsR0FBb0RGLE1BQU10TCxTQUFTd0wsT0FBVCxDQUFOLENBQTNELENBRitCLENBRy9CO0FBQ0Q7O0FBRUQsUUFBTSxJQUFJdGEsS0FBSixDQUFVLHNJQUFWLENBQU47QUFDRCxDQVhELEU7Ozs7Ozs7Ozs7Ozs7QUNBQSxJQUFJbWEsbUJBQUo7QUFBZWhlLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQ0ksU0FBRCxvQkFBU0gsQ0FBVCxFQUFXO0FBQUM2ZCxpQkFBVzdkLENBQVg7QUFBYTtBQUF6QixDQUFuQyxFQUE4RCxDQUE5RDtBQUFmSCxPQUFPaUQsYUFBUCxDQUVlLFVBQUNpYixnQkFBRCxFQUFtQkMsT0FBbkIsRUFBK0I7QUFDNUMsTUFBSUQsb0JBQW9CQyxPQUF4QixFQUFpQztBQUMvQixRQUFNeEwsV0FBV3FMLFdBQVdJLE9BQVgsQ0FBbUJGLGdCQUFuQixDQUFqQjtBQUNBLFdBQU92TCxTQUFTd0wsT0FBVCxDQUFQO0FBQ0Q7O0FBRUQsUUFBTSxJQUFJdGEsS0FBSixDQUFVLHNJQUFWLENBQU47QUFDRCxDQVRELEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUEsSUFBSTZNLGVBQUo7O0FBQVUxUSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUN3USxPQUFELGlCQUFPdlEsQ0FBUCxFQUFTO0FBQUN1USxhQUFNdlEsQ0FBTjtBQUFRO0FBQWxCLENBQXJDLEVBQXlELENBQXpEOztBQUE0RCxJQUFJSixnQkFBSjs7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxRQUFELGtCQUFRSSxDQUFSLEVBQVU7QUFBQ0osY0FBT0ksQ0FBUDtBQUFTO0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUk0Uyx1QkFBSjtBQUFtQi9TLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxvQkFBUixDQUFiLEVBQTJDO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDNFMscUJBQWU1UyxDQUFmO0FBQWlCO0FBQTdCLENBQTNDLEVBQTBFLENBQTFFO0FBQTZFLElBQUk0VSx1QkFBSjtBQUFtQi9VLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw0QkFBUixDQUFiLEVBQW1EO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDNFUscUJBQWU1VSxDQUFmO0FBQWlCO0FBQTdCLENBQW5ELEVBQWtGLENBQWxGO0FBQXFGLElBQUkyVSx1QkFBSjtBQUFtQjlVLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw0QkFBUixDQUFiLEVBQW1EO0FBQUNJLFNBQUQsb0JBQVNILENBQVQsRUFBVztBQUFDMlUscUJBQWUzVSxDQUFmO0FBQWlCO0FBQTdCLENBQW5ELEVBQWtGLENBQWxGOztBQU0zVyxJQUFNZ1MsWUFBWSxTQUFaQSxTQUFZLENBQUMvQixPQUFELFFBQWtDO0FBQUEsTUFBdEJGLE9BQXNCLFFBQXRCQSxPQUFzQjtBQUFBLE1BQWJILE1BQWEsUUFBYkEsTUFBYTs7QUFDbEQsTUFBSTtBQUNGaFEsWUFBT3VlLEtBQVAsQ0FBYSxZQUFNO0FBQ2pCNU4sYUFBTTZOLElBQU4sQ0FBV25PLE9BQVg7O0FBQ0FGO0FBQ0QsS0FIRDtBQUlELEdBTEQsQ0FLRSxPQUFPdk0sU0FBUCxFQUFrQjtBQUNsQm9NLFdBQU9wTSxTQUFQO0FBQ0Q7QUFDRixDQVREOztBQU5BM0QsT0FBT2lELGFBQVAsQ0FpQmUsaUJBRVQ7QUFBQSxNQURKc1MsSUFDSSxTQURKQSxJQUNJO0FBQUEsTUFERUosSUFDRixTQURFQSxJQUNGO0FBQUEsTUFEUXhDLFFBQ1IsU0FEUUEsUUFDUjtBQUFBLE1BRGtCQyxZQUNsQixTQURrQkEsWUFDbEI7QUFBQSxNQURtQzRMLElBQ25DOztBQUNKLE1BQUlqSixRQUFRSixJQUFSLElBQWdCeEMsUUFBcEIsRUFBOEI7QUFDNUIsV0FBTyxJQUFJeEMsT0FBSixDQUFZLFVBQUNELE9BQUQsRUFBVUgsTUFBVixFQUFxQjtBQUN0Q29DLDJDQUNLcU0sSUFETDtBQUVFakosY0FBTTVDLFdBQVdvQyxlQUFlaEMsb0NBQWtDSixRQUFsQyxVQUFmLEVBQW1FQyxnQkFBZ0IsRUFBbkYsQ0FBWCxHQUFxRzJDLElBRjdHO0FBR0VKLGNBQU14QyxXQUFXbUMsZUFBZS9CLG9DQUFrQ0osUUFBbEMsV0FBZixFQUFvRUMsZ0JBQWdCLEVBQXBGLENBQVgsR0FBc0d1QztBQUg5RyxVQUlHO0FBQUVqRix3QkFBRjtBQUFXSDtBQUFYLE9BSkg7QUFLRCxLQU5NLENBQVA7QUFPRDs7QUFDRCxRQUFNLElBQUlsTSxLQUFKLENBQVUseUZBQVYsQ0FBTjtBQUNELENBOUJELEU7Ozs7Ozs7Ozs7Ozs7QUNBQSxJQUFNNGEsa0JBQWtCLFNBQWxCQSxlQUFrQjtBQUFBLFNBQVk7QUFDbENsTyxXQUFPbkYsUUFBUW1GLEtBRG1CO0FBRWxDck8sVUFBTTtBQUNKa1AsYUFBT2hHLFFBQVFzVCxVQURYO0FBRUpyTixZQUFNakcsUUFBUXVUO0FBRlY7QUFGNEIsR0FBWjtBQUFBLENBQXhCOztBQVFBLElBQU1DLG9CQUFvQixTQUFwQkEsaUJBQW9CO0FBQUEsU0FBWTtBQUNwQ3JPLFdBQU9uRixRQUFRbUYsS0FEcUI7QUFFcENyTyxVQUFNO0FBQ0prUCxhQUFPaEcsUUFBUXlULFVBRFg7QUFFSnhOLFlBQU1qRyxRQUFRMFQ7QUFGVjtBQUY4QixHQUFaO0FBQUEsQ0FBMUI7O0FBUUEsSUFBTUMsb0JBQW9CLFNBQXBCQSxpQkFBb0IsQ0FBQzVQLE9BQUQsRUFBVWpFLFFBQVYsRUFBdUI7QUFDL0MsTUFBSUEsU0FBUzRLLFFBQWIsRUFBdUIsT0FBTzhJLGtCQUFrQjFULFNBQVM0SyxRQUEzQixDQUFQO0FBQ3ZCLE1BQUk1SyxTQUFTZ0wsTUFBYixFQUFxQixPQUFPdUksZ0JBQWdCdlQsU0FBU2dMLE1BQXpCLENBQVA7QUFDdEIsQ0FIRDs7QUFoQkFsVyxPQUFPaUQsYUFBUCxDQXFCZSxVQUFDbU4sT0FBRCxFQUFVd0IsSUFBVixFQUFtQjtBQUNoQyxNQUFNb04sVUFBVSxDQUFDNU8sUUFBUU8sUUFBekI7QUFDQSxNQUFNc08sY0FBY0QsVUFBVUQsa0JBQWtCM08sUUFBUWpCLE9BQTFCLEVBQW1DeUMsS0FBSzFHLFFBQXhDLENBQVYsR0FBOEQsSUFBbEY7QUFDQSxTQUFPOFQsVUFBVUMsV0FBVixHQUF3QixJQUEvQjtBQUNELENBekJELEU7Ozs7Ozs7Ozs7Ozs7QUNBQSxJQUFJQyxnQkFBSjtBQUFBLElBQVdDLHNCQUFYOztBQUF3Qm5mLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQ2dmLFFBQUQsa0JBQVEvZSxDQUFSLEVBQVU7QUFBQytlLGNBQU8vZSxDQUFQO0FBQVMsR0FBcEI7QUFBcUJnZixjQUFyQix3QkFBa0NoZixDQUFsQyxFQUFvQztBQUFDZ2Ysb0JBQWFoZixDQUFiO0FBQWU7QUFBcEQsQ0FBbkMsRUFBeUYsQ0FBekY7QUFBeEJILE9BQU9pRCxhQUFQLENBRWUsVUFBQ21jLFFBQUQsRUFBV2hQLE9BQVgsRUFBdUI7QUFDcEMsTUFBTWlQLFNBQVMsSUFBSUgsT0FBSixFQUFmO0FBQ0EsTUFBTUksU0FBU2xQLFVBQVUsSUFBSStPLGFBQUosQ0FBaUIvTyxPQUFqQixDQUFWLEdBQXNDLElBQUkrTyxhQUFKLEVBQXJEO0FBQ0EsTUFBTUksU0FBU0YsT0FBT0csS0FBUCxDQUFhSixRQUFiLENBQWY7QUFDQSxTQUFPRSxPQUFPRyxNQUFQLENBQWNGLE1BQWQsQ0FBUDtBQUNELENBUEQsRTs7Ozs7Ozs7Ozs7OztBQ0FBLElBQUl4ZixnQkFBSjs7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxRQUFELGtCQUFRSSxDQUFSLEVBQVU7QUFBQ0osY0FBT0ksQ0FBUDtBQUFTO0FBQXBCLENBQXRDLEVBQTRELENBQTVEOztBQUErRCxJQUFJdWYsd0JBQUo7O0FBQW1CMWYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHlCQUFSLENBQWIsRUFBZ0Q7QUFBQ3dmLGdCQUFELDBCQUFnQnZmLENBQWhCLEVBQWtCO0FBQUN1ZixzQkFBZXZmLENBQWY7QUFBaUI7QUFBcEMsQ0FBaEQsRUFBc0YsQ0FBdEY7QUFBN0ZILE9BQU9pRCxhQUFQLENBR2UsZ0JBQW1DO0FBQUEsTUFBaENNLE9BQWdDLFFBQWhDQSxPQUFnQztBQUFBLE1BQXZCYSxLQUF1QixRQUF2QkEsS0FBdUI7QUFBQSxNQUFoQkMsU0FBZ0IsUUFBaEJBLFNBQWdCOztBQUNoRCxNQUFJdEUsUUFBTzRmLFFBQVgsRUFBcUI7QUFDbkJELG9CQUFlRSxPQUFmLENBQXVCO0FBQ3JCMWQsVUFEcUIsZ0JBQ2hCQSxLQURnQixFQUNWO0FBQUUsZUFBT3FCLFFBQVFzYyxPQUFSLENBQWdCM2QsS0FBaEIsSUFBd0IsQ0FBQyxDQUFoQztBQUFvQyxPQUQ1QjtBQUVyQjRkLGtCQUZxQiwwQkFFTjtBQUFFLGVBQU8sSUFBUDtBQUFjO0FBRlYsS0FBdkIsRUFHRzFiLEtBSEgsRUFHVUMsU0FIVjtBQUlEO0FBQ0YsQ0FWRCxFOzs7Ozs7Ozs7Ozs7O0FDQUFyRSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMkJBQVIsQ0FBYixFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCBCYXR0ZXJpZXMgZnJvbSAnLi4vQmF0dGVyaWVzJztcblxuTWV0ZW9yLnB1Ymxpc2goJ2JhdHRlcmllcycsIGZ1bmN0aW9uIGJhdHRlcmllcygpIHtcbiAgcmV0dXJuIEJhdHRlcmllcy5maW5kKHsgb3duZXI6IHRoaXMudXNlcklkIH0pO1xufSk7XG5cbi8vIE5vdGU6IGJhdHRlcmllcy52aWV3IGlzIGFsc28gdXNlZCB3aGVuIGVkaXRpbmcgYW4gZXhpc3RpbmcgZG9jdW1lbnQuXG5NZXRlb3IucHVibGlzaCgnYmF0dGVyaWVzLnZpZXcnLCBmdW5jdGlvbiBiYXR0ZXJpZXNWaWV3KGJhdHRlcnlJZCkge1xuICBjaGVjayhiYXR0ZXJ5SWQsIFN0cmluZyk7XG4gIHJldHVybiBCYXR0ZXJpZXMuZmluZCh7IF9pZDogYmF0dGVyeUlkLCBvd25lcjogdGhpcy51c2VySWQgfSk7XG59KTtcbiIsIi8qIGVzbGludC1kaXNhYmxlIGNvbnNpc3RlbnQtcmV0dXJuICovXG5cbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuY29uc3QgQmF0dGVyaWVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ0JhdHRlcmllcycpO1xuXG5CYXR0ZXJpZXMuYWxsb3coe1xuICBpbnNlcnQ6ICgpID0+IGZhbHNlLFxuICB1cGRhdGU6ICgpID0+IGZhbHNlLFxuICByZW1vdmU6ICgpID0+IGZhbHNlLFxufSk7XG5cbkJhdHRlcmllcy5kZW55KHtcbiAgaW5zZXJ0OiAoKSA9PiB0cnVlLFxuICB1cGRhdGU6ICgpID0+IHRydWUsXG4gIHJlbW92ZTogKCkgPT4gdHJ1ZSxcbn0pO1xuXG5cbkJhdHRlcmllcy5zY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgb3duZXI6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdUaGUgSUQgb2YgdGhlIHVzZXIgdGhpcyBiYXR0ZXJ5IGJlbG9uZ3MgdG8uJyxcbiAgfSxcbiAgY3JlYXRlZEF0OiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIGRhdGUgdGhpcyBiYXR0ZXJ5IHdhcyBjcmVhdGVkIGluIHRoZSBkYXRhYmFzZS4nLFxuICAgIGF1dG9WYWx1ZSgpIHtcbiAgICAgIGlmICh0aGlzLmlzSW5zZXJ0KSByZXR1cm4gKG5ldyBEYXRlKCkpLnRvSVNPU3RyaW5nKCk7XG4gICAgfSxcbiAgfSxcbiAgdXBkYXRlZEF0OiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIGRhdGUgdGhpcyBiYXR0ZXJ5IHdhcyBsYXN0IHVwZGF0ZWQuJyxcbiAgICBhdXRvVmFsdWUoKSB7XG4gICAgICBpZiAodGhpcy5pc0luc2VydCB8fCB0aGlzLmlzVXBkYXRlKSByZXR1cm4gKG5ldyBEYXRlKCkpLnRvSVNPU3RyaW5nKCk7XG4gICAgfSxcbiAgfSxcbiAgbmFtZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ0EgbmFtZSB0byBpZGVudGlmeSB0aGUgYmF0dGVyeS4nLFxuICB9LFxuICBtb2RlbDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBtb2RlbCBvZiB0aGUgYmF0dGVyeS4nLFxuICB9LFxuICByZWdpc3RyYXRpb25OdW1iZXI6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdUaGUgc2VyaWFsIG51bWJlciB0byBpZGVudGlmeSB0aGUgYmF0dGVyeS4nLFxuICB9LFxuICBhbXBlcmVzOiB7XG4gICAgdHlwZTogTnVtYmVyLFxuICAgIGxhYmVsOiAnVGhlIHBvd2VyIHRoaXMgYmF0dGVyeSBwcm92aWRlcyBpbiBBbXBlcmVzLicsXG4gICAgbWluOiAwLFxuICB9LFxuICBjZWxsTnVtYmVyOiB7XG4gICAgdHlwZTogU2ltcGxlU2NoZW1hLkludGVnZXIsXG4gICAgbGFiZWw6ICdUaGUgbnVtYmVyIG9mIGNlbGxzIHRoaXMgYmF0dGVyeSBoYXMuJyxcbiAgICBtaW46IDAsXG4gIH0sXG4gIHdlaWdodDoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgICBsYWJlbDogJ1RoZSB3ZWlnaHQgb2YgdGhpcyBiYXR0ZXJ5IGluIGdyYW1zLicsXG4gICAgbWluOiAwLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICBkZWxldGVkOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIGRhdGUgdGhlIGJhdHRlcnkgd2FzIGRlbGV0ZWQuJyxcbiAgICBhdXRvVmFsdWUoKSB7XG4gICAgICBpZiAodGhpcy5pc0luc2VydCkgcmV0dXJuICdubyc7XG4gICAgfSxcbiAgfSxcbiAgbG9nRGF0YToge1xuICAgIHR5cGU6IE9iamVjdCxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgICBibGFja2JveDogdHJ1ZSxcbiAgICBsYWJlbDogJ1RoIGxvZyBkYXRhIGZvciB0aGlzIGJhdHRlcnksIGZvciBtYWludGVuYW5jZSBwdXJwb3NlcycsXG4gIH0sXG59KTtcblxuQmF0dGVyaWVzLmF0dGFjaFNjaGVtYShCYXR0ZXJpZXMuc2NoZW1hKTtcblxuZXhwb3J0IGRlZmF1bHQgQmF0dGVyaWVzO1xuIiwiLyogZXNsaW50LWRpc2FibGUgbWV0ZW9yL2F1ZGl0LWFyZ3VtZW50LWNoZWNrcyAqL1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgQmF0dGVyaWVzIGZyb20gJy4vQmF0dGVyaWVzJztcbmltcG9ydCByYXRlTGltaXQgZnJvbSAnLi4vLi4vbW9kdWxlcy9yYXRlLWxpbWl0JztcblxuY29uc3QgbmV3QmF0dGVyeVNjaGVtYSA9IEJhdHRlcmllcy5zY2hlbWEucGljaygnbmFtZScsICdtb2RlbCcsICdyZWdpc3RyYXRpb25OdW1iZXInLCAnYW1wZXJlcycsICdjZWxsTnVtYmVyJywgJ3dlaWdodCcpO1xuXG5jb25zdCBlZGl0QmF0dGVyeVNjaGVtYSA9IEJhdHRlcmllcy5zY2hlbWEucGljaygnbmFtZScsICdtb2RlbCcsICdyZWdpc3RyYXRpb25OdW1iZXInLCAnYW1wZXJlcycsICdjZWxsTnVtYmVyJywgJ3dlaWdodCcpO1xuZWRpdEJhdHRlcnlTY2hlbWEuZXh0ZW5kKHsgX2lkOiBTdHJpbmcgfSk7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgJ2JhdHRlcmllcy5pbnNlcnQnOiBmdW5jdGlvbiBiYXR0ZXJpZXNJbnNlcnQoYmF0dGVyeSkge1xuICAgIHRyeSB7XG4gICAgICBuZXdCYXR0ZXJ5U2NoZW1hLnZhbGlkYXRlKGJhdHRlcnkpO1xuICAgICAgcmV0dXJuIEJhdHRlcmllcy5pbnNlcnQoeyBvd25lcjogdGhpcy51c2VySWQsIC4uLmJhdHRlcnkgfSk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICBpZiAoZXhjZXB0aW9uLmVycm9yID09PSAndmFsaWRhdGlvbi1lcnJvcicpIHtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig1MDAsIGV4Y2VwdGlvbi5tZXNzYWdlKTtcbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxuICAnYmF0dGVyaWVzLnVwZGF0ZSc6IGZ1bmN0aW9uIGJhdHRlcmllc1VwZGF0ZShiYXR0ZXJ5KSB7XG4gICAgdHJ5IHtcbiAgICAgIGVkaXRCYXR0ZXJ5U2NoZW1hLnZhbGlkYXRlKGJhdHRlcnkpO1xuICAgICAgY29uc3QgYmF0dGVyeUlkID0gYmF0dGVyeS5faWQ7XG4gICAgICBCYXR0ZXJpZXMudXBkYXRlKGJhdHRlcnlJZCwgeyAkc2V0OiBiYXR0ZXJ5IH0pO1xuICAgICAgcmV0dXJuIGJhdHRlcnlJZDtcbiAgICAgIC8vIFJldHVybiBfaWQgc28gd2UgY2FuIHJlZGlyZWN0IHRvIGJhdHRlcnkgYWZ0ZXIgdXBkYXRlLlxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgaWYgKGV4Y2VwdGlvbi5lcnJvciA9PT0gJ3ZhbGlkYXRpb24tZXJyb3InKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCBleGNlcHRpb24ubWVzc2FnZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ2JhdHRlcmllcy5zb2Z0RGVsZXRlJzogZnVuY3Rpb24gYmF0dGVyaWVzU29mdERlbGV0ZShiYXR0ZXJ5SWQpIHtcbiAgICBjaGVjayhiYXR0ZXJ5SWQsIFN0cmluZyk7XG4gICAgdHJ5IHtcbiAgICAgIEJhdHRlcmllcy51cGRhdGUoYmF0dGVyeUlkLCB7ICRzZXQ6IHsgZGVsZXRlZDogKG5ldyBEYXRlKCkpLnRvSVNPU3RyaW5nKCkgfSB9KTtcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxuICAnYmF0dGVyaWVzLnJlc3RvcmUnOiBmdW5jdGlvbiBiYXR0ZXJpZXNSZXN0b3JlKGJhdHRlcnlJZCkge1xuICAgIGNoZWNrKGJhdHRlcnlJZCwgU3RyaW5nKTtcbiAgICB0cnkge1xuICAgICAgQmF0dGVyaWVzLnVwZGF0ZShiYXR0ZXJ5SWQsIHsgJHNldDogeyBkZWxldGVkOiAnbm8nIH0gfSk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ2JhdHRlcmllcy5oYXJkRGVsZXRlJzogZnVuY3Rpb24gYmF0dGVyaWVzSGFyZERlbGV0ZShiYXR0ZXJ5SWQpIHtcbiAgICBjaGVjayhiYXR0ZXJ5SWQsIFN0cmluZyk7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBCYXR0ZXJpZXMucmVtb3ZlKGJhdHRlcnlJZCk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbn0pO1xuXG5yYXRlTGltaXQoe1xuICBtZXRob2RzOiBbXG4gICAgJ2JhdHRlcmllcy5pbnNlcnQnLFxuICAgICdiYXR0ZXJpZXMudXBkYXRlJyxcbiAgICAnYmF0dGVyaWVzLnNvZnREZWxldGUnLFxuICAgICdiYXR0ZXJpZXMucmVzdG9yZScsXG4gICAgJ2JhdHRlcmllcy5oYXJkRGVsZXRlJyxcbiAgXSxcbiAgbGltaXQ6IDUsXG4gIHRpbWVSYW5nZTogMTAwMCxcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJztcbmltcG9ydCBmcyBmcm9tICdmcyc7XG5pbXBvcnQgcmF0ZUxpbWl0IGZyb20gJy4uLy4uLy4uL21vZHVsZXMvcmF0ZS1saW1pdCc7XG5pbXBvcnQgeyBzYXZlRmlsZUZyb21idWZmZXIsIGRlbGV0ZUZpbGUsIGdldEZpbGVMaXN0IH0gZnJvbSAnLi4vLi4vLi4vbW9kdWxlcy9zZXJ2ZXIvZmlsZS1zeXN0ZW0nO1xuXG5jb25zdCBGdXR1cmUgPSByZXF1aXJlKCdmaWJlcnMvZnV0dXJlJyk7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgJ2ZpbGVUcmFuc2Zlci5zYXZlRmlsZSc6IChidWZmZXIsIG1pc3Npb25JZCwgZmlsZU5hbWUpID0+IHtcbiAgICBjaGVjayhidWZmZXIsIFVpbnQ4QXJyYXkpO1xuICAgIGNoZWNrKG1pc3Npb25JZCwgU3RyaW5nKTtcbiAgICBjaGVjayhmaWxlTmFtZSwgU3RyaW5nKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgbWlzc2lvbkRpciA9IHBhdGguam9pbihNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5jb25maWcubWlzc2lvbnNQYXRoLCBgJHttaXNzaW9uSWR9L2ApO1xuICAgICAgY29uc3QgZnV0dXJlID0gbmV3IEZ1dHVyZSgpO1xuICAgICAgc2F2ZUZpbGVGcm9tYnVmZmVyKGJ1ZmZlciwgbWlzc2lvbkRpciwgZmlsZU5hbWUsIChvYmpKc29uKSA9PiB7XG4gICAgICAgIGZ1dHVyZS5yZXR1cm4ob2JqSnNvbik7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiBmdXR1cmUud2FpdCgpO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG5cbiAgJ2ZpbGVUcmFuc2Zlci5kZWxldGVGaWxlJzogKG1pc3Npb25JZCwgZmlsZU5hbWUpID0+IHtcbiAgICBjaGVjayhtaXNzaW9uSWQsIFN0cmluZyk7XG4gICAgY2hlY2soZmlsZU5hbWUsIFN0cmluZyk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IG1pc3Npb25EaXIgPSBwYXRoLmpvaW4oTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUuY29uZmlnLm1pc3Npb25zUGF0aCwgYCR7bWlzc2lvbklkfS9gKTtcbiAgICAgIGNvbnN0IGZ1dHVyZSA9IG5ldyBGdXR1cmUoKTtcbiAgICAgIGRlbGV0ZUZpbGUobWlzc2lvbkRpciwgZmlsZU5hbWUsIChvYmpKc29uKSA9PiB7XG4gICAgICAgIGZ1dHVyZS5yZXR1cm4ob2JqSnNvbik7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiBmdXR1cmUud2FpdCgpO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG5cbiAgJ2ZpbGVUcmFuc2Zlci5zYXZlRm9sZGVyJzogKG1pc3Npb25JZCwgZGlyUGF0aCkgPT4ge1xuICAgIGNoZWNrKG1pc3Npb25JZCwgU3RyaW5nKTtcbiAgICBjaGVjayhkaXJQYXRoLCBTdHJpbmcpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBmdXR1cmUgPSBuZXcgRnV0dXJlKCk7XG4gICAgICBpZiAoZnMuZXhpc3RzU3luYyhkaXJQYXRoKSkge1xuICAgICAgICBjb25zdCBtaXNzaW9uRGlyID0gcGF0aC5qb2luKE1ldGVvci5zZXR0aW5ncy5wcml2YXRlLmNvbmZpZy5taXNzaW9uc1BhdGgsIGAke21pc3Npb25JZH0vYCk7XG4gICAgICAgIGdldEZpbGVMaXN0KGRpclBhdGgsIChhcnJheSkgPT4ge1xuICAgICAgICAgIGFycmF5LmZvckVhY2goKGZpbGVOYW1lKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBmaWxlUGF0aCA9IHBhdGguam9pbihkaXJQYXRoLCBmaWxlTmFtZSk7XG4gICAgICAgICAgICBjb25zdCBuZXdGaWxlUGF0aCA9IHBhdGguam9pbihtaXNzaW9uRGlyLCBmaWxlTmFtZSk7XG4gICAgICAgICAgICBmcy5jb3B5RmlsZVN5bmMoZmlsZVBhdGgsIG5ld0ZpbGVQYXRoKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBFcnJvcignRGlyZWN0b3J5IG5vdCBmb3VuZCcpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZ1dHVyZS53YWl0KCk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbn0pO1xuXG5yYXRlTGltaXQoe1xuICBtZXRob2RzOiBbXG4gICAgJ2ZpbGVUcmFuc2Zlci5zYXZlRmlsZScsXG4gICAgJ2ZpbGVUcmFuc2Zlci5kZWxldGVGaWxlJyxcbiAgICAnZmlsZVRyYW5zZmVyLnNhdmVGb2xkZXInLFxuICBdLFxuICBsaW1pdDogNSxcbiAgdGltZVJhbmdlOiAxMDAwLFxufSk7XG4iLCIvKiBlc2xpbnQtZGlzYWJsZSBvYmplY3Qtc2hvcnRoYW5kICovXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCBNaXNzaW9ucyBmcm9tICcuLi9NaXNzaW9ucyc7XG5cbk1ldGVvci5wdWJsaXNoKCdtaXNzaW9ucycsIGZ1bmN0aW9uIG1pc3Npb25zKHByb2plY3RJZCkge1xuICBjaGVjayhwcm9qZWN0SWQsIFN0cmluZyk7XG4gIHJldHVybiBNaXNzaW9ucy5maW5kKHsgb3duZXI6IHRoaXMudXNlcklkLCBwcm9qZWN0OiBwcm9qZWN0SWQgfSk7XG59KTtcblxuLy8gTm90ZTogbWlzc2lvbnMudmlldyBpcyBhbHNvIHVzZWQgd2hlbiBlZGl0aW5nIGFuIGV4aXN0aW5nIG1pc3Npb24uXG5NZXRlb3IucHVibGlzaCgnbWlzc2lvbnMudmlldycsIGZ1bmN0aW9uIG1pc3Npb25zVmlldyhwcm9qZWN0SWQsIG1pc3Npb25JZCkge1xuICBjaGVjayhtaXNzaW9uSWQsIFN0cmluZyk7XG4gIGNoZWNrKHByb2plY3RJZCwgU3RyaW5nKTtcbiAgcmV0dXJuIE1pc3Npb25zLmZpbmQoeyBfaWQ6IG1pc3Npb25JZCwgb3duZXI6IHRoaXMudXNlcklkLCBwcm9qZWN0OiBwcm9qZWN0SWQgfSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ21pc3Npb25zLmV4cG9ydCcsIGZ1bmN0aW9uIG1pc3Npb25zRXhwb3J0KCkge1xuICByZXR1cm4gTWlzc2lvbnMuZmluZCh7IG93bmVyOiB0aGlzLnVzZXJJZCB9KTtcbn0pO1xuIiwiLyogZXNsaW50LWRpc2FibGUgY29uc2lzdGVudC1yZXR1cm4gKi9cblxuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuaW1wb3J0IHsgRmVhdHVyZVBvaW50LCBGZWF0dXJlUG9seWdvbiwgRmVhdHVyZUxpbmVTdHJpbmcsIEZlYXR1cmVDb2xsZWN0aW9uUG9pbnRzIH0gZnJvbSAnLi4vU2NoZW1hVXRpbGl0aWVzL0dlb0pTT05TY2hlbWEuanMnO1xuXG5jb25zdCBNaXNzaW9ucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdNaXNzaW9ucycpO1xuXG5NaXNzaW9ucy5hbGxvdyh7XG4gIGluc2VydDogKCkgPT4gZmFsc2UsXG4gIHVwZGF0ZTogKCkgPT4gZmFsc2UsXG4gIHJlbW92ZTogKCkgPT4gZmFsc2UsXG59KTtcblxuTWlzc2lvbnMuZGVueSh7XG4gIGluc2VydDogKCkgPT4gdHJ1ZSxcbiAgdXBkYXRlOiAoKSA9PiB0cnVlLFxuICByZW1vdmU6ICgpID0+IHRydWUsXG59KTtcblxuY29uc3QgZmxpZ2h0UGFyYW1ldGVyc1NjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICBoZWlnaHQ6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgbGFiZWw6ICdUaGUgYWx0aXR1ZGUgb2YgdGhlIGZsaWdodCBpbiBtZXRlcnMnLFxuICAgIG1pbjogMCxcbiAgfSxcbiAgc3BlZWQ6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgbGFiZWw6ICdUaGUgc3BlZWQgb2YgdGhlIGZsaWdodCBpbiBtZXRlcnMgcGVyIHNlY29uZCcsXG4gICAgbWluOiAwLFxuICB9LFxuICBlbnRyeU1hcmdpbjoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgICBsYWJlbDogJ1RoZSBlbnRyeSBtYXJnaW4gZm9yIHRoZSBmaXhlZCB3aW5nIHJwYSBpbiBtZXRlcnMnLFxuICAgIG1pbjogMCxcbiAgfSxcbiAgYXhpc0J1ZmZlcjoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgICBsYWJlbDogJ1RoZSBlbnRyeSBheGlzIGJ1ZmZlciBmb3IgdGhlIGxpbmVhciBtaXNzaW9uIGluIG1ldGVycycsXG4gICAgbWluOiAwLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxufSk7XG5cbmNvbnN0IHBpY3R1cmVHcmlkU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIG92ZXJsYXA6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgbGFiZWw6ICdUaGUgb3ZlcmxhcCBpbiAlJyxcbiAgICBtaW46IDAsXG4gICAgbWF4OiAxMDAsXG4gIH0sXG4gIHNpZGVsYXA6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgbGFiZWw6ICdUaGUgc2lkZWxhcCBpbiAlJyxcbiAgICBtaW46IDAsXG4gICAgbWF4OiAxMDAsXG4gIH0sXG59KTtcblxuY29uc3QgbWlzc2lvbkNhbGN1bGF0ZWREYXRhU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIGZsaWdodFRpbWU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdUaGUgdGltZSBpdCB0YWtlcyB0byBjb21wbGV0ZSB0aGUgbWlzc2lvbicsXG4gICAgbWluOiAwLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICBmbGlnaHRUaW1lTWludXRlczoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgICBsYWJlbDogJ1RoZSB0aW1lIGl0IHRha2VzIHRvIGNvbXBsZXRlIHRoZSBtaXNzaW9uIGluIG1pbnV0ZXMnLFxuICAgIG1pbjogMCxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgcGF0aExlbmd0aDoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgICBsYWJlbDogJ1RoZSBsZW5ndGggdGhlIHJwYSBpcyBnb2luZyB0byB0cmF2ZWwgaW4gbWV0ZXJzJyxcbiAgICBtaW46IDAsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gIHJlc29sdXRpb246IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgbGFiZWw6ICdUaGUgZ3JvdW5kIHJlc29sdXRpb24gb2J0YWluZWQgaW4gY20vcHgnLFxuICAgIG1pbjogMCxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgc2hvb3RUaW1lOiB7XG4gICAgdHlwZTogTnVtYmVyLFxuICAgIGxhYmVsOiAnVGltZSBiZXR3ZWVlbiBwaG90b3MgaW4gc2Vjb25kcycsXG4gICAgbWluOiAwLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICB0b3RhbEFyZWE6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgbGFiZWw6ICdUaGUgdG90YWwgYXJlYSBmb3IgdGhlIHBob3RvZ3JhbWV0cmljIGltYWdlIGluIGhlY3RhcmVzJyxcbiAgICBtaW46IDAsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gIGRpc3RQaWNzOiB7XG4gICAgdHlwZTogTnVtYmVyLFxuICAgIGxhYmVsOiAnRGlzdGFuY2UgYmV0d2VlZW4gcGhvdG9zIGluIG1ldGVycycsXG4gICAgbWluOiAwLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxufSk7XG5cbmNvbnN0IG1pc3Npb25DYWxjdWxhdGlvblNjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICB3YXlwb2ludExpc3Q6IHtcbiAgICB0eXBlOiBGZWF0dXJlQ29sbGVjdGlvblBvaW50cyxcbiAgICBsYWJlbDogJ0ZlYXR1cmUgQ29sbGVjdGlvbiByZXByZXNlbnRpbmcgdGhlIHdheXBvaW50cyBmb3IgdGhlIG1pc3Npb24nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICBtaXNzaW9uQ2FsY3VsYXRlZERhdGE6IHtcbiAgICB0eXBlOiBtaXNzaW9uQ2FsY3VsYXRlZERhdGFTY2hlbWEsXG4gICAgbGFiZWw6ICdUaGlzIGlzIHRoZSBkYXRhIG9idGFpbmVkIGZyb20gY2FsY3VsYXRpbmcgdGhlIG1pc3Npb24nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxufSk7XG5cbk1pc3Npb25zLnNjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICBvd25lcjoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBJRCBvZiB0aGUgdXNlciB0aGlzIG1pc3Npb24gYmVsb25ncyB0by4nLFxuICB9LFxuICBwcm9qZWN0OiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIElEIG9mIHRoZSBwcm9qZWN0IHRoaXMgbWlzc2lvbiBiZWxvbmdzIHRvLicsXG4gIH0sXG4gIGNyZWF0ZWRBdDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBkYXRlIHRoaXMgbWlzc2lvbiB3YXMgY3JlYXRlZC4nLFxuICAgIGF1dG9WYWx1ZSgpIHtcbiAgICAgIGlmICh0aGlzLmlzSW5zZXJ0KSByZXR1cm4gKG5ldyBEYXRlKCkpLnRvSVNPU3RyaW5nKCk7XG4gICAgfSxcbiAgfSxcbiAgdXBkYXRlZEF0OiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIGRhdGUgdGhpcyBtaXNzaW9uIHdhcyBsYXN0IHVwZGF0ZWQuJyxcbiAgICBhdXRvVmFsdWUoKSB7XG4gICAgICBpZiAodGhpcy5pc0luc2VydCB8fCB0aGlzLmlzVXBkYXRlKSByZXR1cm4gKG5ldyBEYXRlKCkpLnRvSVNPU3RyaW5nKCk7XG4gICAgfSxcbiAgfSxcbiAgbmFtZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBuYW1lIG9mIHRoZSBtaXNzaW9uLicsXG4gIH0sXG4gIGRlc2NyaXB0aW9uOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIGRlc2NyaXB0aW9uIG9mIHRoZSBtaXNzaW9uLicsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gIHJwYToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBJRCBvZiB0aGUgcmVtb3RlIHByb3BlbGxlZCBhaXJjcmFmdCB1c2VkLicsXG4gIH0sXG4gIHBheWxvYWQ6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdUaGUgSUQgb2YgdGhlIHBheWxvYWQgdXNlZC4nLFxuICB9LFxuICBtaXNzaW9uVHlwZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBtaXNzaW9uIHR5cGUnLFxuICAgIGFsbG93ZWRWYWx1ZXM6IFsnU3VyZmFjZSBBcmVhJywgJ0xpbmVhciBBcmVhJ10sXG4gIH0sXG4gIGxheWVyczoge1xuICAgIHR5cGU6IEFycmF5LFxuICAgIGxhYmVsOiAnVGhlIGxheWVycyByZXF1ZXN0ZWQgZm9yIHRoZSBtaXNzaW9uJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgJ2xheWVycy4kJzoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBuYW1lIG9mIHRoZSBsYXllciByZXF1ZXN0ZWQgZm9yIHRoZSBtaXNzaW9uJyxcbiAgfSxcbiAgZmxpZ2h0UGxhbjoge1xuICAgIHR5cGU6IE9iamVjdCxcbiAgICBsYWJlbDogJ0FsbCB0aGUgZGF0YSByZWxhdGVkIHRvIHRoZSBmbGlnaHQnLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICAnZmxpZ2h0UGxhbi50YWtlT2ZmUG9pbnQnOiB7XG4gICAgdHlwZTogRmVhdHVyZVBvaW50LFxuICAgIGxhYmVsOiAnVGhlIHRha2Ugb2ZmIHBvaW50IGZvciB0aGUgZmxpZ2h0JyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgJ2ZsaWdodFBsYW4ubGFuZGluZ1BvaW50Jzoge1xuICAgIHR5cGU6IEZlYXR1cmVQb2ludCxcbiAgICBsYWJlbDogJ1RoZSBsYW5kaW5nIHBvaW50IGZvciB0aGUgZmxpZ2h0JyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgJ2ZsaWdodFBsYW4ubWlzc2lvbkFyZWEnOiB7XG4gICAgdHlwZTogRmVhdHVyZVBvbHlnb24sXG4gICAgbGFiZWw6ICdBbGwgdGhlIGRhdGEgcmVsYXRlZCB0byB0aGUgYXJlYSBmb3IgdGhlIGZsaWdodCcsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gICdmbGlnaHRQbGFuLm1pc3Npb25BeGlzJzoge1xuICAgIHR5cGU6IEZlYXR1cmVMaW5lU3RyaW5nLFxuICAgIGxhYmVsOiAnQWxsIHRoZSBkYXRhIHJlbGF0ZWQgdG8gdGhlIGF4aXMgZm9yIHRoZSBmbGlnaHQnLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICAnZmxpZ2h0UGxhbi5mbGlnaHRQYXJhbWV0ZXJzJzoge1xuICAgIHR5cGU6IGZsaWdodFBhcmFtZXRlcnNTY2hlbWEsXG4gICAgbGFiZWw6ICdEYXRhIHJlbGF0ZWQgdG8gdGhlIGZsaWdodCcsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gICdmbGlnaHRQbGFuLnBpY3R1cmVHcmlkJzoge1xuICAgIHR5cGU6IHBpY3R1cmVHcmlkU2NoZW1hLFxuICAgIGxhYmVsOiAnQWxsIHRoZSBkYXRhIHJlbGF0ZWQgdG8gdGhlIGFyZWEgZm9yIHRoZSBmbGlnaHQnLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICAnZmxpZ2h0UGxhbi5taXNzaW9uQ2FsY3VsYXRpb24nOiB7XG4gICAgdHlwZTogbWlzc2lvbkNhbGN1bGF0aW9uU2NoZW1hLFxuICAgIGxhYmVsOiAnVGhpcyBpcyB3aGVyZSB3ZSBzdG9yZSB0aGUgZGF0YSBmcm9tIHRoZSB3YXlwb2ludCBjYWxjdWxhdGlvbicsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gICdmbGlnaHRQbGFuLmxhbmRpbmdCZWFyaW5nJzoge1xuICAgIHR5cGU6IEZlYXR1cmVMaW5lU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhpcyBpcyBhIGdlb0pTT04gZmVhdHVyZSByZXByZXNlbnRpbmcgdGhlIGFuZ2xlIGZvciB0aGUgbGFuZGluZyBwYXRoJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgZGVsZXRlZDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBkYXRlIHRoZSBtaXNzaW9uIHdhcyBkZWxldGVkLicsXG4gICAgYXV0b1ZhbHVlKCkge1xuICAgICAgaWYgKHRoaXMuaXNJbnNlcnQpIHJldHVybiAnbm8nO1xuICAgIH0sXG4gIH0sXG4gIGRvbmU6IHtcbiAgICB0eXBlOiBCb29sZWFuLFxuICAgIGxhYmVsOiAnSXMgdGhlIG1pc3Npb24gZG9uZT8nLFxuICAgIGF1dG9WYWx1ZSgpIHtcbiAgICAgIGlmICh0aGlzLmlzSW5zZXJ0KSByZXR1cm4gZmFsc2U7XG4gICAgfSxcbiAgfSxcbiAgc3RhdHVzOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnSG93IGlzIHRoZSBtaXNzaW9uIGRvaW5nPycsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG59KTtcblxuTWlzc2lvbnMuYXR0YWNoU2NoZW1hKE1pc3Npb25zLnNjaGVtYSk7XG5cbmV4cG9ydCBkZWZhdWx0IE1pc3Npb25zO1xuIiwiLyogZXNsaW50LWRpc2FibGUgbWV0ZW9yL2F1ZGl0LWFyZ3VtZW50LWNoZWNrcyAqL1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCc7XG5pbXBvcnQgTWlzc2lvbnMgZnJvbSAnLi9NaXNzaW9ucyc7XG5pbXBvcnQgcmF0ZUxpbWl0IGZyb20gJy4uLy4uL21vZHVsZXMvcmF0ZS1saW1pdCc7XG5pbXBvcnQgeyBkZWxldGVGb2xkZXJSZWN1cnNpdmVTeW5jIH0gZnJvbSAnLi4vLi4vbW9kdWxlcy9zZXJ2ZXIvZmlsZS1zeXN0ZW0nO1xuXG5pbXBvcnQgeyBGZWF0dXJlUG9pbnQsIEZlYXR1cmVQb2x5Z29uLCBGZWF0dXJlTGluZVN0cmluZywgRmVhdHVyZUNvbGxlY3Rpb25Qb2ludHMgfSBmcm9tICcuLi9TY2hlbWFVdGlsaXRpZXMvR2VvSlNPTlNjaGVtYS5qcyc7XG5cbmNvbnN0IG5ld01pc3Npb25TY2hlbWEgPSBNaXNzaW9ucy5zY2hlbWEucGljaygnbmFtZScsICdwcm9qZWN0JywgJ3JwYScsICdtaXNzaW9uVHlwZScsICdkZXNjcmlwdGlvbicsICdwYXlsb2FkJyk7XG5cbmNvbnN0IGltcG9ydE1pc3Npb25TY2hlbWEgPSBNaXNzaW9ucy5zY2hlbWEucGljaygnbmFtZScsICdwcm9qZWN0JywgJ3JwYScsICdtaXNzaW9uVHlwZScsICdkZXNjcmlwdGlvbicsICdwYXlsb2FkJywgJ2ZsaWdodFBsYW4nKTtcblxuY29uc3QgZWRpdE1pc3Npb25TY2hlbWEgPSBNaXNzaW9ucy5zY2hlbWEucGljaygnbmFtZScsICdwcm9qZWN0JywgJ3JwYScsICdtaXNzaW9uVHlwZScsICdkZXNjcmlwdGlvbicsICdwYXlsb2FkJyk7XG5lZGl0TWlzc2lvblNjaGVtYS5leHRlbmQoeyBfaWQ6IFN0cmluZyB9KTtcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAnbWlzc2lvbnMuaW5zZXJ0JzogZnVuY3Rpb24gbWlzc2lvbnNJbnNlcnQobWlzc2lvbikge1xuICAgIHRyeSB7XG4gICAgICBuZXdNaXNzaW9uU2NoZW1hLnZhbGlkYXRlKG1pc3Npb24pO1xuICAgICAgY29uc3QgbmV3TWlzc2lvbklEID0gTWlzc2lvbnMuaW5zZXJ0KHsgb3duZXI6IHRoaXMudXNlcklkLCAuLi5taXNzaW9uIH0pO1xuICAgICAgY29uc3QgbWlzc2lvbkRpciA9IHBhdGguam9pbihNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5jb25maWcubWlzc2lvbnNQYXRoLCBuZXdNaXNzaW9uSUQpO1xuICAgICAgZnMubWtkaXJTeW5jKG1pc3Npb25EaXIpO1xuICAgICAgcmV0dXJuIG5ld01pc3Npb25JRDtcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIGlmIChleGNlcHRpb24uZXJyb3IgPT09ICd2YWxpZGF0aW9uLWVycm9yJykge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgZXhjZXB0aW9uLm1lc3NhZ2UpO1xuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICdtaXNzaW9ucy5pbXBvcnQnOiBmdW5jdGlvbiBtaXNzaW9uc0ltcG9ydChtaXNzaW9uKSB7XG4gICAgdHJ5IHtcbiAgICAgIGltcG9ydE1pc3Npb25TY2hlbWEudmFsaWRhdGUobWlzc2lvbik7XG4gICAgICByZXR1cm4gTWlzc2lvbnMuaW5zZXJ0KHsgb3duZXI6IHRoaXMudXNlcklkLCAuLi5taXNzaW9uIH0pO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgaWYgKGV4Y2VwdGlvbi5lcnJvciA9PT0gJ3ZhbGlkYXRpb24tZXJyb3InKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCBleGNlcHRpb24ubWVzc2FnZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ21pc3Npb25zLnVwZGF0ZSc6IGZ1bmN0aW9uIG1pc3Npb25zVXBkYXRlKG1pc3Npb24pIHtcbiAgICB0cnkge1xuICAgICAgZWRpdE1pc3Npb25TY2hlbWEudmFsaWRhdGUobWlzc2lvbik7XG4gICAgICBjb25zdCBtaXNzaW9uSWQgPSBtaXNzaW9uLl9pZDtcbiAgICAgIE1pc3Npb25zLnVwZGF0ZShtaXNzaW9uSWQsIHsgJHNldDogbWlzc2lvbiB9KTtcbiAgICAgIHJldHVybiBtaXNzaW9uSWQ7IC8vIFJldHVybiBfaWQgc28gd2UgY2FuIHJlZGlyZWN0IHRvIGRvY3VtZW50IGFmdGVyIHVwZGF0ZS5cbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIGlmIChleGNlcHRpb24uZXJyb3IgPT09ICd2YWxpZGF0aW9uLWVycm9yJykge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgZXhjZXB0aW9uLm1lc3NhZ2UpO1xuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICdtaXNzaW9ucy5zb2Z0RGVsZXRlJzogZnVuY3Rpb24gbWlzc2lvbnNTb2Z0RGVsZXRlKG1pc3Npb25JZCkge1xuICAgIGNoZWNrKG1pc3Npb25JZCwgU3RyaW5nKTtcbiAgICB0cnkge1xuICAgICAgTWlzc2lvbnMudXBkYXRlKG1pc3Npb25JZCwgeyAkc2V0OiB7IGRlbGV0ZWQ6IChuZXcgRGF0ZSgpKS50b0lTT1N0cmluZygpIH0gfSk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ21pc3Npb25zLnJlc3RvcmUnOiBmdW5jdGlvbiBtaXNzaW9uc1Jlc3RvcmUobWlzc2lvbklkKSB7XG4gICAgY2hlY2sobWlzc2lvbklkLCBTdHJpbmcpO1xuICAgIHRyeSB7XG4gICAgICBNaXNzaW9ucy51cGRhdGUobWlzc2lvbklkLCB7ICRzZXQ6IHsgZGVsZXRlZDogJ25vJyB9IH0pO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICdtaXNzaW9ucy5oYXJkRGVsZXRlJzogZnVuY3Rpb24gbWlzc2lvbnNIYXJkRGVsZXRlKG1pc3Npb25JZCkge1xuICAgIGNoZWNrKG1pc3Npb25JZCwgU3RyaW5nKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgbWlzc2lvbkRpciA9IHBhdGguam9pbihNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5jb25maWcubWlzc2lvbnNQYXRoLCBtaXNzaW9uSWQpO1xuICAgICAgZGVsZXRlRm9sZGVyUmVjdXJzaXZlU3luYyhtaXNzaW9uRGlyLCB0cnVlKTtcbiAgICAgIHJldHVybiBNaXNzaW9ucy5yZW1vdmUobWlzc2lvbklkKTtcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxuICAnbWlzc2lvbnMuc2V0RG9uZSc6IGZ1bmN0aW9uIG1pc3Npb25zU2V0RG9uZShtaXNzaW9uSWQsIHNldERvbmUpIHtcbiAgICBjaGVjayhtaXNzaW9uSWQsIFN0cmluZyk7XG4gICAgY2hlY2soc2V0RG9uZSwgQm9vbGVhbik7XG4gICAgdHJ5IHtcbiAgICAgIE1pc3Npb25zLnVwZGF0ZShtaXNzaW9uSWQsIHsgJHNldDogeyBkb25lOiBzZXREb25lIH0gfSk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ21pc3Npb25zLnNldFRha2VPZmZQb2ludCc6IGZ1bmN0aW9uIG1pc3Npb25zU2V0VGFrZU9mZlBvaW50KG1pc3Npb25JZCwgdGFrZU9mZlBvaW50KSB7XG4gICAgY2hlY2sobWlzc2lvbklkLCBTdHJpbmcpO1xuICAgIHRyeSB7XG4gICAgICBGZWF0dXJlUG9pbnQudmFsaWRhdGUodGFrZU9mZlBvaW50KTtcbiAgICAgIE1pc3Npb25zLnVwZGF0ZShtaXNzaW9uSWQsIHsgJHNldDogeyAnZmxpZ2h0UGxhbi50YWtlT2ZmUG9pbnQnOiB0YWtlT2ZmUG9pbnQgfSB9KTtcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIGlmIChleGNlcHRpb24uZXJyb3IgPT09ICd2YWxpZGF0aW9uLWVycm9yJykge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgZXhjZXB0aW9uLm1lc3NhZ2UpO1xuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICdtaXNzaW9ucy5zZXRMYW5kaW5nUG9pbnQnOiBmdW5jdGlvbiBtaXNzaW9uc1NldExhbmRpbmdQb2ludChtaXNzaW9uSWQsIGxhbmRpbmdQb2ludCkge1xuICAgIGNoZWNrKG1pc3Npb25JZCwgU3RyaW5nKTtcbiAgICB0cnkge1xuICAgICAgRmVhdHVyZVBvaW50LnZhbGlkYXRlKGxhbmRpbmdQb2ludCk7XG4gICAgICBNaXNzaW9ucy51cGRhdGUobWlzc2lvbklkLCB7ICRzZXQ6IHsgJ2ZsaWdodFBsYW4ubGFuZGluZ1BvaW50JzogbGFuZGluZ1BvaW50IH0gfSk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICBpZiAoZXhjZXB0aW9uLmVycm9yID09PSAndmFsaWRhdGlvbi1lcnJvcicpIHtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig1MDAsIGV4Y2VwdGlvbi5tZXNzYWdlKTtcbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxuICAnbWlzc2lvbnMuc2V0TWlzc2lvbkdlb21ldHJ5JzogZnVuY3Rpb24gbWlzc2lvbnNTZXRNaXNzaW9uR2VvbWV0cnkobWlzc2lvbklkLCBtaXNzaW9uR2VvbWV0cnkpIHtcbiAgICBjaGVjayhtaXNzaW9uSWQsIFN0cmluZyk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IG1pc3Npb24gPSBNaXNzaW9ucy5maW5kT25lKG1pc3Npb25JZCk7XG4gICAgICBpZiAobWlzc2lvbkdlb21ldHJ5KSB7XG4gICAgICAgIGlmIChtaXNzaW9uLm1pc3Npb25UeXBlID09PSAnU3VyZmFjZSBBcmVhJykge1xuICAgICAgICAgIEZlYXR1cmVQb2x5Z29uLnZhbGlkYXRlKG1pc3Npb25HZW9tZXRyeSk7XG4gICAgICAgICAgTWlzc2lvbnMudXBkYXRlKG1pc3Npb25JZCwgeyAkc2V0OiB7ICdmbGlnaHRQbGFuLm1pc3Npb25BcmVhJzogbWlzc2lvbkdlb21ldHJ5IH0gfSk7XG4gICAgICAgIH0gZWxzZSBpZiAobWlzc2lvbi5taXNzaW9uVHlwZSA9PT0gJ0xpbmVhciBBcmVhJykge1xuICAgICAgICAgIEZlYXR1cmVMaW5lU3RyaW5nLnZhbGlkYXRlKG1pc3Npb25HZW9tZXRyeSk7XG4gICAgICAgICAgTWlzc2lvbnMudXBkYXRlKG1pc3Npb25JZCwgeyAkc2V0OiB7ICdmbGlnaHRQbGFuLm1pc3Npb25BeGlzJzogbWlzc2lvbkdlb21ldHJ5IH0gfSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoIW1pc3Npb25HZW9tZXRyeSkge1xuICAgICAgICBpZiAobWlzc2lvbi5taXNzaW9uVHlwZSA9PT0gJ1N1cmZhY2UgQXJlYScpIHtcbiAgICAgICAgICBNaXNzaW9ucy51cGRhdGUobWlzc2lvbklkLCB7ICR1bnNldDogeyAnZmxpZ2h0UGxhbi5taXNzaW9uQXJlYSc6ICcnIH0gfSk7XG4gICAgICAgIH0gZWxzZSBpZiAobWlzc2lvbi5taXNzaW9uVHlwZSA9PT0gJ0xpbmVhciBBcmVhJykge1xuICAgICAgICAgIE1pc3Npb25zLnVwZGF0ZShtaXNzaW9uSWQsIHsgJHVuc2V0OiB7ICdmbGlnaHRQbGFuLm1pc3Npb25BeGlzJzogJycgfSB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgaWYgKGV4Y2VwdGlvbi5lcnJvciA9PT0gJ3ZhbGlkYXRpb24tZXJyb3InKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCBleGNlcHRpb24ubWVzc2FnZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ21pc3Npb25zLnNldEZsaWdodFBhcmFtcyc6IGZ1bmN0aW9uIG1pc3Npb25zU2V0RmxpZ2h0UGFyYW1zKG1pc3Npb25JZCwgZmxpZ2h0UGFyYW1ldGVycykge1xuICAgIGNoZWNrKG1pc3Npb25JZCwgU3RyaW5nKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZmxpZ2h0UGFyYW1zU2NoZW1hID0gTWlzc2lvbnMuc2NoZW1hLmdldE9iamVjdFNjaGVtYSgnZmxpZ2h0UGxhbi5mbGlnaHRQYXJhbWV0ZXJzJyk7XG4gICAgICBmbGlnaHRQYXJhbXNTY2hlbWEudmFsaWRhdGUoZmxpZ2h0UGFyYW1ldGVycyk7XG4gICAgICBNaXNzaW9ucy51cGRhdGUobWlzc2lvbklkLCB7XG4gICAgICAgICRzZXQ6IHsgJ2ZsaWdodFBsYW4uZmxpZ2h0UGFyYW1ldGVycyc6IGZsaWdodFBhcmFtZXRlcnMgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgaWYgKGV4Y2VwdGlvbi5lcnJvciA9PT0gJ3ZhbGlkYXRpb24tZXJyb3InKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCBleGNlcHRpb24ubWVzc2FnZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ21pc3Npb25zLnNldFBpY3R1cmVHcmlkJzogZnVuY3Rpb24gbWlzc2lvbnNTZXRQaWN0dXJlR3JpZChtaXNzaW9uSWQsIHBpY3R1cmVHcmlkKSB7XG4gICAgY2hlY2sobWlzc2lvbklkLCBTdHJpbmcpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBwaWN0dXJlR3JpZFNjaGVtYSA9IE1pc3Npb25zLnNjaGVtYS5nZXRPYmplY3RTY2hlbWEoJ2ZsaWdodFBsYW4ucGljdHVyZUdyaWQnKTtcbiAgICAgIHBpY3R1cmVHcmlkU2NoZW1hLnZhbGlkYXRlKHBpY3R1cmVHcmlkKTtcbiAgICAgIE1pc3Npb25zLnVwZGF0ZShtaXNzaW9uSWQsIHtcbiAgICAgICAgJHNldDogeyAnZmxpZ2h0UGxhbi5waWN0dXJlR3JpZCc6IHBpY3R1cmVHcmlkIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIGlmIChleGNlcHRpb24uZXJyb3IgPT09ICd2YWxpZGF0aW9uLWVycm9yJykge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgZXhjZXB0aW9uLm1lc3NhZ2UpO1xuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG5cbiAgJ21pc3Npb25zLnNldE1pc3Npb25DYWxjdWxhdGlvbnMnOiBmdW5jdGlvbiBtaXNzaW9uc1NldE1pc3Npb25DYWxjdWxhdGlvbnMobWlzc2lvbklkLCBtaXNzaW9uQ2FsY3VsYXRpb25zRGF0YSkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBtaXNzaW9uQ2FsY3VsYXRlZERhdGFTY2hlbWEgPSBNaXNzaW9ucy5zY2hlbWEuZ2V0T2JqZWN0U2NoZW1hKCdmbGlnaHRQbGFuLm1pc3Npb25DYWxjdWxhdGlvbi5taXNzaW9uQ2FsY3VsYXRlZERhdGEnKTtcbiAgICAgIG1pc3Npb25DYWxjdWxhdGVkRGF0YVNjaGVtYS52YWxpZGF0ZShtaXNzaW9uQ2FsY3VsYXRpb25zRGF0YS5taXNzaW9uQ2FsY3VsYXRlZERhdGEpO1xuICAgICAgRmVhdHVyZUNvbGxlY3Rpb25Qb2ludHMudmFsaWRhdGUobWlzc2lvbkNhbGN1bGF0aW9uc0RhdGEud2F5cG9pbnRMaXN0KTtcblxuICAgICAgTWlzc2lvbnMudXBkYXRlKG1pc3Npb25JZCwge1xuICAgICAgICAkc2V0OiB7ICdmbGlnaHRQbGFuLm1pc3Npb25DYWxjdWxhdGlvbic6IG1pc3Npb25DYWxjdWxhdGlvbnNEYXRhIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIGlmIChleGNlcHRpb24uZXJyb3IgPT09ICd2YWxpZGF0aW9uLWVycm9yJykge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgZXhjZXB0aW9uLm1lc3NhZ2UpO1xuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICdtaXNzaW9ucy5lZGl0V2F5UG9pbnRMaXN0JzogZnVuY3Rpb24gbWlzc2lvbnNFZGl0V2F5cG9pbnRMaXN0KG1pc3Npb25JZCwgbmV3V2F5UG9pbnRMaXN0KSB7XG4gICAgY2hlY2sobWlzc2lvbklkLCBTdHJpbmcpO1xuICAgIHRyeSB7XG4gICAgICBGZWF0dXJlQ29sbGVjdGlvblBvaW50cy52YWxpZGF0ZShuZXdXYXlQb2ludExpc3QpO1xuICAgICAgTWlzc2lvbnMudXBkYXRlKG1pc3Npb25JZCwge1xuICAgICAgICAkc2V0OiB7ICdmbGlnaHRQbGFuLm1pc3Npb25DYWxjdWxhdGlvbi53YXlwb2ludExpc3QnOiBuZXdXYXlQb2ludExpc3QgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgaWYgKGV4Y2VwdGlvbi5lcnJvciA9PT0gJ3ZhbGlkYXRpb24tZXJyb3InKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCBleGNlcHRpb24ubWVzc2FnZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ21pc3Npb25zLmNsZWFyV2F5UG9pbnRzJzogZnVuY3Rpb24gbWlzc2lvbnNDbGVhcldheVBvaW50cyhtaXNzaW9uSWQpIHtcbiAgICB0cnkge1xuICAgICAgTWlzc2lvbnMudXBkYXRlKG1pc3Npb25JZCwgeyAkdW5zZXQ6IHsgJ2ZsaWdodFBsYW4udGFrZU9mZlBvaW50JzogJycgfSB9KTtcbiAgICAgIE1pc3Npb25zLnVwZGF0ZShtaXNzaW9uSWQsIHsgJHVuc2V0OiB7ICdmbGlnaHRQbGFuLmxhbmRpbmdQb2ludCc6ICcnIH0gfSk7XG4gICAgICBNaXNzaW9ucy51cGRhdGUobWlzc2lvbklkLCB7ICR1bnNldDogeyAnZmxpZ2h0UGxhbi5taXNzaW9uQXJlYSc6ICcnIH0gfSk7XG4gICAgICBNaXNzaW9ucy51cGRhdGUobWlzc2lvbklkLCB7ICR1bnNldDogeyAnZmxpZ2h0UGxhbi5taXNzaW9uQXhpcyc6ICcnIH0gfSk7XG4gICAgICBNaXNzaW9ucy51cGRhdGUobWlzc2lvbklkLCB7ICR1bnNldDogeyAnZmxpZ2h0UGxhbi5taXNzaW9uQ2FsY3VsYXRpb24nOiAnJyB9IH0pO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgaWYgKGV4Y2VwdGlvbi5lcnJvciA9PT0gJ3ZhbGlkYXRpb24tZXJyb3InKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCBleGNlcHRpb24ubWVzc2FnZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ21pc3Npb25zLmVkaXRXYXlQb2ludEFsdFJlbGF0aXZlJzogZnVuY3Rpb24gbWlzc2lvbnNFZGl0V2F5cG9pbnRMaXN0KG1pc3Npb25JZCwgd2F5cG9pbnRJbmRleCwgbmV3V2F5UG9pbnRBbHRSZWxhdGl2ZSkge1xuICAgIGNoZWNrKG1pc3Npb25JZCwgU3RyaW5nKTtcbiAgICBjaGVjayh3YXlwb2ludEluZGV4LCBOdW1iZXIpO1xuICAgIGNoZWNrKG5ld1dheVBvaW50QWx0UmVsYXRpdmUsIE51bWJlcik7XG4gICAgdHJ5IHtcbiAgICAgIE1pc3Npb25zLnVwZGF0ZShcbiAgICAgICAgeyBfaWQ6IG1pc3Npb25JZCwgJ2ZsaWdodFBsYW4ubWlzc2lvbkNhbGN1bGF0aW9uLndheXBvaW50TGlzdC5mZWF0dXJlcy5wcm9wZXJ0aWVzLnRvdGFsTnVtYmVyJzogd2F5cG9pbnRJbmRleCB9LFxuICAgICAgICB7ICRzZXQ6IHsgJ2ZsaWdodFBsYW4ubWlzc2lvbkNhbGN1bGF0aW9uLndheXBvaW50TGlzdC5mZWF0dXJlcy4kLnByb3BlcnRpZXMuYWx0UmVsYXRpdmUnOiBuZXdXYXlQb2ludEFsdFJlbGF0aXZlIH0gfSxcbiAgICAgICk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICBpZiAoZXhjZXB0aW9uLmVycm9yID09PSAndmFsaWRhdGlvbi1lcnJvcicpIHtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig1MDAsIGV4Y2VwdGlvbi5tZXNzYWdlKTtcbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxuICAnbWlzc2lvbnMuc2V0TGFuZGluZ0JlYXJpbmcnOiBmdW5jdGlvbiBtaXNzaW9uc1NldExhbmRpbmdCZWFyaW5nKG1pc3Npb25JZCwgbGFuZGluZ0JlYXJpbmcpIHtcbiAgICBjaGVjayhtaXNzaW9uSWQsIFN0cmluZyk7XG4gICAgdHJ5IHtcbiAgICAgIGlmIChsYW5kaW5nQmVhcmluZykge1xuICAgICAgICBGZWF0dXJlTGluZVN0cmluZy52YWxpZGF0ZShsYW5kaW5nQmVhcmluZyk7XG4gICAgICAgIE1pc3Npb25zLnVwZGF0ZShtaXNzaW9uSWQsIHsgJHNldDogeyAnZmxpZ2h0UGxhbi5sYW5kaW5nQmVhcmluZyc6IGxhbmRpbmdCZWFyaW5nIH0gfSk7XG4gICAgICB9IGVsc2UgaWYgKCFsYW5kaW5nQmVhcmluZykge1xuICAgICAgICBNaXNzaW9ucy51cGRhdGUobWlzc2lvbklkLCB7ICR1bnNldDogeyAnZmxpZ2h0UGxhbi5sYW5kaW5nQmVhcmluZyc6ICcnIH0gfSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICBpZiAoZXhjZXB0aW9uLmVycm9yID09PSAndmFsaWRhdGlvbi1lcnJvcicpIHtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig1MDAsIGV4Y2VwdGlvbi5tZXNzYWdlKTtcbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxufSk7XG5cbnJhdGVMaW1pdCh7XG4gIG1ldGhvZHM6IFtcbiAgICAnbWlzc2lvbnMuaW5zZXJ0JyxcbiAgICAnbWlzc2lvbnMuaW1wb3J0JyxcbiAgICAnbWlzc2lvbnMudXBkYXRlJyxcbiAgICAnbWlzc2lvbnMuc29mdERlbGV0ZScsXG4gICAgJ21pc3Npb25zLnJlc3RvcmUnLFxuICAgICdtaXNzaW9ucy5oYXJkRGVsZXRlJyxcbiAgICAnbWlzc2lvbnMuc2V0RG9uZScsXG4gICAgJ21pc3Npb25zLnNldExhbmRpbmdQb2ludCcsXG4gICAgJ21pc3Npb25zLnNldFRha2VPZmZQb2ludCcsXG4gICAgJ21pc3Npb25zLnNldE1pc3Npb25HZW9tZXRyeScsXG4gICAgJ21pc3Npb25zLnNldEZsaWdodFBhcmFtcycsXG4gICAgJ21pc3Npb25zLnNldFBpY3R1cmVHcmlkJyxcbiAgICAnbWlzc2lvbnMuc2V0TWlzc2lvbkNhbGN1bGF0aW9ucycsXG4gICAgJ21pc3Npb25zLmVkaXRXYXlQb2ludExpc3QnLFxuICAgICdtaXNzaW9ucy5jbGVhcldheVBvaW50cycsXG4gICAgJ21pc3Npb25zLmVkaXRXYXlQb2ludEFsdFJlbGF0aXZlJyxcbiAgICAnbWlzc2lvbnMuc2V0TGFuZGluZ0JlYXJpbmcnLFxuICBdLFxuICBsaW1pdDogNSxcbiAgdGltZVJhbmdlOiAxMDAwLFxufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCB7IFNlcnZpY2VDb25maWd1cmF0aW9uIH0gZnJvbSAnbWV0ZW9yL3NlcnZpY2UtY29uZmlndXJhdGlvbic7XG5pbXBvcnQgcmF0ZUxpbWl0IGZyb20gJy4uLy4uLy4uL21vZHVsZXMvcmF0ZS1saW1pdCc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgJ29hdXRoLnZlcmlmeUNvbmZpZ3VyYXRpb24nOiBmdW5jdGlvbiBvYXV0aFZlcmlmeUNvbmZpZ3VyYXRpb24oc2VydmljZXMpIHtcbiAgICBjaGVjayhzZXJ2aWNlcywgQXJyYXkpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHZlcmlmaWVkU2VydmljZXMgPSBbXTtcbiAgICAgIHNlcnZpY2VzLmZvckVhY2goKHNlcnZpY2UpID0+IHtcbiAgICAgICAgaWYgKFNlcnZpY2VDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zLmZpbmRPbmUoeyBzZXJ2aWNlIH0pKSB7XG4gICAgICAgICAgdmVyaWZpZWRTZXJ2aWNlcy5wdXNoKHNlcnZpY2UpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHJldHVybiB2ZXJpZmllZFNlcnZpY2VzLnNvcnQoKTtcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxufSk7XG5cbnJhdGVMaW1pdCh7XG4gIG1ldGhvZHM6IFtcbiAgICAnb2F1dGgudmVyaWZ5Q29uZmlndXJhdGlvbicsXG4gIF0sXG4gIGxpbWl0OiA1LFxuICB0aW1lUmFuZ2U6IDEwMDAsXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IFBheWxvYWRzIGZyb20gJy4uL1BheWxvYWRzJztcblxuTWV0ZW9yLnB1Ymxpc2goJ3BheWxvYWRzJywgZnVuY3Rpb24gcGF5bG9hZHMoKSB7XG4gIHJldHVybiBQYXlsb2Fkcy5maW5kKHsgb3duZXI6IHRoaXMudXNlcklkIH0pO1xufSk7XG5cbi8vIE5vdGU6IHBheWxvYWRzLnZpZXcgaXMgYWxzbyB1c2VkIHdoZW4gZWRpdGluZyBhbiBleGlzdGluZyBkb2N1bWVudC5cbk1ldGVvci5wdWJsaXNoKCdwYXlsb2Fkcy52aWV3JywgZnVuY3Rpb24gcGF5bG9hZHNWaWV3KHBheWxvYWRJZCkge1xuICBjaGVjayhwYXlsb2FkSWQsIFN0cmluZyk7XG4gIHJldHVybiBQYXlsb2Fkcy5maW5kKHsgX2lkOiBwYXlsb2FkSWQsIG93bmVyOiB0aGlzLnVzZXJJZCB9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgncGF5bG9hZHMubWlzc2lvbicsIGZ1bmN0aW9uIHBheWxvYWRzTWlzc2lvbigpIHtcbiAgcmV0dXJuIFBheWxvYWRzLmZpbmQoeyBvd25lcjogdGhpcy51c2VySWQgfSwge1xuICAgIGZpZWxkczogeyBuYW1lOiAxLCBtb2RlbDogMSB9LFxuICB9KTtcbn0pO1xuIiwiLyogZXNsaW50LWRpc2FibGUgY29uc2lzdGVudC1yZXR1cm4gKi9cblxuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuXG5jb25zdCBQYXlsb2FkcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdQYXlsb2FkcycpO1xuXG5QYXlsb2Fkcy5hbGxvdyh7XG4gIGluc2VydDogKCkgPT4gZmFsc2UsXG4gIHVwZGF0ZTogKCkgPT4gZmFsc2UsXG4gIHJlbW92ZTogKCkgPT4gZmFsc2UsXG59KTtcblxuUGF5bG9hZHMuZGVueSh7XG4gIGluc2VydDogKCkgPT4gdHJ1ZSxcbiAgdXBkYXRlOiAoKSA9PiB0cnVlLFxuICByZW1vdmU6ICgpID0+IHRydWUsXG59KTtcblxuY29uc3QgY2FtZXJhUGFyYW1ldGVyc1NjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICBmb2NhbExlbmd0aDoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgICBsYWJlbDogJ1RoZSBmb2NhbCBsZW5ndGggb2YgdGhlIGNhbWVyYSBpbiBtaWxpbWV0ZXJzJyxcbiAgICBtaW46IDEsXG4gIH0sXG4gIHNlbnNvcldpZHRoOiB7XG4gICAgdHlwZTogTnVtYmVyLFxuICAgIGxhYmVsOiAnVGhlIHNlbnNvciB3aWR0aCBpbiBtaWxpbWV0ZXJzJyxcbiAgICBtaW46IDEsXG4gIH0sXG4gIHNlbnNvckhlaWdodDoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgICBsYWJlbDogJ1RoZSBzZW5zb3IgaGVpZ2h0IGluIG1pbGltZXRlcnMnLFxuICAgIG1pbjogMSxcbiAgfSxcbiAgaW1hZ2VXaWR0aDoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgICBsYWJlbDogJ1RoZSBpbWFnZSB3aWR0aCBpbiBwaXhlbHMnLFxuICAgIG1pbjogMSxcbiAgfSxcbiAgaW1hZ2VIZWlnaHQ6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgbGFiZWw6ICdUaGUgaW1hZ2UgaGVpZ2h0IGluIHBpeGVscycsXG4gICAgbWluOiAxLFxuICB9LFxufSk7XG5cblBheWxvYWRzLnNjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICBvd25lcjoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBJRCBvZiB0aGUgdXNlciB0aGlzIHBheWxvYWQgYmVsb25ncyB0by4nLFxuICB9LFxuICBjcmVhdGVkQXQ6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdUaGUgZGF0ZSB0aGlzIHBheWxvYWQgd2FzIGNyZWF0ZWQuJyxcbiAgICBhdXRvVmFsdWUoKSB7XG4gICAgICBpZiAodGhpcy5pc0luc2VydCkgcmV0dXJuIChuZXcgRGF0ZSgpKS50b0lTT1N0cmluZygpO1xuICAgIH0sXG4gIH0sXG4gIHVwZGF0ZWRBdDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBkYXRlIHRoaXMgcGF5bG9hZCB3YXMgbGFzdCB1cGRhdGVkLicsXG4gICAgYXV0b1ZhbHVlKCkge1xuICAgICAgaWYgKHRoaXMuaXNJbnNlcnQgfHwgdGhpcy5pc1VwZGF0ZSkgcmV0dXJuIChuZXcgRGF0ZSgpKS50b0lTT1N0cmluZygpO1xuICAgIH0sXG4gIH0sXG4gIG5hbWU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdBIG5hbWUgdG8gaWRlbnRpZnkgdGhlIHBheWxvYWQuJyxcbiAgfSxcbiAgcmVnaXN0cmF0aW9uTnVtYmVyOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIHNlcmlhbCBudW1iZXIgdG8gaWRlbnRpZnkgdGhlIHBheWxvYWQuJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgbW9kZWw6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdUaGUgbW9kZWwgb2YgdGhlIHBheWxvYWQuJyxcbiAgfSxcbiAgd2VpZ2h0OiB7XG4gICAgdHlwZTogTnVtYmVyLFxuICAgIGxhYmVsOiAnVGhlIHdlaWdodCBvZiB0aGlzIHBheWxvYWQgaW4gZ3JhbXMuJyxcbiAgICBtaW46IDAsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gIHBheWxvYWRUeXBlOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGFsbG93ZWRWYWx1ZXM6IFsnQ2FtZXJhJ10sXG4gICAgbGFiZWw6ICdUaGUgdHlwZSBvZiBzZW5zb3Igb2YgdGhlIHBheWxvYWQuJyxcbiAgfSxcbiAgZGVsZXRlZDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBkYXRlIHRoZSBwYXlsb2FkIHdhcyBkZWxldGVkLicsXG4gICAgYXV0b1ZhbHVlKCkge1xuICAgICAgaWYgKHRoaXMuaXNJbnNlcnQpIHJldHVybiAnbm8nO1xuICAgIH0sXG4gIH0sXG4gIHNlbnNvclBhcmFtZXRlcnM6IHtcbiAgICB0eXBlOiBTaW1wbGVTY2hlbWEub25lT2YoY2FtZXJhUGFyYW1ldGVyc1NjaGVtYSksXG4gICAgbGFiZWw6ICdUaGUgcGFyYW1ldGVycyBmb3IgdGhlIHBheWxvYWQgc2Vuc29yLicsXG4gIH0sXG59KTtcblxuUGF5bG9hZHMuYXR0YWNoU2NoZW1hKFBheWxvYWRzLnNjaGVtYSk7XG5cbmV4cG9ydCBkZWZhdWx0IFBheWxvYWRzO1xuIiwiLyogZXNsaW50LWRpc2FibGUgbWV0ZW9yL2F1ZGl0LWFyZ3VtZW50LWNoZWNrcyAqL1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgUGF5bG9hZHMgZnJvbSAnLi9QYXlsb2Fkcyc7XG5pbXBvcnQgcmF0ZUxpbWl0IGZyb20gJy4uLy4uL21vZHVsZXMvcmF0ZS1saW1pdCc7XG5cbmNvbnN0IG5ld1BheWxvYWRTY2hlbWEgPSBQYXlsb2Fkcy5zY2hlbWEucGljaygnbmFtZScsICdyZWdpc3RyYXRpb25OdW1iZXInLCAnbW9kZWwnLCAnd2VpZ2h0JywgJ3BheWxvYWRUeXBlJywgJ3NlbnNvclBhcmFtZXRlcnMnKTtcblxuY29uc3QgZWRpdFBheWxvYWRTY2hlbWEgPSBQYXlsb2Fkcy5zY2hlbWEucGljaygnbmFtZScsICdyZWdpc3RyYXRpb25OdW1iZXInLCAnbW9kZWwnLCAnd2VpZ2h0JywgJ3BheWxvYWRUeXBlJywgJ3NlbnNvclBhcmFtZXRlcnMnKTtcbmVkaXRQYXlsb2FkU2NoZW1hLmV4dGVuZCh7IF9pZDogU3RyaW5nIH0pO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICdwYXlsb2Fkcy5pbnNlcnQnOiBmdW5jdGlvbiBwYXlsb2Fkc0luc2VydChwYXlsb2FkKSB7XG4gICAgdHJ5IHtcbiAgICAgIG5ld1BheWxvYWRTY2hlbWEudmFsaWRhdGUocGF5bG9hZCk7XG4gICAgICByZXR1cm4gUGF5bG9hZHMuaW5zZXJ0KHsgb3duZXI6IHRoaXMudXNlcklkLCAuLi5wYXlsb2FkIH0pO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgaWYgKGV4Y2VwdGlvbi5lcnJvciA9PT0gJ3ZhbGlkYXRpb24tZXJyb3InKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCBleGNlcHRpb24ubWVzc2FnZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ3BheWxvYWRzLnVwZGF0ZSc6IGZ1bmN0aW9uIHBheWxvYWRzVXBkYXRlKHBheWxvYWQpIHtcbiAgICB0cnkge1xuICAgICAgZWRpdFBheWxvYWRTY2hlbWEudmFsaWRhdGUocGF5bG9hZCk7XG4gICAgICBjb25zdCBwYXlsb2FkSWQgPSBwYXlsb2FkLl9pZDtcbiAgICAgIFBheWxvYWRzLnVwZGF0ZShwYXlsb2FkSWQsIHsgJHNldDogcGF5bG9hZCB9KTtcbiAgICAgIHJldHVybiBwYXlsb2FkSWQ7XG4gICAgICAvLyBSZXR1cm4gX2lkIHNvIHdlIGNhbiByZWRpcmVjdCB0byBwYXlsb2FkIGFmdGVyIHVwZGF0ZS5cbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIGlmIChleGNlcHRpb24uZXJyb3IgPT09ICd2YWxpZGF0aW9uLWVycm9yJykge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgZXhjZXB0aW9uLm1lc3NhZ2UpO1xuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICdwYXlsb2Fkcy5zb2Z0RGVsZXRlJzogZnVuY3Rpb24gcGF5bG9hZHNTb2Z0RGVsZXRlKHBheWxvYWRJZCkge1xuICAgIGNoZWNrKHBheWxvYWRJZCwgU3RyaW5nKTtcbiAgICB0cnkge1xuICAgICAgUGF5bG9hZHMudXBkYXRlKHBheWxvYWRJZCwgeyAkc2V0OiB7IGRlbGV0ZWQ6IChuZXcgRGF0ZSgpKS50b0lTT1N0cmluZygpIH0gfSk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ3BheWxvYWRzLnJlc3RvcmUnOiBmdW5jdGlvbiBwYXlsb2Fkc1Jlc3RvcmUocGF5bG9hZElkKSB7XG4gICAgY2hlY2socGF5bG9hZElkLCBTdHJpbmcpO1xuICAgIHRyeSB7XG4gICAgICBQYXlsb2Fkcy51cGRhdGUocGF5bG9hZElkLCB7ICRzZXQ6IHsgZGVsZXRlZDogJ25vJyB9IH0pO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICdwYXlsb2Fkcy5oYXJkRGVsZXRlJzogZnVuY3Rpb24gcGF5bG9hZHNIYXJkRGVsZXRlKHBheWxvYWRJZCkge1xuICAgIGNoZWNrKHBheWxvYWRJZCwgU3RyaW5nKTtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIFBheWxvYWRzLnJlbW92ZShwYXlsb2FkSWQpO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG59KTtcblxucmF0ZUxpbWl0KHtcbiAgbWV0aG9kczogW1xuICAgICdwYXlsb2Fkcy5pbnNlcnQnLFxuICAgICdwYXlsb2Fkcy51cGRhdGUnLFxuICAgICdwYXlsb2Fkcy5zb2Z0RGVsZXRlJyxcbiAgICAncGF5bG9hZHMucmVzdG9yZScsXG4gICAgJ3BheWxvYWRzLmhhcmREZWxldGUnLFxuICBdLFxuICBsaW1pdDogNSxcbiAgdGltZVJhbmdlOiAxMDAwLFxufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCBQcm9qZWN0cyBmcm9tICcuLi9Qcm9qZWN0cyc7XG5cbk1ldGVvci5wdWJsaXNoKCdwcm9qZWN0cycsIGZ1bmN0aW9uIHByb2plY3RzKCkge1xuICByZXR1cm4gUHJvamVjdHMuZmluZCh7IG93bmVyOiB0aGlzLnVzZXJJZCB9KTtcbn0pO1xuXG4vLyBOb3RlOiBwcm9qZWN0cy52aWV3IGlzIGFsc28gdXNlZCB3aGVuIGVkaXRpbmcgYW4gZXhpc3RpbmcgZG9jdW1lbnQuXG5NZXRlb3IucHVibGlzaCgncHJvamVjdHMudmlldycsIGZ1bmN0aW9uIHByb2plY3RzVmlldyhwcm9qZWN0SWQpIHtcbiAgY2hlY2socHJvamVjdElkLCBTdHJpbmcpO1xuICByZXR1cm4gUHJvamVjdHMuZmluZCh7IF9pZDogcHJvamVjdElkLCBvd25lcjogdGhpcy51c2VySWQgfSk7XG59KTtcbiIsIi8qIGVzbGludC1kaXNhYmxlIGNvbnNpc3RlbnQtcmV0dXJuICovXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5pbXBvcnQgeyBGZWF0dXJlUG9pbnQgfSBmcm9tICcuLi9TY2hlbWFVdGlsaXRpZXMvR2VvSlNPTlNjaGVtYS5qcyc7XG5cbmNvbnN0IFByb2plY3RzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ1Byb2plY3RzJyk7XG5cblByb2plY3RzLmFsbG93KHtcbiAgaW5zZXJ0OiAoKSA9PiBmYWxzZSxcbiAgdXBkYXRlOiAoKSA9PiBmYWxzZSxcbiAgcmVtb3ZlOiAoKSA9PiBmYWxzZSxcbn0pO1xuXG5Qcm9qZWN0cy5kZW55KHtcbiAgaW5zZXJ0OiAoKSA9PiB0cnVlLFxuICB1cGRhdGU6ICgpID0+IHRydWUsXG4gIHJlbW92ZTogKCkgPT4gdHJ1ZSxcbn0pO1xuXG5Qcm9qZWN0cy5zY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgb3duZXI6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdUaGUgSUQgb2YgdGhlIHVzZXIgdGhpcyBwcm9qZWN0IGJlbG9uZ3MgdG8uJyxcbiAgfSxcbiAgY3JlYXRlZEF0OiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIGRhdGUgdGhpcyBwcm9qZWN0IHdhcyBjcmVhdGVkLicsXG4gICAgYXV0b1ZhbHVlKCkge1xuICAgICAgaWYgKHRoaXMuaXNJbnNlcnQpIHJldHVybiAobmV3IERhdGUoKSkudG9JU09TdHJpbmcoKTtcbiAgICB9LFxuICB9LFxuICB1cGRhdGVkQXQ6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdUaGUgZGF0ZSB0aGlzIHByb2plY3Qgd2FzIGxhc3QgdXBkYXRlZC4nLFxuICAgIGF1dG9WYWx1ZSgpIHtcbiAgICAgIGlmICh0aGlzLmlzSW5zZXJ0IHx8IHRoaXMuaXNVcGRhdGUpIHJldHVybiAobmV3IERhdGUoKSkudG9JU09TdHJpbmcoKTtcbiAgICB9LFxuICB9LFxuICBuYW1lOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIG5hbWUgb2YgdGhlIHByb2plY3QuJyxcbiAgfSxcbiAgZGVzY3JpcHRpb246IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gICAgbGFiZWw6ICdUaGUgZGVzY3JpcHRpb24gb2YgdGhlIHByb2plY3QuJyxcbiAgfSxcbiAgbWFwTG9jYXRpb246IHtcbiAgICB0eXBlOiBGZWF0dXJlUG9pbnQsXG4gICAgbGFiZWw6ICdUaGUgbG9jYXRpb24gb2YgdGhlIHByb2plY3QgZm9yIHRoZSBtYXAuJyxcbiAgfSxcbiAgZGVsZXRlZDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBkYXRlIHRoZSBwcm9qZWN0IHdhcyBkZWxldGVkLicsXG4gICAgYXV0b1ZhbHVlKCkge1xuICAgICAgaWYgKHRoaXMuaXNJbnNlcnQpIHJldHVybiAnbm8nO1xuICAgIH0sXG4gIH0sXG4gIGRvbmU6IHtcbiAgICB0eXBlOiBCb29sZWFuLFxuICAgIGxhYmVsOiAnSXMgdGhlIHByb2plY3QgZG9uZT8nLFxuICAgIGF1dG9WYWx1ZSgpIHtcbiAgICAgIGlmICh0aGlzLmlzSW5zZXJ0KSByZXR1cm4gZmFsc2U7XG4gICAgfSxcbiAgfSxcbn0pO1xuXG5Qcm9qZWN0cy5hdHRhY2hTY2hlbWEoUHJvamVjdHMuc2NoZW1hKTtcblxuZXhwb3J0IGRlZmF1bHQgUHJvamVjdHM7XG4iLCIvKiBlc2xpbnQtZGlzYWJsZSBtZXRlb3IvYXVkaXQtYXJndW1lbnQtY2hlY2tzICovXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCBQcm9qZWN0cyBmcm9tICcuL1Byb2plY3RzJztcbmltcG9ydCByYXRlTGltaXQgZnJvbSAnLi4vLi4vbW9kdWxlcy9yYXRlLWxpbWl0JztcblxuY29uc3QgbmV3UHJvamVjdFNjaGVtYSA9IFByb2plY3RzLnNjaGVtYS5waWNrKCduYW1lJywgJ2Rlc2NyaXB0aW9uJywgJ21hcExvY2F0aW9uJyk7XG5cbmNvbnN0IGVkaXRQcm9qZWN0U2NoZW1hID0gUHJvamVjdHMuc2NoZW1hLnBpY2soJ25hbWUnLCAnZGVzY3JpcHRpb24nLCAnbWFwTG9jYXRpb24nKTtcbmVkaXRQcm9qZWN0U2NoZW1hLmV4dGVuZCh7IF9pZDogU3RyaW5nIH0pO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICdwcm9qZWN0cy5pbnNlcnQnOiBmdW5jdGlvbiBwcm9qZWN0c0luc2VydChwcm9qZWN0KSB7XG4gICAgdHJ5IHtcbiAgICAgIG5ld1Byb2plY3RTY2hlbWEudmFsaWRhdGUocHJvamVjdCk7XG4gICAgICByZXR1cm4gUHJvamVjdHMuaW5zZXJ0KHsgb3duZXI6IHRoaXMudXNlcklkLCAuLi5wcm9qZWN0IH0pO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgaWYgKGV4Y2VwdGlvbi5lcnJvciA9PT0gJ3ZhbGlkYXRpb24tZXJyb3InKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCBleGNlcHRpb24ubWVzc2FnZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ3Byb2plY3RzLnVwZGF0ZSc6IGZ1bmN0aW9uIHByb2plY3RzVXBkYXRlKHByb2plY3QpIHtcbiAgICB0cnkge1xuICAgICAgZWRpdFByb2plY3RTY2hlbWEudmFsaWRhdGUocHJvamVjdCk7XG4gICAgICBjb25zdCBwcm9qZWN0SWQgPSBwcm9qZWN0Ll9pZDtcbiAgICAgIFByb2plY3RzLnVwZGF0ZShwcm9qZWN0SWQsIHsgJHNldDogcHJvamVjdCB9KTtcbiAgICAgIHJldHVybiBwcm9qZWN0SWQ7XG4gICAgICAvLyBSZXR1cm4gX2lkIHNvIHdlIGNhbiByZWRpcmVjdCB0byBwcm9qZWN0IGFmdGVyIHVwZGF0ZS5cbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIGlmIChleGNlcHRpb24uZXJyb3IgPT09ICd2YWxpZGF0aW9uLWVycm9yJykge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgZXhjZXB0aW9uLm1lc3NhZ2UpO1xuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICdwcm9qZWN0cy5zb2Z0RGVsZXRlJzogZnVuY3Rpb24gcHJvamVjdHNTb2Z0RGVsZXRlKHByb2plY3RJZCkge1xuICAgIGNoZWNrKHByb2plY3RJZCwgU3RyaW5nKTtcbiAgICB0cnkge1xuICAgICAgUHJvamVjdHMudXBkYXRlKHByb2plY3RJZCwgeyAkc2V0OiB7IGRlbGV0ZWQ6IChuZXcgRGF0ZSgpKS50b0lTT1N0cmluZygpIH0gfSk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ3Byb2plY3RzLnJlc3RvcmUnOiBmdW5jdGlvbiBwcm9qZWN0c1Jlc3RvcmUocHJvamVjdElkKSB7XG4gICAgY2hlY2socHJvamVjdElkLCBTdHJpbmcpO1xuICAgIHRyeSB7XG4gICAgICBQcm9qZWN0cy51cGRhdGUocHJvamVjdElkLCB7ICRzZXQ6IHsgZGVsZXRlZDogJ25vJyB9IH0pO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICdwcm9qZWN0cy5oYXJkRGVsZXRlJzogZnVuY3Rpb24gcHJvamVjdHNIYXJkRGVsZXRlKHByb2plY3RJZCkge1xuICAgIGNoZWNrKHByb2plY3RJZCwgU3RyaW5nKTtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIFByb2plY3RzLnJlbW92ZShwcm9qZWN0SWQpO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICdwcm9qZWN0cy5zZXREb25lJzogZnVuY3Rpb24gcHJvamVjdHNTZXREb25lKHByb2plY3RJZCwgc2V0RG9uZSkge1xuICAgIGNoZWNrKHByb2plY3RJZCwgU3RyaW5nKTtcbiAgICBjaGVjayhzZXREb25lLCBCb29sZWFuKTtcbiAgICB0cnkge1xuICAgICAgUHJvamVjdHMudXBkYXRlKHByb2plY3RJZCwgeyAkc2V0OiB7IGRvbmU6IHNldERvbmUgfSB9KTtcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxufSk7XG5cbnJhdGVMaW1pdCh7XG4gIG1ldGhvZHM6IFtcbiAgICAncHJvamVjdHMuaW5zZXJ0JyxcbiAgICAncHJvamVjdHMudXBkYXRlJyxcbiAgICAncHJvamVjdHMuc29mdERlbGV0ZScsXG4gICAgJ3Byb2plY3RzLnJlc3RvcmUnLFxuICAgICdwcm9qZWN0cy5oYXJkRGVsZXRlJyxcbiAgICAncHJvamVjdHMuc2V0RG9uZScsXG4gIF0sXG4gIGxpbWl0OiA1LFxuICB0aW1lUmFuZ2U6IDEwMDAsXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IFJQQXMgZnJvbSAnLi4vUlBBcyc7XG5cbk1ldGVvci5wdWJsaXNoKCdycGFzJywgZnVuY3Rpb24gcnBhcygpIHtcbiAgcmV0dXJuIFJQQXMuZmluZCh7IG93bmVyOiB0aGlzLnVzZXJJZCB9KTtcbn0pO1xuXG4vLyBOb3RlOiBkb2N1bWVudHMudmlldyBpcyBhbHNvIHVzZWQgd2hlbiBlZGl0aW5nIGFuIGV4aXN0aW5nIGRvY3VtZW50LlxuTWV0ZW9yLnB1Ymxpc2goJ3JwYXMudmlldycsIGZ1bmN0aW9uIHJwYXNWaWV3KHJwYUlkKSB7XG4gIGNoZWNrKHJwYUlkLCBTdHJpbmcpO1xuICByZXR1cm4gUlBBcy5maW5kKHsgX2lkOiBycGFJZCwgb3duZXI6IHRoaXMudXNlcklkIH0pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCdycGFzLm1pc3Npb24nLCBmdW5jdGlvbiBycGFzTWlzc2lvbigpIHtcbiAgcmV0dXJuIFJQQXMuZmluZCh7IG93bmVyOiB0aGlzLnVzZXJJZCB9LCB7XG4gICAgZmllbGRzOiB7IG5hbWU6IDEsIHJwYVR5cGU6IDEgfSxcbiAgfSk7XG59KTtcbiIsIi8qIGVzbGludC1kaXNhYmxlIGNvbnNpc3RlbnQtcmV0dXJuICovXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5cbmNvbnN0IFJQQXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignUlBBcycpO1xuXG5SUEFzLmFsbG93KHtcbiAgaW5zZXJ0OiAoKSA9PiBmYWxzZSxcbiAgdXBkYXRlOiAoKSA9PiBmYWxzZSxcbiAgcmVtb3ZlOiAoKSA9PiBmYWxzZSxcbn0pO1xuXG5SUEFzLmRlbnkoe1xuICBpbnNlcnQ6ICgpID0+IHRydWUsXG4gIHVwZGF0ZTogKCkgPT4gdHJ1ZSxcbiAgcmVtb3ZlOiAoKSA9PiB0cnVlLFxufSk7XG5cbmNvbnN0IGZsaWdodFBhcmFtZXRlcnNTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgbWF4RGVzY2VuZFNsb3BlOiB7XG4gICAgdHlwZTogU2ltcGxlU2NoZW1hLkludGVnZXIsXG4gICAgbGFiZWw6ICdUaGUgbWF4IHNsb3BlIGZvciB0aGUgZGVzY2VuZCBvZiB0aGUgcnBhcyBpbiAlJyxcbiAgICBtaW46IDAsXG4gICAgbWF4OiAxMDAsXG4gIH0sXG4gIG1heEFzY2VuZFNsb3BlOiB7XG4gICAgdHlwZTogU2ltcGxlU2NoZW1hLkludGVnZXIsXG4gICAgbGFiZWw6ICdUaGUgbWF4IHNsb3BlIGZvciB0aGUgZGVzY2VuZCBvZiB0aGUgcnBhcyBpbiAlJyxcbiAgICBtaW46IDAsXG4gICAgbWF4OiAxMDAsXG4gIH0sXG4gIG9wdGltYWxMYW5kaW5nU2xvcGU6IHtcbiAgICB0eXBlOiBTaW1wbGVTY2hlbWEuSW50ZWdlcixcbiAgICBsYWJlbDogJ1RoZSBvcHRpbWFsIHNsb3BlIGZvciB0aGUgbGFuZGluZyB0aGUgcnBhcyBpbiAlJyxcbiAgICBtaW46IDAsXG4gICAgbWF4OiAxMDAsXG4gIH0sXG4gIG9wdGltYWxUYWtlT2ZmU2xvcGU6IHtcbiAgICB0eXBlOiBTaW1wbGVTY2hlbWEuSW50ZWdlcixcbiAgICBsYWJlbDogJ1RoZSBvcHRpbWFsIHNsb3BlIGZvciB0aGUgdGFrZW9mZiBvZiB0aGUgcnBhcyBpbiAlJyxcbiAgICBtaW46IDAsXG4gICAgbWF4OiAxMDAsXG4gIH0sXG4gIG1heExhbmRTcGVlZDoge1xuICAgIHR5cGU6IFNpbXBsZVNjaGVtYS5JbnRlZ2VyLFxuICAgIGxhYmVsOiAnVGhlIG1heCBsYW5kaW5nIHNwZWVkIGZvciB0aGUgY29wdGVyIHJwYXMgaW4gY20vcycsXG4gICAgbWluOiAwLFxuICAgIG1heDogMjAwLFxuICB9LFxufSk7XG5cblJQQXMuc2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIG93bmVyOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIElEIG9mIHRoZSB1c2VyIHRoaXMgcnBhcyBiZWxvbmdzIHRvLicsXG4gIH0sXG4gIGNyZWF0ZWRBdDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBkYXRlIHRoaXMgcnBhcyB3YXMgY3JlYXRlZC4nLFxuICAgIGF1dG9WYWx1ZSgpIHtcbiAgICAgIGlmICh0aGlzLmlzSW5zZXJ0KSByZXR1cm4gKG5ldyBEYXRlKCkpLnRvSVNPU3RyaW5nKCk7XG4gICAgfSxcbiAgfSxcbiAgdXBkYXRlZEF0OiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIGRhdGUgdGhpcyBycGFzIHdhcyBsYXN0IHVwZGF0ZWQuJyxcbiAgICBhdXRvVmFsdWUoKSB7XG4gICAgICBpZiAodGhpcy5pc0luc2VydCB8fCB0aGlzLmlzVXBkYXRlKSByZXR1cm4gKG5ldyBEYXRlKCkpLnRvSVNPU3RyaW5nKCk7XG4gICAgfSxcbiAgfSxcbiAgbmFtZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBuYW1lIG9mIHRoZSBycGFzLicsXG4gIH0sXG4gIHJwYVR5cGU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdUaGUgdHlwZSBvZiB0aGUgcnBhcy4nLFxuICAgIGFsbG93ZWRWYWx1ZXM6IFsnUGxhbmUnLCAnTXVsdGlDb3B0ZXInXSxcbiAgfSxcbiAgbW9kZWw6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdUaGUgbW9kZWwgb2YgdGhlIHJwYXMuJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgcmVnaXN0cmF0aW9uTnVtYmVyOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIHJlZ2lzdHJhdGlvbiBudW1iZXIgb2YgdGhpcyBycGFzLicsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gIGNvbnN0cnVjdGlvbkRhdGU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdUaGUgZGF0ZSB0aGlzIHJwYXMgd2FzIGJ1aWx0LicsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gIHNlcmlhbE51bWJlcjoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBzZXJpYWwgbnVtYmVyIG9mIHRoaXMgcnBhcy4nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICB3ZWlnaHQ6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgbGFiZWw6ICdUaGUgd2VpZ2h0IG9mIHRoaXMgcnBhcyBpbiBncmFtcy4nLFxuICAgIG1pbjogMCxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgZmxpZ2h0UGFyYW1ldGVyczoge1xuICAgIHR5cGU6IGZsaWdodFBhcmFtZXRlcnNTY2hlbWEsXG4gICAgbGFiZWw6ICdUaGUgcGFyYW1ldGVycyBmb3IgdGhlIHJwYXMgZmxpZ2h0LicsXG4gIH0sXG4gIGRlbGV0ZWQ6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdUaGUgZGF0ZSB0aGUgcnBhcyB3YXMgZGVsZXRlZC4nLFxuICAgIGF1dG9WYWx1ZSgpIHtcbiAgICAgIGlmICh0aGlzLmlzSW5zZXJ0KSByZXR1cm4gJ25vJztcbiAgICB9LFxuICB9LFxufSk7XG5cblJQQXMuYXR0YWNoU2NoZW1hKFJQQXMuc2NoZW1hKTtcblxuZXhwb3J0IGRlZmF1bHQgUlBBcztcbiIsIi8qIGVzbGludC1kaXNhYmxlIG1ldGVvci9hdWRpdC1hcmd1bWVudC1jaGVja3MgKi9cbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IFJQQXMgZnJvbSAnLi9SUEFzJztcbmltcG9ydCByYXRlTGltaXQgZnJvbSAnLi4vLi4vbW9kdWxlcy9yYXRlLWxpbWl0JztcblxuY29uc3QgbmV3UlBBU2NoZW1hID0gUlBBcy5zY2hlbWEucGljaygnbmFtZScsICdycGFUeXBlJywgJ21vZGVsJywgJ3JlZ2lzdHJhdGlvbk51bWJlcicsICdjb25zdHJ1Y3Rpb25EYXRlJywgJ3NlcmlhbE51bWJlcicsICd3ZWlnaHQnLCAnZmxpZ2h0UGFyYW1ldGVycycpO1xuXG5jb25zdCBlZGl0UlBBU2NoZW1hID0gUlBBcy5zY2hlbWEucGljaygnbmFtZScsICdycGFUeXBlJywgJ21vZGVsJywgJ3JlZ2lzdHJhdGlvbk51bWJlcicsICdjb25zdHJ1Y3Rpb25EYXRlJywgJ3NlcmlhbE51bWJlcicsICd3ZWlnaHQnLCAnZmxpZ2h0UGFyYW1ldGVycycpO1xuZWRpdFJQQVNjaGVtYS5leHRlbmQoeyBfaWQ6IFN0cmluZyB9KTtcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAncnBhcy5pbnNlcnQnOiBmdW5jdGlvbiBycGFzSW5zZXJ0KHJwYSkge1xuICAgIHRyeSB7XG4gICAgICBuZXdSUEFTY2hlbWEudmFsaWRhdGUocnBhKTtcbiAgICAgIHJldHVybiBSUEFzLmluc2VydCh7IG93bmVyOiB0aGlzLnVzZXJJZCwgLi4ucnBhIH0pO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgaWYgKGV4Y2VwdGlvbi5lcnJvciA9PT0gJ3ZhbGlkYXRpb24tZXJyb3InKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCBleGNlcHRpb24ubWVzc2FnZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ3JwYXMudXBkYXRlJzogZnVuY3Rpb24gcnBhc1VwZGF0ZShycGEpIHtcbiAgICB0cnkge1xuICAgICAgZWRpdFJQQVNjaGVtYS52YWxpZGF0ZShycGEpO1xuICAgICAgY29uc3QgcnBhSWQgPSBycGEuX2lkO1xuICAgICAgUlBBcy51cGRhdGUocnBhSWQsIHsgJHNldDogcnBhIH0pO1xuICAgICAgcmV0dXJuIHJwYUlkO1xuICAgICAgLy8gUmV0dXJuIF9pZCBzbyB3ZSBjYW4gcmVkaXJlY3QgdG8gZG9jdW1lbnQgYWZ0ZXIgdXBkYXRlLlxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgaWYgKGV4Y2VwdGlvbi5lcnJvciA9PT0gJ3ZhbGlkYXRpb24tZXJyb3InKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCBleGNlcHRpb24ubWVzc2FnZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ3JwYXMuc29mdERlbGV0ZSc6IGZ1bmN0aW9uIHJwYXNTb2Z0RGVsZXRlKHJwYUlkKSB7XG4gICAgY2hlY2socnBhSWQsIFN0cmluZyk7XG4gICAgdHJ5IHtcbiAgICAgIFJQQXMudXBkYXRlKHJwYUlkLCB7ICRzZXQ6IHsgZGVsZXRlZDogKG5ldyBEYXRlKCkpLnRvSVNPU3RyaW5nKCkgfSB9KTtcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxuICAncnBhcy5yZXN0b3JlJzogZnVuY3Rpb24gcnBhc1Jlc3RvcmUocnBhSWQpIHtcbiAgICBjaGVjayhycGFJZCwgU3RyaW5nKTtcbiAgICB0cnkge1xuICAgICAgUlBBcy51cGRhdGUocnBhSWQsIHsgJHNldDogeyBkZWxldGVkOiAnbm8nIH0gfSk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ3JwYXMuaGFyZERlbGV0ZSc6IGZ1bmN0aW9uIHJwYXNIYXJkRGVsZXRlKHJwYXNJZCkge1xuICAgIGNoZWNrKHJwYXNJZCwgU3RyaW5nKTtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIFJQQXMucmVtb3ZlKHJwYXNJZCk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbn0pO1xuXG5yYXRlTGltaXQoe1xuICBtZXRob2RzOiBbXG4gICAgJ3JwYXMuaW5zZXJ0JyxcbiAgICAncnBhcy51cGRhdGUnLFxuICAgICdycGFzLnNvZnREZWxldGUnLFxuICAgICdycGFzLnJlc3RvcmUnLFxuICAgICdycGFzLmhhcmREZWxldGUnLFxuICBdLFxuICBsaW1pdDogNSxcbiAgdGltZVJhbmdlOiAxMDAwLFxufSk7XG4iLCIvKiBlc2xpbnQtZGlzYWJsZSBjb25zaXN0ZW50LXJldHVybiAqL1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJztcblxuXG5sZXQgYWN0aW9uO1xuXG5jb25zdCB1cGRhdGVVc2VyID0gKHVzZXJJZCwgeyBlbWFpbEFkZHJlc3MsIHByb2ZpbGUgfSkgPT4ge1xuICBjb25zb2xlLmxvZyh1c2VySWQsIGVtYWlsQWRkcmVzcywgSlNPTi5zdHJpbmdpZnkocHJvZmlsZSkpO1xuICB0cnkge1xuICAgIGNvbnN0IGN1cnJlbnRFbWFpbCA9IE1ldGVvci51c2Vycy5maW5kKFxuICAgICAgeyBfaWQ6IHVzZXJJZCB9LFxuICAgICAge1xuICAgICAgICBmaWVsZHM6IHtcbiAgICAgICAgICBlbWFpbHM6IDEsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICkuZmV0Y2goKVswXS5lbWFpbHNbMF0uYWRkcmVzcztcbiAgICBpZiAoZW1haWxBZGRyZXNzID09PSBjdXJyZW50RW1haWwpIHtcbiAgICAgIE1ldGVvci51c2Vycy51cGRhdGUodXNlcklkLCB7XG4gICAgICAgICRzZXQ6IHsgcHJvZmlsZSB9LFxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIE1ldGVvci51c2Vycy51cGRhdGUodXNlcklkLCB7XG4gICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAnZW1haWxzLjAuYWRkcmVzcyc6IGVtYWlsQWRkcmVzcyxcbiAgICAgICAgICAnZW1haWxzLjAudmVyaWZpZWQnOiBmYWxzZSxcbiAgICAgICAgICBwcm9maWxlLFxuICAgICAgICB9LFxuICAgICAgfSwgKGVycm9yKSA9PiB7XG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGVycm9yLnJlYXNvbik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgQWNjb3VudHMuc2VuZFZlcmlmaWNhdGlvbkVtYWlsKHVzZXJJZCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgYWN0aW9uLnJlamVjdChgW2VkaXRQcm9maWxlLnVwZGF0ZVVzZXJdICR7ZXhjZXB0aW9ufWApO1xuICB9XG59O1xuXG5jb25zdCBlZGl0UHJvZmlsZSA9ICh7IHVzZXJJZCwgcHJvZmlsZSB9LCBwcm9taXNlKSA9PiB7XG4gIGNvbnNvbGUubG9nKCdjYWxscyBpbnNpZGUgZWRpdC1wcm9maWxlJyk7XG4gIGNvbnNvbGUubG9nKHVzZXJJZCwgSlNPTi5zdHJpbmdpZnkocHJvZmlsZSkpO1xuICB0cnkge1xuICAgIGFjdGlvbiA9IHByb21pc2U7XG4gICAgdXBkYXRlVXNlcih1c2VySWQsIHByb2ZpbGUpO1xuICAgIGFjdGlvbi5yZXNvbHZlKCk7XG4gIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgIGFjdGlvbi5yZWplY3QoYFtlZGl0UHJvZmlsZS5oYW5kbGVyXSAke2V4Y2VwdGlvbn1gKTtcbiAgfVxufTtcblxuZXhwb3J0IGRlZmF1bHQgb3B0aW9ucyA9PlxuICBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PlxuICAgIGVkaXRQcm9maWxlKG9wdGlvbnMsIHsgcmVzb2x2ZSwgcmVqZWN0IH0pKTtcbiIsIi8qIGVzbGludC1kaXNhYmxlIG1ldGVvci9hdWRpdC1hcmd1bWVudC1jaGVja3MgKi9cbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSc7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5cbmltcG9ydCBlZGl0UHJvZmlsZSBmcm9tICcuL2VkaXQtcHJvZmlsZSc7XG5pbXBvcnQgcmF0ZUxpbWl0IGZyb20gJy4uLy4uLy4uL21vZHVsZXMvcmF0ZS1saW1pdCc7XG5cbmNvbnN0IG5ld1VzZXJTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgcHJvZmlsZToge1xuICAgIHR5cGU6IE9iamVjdCxcbiAgfSxcbiAgJ3Byb2ZpbGUubmFtZSc6IHtcbiAgICB0eXBlOiBPYmplY3QsXG4gIH0sXG4gICdwcm9maWxlLm5hbWUuZmlyc3QnOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICB9LFxuICAncHJvZmlsZS5uYW1lLmxhc3QnOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICB9LFxuICBlbWFpbDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICByZWdFeDogU2ltcGxlU2NoZW1hLlJlZ0V4LkVtYWlsLFxuICB9LFxuICBwYXNzd29yZDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBtaW46IDYsXG4gIH0sXG59KTtcblxuY29uc3QgZWRpdFVzZXJTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgcHJvZmlsZToge1xuICAgIHR5cGU6IE9iamVjdCxcbiAgfSxcbiAgJ3Byb2ZpbGUubmFtZSc6IHtcbiAgICB0eXBlOiBPYmplY3QsXG4gIH0sXG4gICdwcm9maWxlLm5hbWUuZmlyc3QnOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICB9LFxuICAncHJvZmlsZS5uYW1lLmxhc3QnOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICB9LFxuICBlbWFpbDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICByZWdFeDogU2ltcGxlU2NoZW1hLlJlZ0V4LkVtYWlsLFxuICB9LFxuICBfaWQ6IFN0cmluZyxcbn0pO1xuXG5cbk1ldGVvci5tZXRob2RzKHtcbiAgJ3VzZXJzLmNoYW5nZVJvbGUnOiBmdW5jdGlvbiB1c2Vyc0NoYW5nZVJvbGUodXNlcklkLCBuZXdSb2xlKSB7XG4gICAgY2hlY2sodXNlcklkLCBTdHJpbmcpO1xuICAgIGNoZWNrKG5ld1JvbGUsIFN0cmluZyk7XG5cbiAgICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCBbJ2FkbWluJ10pKSB7XG4gICAgICBSb2xlcy5zZXRVc2VyUm9sZXModXNlcklkLCBuZXdSb2xlKTtcbiAgICB9IGVsc2UgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh1c2VySWQsIFsnYWRtaW4nXSkpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsICdObyB3YXkgSm9zZScpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCAnSGEhIE5pY2UgdHJ5LCBzbGljay4nKTtcbiAgICB9XG4gIH0sXG5cbiAgJ3VzZXJzLnNlbmRWZXJpZmljYXRpb25FbWFpbCc6IGZ1bmN0aW9uIHNlbmRWZXJpZmljYXRpb25FbWFpbCh1c2VySWQpIHtcbiAgICByZXR1cm4gQWNjb3VudHMuc2VuZFZlcmlmaWNhdGlvbkVtYWlsKHVzZXJJZCk7XG4gIH0sXG5cbiAgJ3VzZXJzLnNldFBhc3N3b3JkJzogZnVuY3Rpb24gdXNlcnNTZXRQYXNzd29yZCh1c2VySWQpIHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIEFjY291bnRzLnNldFBhc3N3b3JkKHVzZXJJZCwgJ3Bhc3N3b3JkJyk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcblxuICAndXNlcnMuZWRpdFByb2ZpbGUnOiBmdW5jdGlvbiB1c2Vyc0VkaXRQcm9maWxlKHByb2ZpbGUpIHtcbiAgICBjaGVjayhwcm9maWxlLCB7XG4gICAgICBlbWFpbEFkZHJlc3M6IFN0cmluZyxcbiAgICAgIHByb2ZpbGU6IHtcbiAgICAgICAgbmFtZToge1xuICAgICAgICAgIGZpcnN0OiBTdHJpbmcsXG4gICAgICAgICAgbGFzdDogU3RyaW5nLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9KTtcbiAgICByZXR1cm4gZWRpdFByb2ZpbGUoeyB1c2VySWQ6IHRoaXMudXNlcklkLCBwcm9maWxlIH0pXG4gICAgICAudGhlbihyZXNwb25zZSA9PiByZXNwb25zZSlcbiAgICAgIC5jYXRjaCgoZXhjZXB0aW9uKSA9PiB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgICB9KTtcbiAgfSxcbiAgJ3VzZXJzLnNvZnREZWxldGUnOiBmdW5jdGlvbiB1c2Vyc1NvZnREZWxldGUodXNlcklkKSB7XG4gICAgY2hlY2sodXNlcklkLCBTdHJpbmcpO1xuICAgIHRyeSB7XG4gICAgICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCBbJ2FkbWluJ10pKSB7XG4gICAgICAgIE1ldGVvci51c2Vycy51cGRhdGUodXNlcklkLCB7ICRzZXQ6IHsgZGVsZXRlZDogKG5ldyBEYXRlKCkpLnRvSVNPU3RyaW5nKCkgfSB9KTtcbiAgICAgIH0gZWxzZSBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKHVzZXJJZCwgWydhZG1pbiddKSkge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCAnTm8gd2F5IEpvc2UnKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsICdIYSEgTmljZSB0cnksIHNsaWNrLicpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICd1c2Vycy5yZXN0b3JlJzogZnVuY3Rpb24gcHJvamVjdHNSZXN0b3JlKHVzZXJJZCkge1xuICAgIGNoZWNrKHVzZXJJZCwgU3RyaW5nKTtcbiAgICB0cnkge1xuICAgICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbiddKSkge1xuICAgICAgICBNZXRlb3IudXNlcnMudXBkYXRlKHVzZXJJZCwgeyAkc2V0OiB7IGRlbGV0ZWQ6ICdubycgfSB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsICdIYSEgTmljZSB0cnksIHNsaWNrLicpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICd1c2Vycy5oYXJkRGVsZXRlJzogZnVuY3Rpb24gdXNlcnNIYXJkRGVsZXRlKHVzZXJJZCkge1xuICAgIGNoZWNrKHVzZXJJZCwgU3RyaW5nKTtcbiAgICB0cnkge1xuICAgICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbiddKSkge1xuICAgICAgICBNZXRlb3IudXNlcnMucmVtb3ZlKHVzZXJJZCk7XG4gICAgICB9IGVsc2UgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh1c2VySWQsIFsnYWRtaW4nXSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgJ05vIHdheSBKb3NlJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCAnSGEhIE5pY2UgdHJ5LCBzbGljay4nKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxuICAndXNlcnMuaW5zZXJ0JzogZnVuY3Rpb24gdXNlcnNJbnNlcnQodXNlcikge1xuICAgIHRyeSB7XG4gICAgICBuZXdVc2VyU2NoZW1hLnZhbGlkYXRlKHVzZXIpO1xuICAgICAgcmV0dXJuIEFjY291bnRzLmNyZWF0ZVVzZXIodXNlcik7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICBpZiAoZXhjZXB0aW9uLmVycm9yID09PSAndmFsaWRhdGlvbi1lcnJvcicpIHtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig1MDAsIGV4Y2VwdGlvbi5tZXNzYWdlKTtcbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxuICAndXNlcnMudXBkYXRlJzogZnVuY3Rpb24gdXNlcnNVcGRhdGUodXNlcikge1xuICAgIGNvbnNvbGUubG9nKCdjYWxsaW5nIHVzZXJzLnVwZGF0ZScpO1xuICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHVzZXIpKTtcbiAgICB0cnkge1xuICAgICAgZWRpdFVzZXJTY2hlbWEudmFsaWRhdGUodXNlcik7XG4gICAgICBjb25zdCB1c2VyUHJvZmlsZSA9IHtcbiAgICAgICAgZW1haWxBZGRyZXNzOiB1c2VyLmVtYWlsLFxuICAgICAgICBwcm9maWxlOiB7XG4gICAgICAgICAgbmFtZToge1xuICAgICAgICAgICAgZmlyc3Q6IHVzZXIucHJvZmlsZS5uYW1lLmZpcnN0LFxuICAgICAgICAgICAgbGFzdDogdXNlci5wcm9maWxlLm5hbWUubGFzdCxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfTtcbiAgICAgIGNvbnNvbGUubG9nKGB1c2VyUHJvZmlsZSAke0pTT04uc3RyaW5naWZ5KHVzZXJQcm9maWxlKX1gKTtcbiAgICAgIHJldHVybiBlZGl0UHJvZmlsZSh7IHVzZXJJZDogdXNlci5faWQsIHVzZXJQcm9maWxlIH0pXG4gICAgICAgIC50aGVuKHJlc3BvbnNlID0+IHJlc3BvbnNlKVxuICAgICAgICAuY2F0Y2goKGV4Y2VwdGlvbikgPT4ge1xuICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgaWYgKGV4Y2VwdGlvbi5lcnJvciA9PT0gJ3ZhbGlkYXRpb24tZXJyb3InKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCBleGNlcHRpb24ubWVzc2FnZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbn0pO1xucmF0ZUxpbWl0KHtcbiAgbWV0aG9kczogW1xuICAgICd1c2Vycy5lZGl0UHJvZmlsZScsXG4gICAgJ3VzZXJzLnNlbmRWZXJpZmljYXRpb25FbWFpbCcsXG4gICAgJ3VzZXJzLmNoYW5nZVJvbGUnLFxuICAgICd1c2Vycy5zb2Z0RGVsZXRlJyxcbiAgICAndXNlcnMucmVzdG9yZScsXG4gICAgJ3VzZXJzLmhhcmREZWxldGUnLFxuICAgICd1c2Vycy5pbnNlcnQnLFxuICBdLFxuICBsaW1pdDogNSxcbiAgdGltZVJhbmdlOiAxMDAwLFxufSk7XG4iLCIvKiBlc2xpbnQtZGlzYWJsZSBjb25zaXN0ZW50LXJldHVybiAqL1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XG5cbk1ldGVvci5wdWJsaXNoKCd1c2Vycy5tYW5hZ2VtZW50JywgZnVuY3Rpb24gdXNlcnNNYW5hZ2VtZW50KCkge1xuICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCBbJ2FkbWluJ10pKSB7XG4gICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kKHt9LCB7XG4gICAgICBmaWVsZHM6IHtcbiAgICAgICAgZW1haWxzOiAxLFxuICAgICAgICByb2xlczogMSxcbiAgICAgICAgcHJvZmlsZTogMSxcbiAgICAgICAgc2VydmljZXM6IDEsXG4gICAgICAgIGRlbGV0ZWQ6IDEsXG4gICAgICAgIGNyZWF0ZWRBdDogMSxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cbn0pO1xuXG5NZXRlb3IucHVibGlzaCgndXNlcnMuZWRpdFByb2ZpbGUnLCBmdW5jdGlvbiB1c2Vyc1Byb2ZpbGUoKSB7XG4gIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh7IF9pZDogdGhpcy51c2VySWQgfSwge1xuICAgIGZpZWxkczoge1xuICAgICAgZW1haWxzOiAxLFxuICAgICAgcHJvZmlsZTogMSxcbiAgICAgIHNlcnZpY2VzOiAxLFxuICAgIH0sXG4gIH0pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCd1c2Vycy52aWV3JywgKHVzZXJJZCkgPT4ge1xuICBjaGVjayh1c2VySWQsIFN0cmluZyk7XG4gIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh7IF9pZDogdXNlcklkIH0sIHtcbiAgICBmaWVsZHM6IHtcbiAgICAgIGVtYWlsczogMSxcbiAgICAgIHByb2ZpbGU6IDEsXG4gICAgICBzZXJ2aWNlczogMSxcbiAgICAgIGNyZWF0ZWRBdDogMSxcbiAgICAgIHJvbGVzOiAxLFxuICAgICAgZGVsZXRlZDogMSxcbiAgICB9LFxuICB9KTtcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgc2VuZEVtYWlsIGZyb20gJy4uLy4uLy4uL21vZHVsZXMvc2VydmVyL3NlbmQtZW1haWwnO1xuaW1wb3J0IGdldE9BdXRoUHJvZmlsZSBmcm9tICcuLi8uLi8uLi9tb2R1bGVzL2dldC1vYXV0aC1wcm9maWxlJztcblxuZXhwb3J0IGRlZmF1bHQgKG9wdGlvbnMsIHVzZXIpID0+IHtcbiAgY29uc3QgT0F1dGhQcm9maWxlID0gZ2V0T0F1dGhQcm9maWxlKG9wdGlvbnMsIHVzZXIpO1xuXG4gIGNvbnN0IGFwcGxpY2F0aW9uTmFtZSA9ICdJcHNpbHVtJztcbiAgY29uc3QgZmlyc3ROYW1lID0gT0F1dGhQcm9maWxlID8gT0F1dGhQcm9maWxlLm5hbWUuZmlyc3QgOiBvcHRpb25zLnByb2ZpbGUubmFtZS5maXJzdDtcbiAgY29uc3QgZW1haWxBZGRyZXNzID0gT0F1dGhQcm9maWxlID8gT0F1dGhQcm9maWxlLmVtYWlsIDogb3B0aW9ucy5lbWFpbDtcblxuICByZXR1cm4gc2VuZEVtYWlsKHtcbiAgICB0bzogZW1haWxBZGRyZXNzLFxuICAgIGZyb206IGAke2FwcGxpY2F0aW9uTmFtZX0gPGluZm9Ac3JtY29uc3VsdGluZy5lcz5gLFxuICAgIHN1YmplY3Q6IGBbJHthcHBsaWNhdGlvbk5hbWV9XSBXZWxjb21lLCAke2ZpcnN0TmFtZX0hYCxcbiAgICB0ZW1wbGF0ZTogJ3dlbGNvbWUnLFxuICAgIHRlbXBsYXRlVmFyczoge1xuICAgICAgYXBwbGljYXRpb25OYW1lLFxuICAgICAgZmlyc3ROYW1lLFxuICAgICAgd2VsY29tZVVybDogTWV0ZW9yLmFic29sdXRlVXJsKCdwcm9qZWN0cycpLCAvLyBlLmcuLCByZXR1cm5zIGh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9wcm9qZWN0c1xuICAgIH0sXG4gIH0pXG4gICAgLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgYCR7ZXJyb3J9YCk7XG4gICAgfSk7XG59O1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgZ2V0UHJpdmF0ZUZpbGUgZnJvbSAnLi4vLi4vLi4vbW9kdWxlcy9zZXJ2ZXIvZ2V0LXByaXZhdGUtZmlsZSc7XG5pbXBvcnQgcGFyc2VNYXJrZG93biBmcm9tICcuLi8uLi8uLi9tb2R1bGVzL3BhcnNlLW1hcmtkb3duJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAndXRpbGl0eS5nZXRQYWdlJzogZnVuY3Rpb24gdXRpbGl0eUdldFBhZ2UoZmlsZU5hbWUpIHtcbiAgICBjaGVjayhmaWxlTmFtZSwgU3RyaW5nKTtcbiAgICByZXR1cm4gcGFyc2VNYXJrZG93bihnZXRQcml2YXRlRmlsZShgcGFnZXMvJHtmaWxlTmFtZX0ubWRgKSk7XG4gIH0sXG59KTtcbiIsIi8qIGVzbGludC1kaXNhYmxlIGNvbnNpc3RlbnQtcmV0dXJuLG1heC1sZW4gKi9cbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuLy8gR2VvbWV0cnkgUHJpbWl0aXZlc1xuZXhwb3J0IGNvbnN0IFBvaW50ID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIHR5cGU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdUaGUgdHlwZSBvZiB0aGUgZmVhdHVyZS4nLFxuICAgIGFsbG93ZWRWYWx1ZXM6IFsnUG9pbnQnXSxcbiAgfSxcbiAgY29vcmRpbmF0ZXM6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0Egc2luZ2xlIHBvc2l0aW9uLiBGdW5kYW1lbnRhbCBnZW9tZXRyeSBjb25zdHJ1Y3QuIFRoZSBvcmRlciBmb3IgdGhlIGVsZW1lbnRzIGlzIGxvbmdpdHVkZSAoZWFzdGluZykgYW5kIGxhdGl0dWRlIChub3J0aGluZyksIGluIHRoYXQgcHJlY2lzZSBvcmRlciwgYWx0aXR1ZGUgb3IgZWxldmF0aW9uIE1BWSBiZSBpbmNsdWRlZC4nLFxuICAgIG1pbkNvdW50OiAyLFxuICAgIG1heENvdW50OiAzLFxuICB9LFxuICAnY29vcmRpbmF0ZXMuJCc6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgbGFiZWw6ICdBIG51bWJlciByZXByZXNlbnRpbmcgbG9uZ2l0dWRlIChlYXN0aW5nKSwgbGF0aXR1ZGUgKG5vcnRoaW5nKSwgYWx0aXR1ZGUgb3IgZWxldmF0aW9uJyxcbiAgfSxcbn0pO1xuXG5leHBvcnQgY29uc3QgTGluZVN0cmluZyA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICB0eXBlOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIHR5cGUgb2YgdGhlIGZlYXR1cmUuJyxcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ0xpbmVTdHJpbmcnXSxcbiAgfSxcbiAgY29vcmRpbmF0ZXM6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0FuIGFycmF5IG9mIHR3byBvciBtb3JlIHBvc2l0aW9ucycsXG4gICAgbWluQ291bnQ6IDIsXG4gIH0sXG4gICdjb29yZGluYXRlcy4kJzoge1xuICAgIHR5cGU6IEFycmF5LFxuICAgIGxhYmVsOiAnQSBzaW5nbGUgcG9zaXRpb24uJyxcbiAgICBtaW5Db3VudDogMixcbiAgICBtYXhDb3VudDogMyxcbiAgfSxcbiAgJ2Nvb3JkaW5hdGVzLiQuJCc6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgbGFiZWw6ICdBIG51bWJlciByZXByZXNlbnRpbmcgbG9uZ2l0dWRlIChlYXN0aW5nKSwgbGF0aXR1ZGUgKG5vcnRoaW5nKSwgYWx0aXR1ZGUgb3IgZWxldmF0aW9uJyxcbiAgfSxcbn0pO1xuXG5leHBvcnQgY29uc3QgUG9seWdvbiA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICB0eXBlOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIHR5cGUgb2YgdGhlIGZlYXR1cmUuJyxcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ1BvbHlnb24nXSxcbiAgfSxcbiAgY29vcmRpbmF0ZXM6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0FuIGFycmF5IG9mIGxpbmVhciByaW5ncywgdGhlIGZpcnN0IG11c3QgYmUgdGhlIGV4dGVyaW9yIHJpbmcsIGFueSBvdGhlcnMgbXVzdCBiZSB0aGUgaW50ZXJpb3IgcmluZ3MnLFxuICB9LFxuICAnY29vcmRpbmF0ZXMuJCc6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0EgbGluZWFyIFJpbmcuIEFuIGFycmF5IG9mIGZvdXIgb3IgbW9yZSBwb3NpdGlvbnMgd2hlcmUgdGhlIGZpcnN0IGVxdWFscyB0aGUgbGFzdCwgZm9sbG93cyByaWdodC1oYW5kIHJ1bGUgaW4gcmVzcGVjdCB3aXRoIHRoZSBhcmVhIGl0IGJvdW5kcy4gRXh0ZXJpb3IgcmluZ3MgYXJlIGNvdW50ZXJjbG9ja3dpc2UgYW5kIGhvbGVzIGFyZSBjbG9ja3dpc2UnLFxuICAgIG1pbkNvdW50OiA0LFxuICAgIGN1c3RvbSgpIHtcbiAgICAgIGNvbnN0IGxhc3RQb3NpdGlvbkluZGV4ID0gdGhpcy52YWx1ZS5sZW5ndGggLSAxO1xuICAgICAgaWYgKHRoaXMudmFsdWVbMF0ubGVuZ3RoICE9PSB0aGlzLnZhbHVlW2xhc3RQb3NpdGlvbkluZGV4XS5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuICdQb3NpdGlvbnMgZG8gbm90IGhhdmUgc2FtZSBudW1iZXIgb2YgaXRlbXMnO1xuICAgICAgfVxuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLnZhbHVlWzBdLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgICAgIGlmICh0aGlzLnZhbHVlWzBdW2ldICE9PSB0aGlzLnZhbHVlW2xhc3RQb3NpdGlvbkluZGV4XVtpXSkge1xuICAgICAgICAgIHJldHVybiAnRmlyc3QgYW5kIExhc3QgUG9pbnQgbXVzdCBiZSBlcXVhbC4nO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgfSxcbiAgJ2Nvb3JkaW5hdGVzLiQuJCc6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0Egc2luZ2xlIHBvc2l0aW9uLicsXG4gICAgbWluQ291bnQ6IDIsXG4gICAgbWF4Q291bnQ6IDMsXG4gIH0sXG4gICdjb29yZGluYXRlcy4kLiQuJCc6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgbGFiZWw6ICdBIG51bWJlciByZXByZXNlbnRpbmcgbG9uZ2l0dWRlIChlYXN0aW5nKSwgbGF0aXR1ZGUgKG5vcnRoaW5nKSwgYWx0aXR1ZGUgb3IgZWxldmF0aW9uJyxcbiAgfSxcbn0pO1xuXG4vLyBNdWx0aXBhcnQgR2VvbWV0cmllc1xuZXhwb3J0IGNvbnN0IE11bHRpUG9pbnQgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgdHlwZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSB0eXBlIG9mIHRoZSBmZWF0dXJlLicsXG4gICAgYWxsb3dlZFZhbHVlczogWydNdWx0aVBvaW50J10sXG4gIH0sXG4gIGNvb3JkaW5hdGVzOiB7XG4gICAgdHlwZTogQXJyYXksXG4gICAgbGFiZWw6ICdBbiBhcnJheSBvZiBwb3NpdGlvbnMnLFxuICB9LFxuICAnY29vcmRpbmF0ZXMuJCc6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0Egc2luZ2xlIHBvc2l0aW9uLicsXG4gICAgbWluQ291bnQ6IDIsXG4gICAgbWF4Q291bnQ6IDMsXG4gIH0sXG4gICdjb29yZGluYXRlcy4kLiQnOiB7XG4gICAgdHlwZTogTnVtYmVyLFxuICAgIGxhYmVsOiAnQSBudW1iZXIgcmVwcmVzZW50aW5nIGxvbmdpdHVkZSAoZWFzdGluZyksIGxhdGl0dWRlIChub3J0aGluZyksIGFsdGl0dWRlIG9yIGVsZXZhdGlvbicsXG4gIH0sXG59KTtcblxuZXhwb3J0IGNvbnN0IE11bHRpTGluZVN0cmluZyA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICB0eXBlOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIHR5cGUgb2YgdGhlIGZlYXR1cmUuJyxcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ011bHRpTGluZVN0cmluZyddLFxuICB9LFxuICBjb29yZGluYXRlczoge1xuICAgIHR5cGU6IEFycmF5LFxuICAgIGxhYmVsOiAnQW4gYXJyYXkgb2YgbGluZVN0cmluZ3MnLFxuICB9LFxuICAnY29vcmRpbmF0ZXMuJCc6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0Egc2luZ2xlIGxpbmVTdHJpbmcuIEFuIGFycmF5IG9mIHR3byBvciBtb3JlIHBvc2l0aW9ucycsXG4gICAgbWluQ291bnQ6IDIsXG4gIH0sXG4gICdjb29yZGluYXRlcy4kLiQnOiB7XG4gICAgdHlwZTogQXJyYXksXG4gICAgbGFiZWw6ICdBIHNpbmdsZSBwb3NpdGlvbi4nLFxuICAgIG1pbkNvdW50OiAyLFxuICAgIG1heENvdW50OiAzLFxuICB9LFxuICAnY29vcmRpbmF0ZXMuJC4kLiQnOiB7XG4gICAgdHlwZTogTnVtYmVyLFxuICAgIGxhYmVsOiAnQSBudW1iZXIgcmVwcmVzZW50aW5nIGxvbmdpdHVkZSAoZWFzdGluZyksIGxhdGl0dWRlIChub3J0aGluZyksIGFsdGl0dWRlIG9yIGVsZXZhdGlvbicsXG4gIH0sXG59KTtcblxuZXhwb3J0IGNvbnN0IE11bHRpUG9seWdvbiA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICB0eXBlOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIHR5cGUgb2YgdGhlIGZlYXR1cmUuJyxcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ011bHRpUG9seWdvbiddLFxuICB9LFxuICBjb29yZGluYXRlczoge1xuICAgIHR5cGU6IEFycmF5LFxuICAgIGxhYmVsOiAnQW4gYXJyYXkgb2YgcG9seWdvbnMnLFxuICB9LFxuICAnY29vcmRpbmF0ZXMuJCc6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0Egc2luZ2xlIHBvbHlnb24uIEFuIGFycmF5IG9mIGxpbmVhciByaW5ncywgdGhlIGZpcnN0IG11c3QgYmUgdGhlIGV4dGVyaW9yIHJpbmcsIGFueSBvdGhlcnMgbXVzdCBiZSB0aGUgaW50ZXJpb3IgcmluZ3MnLFxuICB9LFxuICAnY29vcmRpbmF0ZXMuJC4kJzoge1xuICAgIHR5cGU6IEFycmF5LFxuICAgIGxhYmVsOiAnQSBsaW5lYXJSaW5nLiBBbiBhcnJheSBvZiBmb3VyIG9yIG1vcmUgcG9zaXRpb25zIHdoZXJlIHRoZSBmaXJzdCBlcXVhbHMgdGhlIGxhc3QsIGZvbGxvd3MgcmlnaHQtaGFuZCBydWxlIGluIHJlc3BlY3Qgd2l0aCB0aGUgYXJlYSBpdCBib3VuZHMuIEV4dGVyaW9yIHJpbmdzIGFyZSBjb3VudGVyY2xvY2t3aXNlIGFuZCBob2xlcyBhcmUgY2xvY2t3aXNlJyxcbiAgICBtaW5Db3VudDogNCxcbiAgICBjdXN0b20oKSB7XG4gICAgICBjb25zdCBsYXN0UG9zaXRpb25JbmRleCA9IHRoaXMudmFsdWUubGVuZ3RoIC0gMTtcbiAgICAgIGlmICh0aGlzLnZhbHVlWzBdLmxlbmd0aCAhPT0gdGhpcy52YWx1ZVtsYXN0UG9zaXRpb25JbmRleF0ubGVuZ3RoKSB7XG4gICAgICAgIHJldHVybiAnUG9zaXRpb25zIGRvIG5vdCBoYXZlIHNhbWUgbnVtYmVyIG9mIGl0ZW1zJztcbiAgICAgIH1cbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy52YWx1ZVswXS5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICBpZiAodGhpcy52YWx1ZVswXVtpXSAhPT0gdGhpcy52YWx1ZVtsYXN0UG9zaXRpb25JbmRleF1baV0pIHtcbiAgICAgICAgICByZXR1cm4gJ0ZpcnN0IGFuZCBMYXN0IFBvaW50IG11c3QgYmUgZXF1YWwuJztcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gIH0sXG4gICdjb29yZGluYXRlcy4kLiQuJCc6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0Egc2luZ2xlIHBvc2l0aW9uLicsXG4gICAgbWluQ291bnQ6IDIsXG4gICAgbWF4Q291bnQ6IDMsXG4gIH0sXG4gICdjb29yZGluYXRlcy4kLiQuJC4kJzoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgICBsYWJlbDogJ0EgbnVtYmVyIHJlcHJlc2VudGluZyBsb25naXR1ZGUgKGVhc3RpbmcpLCBsYXRpdHVkZSAobm9ydGhpbmcpLCBhbHRpdHVkZSBvciBlbGV2YXRpb24nLFxuICB9LFxufSk7XG5cbi8vIENvbGxlY3Rpb25zXG5leHBvcnQgY29uc3QgR2VvbWV0cnlDb2xsZWN0aW9uID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIHR5cGU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdBIEdlb21ldHJ5Q29sbGVjdGlvbiBoYXMgYSBtZW1iZXIgd2l0aCB0aGUgbmFtZSBcImdlb21ldHJpZXNcIi4gRWFjaCBlbGVtZW50IG9mIHRoaXMgYXJyYXkgaXMgYSBHZW9KU09OIEdlb21ldHJ5IG9iamVjdC4gR2VvbWV0cnlDb2xsZWN0aW9ucyBjb21wb3NlZCBvZiBhIHNpbmdsZSBwYXJ0IG9yIGEgbnVtYmVyIG9mIHBhcnRzIG9mIGEgc2luZ2xlIHR5cGUgU0hPVUxEIGJlIGF2b2lkZWQnLFxuICAgIGFsbG93ZWRWYWx1ZXM6IFsnR2VvbWV0cnlDb2xsZWN0aW9uJ10sXG4gIH0sXG4gIGJib3g6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0luY2x1ZGVzIGluZm9ybWF0aW9uIG9uIHRoZSBjb29yZGluYXRlIHJhbmdlLiBMZW5ndGggMipuIHdoZXJlIG4gaXMgdGhlIG51bWJlciBvZiBkaW1lbnNpb25zIHJlcHJlc2VudGVkIGluIHRoZSBjb250YWluZWQgZ2VvbWV0cmllcy4gQXhlcyBvcmRlciBvZiBiYm94IGZvbGxvd3MgdGhlIGF4ZXMgb3JkZXIgb2YgZ2VvbWV0cmllcy4gVGhlIHZhbHVlcyBvZiBhIFwiYmJveFwiIGFycmF5IGFyZSBcIlt3ZXN0LCBzb3V0aCwgZWFzdCwgbm9ydGhdXCIsIG5vdCBcIlttaW54LCBtaW55LCBtYXh4LCBtYXh5XVwiLicsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gICdiYm94LiQnOiB7XG4gICAgdHlwZTogTnVtYmVyLFxuICB9LFxuICBnZW9tZXRyaWVzOiB7XG4gICAgdHlwZTogQXJyYXksXG4gICAgbGFiZWw6ICdBbiBhcnJheSBvZiBHZW9KU09OIEdlb21ldHJ5IG9iamVjdHMnLFxuICB9LFxuICAnZ2VvbWV0cmllcy4kJzoge1xuICAgIC8vIEJVRyBkb2VzIG5vdCB3b3JrIC0gU2ltcGxlU2NoZW1hIG9ubHkga2VlcHMgdGhlIGxhc3Qgc2NoZW1hXG4gICAgdHlwZTogU2ltcGxlU2NoZW1hLm9uZU9mKFBvaW50LCBNdWx0aVBvaW50LCBMaW5lU3RyaW5nLCBNdWx0aUxpbmVTdHJpbmcsIFBvbHlnb24sIE11bHRpUG9seWdvbiksXG4gICAgbGFiZWw6ICdHZW9KU09OIEdlb21ldHJ5IG9iamVjdHMnLFxuICB9LFxufSk7XG5cbmV4cG9ydCBjb25zdCBGZWF0dXJlID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIHR5cGU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdBIEZlYXR1cmUgb2JqZWN0IHJlcHJlc2VudHMgYSBzcGF0aWFsbHkgYm91bmRlZCBlbnRpdHkuJyxcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ0ZlYXR1cmUnXSxcbiAgfSxcbiAgaWQ6IHtcbiAgICB0eXBlOiBTaW1wbGVTY2hlbWEub25lT2YoU3RyaW5nLCBOdW1iZXIpLFxuICAgIGxhYmVsOiAnQ29tbW9ubHkgdXNlZCBpZGVudGlmaWVyJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgYmJveDoge1xuICAgIHR5cGU6IEFycmF5LFxuICAgIGxhYmVsOiAnSW5jbHVkZXMgaW5mb3JtYXRpb24gb24gdGhlIGNvb3JkaW5hdGUgcmFuZ2UuIExlbmd0aCAyKm4gd2hlcmUgbiBpcyB0aGUgbnVtYmVyIG9mIGRpbWVuc2lvbnMgcmVwcmVzZW50ZWQgaW4gdGhlIGNvbnRhaW5lZCBnZW9tZXRyaWVzLiBBeGVzIG9yZGVyIG9mIGJib3ggZm9sbG93cyB0aGUgYXhlcyBvcmRlciBvZiBnZW9tZXRyaWVzJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgJ2Jib3guJCc6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gIH0sXG4gIGdlb21ldHJ5OiB7XG4gICAgLy8gQlVHIGRvZXMgbm90IHdvcmsgLSBTaW1wbGVTY2hlbWEgb25seSBrZWVwcyB0aGUgbGFzdCBzY2hlbWFcbiAgICB0eXBlOiBTaW1wbGVTY2hlbWEub25lT2YoUG9pbnQsIE11bHRpUG9pbnQsIExpbmVTdHJpbmcsIE11bHRpTGluZVN0cmluZywgUG9seWdvbiwgTXVsdGlQb2x5Z29uLCBHZW9tZXRyeUNvbGxlY3Rpb24pLFxuICAgIGxhYmVsOiAnVGhlIHZhbHVlIG9mIHRoZSBnZW9tZXRyeSBtZW1iZXIgU0hBTEwgYmUgZWl0aGVyIGEgR2VvbWV0cnkgb2JqZWN0IGFzIGRlZmluZWQgYWJvdmUgb3IsIGluIHRoZSBjYXNlIHRoYXQgdGhlIEZlYXR1cmUgaXMgdW5sb2NhdGVkLCBhIEpTT04gbnVsbCB2YWx1ZS4nLFxuICB9LFxuICBwcm9wZXJ0aWVzOiB7XG4gICAgdHlwZTogT2JqZWN0LFxuICAgIGxhYmVsOiAnRXh0cmEgcHJvcGVydGllcyBmb3IgdGhlIGZlYXR1cmUnLFxuICAgIGJsYWNrYm94OiB0cnVlLFxuICB9LFxufSk7XG5cbmV4cG9ydCBjb25zdCBGZWF0dXJlQ29sbGVjdGlvbiA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICB0eXBlOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIHR5cGUgb2YgdGhlIGZlYXR1cmUuJyxcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ0ZlYXR1cmVDb2xsZWN0aW9uJ10sXG4gIH0sXG4gIGJib3g6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0luY2x1ZGVzIGluZm9ybWF0aW9uIG9uIHRoZSBjb29yZGluYXRlIHJhbmdlLiBMZW5ndGggMipuIHdoZXJlIG4gaXMgdGhlIG51bWJlciBvZiBkaW1lbnNpb25zIHJlcHJlc2VudGVkIGluIHRoZSBjb250YWluZWQgZ2VvbWV0cmllcy4gQXhlcyBvcmRlciBvZiBiYm94IGZvbGxvd3MgdGhlIGF4ZXMgb3JkZXIgb2YgZ2VvbWV0cmllcycsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gICdiYm94LiQnOiB7XG4gICAgdHlwZTogTnVtYmVyLFxuICB9LFxuICBmZWF0dXJlczoge1xuICAgIHR5cGU6IEFycmF5LFxuICAgIGxhYmVsOiAnQW4gYXJyYXkgb2YgdGhlIGZlYXR1cmVzJyxcbiAgfSxcbiAgJ2ZlYXR1cmVzLiQnOiB7XG4gICAgLy8gQlVHIGRvZXMgbm90IHdvcmsgLSBTaW1wbGVTY2hlbWEgb25seSBrZWVwcyB0aGUgbGFzdCBzY2hlbWFcbiAgICB0eXBlOiBGZWF0dXJlLFxuICAgIGxhYmVsOiAnQSBmZWF0dXJlIG9iamVjdCcsXG4gIH0sXG59KTtcblxuXG5leHBvcnQgY29uc3QgR2VvSlNPTlNjaGVtYURlZiA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAvLyBCVUcgZG9lcyBub3Qgd29yayAtIFNpbXBsZVNjaGVtYSBvbmx5IGtlZXBzIHRoZSBsYXN0IHNjaGVtYVxuICBHZW9KU09OOiB7XG4gICAgdHlwZTogU2ltcGxlU2NoZW1hLm9uZU9mKFBvaW50LCBMaW5lU3RyaW5nLCBQb2x5Z29uLCBNdWx0aVBvaW50LCBNdWx0aUxpbmVTdHJpbmcsIE11bHRpUG9seWdvbiwgR2VvbWV0cnlDb2xsZWN0aW9uLCBGZWF0dXJlLCBGZWF0dXJlQ29sbGVjdGlvbiksXG4gIH0sXG59KTtcblxuLy8gZXhwb3J0IGRlZmF1bHQgR2VvSlNPTlNjaGVtYURlZjtcblxuLy8gRklYTUUgV29ya2Fyb3VuZHMgdG8gU2ltcGxlU2NoZW1hIGxpbWl0YXRpb25zXG5leHBvcnQgY29uc3QgRmVhdHVyZVBvaW50ID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIHR5cGU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdBIEZlYXR1cmUgb2JqZWN0IHJlcHJlc2VudHMgYSBzcGF0aWFsbHkgYm91bmRlZCBlbnRpdHkuJyxcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ0ZlYXR1cmUnXSxcbiAgfSxcbiAgaWQ6IHtcbiAgICB0eXBlOiBTaW1wbGVTY2hlbWEub25lT2YoU3RyaW5nLCBOdW1iZXIpLFxuICAgIGxhYmVsOiAnQ29tbW9ubHkgdXNlZCBpZGVudGlmaWVyJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgYmJveDoge1xuICAgIHR5cGU6IEFycmF5LFxuICAgIGxhYmVsOiAnSW5jbHVkZXMgaW5mb3JtYXRpb24gb24gdGhlIGNvb3JkaW5hdGUgcmFuZ2UuIExlbmd0aCAyKm4gd2hlcmUgbiBpcyB0aGUgbnVtYmVyIG9mIGRpbWVuc2lvbnMgcmVwcmVzZW50ZWQgaW4gdGhlIGNvbnRhaW5lZCBnZW9tZXRyaWVzLiBBeGVzIG9yZGVyIG9mIGJib3ggZm9sbG93cyB0aGUgYXhlcyBvcmRlciBvZiBnZW9tZXRyaWVzJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgJ2Jib3guJCc6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gIH0sXG4gIGdlb21ldHJ5OiB7XG4gICAgdHlwZTogU2ltcGxlU2NoZW1hLm9uZU9mKFBvaW50KSxcbiAgICBsYWJlbDogJ1RoZSB2YWx1ZSBvZiB0aGUgZ2VvbWV0cnkgbWVtYmVyIFNIQUxMIGJlIGVpdGhlciBhIEdlb21ldHJ5IG9iamVjdCBhcyBkZWZpbmVkIGFib3ZlIG9yLCBpbiB0aGUgY2FzZSB0aGF0IHRoZSBGZWF0dXJlIGlzIHVubG9jYXRlZCwgYSBKU09OIG51bGwgdmFsdWUuJyxcbiAgfSxcbiAgcHJvcGVydGllczoge1xuICAgIHR5cGU6IE9iamVjdCxcbiAgICBsYWJlbDogJ0V4dHJhIHByb3BlcnRpZXMgZm9yIHRoZSBmZWF0dXJlJyxcbiAgICBibGFja2JveDogdHJ1ZSxcbiAgfSxcbn0pO1xuXG5leHBvcnQgY29uc3QgRmVhdHVyZUxpbmVTdHJpbmcgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgdHlwZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ0EgRmVhdHVyZSBvYmplY3QgcmVwcmVzZW50cyBhIHNwYXRpYWxseSBib3VuZGVkIGVudGl0eS4nLFxuICAgIGFsbG93ZWRWYWx1ZXM6IFsnRmVhdHVyZSddLFxuICB9LFxuICBpZDoge1xuICAgIHR5cGU6IFNpbXBsZVNjaGVtYS5vbmVPZihTdHJpbmcsIE51bWJlciksXG4gICAgbGFiZWw6ICdDb21tb25seSB1c2VkIGlkZW50aWZpZXInLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICBiYm94OiB7XG4gICAgdHlwZTogQXJyYXksXG4gICAgbGFiZWw6ICdJbmNsdWRlcyBpbmZvcm1hdGlvbiBvbiB0aGUgY29vcmRpbmF0ZSByYW5nZS4gTGVuZ3RoIDIqbiB3aGVyZSBuIGlzIHRoZSBudW1iZXIgb2YgZGltZW5zaW9ucyByZXByZXNlbnRlZCBpbiB0aGUgY29udGFpbmVkIGdlb21ldHJpZXMuIEF4ZXMgb3JkZXIgb2YgYmJveCBmb2xsb3dzIHRoZSBheGVzIG9yZGVyIG9mIGdlb21ldHJpZXMnLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICAnYmJveC4kJzoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgfSxcbiAgZ2VvbWV0cnk6IHtcbiAgICB0eXBlOiBTaW1wbGVTY2hlbWEub25lT2YoTGluZVN0cmluZyksXG4gICAgbGFiZWw6ICdUaGUgdmFsdWUgb2YgdGhlIGdlb21ldHJ5IG1lbWJlciBTSEFMTCBiZSBlaXRoZXIgYSBHZW9tZXRyeSBvYmplY3QgYXMgZGVmaW5lZCBhYm92ZSBvciwgaW4gdGhlIGNhc2UgdGhhdCB0aGUgRmVhdHVyZSBpcyB1bmxvY2F0ZWQsIGEgSlNPTiBudWxsIHZhbHVlLicsXG4gIH0sXG4gIHByb3BlcnRpZXM6IHtcbiAgICB0eXBlOiBPYmplY3QsXG4gICAgbGFiZWw6ICdFeHRyYSBwcm9wZXJ0aWVzIGZvciB0aGUgZmVhdHVyZScsXG4gICAgYmxhY2tib3g6IHRydWUsXG4gIH0sXG59KTtcblxuZXhwb3J0IGNvbnN0IEZlYXR1cmVQb2x5Z29uID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIHR5cGU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdBIEZlYXR1cmUgb2JqZWN0IHJlcHJlc2VudHMgYSBzcGF0aWFsbHkgYm91bmRlZCBlbnRpdHkuJyxcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ0ZlYXR1cmUnXSxcbiAgfSxcbiAgaWQ6IHtcbiAgICB0eXBlOiBTaW1wbGVTY2hlbWEub25lT2YoU3RyaW5nLCBOdW1iZXIpLFxuICAgIGxhYmVsOiAnQ29tbW9ubHkgdXNlZCBpZGVudGlmaWVyJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgYmJveDoge1xuICAgIHR5cGU6IEFycmF5LFxuICAgIGxhYmVsOiAnSW5jbHVkZXMgaW5mb3JtYXRpb24gb24gdGhlIGNvb3JkaW5hdGUgcmFuZ2UuIExlbmd0aCAyKm4gd2hlcmUgbiBpcyB0aGUgbnVtYmVyIG9mIGRpbWVuc2lvbnMgcmVwcmVzZW50ZWQgaW4gdGhlIGNvbnRhaW5lZCBnZW9tZXRyaWVzLiBBeGVzIG9yZGVyIG9mIGJib3ggZm9sbG93cyB0aGUgYXhlcyBvcmRlciBvZiBnZW9tZXRyaWVzJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgJ2Jib3guJCc6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gIH0sXG4gIGdlb21ldHJ5OiB7XG4gICAgdHlwZTogU2ltcGxlU2NoZW1hLm9uZU9mKFBvbHlnb24pLFxuICAgIGxhYmVsOiAnVGhlIHZhbHVlIG9mIHRoZSBnZW9tZXRyeSBtZW1iZXIgU0hBTEwgYmUgZWl0aGVyIGEgR2VvbWV0cnkgb2JqZWN0IGFzIGRlZmluZWQgYWJvdmUgb3IsIGluIHRoZSBjYXNlIHRoYXQgdGhlIEZlYXR1cmUgaXMgdW5sb2NhdGVkLCBhIEpTT04gbnVsbCB2YWx1ZS4nLFxuICB9LFxuICBwcm9wZXJ0aWVzOiB7XG4gICAgdHlwZTogT2JqZWN0LFxuICAgIGxhYmVsOiAnRXh0cmEgcHJvcGVydGllcyBmb3IgdGhlIGZlYXR1cmUnLFxuICAgIGJsYWNrYm94OiB0cnVlLFxuICB9LFxufSk7XG5cbmV4cG9ydCBjb25zdCBGZWF0dXJlQ29sbGVjdGlvblBvaW50cyA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICB0eXBlOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVGhlIHR5cGUgb2YgdGhlIGZlYXR1cmUuJyxcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ0ZlYXR1cmVDb2xsZWN0aW9uJ10sXG4gIH0sXG4gIGJib3g6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0luY2x1ZGVzIGluZm9ybWF0aW9uIG9uIHRoZSBjb29yZGluYXRlIHJhbmdlLiBMZW5ndGggMipuIHdoZXJlIG4gaXMgdGhlIG51bWJlciBvZiBkaW1lbnNpb25zIHJlcHJlc2VudGVkIGluIHRoZSBjb250YWluZWQgZ2VvbWV0cmllcy4gQXhlcyBvcmRlciBvZiBiYm94IGZvbGxvd3MgdGhlIGF4ZXMgb3JkZXIgb2YgZ2VvbWV0cmllcycsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gICdiYm94LiQnOiB7XG4gICAgdHlwZTogTnVtYmVyLFxuICB9LFxuICBmZWF0dXJlczoge1xuICAgIHR5cGU6IEFycmF5LFxuICAgIGxhYmVsOiAnQW4gYXJyYXkgb2YgdGhlIGZlYXR1cmVzJyxcbiAgfSxcbiAgJ2ZlYXR1cmVzLiQnOiB7XG4gICAgdHlwZTogRmVhdHVyZVBvaW50LFxuICAgIGxhYmVsOiAnQSBmZWF0dXJlIG9iamVjdCcsXG4gIH0sXG59KTtcblxuZXhwb3J0IGNvbnN0IEZlYXR1cmVDb2xsZWN0aW9uTGluZVN0cmluZ3MgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgdHlwZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSB0eXBlIG9mIHRoZSBmZWF0dXJlLicsXG4gICAgYWxsb3dlZFZhbHVlczogWydGZWF0dXJlQ29sbGVjdGlvbiddLFxuICB9LFxuICBiYm94OiB7XG4gICAgdHlwZTogQXJyYXksXG4gICAgbGFiZWw6ICdJbmNsdWRlcyBpbmZvcm1hdGlvbiBvbiB0aGUgY29vcmRpbmF0ZSByYW5nZS4gTGVuZ3RoIDIqbiB3aGVyZSBuIGlzIHRoZSBudW1iZXIgb2YgZGltZW5zaW9ucyByZXByZXNlbnRlZCBpbiB0aGUgY29udGFpbmVkIGdlb21ldHJpZXMuIEF4ZXMgb3JkZXIgb2YgYmJveCBmb2xsb3dzIHRoZSBheGVzIG9yZGVyIG9mIGdlb21ldHJpZXMnLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICAnYmJveC4kJzoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgfSxcbiAgZmVhdHVyZXM6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0FuIGFycmF5IG9mIHRoZSBmZWF0dXJlcycsXG4gIH0sXG4gICdmZWF0dXJlcy4kJzoge1xuICAgIHR5cGU6IEZlYXR1cmVMaW5lU3RyaW5nLFxuICAgIGxhYmVsOiAnQSBmZWF0dXJlIG9iamVjdCcsXG4gIH0sXG59KTtcblxuZXhwb3J0IGNvbnN0IEZlYXR1cmVDb2xsZWN0aW9uUG9seWdvbnMgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgdHlwZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSB0eXBlIG9mIHRoZSBmZWF0dXJlLicsXG4gICAgYWxsb3dlZFZhbHVlczogWydGZWF0dXJlQ29sbGVjdGlvbiddLFxuICB9LFxuICBiYm94OiB7XG4gICAgdHlwZTogQXJyYXksXG4gICAgbGFiZWw6ICdJbmNsdWRlcyBpbmZvcm1hdGlvbiBvbiB0aGUgY29vcmRpbmF0ZSByYW5nZS4gTGVuZ3RoIDIqbiB3aGVyZSBuIGlzIHRoZSBudW1iZXIgb2YgZGltZW5zaW9ucyByZXByZXNlbnRlZCBpbiB0aGUgY29udGFpbmVkIGdlb21ldHJpZXMuIEF4ZXMgb3JkZXIgb2YgYmJveCBmb2xsb3dzIHRoZSBheGVzIG9yZGVyIG9mIGdlb21ldHJpZXMnLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICAnYmJveC4kJzoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgfSxcbiAgZmVhdHVyZXM6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0FuIGFycmF5IG9mIHRoZSBmZWF0dXJlcycsXG4gIH0sXG4gICdmZWF0dXJlcy4kJzoge1xuICAgIHR5cGU6IEZlYXR1cmVQb2x5Z29uLFxuICAgIGxhYmVsOiAnQSBmZWF0dXJlIG9iamVjdCcsXG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSc7XG5pbXBvcnQgZ2V0UHJpdmF0ZUZpbGUgZnJvbSAnLi4vLi4vLi4vbW9kdWxlcy9zZXJ2ZXIvZ2V0LXByaXZhdGUtZmlsZSc7XG5pbXBvcnQgdGVtcGxhdGVUb0hUTUwgZnJvbSAnLi4vLi4vLi4vbW9kdWxlcy9zZXJ2ZXIvaGFuZGxlYmFycy1lbWFpbC10by1odG1sJztcbmltcG9ydCB0ZW1wbGF0ZVRvVGV4dCBmcm9tICcuLi8uLi8uLi9tb2R1bGVzL3NlcnZlci9oYW5kbGViYXJzLWVtYWlsLXRvLXRleHQnO1xuXG5jb25zdCBuYW1lID0gJ0lwc2lsdW0nO1xuY29uc3QgZW1haWwgPSAnPGluZm9Ac3JtY29uc3VsdGluZy5lcz4nO1xuY29uc3QgZnJvbSA9IGAke25hbWV9ICR7ZW1haWx9YDtcbmNvbnN0IHsgZW1haWxUZW1wbGF0ZXMgfSA9IEFjY291bnRzO1xuXG5lbWFpbFRlbXBsYXRlcy5zaXRlTmFtZSA9IG5hbWU7XG5lbWFpbFRlbXBsYXRlcy5mcm9tID0gZnJvbTtcblxuZW1haWxUZW1wbGF0ZXMucmVzZXRQYXNzd29yZCA9IHtcbiAgc3ViamVjdCgpIHtcbiAgICByZXR1cm4gYFske25hbWV9XSBSZXNldCBZb3VyIFBhc3N3b3JkYDtcbiAgfSxcbiAgaHRtbCh1c2VyLCB1cmwpIHtcbiAgICByZXR1cm4gdGVtcGxhdGVUb0hUTUwoZ2V0UHJpdmF0ZUZpbGUoJ2VtYWlsLXRlbXBsYXRlcy9yZXNldC1wYXNzd29yZC5odG1sJyksIHtcbiAgICAgIGZpcnN0TmFtZTogdXNlci5wcm9maWxlLm5hbWUuZmlyc3QsXG4gICAgICBhcHBsaWNhdGlvbk5hbWU6IG5hbWUsXG4gICAgICBlbWFpbEFkZHJlc3M6IHVzZXIuZW1haWxzWzBdLmFkZHJlc3MsXG4gICAgICByZXNldFVybDogdXJsLnJlcGxhY2UoJyMvJywgJycpLFxuICAgIH0pO1xuICB9LFxuICB0ZXh0KHVzZXIsIHVybCkge1xuICAgIGNvbnN0IHVybFdpdGhvdXRIYXNoID0gdXJsLnJlcGxhY2UoJyMvJywgJycpO1xuICAgIGlmIChNZXRlb3IuaXNEZXZlbG9wbWVudCkgY29uc29sZS5pbmZvKGBSZXNldCBQYXNzd29yZCBMaW5rOiAke3VybFdpdGhvdXRIYXNofWApOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgcmV0dXJuIHRlbXBsYXRlVG9UZXh0KGdldFByaXZhdGVGaWxlKCdlbWFpbC10ZW1wbGF0ZXMvcmVzZXQtcGFzc3dvcmQudHh0JyksIHtcbiAgICAgIGZpcnN0TmFtZTogdXNlci5wcm9maWxlLm5hbWUuZmlyc3QsXG4gICAgICBhcHBsaWNhdGlvbk5hbWU6IG5hbWUsXG4gICAgICBlbWFpbEFkZHJlc3M6IHVzZXIuZW1haWxzWzBdLmFkZHJlc3MsXG4gICAgICByZXNldFVybDogdXJsV2l0aG91dEhhc2gsXG4gICAgfSk7XG4gIH0sXG59O1xuXG5lbWFpbFRlbXBsYXRlcy52ZXJpZnlFbWFpbCA9IHtcbiAgc3ViamVjdCgpIHtcbiAgICByZXR1cm4gYFske25hbWV9XSBWZXJpZnkgWW91ciBFbWFpbCBBZGRyZXNzYDtcbiAgfSxcbiAgaHRtbCh1c2VyLCB1cmwpIHtcbiAgICByZXR1cm4gdGVtcGxhdGVUb0hUTUwoZ2V0UHJpdmF0ZUZpbGUoJ2VtYWlsLXRlbXBsYXRlcy92ZXJpZnktZW1haWwuaHRtbCcpLCB7XG4gICAgICBhcHBsaWNhdGlvbk5hbWU6IG5hbWUsXG4gICAgICBmaXJzdE5hbWU6IHVzZXIucHJvZmlsZS5uYW1lLmZpcnN0LFxuICAgICAgdmVyaWZ5VXJsOiB1cmwucmVwbGFjZSgnIy8nLCAnJyksXG4gICAgfSk7XG4gIH0sXG4gIHRleHQodXNlciwgdXJsKSB7XG4gICAgY29uc3QgdXJsV2l0aG91dEhhc2ggPSB1cmwucmVwbGFjZSgnIy8nLCAnJyk7XG4gICAgaWYgKE1ldGVvci5pc0RldmVsb3BtZW50KSBjb25zb2xlLmluZm8oYFZlcmlmeSBFbWFpbCBMaW5rOiAke3VybFdpdGhvdXRIYXNofWApOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgcmV0dXJuIHRlbXBsYXRlVG9UZXh0KGdldFByaXZhdGVGaWxlKCdlbWFpbC10ZW1wbGF0ZXMvdmVyaWZ5LWVtYWlsLnR4dCcpLCB7XG4gICAgICBhcHBsaWNhdGlvbk5hbWU6IG5hbWUsXG4gICAgICBmaXJzdE5hbWU6IHVzZXIucHJvZmlsZS5uYW1lLmZpcnN0LFxuICAgICAgdmVyaWZ5VXJsOiB1cmxXaXRob3V0SGFzaCxcbiAgICB9KTtcbiAgfSxcbn07XG4iLCJpbXBvcnQgJy4vZW1haWwtdGVtcGxhdGVzJztcbmltcG9ydCAnLi9vYXV0aCc7XG5pbXBvcnQgJy4vcm9sZXMnO1xuaW1wb3J0ICcuL29uLWNyZWF0ZS11c2VyJztcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgU2VydmljZUNvbmZpZ3VyYXRpb24gfSBmcm9tICdtZXRlb3Ivc2VydmljZS1jb25maWd1cmF0aW9uJztcblxuXG5sZXQgT0F1dGhTZXR0aW5ncyA9IHtcbiAgZmFjZWJvb2s6IHsgYXBwSWQ6ICcnLCBzZWNyZXQ6ICcnLCBsb2dpblN0eWxlOiAncG9wdXAnIH0sXG4gIGdvb2dsZTogeyBjbGllbnRJZDogJycsIHNlY3JldDogJycsIGxvZ2luU3R5bGU6ICdwb3B1cCcgfSxcbn07XG5cblxuaWYgKE1ldGVvci5zZXR0aW5ncyAmJiBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZSAmJiBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5PQXV0aCkge1xuICBPQXV0aFNldHRpbmdzID0gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUuT0F1dGg7XG59XG5cbmlmIChPQXV0aFNldHRpbmdzKSB7XG4gIE9iamVjdC5rZXlzKE9BdXRoU2V0dGluZ3MpLmZvckVhY2goKHNlcnZpY2UpID0+IHtcbiAgICBTZXJ2aWNlQ29uZmlndXJhdGlvbi5jb25maWd1cmF0aW9ucy51cHNlcnQoXG4gICAgICB7IHNlcnZpY2UgfSxcbiAgICAgIHsgJHNldDogT0F1dGhTZXR0aW5nc1tzZXJ2aWNlXSB9LFxuICAgICk7XG4gIH0pO1xufVxuIiwiaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSc7XG5pbXBvcnQgc2VuZFdlbGNvbWVFbWFpbCBmcm9tICcuLi8uLi8uLi9hcGkvVXNlcnMvc2VydmVyL3NlbmQtd2VsY29tZS1lbWFpbCc7XG5cbkFjY291bnRzLm9uQ3JlYXRlVXNlcigob3B0aW9ucywgdXNlcikgPT4ge1xuICBjb25zdCB1c2VyVG9DcmVhdGUgPSB1c2VyO1xuXG4gIGlmICghdXNlclRvQ3JlYXRlLnJvbGVzKSB7XG4gICAgdXNlclRvQ3JlYXRlLnJvbGVzID0gWydmcmVlLXVzZXInXTtcbiAgfSBlbHNlIHtcbiAgICB1c2VyVG9DcmVhdGUucm9sZXMucHVzaCgnZnJlZS11c2VyJyk7XG4gIH1cbiAgaWYgKG9wdGlvbnMucHJvZmlsZSkgdXNlclRvQ3JlYXRlLnByb2ZpbGUgPSBvcHRpb25zLnByb2ZpbGU7XG4gIHVzZXJUb0NyZWF0ZS5kZWxldGVkID0gJ25vJztcblxuICBzZW5kV2VsY29tZUVtYWlsKG9wdGlvbnMsIHVzZXIpO1xuICByZXR1cm4gdXNlclRvQ3JlYXRlO1xufSk7XG4iLCIvKiBlc2xpbnQtZGlzYWJsZSBuby1yZXR1cm4tYXNzaWduICovXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFJvbGVzIH0gZnJvbSAnbWV0ZW9yL2FsYW5uaW5nOnJvbGVzJztcbmltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSc7XG5cbi8vIFRoaXMgcmVvY25jaWxlcyB0aGUgUm9sZXMgY29sbGVjdGlvbiBpbiBNb25nb0RCIHRvIGVuc3VyZSB3ZSd2ZSByZWNvcmRlZCBhbGwgb2YgdGhlIHBvc3NpYmxlXG4vLyB1c2VyIHJvbGVzLiBXZSBkbyB0aGlzIGJlY2F1c2Ugd2UncmUgbWFudWFsbHkgYWRkaW5nIHJvbGVzIHRvIHVzZXJzIGFuZCB0aGUgYWxhbm5pbmc6cm9sZXNcbi8vIHBhY2thZ2UgZG9lc24ndCBkZXRlY3QgdGhpcy5cblxuY29uc3QgcmVjb25jaWxlUm9sZXMgPSAoKSA9PiB7XG4gIGNvbnN0IHVzZXJzID0gTWV0ZW9yLnVzZXJzLmZpbmQoe30sIHsgcm9sZXM6IDEgfSkuZmV0Y2goKTtcbiAgbGV0IHJvbGVzID0gW107XG4gIHVzZXJzLmZvckVhY2godXNlciA9PiAocm9sZXMgPSBfLnVuaXEocm9sZXMuY29uY2F0KHVzZXIucm9sZXMpKSkpO1xuICByb2xlcy5tYXAobmFtZSA9PiAoIU1ldGVvci5yb2xlcy5maW5kT25lKHsgbmFtZSB9KSA/IFJvbGVzLmNyZWF0ZVJvbGUobmFtZSkgOiBudWxsKSk7XG59O1xuXG5yZWNvbmNpbGVSb2xlcygpO1xuXG5NZXRlb3IudXNlcnMuZmluZCh7fSkub2JzZXJ2ZSh7XG4gIGFkZGVkKCkgeyByZWNvbmNpbGVSb2xlcygpOyB9LFxufSk7XG4iLCJpbXBvcnQgJy4uLy4uL2FwaS9Qcm9qZWN0cy9tZXRob2RzJztcbmltcG9ydCAnLi4vLi4vYXBpL1Byb2plY3RzL3NlcnZlci9wdWJsaWNhdGlvbnMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9NaXNzaW9ucy9tZXRob2RzJztcbmltcG9ydCAnLi4vLi4vYXBpL01pc3Npb25zL3NlcnZlci9wdWJsaWNhdGlvbnMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9SUEFzL21ldGhvZHMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvUlBBcy9zZXJ2ZXIvcHVibGljYXRpb25zJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvUGF5bG9hZHMvbWV0aG9kcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9QYXlsb2Fkcy9zZXJ2ZXIvcHVibGljYXRpb25zJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvQmF0dGVyaWVzL21ldGhvZHMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvQmF0dGVyaWVzL3NlcnZlci9wdWJsaWNhdGlvbnMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9Vc2Vycy9zZXJ2ZXIvbWV0aG9kcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9Vc2Vycy9zZXJ2ZXIvcHVibGljYXRpb25zJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvT0F1dGgvc2VydmVyL21ldGhvZHMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9VdGlsaXR5L3NlcnZlci9tZXRob2RzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvRmxpZVRyYW5zZmVyVXRpbGl0aWVzL3NlcnZlci9tZXRob2RzJztcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG5pZiAoTWV0ZW9yLmlzRGV2ZWxvcG1lbnQpIHByb2Nlc3MuZW52Lk1BSUxfVVJMID0gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUuZW52Lk1BSUxfVVJMO1xuIiwiaW1wb3J0IHNlZWRlciBmcm9tICdAY2xldmVyYmVhZ2xlL3NlZWRlcic7XG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBmYWtlciBmcm9tICdmYWtlcic7XG5pbXBvcnQgUHJvamVjdHMgZnJvbSAnLi4vLi4vYXBpL1Byb2plY3RzL1Byb2plY3RzJztcbmltcG9ydCBNaXNzaW9ucyBmcm9tICcuLi8uLi9hcGkvTWlzc2lvbnMvTWlzc2lvbnMnO1xuXG5pbXBvcnQgUlBBcyBmcm9tICcuLi8uLi9hcGkvUlBBcy9SUEFzJztcbmltcG9ydCBQYXlsb2FkcyBmcm9tICcuLi8uLi9hcGkvUGF5bG9hZHMvUGF5bG9hZHMnO1xuaW1wb3J0IEJhdHRlcmllcyBmcm9tICcuLi8uLi9hcGkvQmF0dGVyaWVzL0JhdHRlcmllcyc7XG5cbmNvbnN0IEdlb0Ryb25lUlBBID0gKHVzZXJJZCkgPT4ge1xuICBjb25zdCBSUEFzVmVjdG9yID0gW107XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgNTsgaSArPSAxKSB7XG4gICAgaWYgKGkgPT09IDApIHtcbiAgICAgIFJQQXNWZWN0b3IucHVzaCh7XG4gICAgICAgIG93bmVyOiB1c2VySWQsXG4gICAgICAgIG5hbWU6ICdHZW9Ecm9uZSBDb255Y2EnLFxuICAgICAgICBycGFUeXBlOiAnUGxhbmUnLFxuICAgICAgICBtb2RlbDogMSxcbiAgICAgICAgcmVnaXN0cmF0aW9uTnVtYmVyOiAxMjM0NSxcbiAgICAgICAgY29uc3RydWN0aW9uRGF0ZTogKG5ldyBEYXRlKCkpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIHNlcmlhbE51bWJlcjogMTIzNDUsXG4gICAgICAgIHdlaWdodDogNSxcbiAgICAgICAgZmxpZ2h0UGFyYW1ldGVyczoge1xuICAgICAgICAgIG1heERlc2NlbmRTbG9wZTogMCxcbiAgICAgICAgICBtYXhBc2NlbmRTbG9wZTogMCxcbiAgICAgICAgICBvcHRpbWFsTGFuZGluZ1Nsb3BlOiA3LFxuICAgICAgICAgIG9wdGltYWxUYWtlT2ZmU2xvcGU6IDAsXG4gICAgICAgICAgbWF4TGFuZFNwZWVkOiAwLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICAgIFJQQXNWZWN0b3IucHVzaCh7XG4gICAgICBvd25lcjogdXNlcklkLFxuICAgICAgbmFtZTogZmFrZXIuY29tbWVyY2UucHJvZHVjdE5hbWUoKSxcbiAgICAgIHJwYVR5cGU6IGZha2VyLnJhbmRvbS5hcnJheUVsZW1lbnQoWydQbGFuZScsICdNdWx0aUNvcHRlciddKSxcbiAgICAgIG1vZGVsOiBmYWtlci5jb21tZXJjZS5wcm9kdWN0QWRqZWN0aXZlKCksXG4gICAgICByZWdpc3RyYXRpb25OdW1iZXI6IGZha2VyLnJhbmRvbS5udW1iZXIoKSxcbiAgICAgIGNvbnN0cnVjdGlvbkRhdGU6IGZha2VyLmRhdGUucGFzdCgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBzZXJpYWxOdW1iZXI6IGZha2VyLnJhbmRvbS5udW1iZXIoKSxcbiAgICAgIHdlaWdodDogZmFrZXIucmFuZG9tLm51bWJlcih7IG1pbjogMCwgbWF4OiAxMDAwIH0pLFxuICAgICAgZmxpZ2h0UGFyYW1ldGVyczoge1xuICAgICAgICBtYXhEZXNjZW5kU2xvcGU6IGZha2VyLnJhbmRvbS5udW1iZXIoeyBtaW46IDAsIG1heDogMTAwIH0pLFxuICAgICAgICBtYXhBc2NlbmRTbG9wZTogZmFrZXIucmFuZG9tLm51bWJlcih7IG1pbjogMCwgbWF4OiAxMDAgfSksXG4gICAgICAgIG9wdGltYWxMYW5kaW5nU2xvcGU6IGZha2VyLnJhbmRvbS5udW1iZXIoeyBtaW46IDAsIG1heDogMTAwIH0pLFxuICAgICAgICBvcHRpbWFsVGFrZU9mZlNsb3BlOiBmYWtlci5yYW5kb20ubnVtYmVyKHsgbWluOiAwLCBtYXg6IDEwMCB9KSxcbiAgICAgICAgbWF4TGFuZFNwZWVkOiBmYWtlci5yYW5kb20ubnVtYmVyKHsgbWluOiAwLCBtYXg6IDEwMCB9KSxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIFJQQXNWZWN0b3I7XG59O1xuXG5cbmNvbnN0IENhbWVyYXNWZWN0b3IgPSAodXNlcklkKSA9PiB7XG4gIGNvbnN0IGNhbWVyYXNWZWN0b3IgPSBbXTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCA1OyBpICs9IDEpIHtcbiAgICBpZiAoaSA9PT0gMCkge1xuICAgICAgY2FtZXJhc1ZlY3Rvci5wdXNoKHtcbiAgICAgICAgb3duZXI6IHVzZXJJZCxcbiAgICAgICAgbmFtZTogJ1NvbnknLFxuICAgICAgICByZWdpc3RyYXRpb25OdW1iZXI6IDEyMzQzLFxuICAgICAgICBtb2RlbDogJ05leHQgNycsXG4gICAgICAgIHdlaWdodDogNTAwLFxuICAgICAgICBwYXlsb2FkVHlwZTogJ0NhbWVyYScsXG4gICAgICAgIHNlbnNvclBhcmFtZXRlcnM6IHtcbiAgICAgICAgICBmb2NhbExlbmd0aDogMTYsXG4gICAgICAgICAgc2Vuc29yV2lkdGg6IDIzLjUsXG4gICAgICAgICAgc2Vuc29ySGVpZ2h0OiAxNS42LFxuICAgICAgICAgIGltYWdlV2lkdGg6IDYwMDAsXG4gICAgICAgICAgaW1hZ2VIZWlnaHQ6IDQwMDAsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gICAgY2FtZXJhc1ZlY3Rvci5wdXNoKHtcbiAgICAgIG93bmVyOiB1c2VySWQsXG4gICAgICBuYW1lOiBmYWtlci5jb21tZXJjZS5wcm9kdWN0TmFtZSgpLFxuICAgICAgcmVnaXN0cmF0aW9uTnVtYmVyOiBmYWtlci5yYW5kb20ubnVtYmVyKCksXG4gICAgICBtb2RlbDogZmFrZXIuY29tbWVyY2UucHJvZHVjdEFkamVjdGl2ZSgpLFxuICAgICAgd2VpZ2h0OiBmYWtlci5yYW5kb20ubnVtYmVyKHsgbWluOiAwLCBtYXg6IDEwMCB9KSxcbiAgICAgIHBheWxvYWRUeXBlOiAnQ2FtZXJhJyxcbiAgICAgIHNlbnNvclBhcmFtZXRlcnM6IHtcbiAgICAgICAgZm9jYWxMZW5ndGg6IGZha2VyLnJhbmRvbS5udW1iZXIoeyBtaW46IDEsIG1heDogNTAgfSksXG4gICAgICAgIHNlbnNvcldpZHRoOiBmYWtlci5yYW5kb20ubnVtYmVyKHsgbWluOiAxLCBtYXg6IDUwIH0pLFxuICAgICAgICBzZW5zb3JIZWlnaHQ6IGZha2VyLnJhbmRvbS5udW1iZXIoeyBtaW46IDEsIG1heDogNTAgfSksXG4gICAgICAgIGltYWdlV2lkdGg6IGZha2VyLnJhbmRvbS5udW1iZXIoeyBtaW46IDQwMCwgbWF4OiAxMDAwMCB9KSxcbiAgICAgICAgaW1hZ2VIZWlnaHQ6IGZha2VyLnJhbmRvbS5udW1iZXIoeyBtaW46IDYwMCwgbWF4OiAxMDAwMCB9KSxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIGNhbWVyYXNWZWN0b3I7XG59O1xuXG5jb25zdCBiYXR0ZXJpZXNTZWVkID0gKHVzZXJJZCkgPT4ge1xuICBjb25zdCBiYXR0ZXJpZXNWZWN0b3IgPSBbXTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCA1OyBpICs9IDEpIHtcbiAgICBiYXR0ZXJpZXNWZWN0b3IucHVzaCh7XG4gICAgICBvd25lcjogdXNlcklkLFxuICAgICAgbmFtZTogZmFrZXIuY29tbWVyY2UucHJvZHVjdE5hbWUoKSxcbiAgICAgIG1vZGVsOiBmYWtlci5jb21tZXJjZS5wcm9kdWN0QWRqZWN0aXZlKCksXG4gICAgICByZWdpc3RyYXRpb25OdW1iZXI6IGZha2VyLnJhbmRvbS5udW1iZXIoKSxcbiAgICAgIGFtcGVyZXM6IGZha2VyLnJhbmRvbS5udW1iZXIoeyBtaW46IDAsIG1heDogMTAwIH0pLFxuICAgICAgY2VsbE51bWJlcjogZmFrZXIucmFuZG9tLm51bWJlcih7IG1pbjogMCwgbWF4OiA1MCB9KSxcbiAgICAgIHdlaWdodDogZmFrZXIucmFuZG9tLm51bWJlcih7IG1pbjogMCwgbWF4OiA1MDAgfSksXG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIGJhdHRlcmllc1ZlY3Rvcjtcbn07XG5cbmNvbnN0IG1pc3Npb25zU2VlZCA9ICh1c2VySWQsIHByb2plY3RJZCwgcnBhc1BheWxvYWRzSURTKSA9PiAoe1xuICBjb2xsZWN0aW9uOiBNaXNzaW9ucyxcbiAgZW52aXJvbm1lbnRzOiBbJ2RldmVsb3BtZW50JywgJ3N0YWdpbmcnLCAncHJvZHVjdGlvbiddLFxuICBub0xpbWl0OiB0cnVlLFxuICBtb2RlbENvdW50OiA1LFxuICBtb2RlbChkYXRhSW5kZXgsIGZha2VyKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIG93bmVyOiB1c2VySWQsXG4gICAgICBwcm9qZWN0OiBwcm9qZWN0SWQsXG4gICAgICBuYW1lOiBgTWlzc2lvbiAjJHtkYXRhSW5kZXggKyAxfWAsXG4gICAgICBkZXNjcmlwdGlvbjogYFRoaXMgaXMgdGhlIGRlc2NyaXB0aW9uIG9mIE1pc3Npb24gIyR7ZGF0YUluZGV4ICsgMX1gLFxuICAgICAgcnBhOiBmYWtlci5yYW5kb20uYXJyYXlFbGVtZW50KHJwYXNQYXlsb2Fkc0lEUy5ycGFzSWRzKSxcbiAgICAgIHBheWxvYWQ6IGZha2VyLnJhbmRvbS5hcnJheUVsZW1lbnQocnBhc1BheWxvYWRzSURTLnBheWxvYWRJZHMpLFxuICAgICAgbWlzc2lvblR5cGU6IGZha2VyLnJhbmRvbS5hcnJheUVsZW1lbnQoWydTdXJmYWNlIEFyZWEnLCAnTGluZWFyIEFyZWEnXSksXG4gICAgfTtcbiAgfSxcbn0pO1xuXG5cbmNvbnN0IHByb2plY3RzU2VlZCA9ICh1c2VySWQsIHJwYXNQYXlsb2Fkc0lEUykgPT4gKHtcbiAgY29sbGVjdGlvbjogUHJvamVjdHMsXG4gIGVudmlyb25tZW50czogWydkZXZlbG9wbWVudCcsICdzdGFnaW5nJ10sXG4gIG5vTGltaXQ6IHRydWUsXG4gIG1vZGVsQ291bnQ6IDUsXG4gIG1vZGVsKGRhdGFJbmRleCwgZmFrZXIpIHtcbiAgICByZXR1cm4ge1xuICAgICAgb3duZXI6IHVzZXJJZCxcbiAgICAgIG5hbWU6IGBQcm9qZWN0ICMke2RhdGFJbmRleCArIDF9YCxcbiAgICAgIGRlc2NyaXB0aW9uOiBgVGhpcyBpcyB0aGUgZGVzY3JpcHRpb24gb2YgUHJvamVjdCAjJHtkYXRhSW5kZXggKyAxfWAsXG4gICAgICBtYXBMb2NhdGlvbjoge1xuICAgICAgICB0eXBlOiAnRmVhdHVyZScsXG4gICAgICAgIGdlb21ldHJ5OiB7XG4gICAgICAgICAgdHlwZTogJ1BvaW50JyxcbiAgICAgICAgICBjb29yZGluYXRlczogW2Zha2VyLmFkZHJlc3MubG9uZ2l0dWRlKCksIGZha2VyLmFkZHJlc3MubGF0aXR1ZGUoKV0sXG4gICAgICAgIH0sXG4gICAgICAgIHByb3BlcnRpZXM6IHsgem9vbTogZmFrZXIucmFuZG9tLm51bWJlcih7IG1pbjogMCwgbWF4OiAxNSB9KSB9LFxuICAgICAgfSxcbiAgICAgIGRhdGEocHJvamVjdElkKSB7XG4gICAgICAgIHJldHVybiBtaXNzaW9uc1NlZWQodXNlcklkLCBwcm9qZWN0SWQsIHJwYXNQYXlsb2Fkc0lEUyk7XG4gICAgICB9LFxuICAgIH07XG4gIH0sXG59KTtcblxuY29uc3QgaW5zZXJ0T3RoZXJEYXRhID0gKHVzZXJJZCkgPT4ge1xuICBjb25zdCB1c2VyUlBBU1BheWxvYWRzID0ge1xuICAgIHJwYXNJZHM6IFtdLFxuICAgIHBheWxvYWRJZHM6IFtdLFxuICB9O1xuICBHZW9Ecm9uZVJQQSh1c2VySWQpLmZvckVhY2goKHJwYSkgPT4ge1xuICAgIGNvbnN0IHJwYUlEID0gUlBBcy5pbnNlcnQocnBhKTtcbiAgICB1c2VyUlBBU1BheWxvYWRzLnJwYXNJZHMucHVzaChycGFJRCk7XG4gIH0pO1xuICBDYW1lcmFzVmVjdG9yKHVzZXJJZCkuZm9yRWFjaCgoY2FtZXJhKSA9PiB7XG4gICAgY29uc3QgcGF5bG9hZElEID0gUGF5bG9hZHMuaW5zZXJ0KGNhbWVyYSk7XG4gICAgdXNlclJQQVNQYXlsb2Fkcy5wYXlsb2FkSWRzLnB1c2gocGF5bG9hZElEKTtcbiAgfSk7XG4gIGJhdHRlcmllc1NlZWQodXNlcklkKS5mb3JFYWNoKChiYXR0ZXJ5KSA9PiB7XG4gICAgQmF0dGVyaWVzLmluc2VydChiYXR0ZXJ5KTtcbiAgfSk7XG4gIHJldHVybiB1c2VyUlBBU1BheWxvYWRzO1xufTtcblxuc2VlZGVyKE1ldGVvci51c2Vycywge1xuICBlbnZpcm9ubWVudHM6IFsnZGV2ZWxvcG1lbnQnLCAnc3RhZ2luZyddLFxuICBub0xpbWl0OiB0cnVlLFxuICBkYXRhOiBbe1xuICAgIGVtYWlsOiAnYWRtaW5AYWRtaW4uY29tJyxcbiAgICBwYXNzd29yZDogJ3Bhc3N3b3JkJyxcbiAgICBwcm9maWxlOiB7XG4gICAgICBuYW1lOiB7XG4gICAgICAgIGZpcnN0OiAnQWRtaW4nLFxuICAgICAgICBsYXN0OiAnVXNlcicsXG4gICAgICB9LFxuICAgIH0sXG4gICAgcm9sZXM6IFsnYWRtaW4nXSxcbiAgICBkYXRhKHVzZXJJZCkge1xuICAgICAgY29uc3QgdXNlckl0ZW1JRFMgPSBpbnNlcnRPdGhlckRhdGEodXNlcklkKTtcbiAgICAgIHJldHVybiBwcm9qZWN0c1NlZWQodXNlcklkLCB1c2VySXRlbUlEUyk7XG4gICAgfSxcbiAgfV0sXG4gIG1vZGVsQ291bnQ6IDUsXG4gIG1vZGVsKGluZGV4LCBmYWtlcikge1xuICAgIGNvbnN0IHVzZXJDb3VudCA9IGluZGV4ICsgMTtcbiAgICByZXR1cm4ge1xuICAgICAgZW1haWw6IGB1c2VyKyR7dXNlckNvdW50fUB0ZXN0LmNvbWAsXG4gICAgICBwYXNzd29yZDogJ3Bhc3N3b3JkJyxcbiAgICAgIHByb2ZpbGU6IHtcbiAgICAgICAgbmFtZToge1xuICAgICAgICAgIGZpcnN0OiBmYWtlci5uYW1lLmZpcnN0TmFtZSgpLFxuICAgICAgICAgIGxhc3Q6IGZha2VyLm5hbWUubGFzdE5hbWUoKSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICByb2xlczogWydmcmVlLXVzZXInXSxcbiAgICAgIGRhdGEodXNlcklkKSB7XG4gICAgICAgIGNvbnN0IHVzZXJJdGVtSURTID0gaW5zZXJ0T3RoZXJEYXRhKHVzZXJJZCk7XG4gICAgICAgIHJldHVybiBwcm9qZWN0c1NlZWQodXNlcklkLCB1c2VySXRlbUlEUyk7XG4gICAgICB9LFxuICAgIH07XG4gIH0sXG59KTtcblxuaWYgKCFNZXRlb3IuaXNQcm9kdWN0aW9uKSB7XG4gIGNvbnN0IHVzZXJFeGlzdHMgPSBNZXRlb3IudXNlcnMuZmluZE9uZSh7ICdlbWFpbHMuMC5hZGRyZXNzJzogJ2FkbWluQGFkbWluLmNvbScgfSk7XG5cbiAgaWYgKCF1c2VyRXhpc3RzLmVtYWlsc1swXS52ZXJpZmllZCkge1xuICAgIE1ldGVvci51c2Vycy51cGRhdGUoXG4gICAgICB7IF9pZDogdXNlckV4aXN0cy5faWQgfSxcbiAgICAgIHsgJHNldDogeyAnZW1haWxzLjAudmVyaWZpZWQnOiB0cnVlIH0gfSxcbiAgICApO1xuICB9XG59XG4iLCJcbmltcG9ydCAnLi9hY2NvdW50cyc7XG5pbXBvcnQgJy4vYXBpJztcbmltcG9ydCAnLi9maXh0dXJlcyc7XG5pbXBvcnQgJy4vZW1haWwnO1xuIiwiXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qIEZpbGUgU3lzdGVtIGJhc2ljIGZ1bmN0aW9uIGZvciBub2RlanMgICAgICAgICAgICBDb21waWxhdGlvbiBtYWRlIGJ5IEx1aXMgSXpxdWllcmRvIE1lc2EgKi9cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5cbmNvbnN0IGZzID0gcmVxdWlyZSgnZnMnKTtcbi8vIGxldCB6aXBGb2xkZXIgPSByZXF1aXJlKCd6aXAtZm9sZGVyJyk7XG5jb25zdCB7IHNwYXduIH0gPSByZXF1aXJlKCdjaGlsZF9wcm9jZXNzJyk7XG5jb25zdCBwYXRoID0gcmVxdWlyZSgncGF0aCcpO1xuXG4vLyBsZXQgRnV0dXJlID0gTnBtLnJlcXVpcmUoICdmaWJlcnMvZnV0dXJlJyApO1xuXG4vKipcbiAqIEJ1aWxkcyBhIGNvbXBsZXRlIHBhdGggdGFraW5nIGNhcmUgYWJvdXQgdGhlIGxhc3QgY2hhcmFjdGVyIG9mXG4gKiB0aGUgQHBhcmFtIGRpci4gSWYgdGhpcyBkb2VzIG5vdCBoYXZlIGEgc2xhc2ggdGhlIGZ1bmN0aW9uIHdpbGwgYWRkIG9uZVxuICogQHBhcmFtIHtzdHJpbmd9IGRpciAtIGRpcmVjdG9yeSB3aXRoIG9yIHdpdGhvdXQgbGFzdCBzbGFzaFxuICogQHBhcmFtIHtzdHJpbmd9IGZpbGVOYW1lIC0gZmlsZW5hbWVcbiAqIEByZXR1cm5zIHtzdHJpbmd9XG4gKi9cblxuY29uc3QgYnVpbGRDb21wbGV0ZVBhdGggPSAoZGlyLCBmaWxlTmFtZSkgPT4ge1xuICBjb25zdCBsYXN0Q2hhciA9IGRpci5zdWJzdHIoZGlyLmxlbmd0aCAtIDEpO1xuICBsZXQgc2xhc2ggPSAnJztcbiAgaWYgKGxhc3RDaGFyICE9PSAnLycpIHNsYXNoID0gJy8nO1xuICByZXR1cm4gZGlyICsgc2xhc2ggKyBmaWxlTmFtZTtcbn07XG5cbi8qKlxuICogRGVsZXRlIGZpbGVzIGFuZCBkaXJlY3RvcmllcyBpbiBhIGZvbGRlci4gVGhpcyBtZXRob2QgaXMgc3luY3Jvbm91c1xuICogQHBhcmFtIHtzdHJpbmd9IHBhdGhcbiAqIEBwYXJhbSB7aW50fSBuaXZlbCBkZSByZWN1cnNpdmlkYWQgLSBTaWVtcHJlIGhheSBxdWUgbWV0ZXIgMC5cbiBFcyBsYSBtYW5lcmEgcXVlIHRpZW5lIGxhIGZ1bmNpw7NuIHJlY3Vyc2l2YSBkZSBkZXRlY3RhciBsYSBwcmltZXJhXG4gIGl0ZXJhY2nDs24geSBhc8OtIG5vIGJvcnJhciBlbCBkaXJlY3RvcmlvIGluaWNpYWwuXG4gKi9cbmxldCBkZWxldGVkRmlsZXMgPSAwO1xuY29uc3QgbnVtYmVyT2ZGb2xkZXJzID0gMDtcbmNvbnN0IGRlbGV0ZUZvbGRlclJlY3Vyc2l2ZVN5bmMgPSAocGF0aERpciwgcm9vdCkgPT4ge1xuICBsZXQgZmlsZXMgPSBbXTtcbiAgaWYgKGZzLmV4aXN0c1N5bmMocGF0aERpcikpIHtcbiAgICBmaWxlcyA9IGZzLnJlYWRkaXJTeW5jKHBhdGhEaXIpO1xuICAgIGZpbGVzLmZvckVhY2goKGZpbGUpID0+IHtcbiAgICAgIGNvbnN0IGN1clBhdGggPSBidWlsZENvbXBsZXRlUGF0aChwYXRoRGlyLCBmaWxlKTtcbiAgICAgIGlmIChmcy5sc3RhdFN5bmMoY3VyUGF0aCkuaXNEaXJlY3RvcnkoKSkgeyAvLyByZWN1cnNlXG4gICAgICAgIGRlbGV0ZUZvbGRlclJlY3Vyc2l2ZVN5bmMoY3VyUGF0aCwgZmFsc2UpO1xuICAgICAgfSBlbHNlIHsgLy8gZGVsZXRlIGZpbGVcbiAgICAgICAgZGVsZXRlZEZpbGVzICs9IDE7XG4gICAgICAgIGZzLnVubGlua1N5bmMoY3VyUGF0aCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgaWYgKCFyb290KSB7XG4gICAgZnMucm1kaXJTeW5jKHBhdGhEaXIpO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiB7IGRlbGV0ZWRGaWxlcywgZm9sZGVyczogbnVtYmVyT2ZGb2xkZXJzIH07XG4gIH1cbn07XG5cblxuLyoqXG4gKiBHZXQgYWxsIHRoZSBmaWxlcyBmcm9tIGEgZGlyZWN0b3J5XG4gKiBAcGFyYW0ge3N0cmluZ30gcGF0aFxuICogQHJldHVybnMge1tdfSAtIGFycmF5IG9mIGZpbGVzXG4gKi9cbmNvbnN0IGdldEZpbGVMaXN0ID0gKHBhdGhEaXIsIGNhbGxiYWNrKSA9PiB7XG4gIGNvbnN0IGZpbGVzQXJyID0gW107XG4gIC8vIGxldCBmdXR1cmUgPSBuZXcgRnV0dXJlKCk7XG4gIGZzLnJlYWRkaXIocGF0aERpciwgKGVyciwgZmlsZXMpID0+IHtcbiAgICBmaWxlcy5mb3JFYWNoKChmaWxlKSA9PiB7XG4gICAgICBmaWxlc0Fyci5wdXNoKGZpbGUpO1xuICAgIH0pO1xuICAgIGNhbGxiYWNrKGZpbGVzQXJyKTtcbiAgICAvLyBmdXR1cmUucmV0dXJuKHtmaWxlczpmaWxlc0Fycn0pXG4gIH0pO1xuICAvLyByZXR1cm4gZnV0dXJlLndhaXQoKTtcbn07XG5cbi8qKlxuICogR2V0IGZpbGVzIGluIGEgZGlyZWN0b3J5IGJ5IGFuIGV4dGVuc2lvblxuICogQHBhcmFtIHtzdHJpbmcgfSBkaXJcbiAqIEBwYXJhbSB7c3RyaW5nfSBleHRlbnNpb24gLSBjYW4gYmUgdXBwZXItY2FzZSBvciBsb3dlci1jYXNlLCB0aGlzIGZ1bmN0aW9uIGlzIGNhc2UgaW5zZW5zaXRpdmVcbiAqIEBwYXJhbSB7ZnVuY3Rpb259IGNhbGxiYWNrIC0gY2FsbGJhY2sgd2l0aCBvbmUgYXJndW1lbnQgdGhhdCByZXR1cm5zXG4gICAgYW5kIGFycmF5IG9mIGZpbGVzIGZpbGVyZWQgYnkgaXRzIGV4dGVuc2lvblxuICovXG5jb25zdCBnZXRGaWxlc0luRGlyQnlFeHRlbnNpb24gPSAoZGlyLCBleHRlbnNpb24sIGNhbGxiYWNrKSA9PiB7XG4gIGNvbnN0IGZpbGVzQXJyID0gW107XG4gIGNvbnN0IHJlID0gbmV3IFJlZ0V4cChleHRlbnNpb24sICdpJyk7XG4gIGNvbnN0IGV4dGVuc2lvbkxlbmdodCA9IGV4dGVuc2lvbi5sZW5ndGg7XG4gIGZzLnJlYWRkaXIoZGlyLCAoZXJyLCBmaWxlcykgPT4ge1xuICAgIGZpbGVzXG4gICAgICAuZmlsdGVyKGZpbGUgPT4gZmlsZS5zdWJzdHIoLWV4dGVuc2lvbkxlbmdodCkubWF0Y2gocmUpKVxuICAgICAgLmZvckVhY2goKGZpbGUpID0+IHtcbiAgICAgICAgZmlsZXNBcnIucHVzaChmaWxlKTtcbiAgICAgIH0pO1xuICAgIGNhbGxiYWNrKGZpbGVzQXJyKTtcbiAgfSk7XG59O1xuXG4vKipcbiAqIEdldCBmaWxlcyBpbiBhIGRpcmVjdG9yeSBieSBhIHByZWZpeFxuICogQHBhcmFtIHtzdHJpbmcgfWRpclxuICogQHBhcmFtIHtzdHJpbmd9IHByZWZpeCAtIGNhbiBiZSB1cHBlci1jYXNlIG9yIGxvd2VyLWNhc2UsIHRoaXMgZnVuY3Rpb24gaXMgY2FzZSBpbnNlbnNpdGl2ZVxuICogQHBhcmFtIHtmdW5jdGlvbn0gY2FsbGJhY2sgLSBjYWxsYmFjayB3aXRoIG9uZSBhcmd1bWVudCB0aGF0XG4gICByZXR1cm5zIGFuZCBhcnJheSBvZiBmaWxlcyBmaWxlcmVkIGJ5IGl0cyBleHRlbnNpb25cbiAqL1xuY29uc3QgZ2V0RmlsZXNJbkRpckJ5UHJlZml4ID0gKGRpciwgcHJlZml4LCBjYWxsYmFjaykgPT4ge1xuICBjb25zdCBmaWxlc0FyciA9IFtdO1xuICBjb25zdCByZSA9IG5ldyBSZWdFeHAocHJlZml4LCAnaScpO1xuICBjb25zdCBwcmVmaXhMZW5naHQgPSBwcmVmaXgubGVuZ3RoO1xuICBmcy5yZWFkZGlyKGRpciwgKGVyciwgZmlsZXMpID0+IHtcbiAgICBmaWxlc1xuICAgICAgLmZpbHRlcihmaWxlID0+IGZpbGUuc3Vic3RyKDAsIHByZWZpeExlbmdodCkubWF0Y2gocmUpKVxuICAgICAgLmZvckVhY2goKGZpbGUpID0+IHtcbiAgICAgICAgZmlsZXNBcnIucHVzaChmaWxlKTtcbiAgICAgIH0pO1xuICAgIGNhbGxiYWNrKGZpbGVzQXJyKTtcbiAgfSk7XG59O1xuXG4vKipcbiAqIERlbGV0ZSBhIGZpbGUgaW4gYSBnaXZlbiBkaXJlY3RvcnlcbiAqIEBwYXJhbSB7c3RyaW5nfSBkaXIgLSBkaXJlY3RvcnlcbiAqIEBwYXJhbSB7c3RyaW5nfSBmaWxlTmFtZVxuICogQHJldHVybnMgeyp9IC0gYSBqc29uIG9iamVjdCB3aXRoIHRocmVlIHBhcmFtZXRlcnM7IHJlc3VsdCAoJ2Vycm9yJyBvciAnb2snKSwgZGlyIGFuZCBmaWxlbmFtZVxuICovXG5jb25zdCBkZWxldGVGaWxlID0gKGRpciwgZmlsZU5hbWUsIGNhbGxiYWNrKSA9PiB7XG4gIGNvbnN0IGNvbXBsZXRlUGF0aCA9IGJ1aWxkQ29tcGxldGVQYXRoKGRpciwgZmlsZU5hbWUpO1xuICAvLyBsZXQgZnV0dXJlID0gbmV3IEZ1dHVyZSgpO1xuICBmcy51bmxpbmsoY29tcGxldGVQYXRoLCAoZXJyKSA9PiB7XG4gICAgaWYgKGVycikge1xuICAgICAgY2FsbGJhY2soeyByZXN1bHQ6ICdlcnJvcicsIGRpciwgZmlsZU5hbWUgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNhbGxiYWNrKHsgcmVzdWx0OiAnb2snLCBkaXIsIGZpbGVOYW1lIH0pO1xuICAgIH1cbiAgfSk7XG4gIC8vIHJldHVybiBmdXR1cmUud2FpdCgpO1xufTtcblxuLyoqXG4gKiBNZXRob2QgdGhhdCBzYXZlIGEgZmlsZSBmcm9tIGEgYnVmZmVyLiBUaGlzXG4gbWV0aG9kIGlzIHVzZWQgZm9yIGEgbWV0ZW9yLmNhbGwsIHNhdmluZyBhIGZpbGUgZnJvbSBjbGllbnQuXG4gKiBUaGlzIG1ldGhvZCB1c2UgRnV0dXJlLCBzbyBpdCBkb2VzIG5vdCByZXR1cm4gYW55dGhpbmcgdW50aWwgaXQgZmluaXNoXG4gKiBAcGFyYW0ge2JpbmFyeX0gYnVmZmVyIC0gYmluYXJ5IGNvbnRlbnQgb2YgdGhlIGZpbGVcbiAqIEBwYXJhbSB7c3RyaW5nfSBkaXIgLSBkaXJlY3Rvcnkgd2hlcmUgd2Ugd2FudCB0byBzdG9yZSB0aGUgZmlsZVxuICogQHBhcmFtIHtzdHJpbmd9IGZpbGVOYW1lIC0gbmFtZSBvZiB0aGUgZmlsZVxuICogQHJldHVybnMgeyp9IC0gYSBqc29uIG9iamVjdCB3aXRoIHRocmVlIHBhcmFtZXRlcnM7IHJlc3VsdCAoJ2Vycm9yJyBvciAnb2snKSwgZGlyIGFuZCBmaWxlbmFtZVxuICovXG5jb25zdCBzYXZlRmlsZUZyb21idWZmZXIgPSAoYnVmZmVyLCBkaXIsIGZpbGVOYW1lLCBjYWxsYmFjaykgPT4ge1xuICBjb25zdCBmdWxsRmlsZU5hbWUgPSBkaXIgKyBmaWxlTmFtZTtcbiAgLy8gbGV0IGZ1dHVyZSA9IG5ldyBGdXR1cmUoKTtcbiAgZnMuc3RhdChkaXIsIChlcnJvciwgc3RhdHMpID0+IHtcbiAgICBpZiAoZXJyb3IpIHtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBjYWxsYmFjayh7IHJlc3VsdDogJ2Vycm9yJywgZGlyLCBmaWxlTmFtZSB9KTtcbiAgICAgICAgLy8gZnV0dXJlLnJldHVybih7cmVzdWx0OidlcnJvcicsZGlyOmRpcixmaWxlTmFtZTpmaWxlTmFtZX0pO1xuICAgICAgfSwgMTAwMCk7XG4gICAgICAvLyByZXR1cm4gbWV0ZW9yRXJyb3I7XG4gICAgfSBlbHNlIGlmIChzdGF0cy5pc0RpcmVjdG9yeSgpKSB7XG4gICAgICBmcy53cml0ZUZpbGUoZnVsbEZpbGVOYW1lLCBuZXcgQnVmZmVyKGJ1ZmZlciksICdiaW5hcnknLCAoZXJyb3IyKSA9PiB7XG4gICAgICAgIGlmIChlcnJvcjIpIHtcbiAgICAgICAgICBjYWxsYmFjayh7IHJlc3VsdDogJ2Vycm9yJywgZGlyLCBmaWxlTmFtZSB9KTtcbiAgICAgICAgICAvLyBmdXR1cmUucmV0dXJuKHtyZXN1bHQ6J2Vycm9yJyxkaXI6ZGlyLGZpbGVOYW1lOmZpbGVOYW1lfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY2FsbGJhY2soeyByZXN1bHQ6ICdvaycsIGRpciwgZmlsZU5hbWUgfSk7XG4gICAgICAgICAgLy8gZnV0dXJlLnJldHVybih7cmVzdWx0OidvaycsZGlyOmRpcixmaWxlTmFtZTpmaWxlTmFtZX0pO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gZnV0dXJlLnJldHVybih7cmVzdWx0OidlcnJvcid9KTtcbiAgICAgIGNhbGxiYWNrKHsgcmVzdWx0OiAnZXJyb3InIH0pO1xuICAgIH1cbiAgfSk7XG4gIC8vIHJldHVybiBmdXR1cmUud2FpdCgpO1xufTtcblxuLyoqXG4gKiBjcmVhdGUgYSBkaXJlY3Rvcnkgd2l0aCBhIHBlcm1pc3Npb24gdHlwZSA3NzdcbiAqIEBwYXJhbSB7c3RyaW5nfSBwYXRoXG4gKi9cbmNvbnN0IGNyZWF0ZURpcmVjdG9yeSA9IChwYXRoRGlyLCBjYWxsYmFjaykgPT4ge1xuICAvLyBwYXRoID0gbWlzc2lvbkRpcmVjdG9yeSArIHBhdGg7XG4gIGNvbnNvbGUubG9nKGBkaXIgY3JlYXRlZCBhdCAke3BhdGhEaXJ9YCk7XG4gIGZzLmV4aXN0cyhwYXRoRGlyLCAoZXhpc3RzKSA9PiB7XG4gICAgY29uc29sZS5sb2coYGJvb2wgdmFsICR7ZXhpc3RzfWApO1xuICAgIGlmICghZXhpc3RzKSB7XG4gICAgICBmcy5ta2RpcihwYXRoRGlyLCAnMDc3NycsICgpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coYGRpciBjcmVhdGVkIGF0ICR7cGF0aERpcn1gKTtcbiAgICAgICAgY2FsbGJhY2sodHJ1ZSk7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY2FsbGJhY2soZmFsc2UpO1xuICAgIH1cbiAgfSk7XG59O1xuXG4vKipcbiAqIFppcCBhIGNvbXBsZXRlIGZvbGRlclxuICogQHBhcmFtIHtzdHJpbmd9IGZvbGRlclBhdGhcbiAqIEBwYXJhbSB7c3RyaW5nfSB6aXBQYXRoXG4gKiBAcGFyYW0ge2Z1bmN0aW9ufSBjYWxsYmFjayAtIHBhc3NpbmcgYSBib29sIGFyZ3VtZW50XG4gKHRydWUgaWYgZXZlcnl0aGluZyBpcyBvaywgZmFsc2UgaWYgYW4gZXJyb3IgaGFwcGVucylcbiAqL1xuY29uc3QgemlwQUNvbXBsZXRlRm9sZGVyID0gKGZvbGRlclBhdGgsIHppcFBhdGgsIGNhbGxiYWNrKSA9PiB7XG4gIHppcEZvbGRlcihmb2xkZXJQYXRoLCB6aXBQYXRoLCAoZXJyKSA9PiB7XG4gICAgaWYgKGVycikge1xuICAgICAgY2FsbGJhY2soZmFsc2UpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjYWxsYmFjayh0cnVlKTtcbiAgICB9XG4gIH0pO1xufTtcblxuY29uc3QgZ2V0RmlsZVNpemUgPSAoZmlsZW5hbWUpID0+IHtcbiAgY29uc3Qgc3RhdHMgPSBmcy5zdGF0U3luYyhmaWxlbmFtZSk7XG4gIGNvbnN0IGZpbGVTaXplSW5CeXRlcyA9IHN0YXRzLnNpemU7XG4gIHJldHVybiBmaWxlU2l6ZUluQnl0ZXM7XG59O1xuXG5jb25zdCBnZXRGb2xkZXJTaXplID0gKGZvbGRlciwgY2FsbGJhY2spID0+IHtcbiAgbGV0IGZvbGRlclNpemUgPSAwO1xuICBmcy5yZWFkZGlyKGZvbGRlciwgKGVyciwgZmlsZXMpID0+IHtcbiAgICBmaWxlcy5mb3JFYWNoKChmaWxlKSA9PiB7XG4gICAgICBmb2xkZXJTaXplICs9IGdldEZpbGVTaXplKHBhdGguam9pbihmb2xkZXIsIGZpbGUpKTtcbiAgICB9KTtcbiAgICBjYWxsYmFjayhmb2xkZXJTaXplKTtcbiAgfSk7XG59O1xuXG5jb25zdCBnZXRGb2xkZXJTaXplX29sZCA9IChwYXRoRGlyLCBjYWxsYmFjaykgPT4ge1xuICBjb25zdCBzaXplID0gc3Bhd24oJ2R1JywgWyctc2gnLCBwYXRoRGlyXSk7XG4gIGNvbnN0IHJlc3VsdCA9IHt9O1xuICBsZXQgdG90YWxTaXplID0gMDtcblxuICBzaXplLnN0ZG91dC5vbignZGF0YScsIChkYXRhKSA9PiB7XG4gICAgcmVzdWx0LmRhdGEgPSBkYXRhO1xuXG4gICAgZGF0YS5mb3JFYWNoKChpdGVtKSA9PiB7XG4gICAgICB0b3RhbFNpemUgKz0gaXRlbTtcbiAgICB9KTtcbiAgICBjYWxsYmFjayh0b3RhbFNpemUpO1xuICB9KTtcbiAgc2l6ZS5zdGRlcnIub24oJ2RhdGEnLCAoZGF0YSkgPT4ge1xuICAgIHJlc3VsdC5lcnJvciA9IGRhdGE7XG4gICAgY2FsbGJhY2socmVzdWx0KTtcbiAgfSk7XG59O1xuXG5leHBvcnQge1xuICBkZWxldGVGb2xkZXJSZWN1cnNpdmVTeW5jLFxuICBidWlsZENvbXBsZXRlUGF0aCxcbiAgZ2V0RmlsZUxpc3QsXG4gIGdldEZpbGVzSW5EaXJCeUV4dGVuc2lvbixcbiAgZGVsZXRlRmlsZSxcbiAgc2F2ZUZpbGVGcm9tYnVmZmVyLFxuICBjcmVhdGVEaXJlY3RvcnksXG4gIC8vIHppcEFDb21wbGV0ZUZvbGRlcixcbiAgZ2V0Rm9sZGVyU2l6ZSxcbiAgZ2V0RmlsZVNpemUsXG59O1xuIiwiaW1wb3J0IGZzIGZyb20gJ2ZzJztcblxuZXhwb3J0IGRlZmF1bHQgcGF0aCA9PiBmcy5yZWFkRmlsZVN5bmMoYGFzc2V0cy9hcHAvJHtwYXRofWAsICd1dGY4Jyk7XG4iLCJpbXBvcnQgaGFuZGxlYmFycyBmcm9tICdoYW5kbGViYXJzJztcbmltcG9ydCBqdWljZSBmcm9tICdqdWljZSc7XG5cbmV4cG9ydCBkZWZhdWx0IChoYW5kbGViYXJzTWFya3VwLCBjb250ZXh0LCBvcHRpb25zKSA9PiB7XG4gIGlmIChoYW5kbGViYXJzTWFya3VwICYmIGNvbnRleHQpIHtcbiAgICBjb25zdCB0ZW1wbGF0ZSA9IGhhbmRsZWJhcnMuY29tcGlsZShoYW5kbGViYXJzTWFya3VwKTtcbiAgICByZXR1cm4gb3B0aW9ucyAmJiAhb3B0aW9ucy5pbmxpbmVDc3MgPyB0ZW1wbGF0ZShjb250ZXh0KSA6IGp1aWNlKHRlbXBsYXRlKGNvbnRleHQpKTtcbiAgICAvLyBVc2UganVpY2UgdG8gaW5saW5lIENTUyA8c3R5bGU+PC9zdHlsZT4gc3R5bGVzIGZyb20gPGhlYWQ+IHVubGVzcyBkaXNhYmxlZC5cbiAgfVxuXG4gIHRocm93IG5ldyBFcnJvcignUGxlYXNlIHBhc3MgSGFuZGxlYmFycyBtYXJrdXAgdG8gY29tcGlsZSBhbmQgYSBjb250ZXh0IG9iamVjdCB3aXRoIGRhdGEgbWFwcGluZyB0byB0aGUgSGFuZGxlYmFycyBleHByZXNzaW9ucyB1c2VkIGluIHlvdXIgdGVtcGxhdGUuJyk7XG59O1xuIiwiaW1wb3J0IGhhbmRsZWJhcnMgZnJvbSAnaGFuZGxlYmFycyc7XG5cbmV4cG9ydCBkZWZhdWx0IChoYW5kbGViYXJzTWFya3VwLCBjb250ZXh0KSA9PiB7XG4gIGlmIChoYW5kbGViYXJzTWFya3VwICYmIGNvbnRleHQpIHtcbiAgICBjb25zdCB0ZW1wbGF0ZSA9IGhhbmRsZWJhcnMuY29tcGlsZShoYW5kbGViYXJzTWFya3VwKTtcbiAgICByZXR1cm4gdGVtcGxhdGUoY29udGV4dCk7XG4gIH1cblxuICB0aHJvdyBuZXcgRXJyb3IoJ1BsZWFzZSBwYXNzIEhhbmRsZWJhcnMgbWFya3VwIHRvIGNvbXBpbGUgYW5kIGEgY29udGV4dCBvYmplY3Qgd2l0aCBkYXRhIG1hcHBpbmcgdG8gdGhlIEhhbmRsZWJhcnMgZXhwcmVzc2lvbnMgdXNlZCBpbiB5b3VyIHRlbXBsYXRlLicpO1xufTtcbiIsImltcG9ydCB7IEVtYWlsIH0gZnJvbSAnbWV0ZW9yL2VtYWlsJztcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IGdldFByaXZhdGVGaWxlIGZyb20gJy4vZ2V0LXByaXZhdGUtZmlsZSc7XG5pbXBvcnQgdGVtcGxhdGVUb1RleHQgZnJvbSAnLi9oYW5kbGViYXJzLWVtYWlsLXRvLXRleHQnO1xuaW1wb3J0IHRlbXBsYXRlVG9IVE1MIGZyb20gJy4vaGFuZGxlYmFycy1lbWFpbC10by1odG1sJztcblxuY29uc3Qgc2VuZEVtYWlsID0gKG9wdGlvbnMsIHsgcmVzb2x2ZSwgcmVqZWN0IH0pID0+IHtcbiAgdHJ5IHtcbiAgICBNZXRlb3IuZGVmZXIoKCkgPT4ge1xuICAgICAgRW1haWwuc2VuZChvcHRpb25zKTtcbiAgICAgIHJlc29sdmUoKTtcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgcmVqZWN0KGV4Y2VwdGlvbik7XG4gIH1cbn07XG5cbmV4cG9ydCBkZWZhdWx0ICh7XG4gIHRleHQsIGh0bWwsIHRlbXBsYXRlLCB0ZW1wbGF0ZVZhcnMsIC4uLnJlc3Rcbn0pID0+IHtcbiAgaWYgKHRleHQgfHwgaHRtbCB8fCB0ZW1wbGF0ZSkge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBzZW5kRW1haWwoe1xuICAgICAgICAuLi5yZXN0LFxuICAgICAgICB0ZXh0OiB0ZW1wbGF0ZSA/IHRlbXBsYXRlVG9UZXh0KGdldFByaXZhdGVGaWxlKGBlbWFpbC10ZW1wbGF0ZXMvJHt0ZW1wbGF0ZX0udHh0YCksICh0ZW1wbGF0ZVZhcnMgfHwge30pKSA6IHRleHQsXG4gICAgICAgIGh0bWw6IHRlbXBsYXRlID8gdGVtcGxhdGVUb0hUTUwoZ2V0UHJpdmF0ZUZpbGUoYGVtYWlsLXRlbXBsYXRlcy8ke3RlbXBsYXRlfS5odG1sYCksICh0ZW1wbGF0ZVZhcnMgfHwge30pKSA6IGh0bWwsXG4gICAgICB9LCB7IHJlc29sdmUsIHJlamVjdCB9KTtcbiAgICB9KTtcbiAgfVxuICB0aHJvdyBuZXcgRXJyb3IoJ1BsZWFzZSBwYXNzIGFuIEhUTUwgc3RyaW5nLCB0ZXh0LCBvciB0ZW1wbGF0ZSBuYW1lIHRvIGNvbXBpbGUgZm9yIHlvdXIgbWVzc2FnZVxcJ3MgYm9keS4nKTtcbn07XG4iLCJjb25zdCBwYXJzZUdvb2dsZURhdGEgPSBzZXJ2aWNlID0+ICh7XG4gIGVtYWlsOiBzZXJ2aWNlLmVtYWlsLFxuICBuYW1lOiB7XG4gICAgZmlyc3Q6IHNlcnZpY2UuZ2l2ZW5fbmFtZSxcbiAgICBsYXN0OiBzZXJ2aWNlLmZhbWlseV9uYW1lLFxuICB9LFxufSk7XG5cbmNvbnN0IHBhcnNlRmFjZWJvb2tEYXRhID0gc2VydmljZSA9PiAoe1xuICBlbWFpbDogc2VydmljZS5lbWFpbCxcbiAgbmFtZToge1xuICAgIGZpcnN0OiBzZXJ2aWNlLmZpcnN0X25hbWUsXG4gICAgbGFzdDogc2VydmljZS5sYXN0X25hbWUsXG4gIH0sXG59KTtcblxuY29uc3QgZ2V0RGF0YUZvclNlcnZpY2UgPSAocHJvZmlsZSwgc2VydmljZXMpID0+IHtcbiAgaWYgKHNlcnZpY2VzLmZhY2Vib29rKSByZXR1cm4gcGFyc2VGYWNlYm9va0RhdGEoc2VydmljZXMuZmFjZWJvb2spO1xuICBpZiAoc2VydmljZXMuZ29vZ2xlKSByZXR1cm4gcGFyc2VHb29nbGVEYXRhKHNlcnZpY2VzLmdvb2dsZSk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCAob3B0aW9ucywgdXNlcikgPT4ge1xuICBjb25zdCBpc09BdXRoID0gIW9wdGlvbnMucGFzc3dvcmQ7XG4gIGNvbnN0IHNlcnZpY2VEYXRhID0gaXNPQXV0aCA/IGdldERhdGFGb3JTZXJ2aWNlKG9wdGlvbnMucHJvZmlsZSwgdXNlci5zZXJ2aWNlcykgOiBudWxsO1xuICByZXR1cm4gaXNPQXV0aCA/IHNlcnZpY2VEYXRhIDogbnVsbDtcbn07XG4iLCJpbXBvcnQgeyBQYXJzZXIsIEh0bWxSZW5kZXJlciB9IGZyb20gJ2NvbW1vbm1hcmsnO1xuXG5leHBvcnQgZGVmYXVsdCAobWFya2Rvd24sIG9wdGlvbnMpID0+IHtcbiAgY29uc3QgcmVhZGVyID0gbmV3IFBhcnNlcigpO1xuICBjb25zdCB3cml0ZXIgPSBvcHRpb25zID8gbmV3IEh0bWxSZW5kZXJlcihvcHRpb25zKSA6IG5ldyBIdG1sUmVuZGVyZXIoKTtcbiAgY29uc3QgcGFyc2VkID0gcmVhZGVyLnBhcnNlKG1hcmtkb3duKTtcbiAgcmV0dXJuIHdyaXRlci5yZW5kZXIocGFyc2VkKTtcbn07XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEREUFJhdGVMaW1pdGVyIH0gZnJvbSAnbWV0ZW9yL2RkcC1yYXRlLWxpbWl0ZXInO1xuXG5leHBvcnQgZGVmYXVsdCAoeyBtZXRob2RzLCBsaW1pdCwgdGltZVJhbmdlIH0pID0+IHtcbiAgaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAgIEREUFJhdGVMaW1pdGVyLmFkZFJ1bGUoe1xuICAgICAgbmFtZShuYW1lKSB7IHJldHVybiBtZXRob2RzLmluZGV4T2YobmFtZSkgPiAtMTsgfSxcbiAgICAgIGNvbm5lY3Rpb25JZCgpIHsgcmV0dXJuIHRydWU7IH0sXG4gICAgfSwgbGltaXQsIHRpbWVSYW5nZSk7XG4gIH1cbn07XG4iLCJpbXBvcnQgJy4uL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXInO1xuIl19
